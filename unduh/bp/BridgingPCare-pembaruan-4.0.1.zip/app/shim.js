// ===== Pengganti API "chrome.*" untuk file bot (ekstensi 1.9.9 → aplikasi) =====
// File bot (common.js, pcare.js, ccare.js, background.js, pengaturan.js) berjalan TANPA diubah:
// setiap panggilan chrome.storage / chrome.runtime / chrome.tabs diteruskan ke proses utama aplikasi.
"use strict";
const fs = require("fs");
const path = require("path");

module.exports = function buatChrome(ipc, { dirEks, peran }) {
  const manifest = JSON.parse(fs.readFileSync(path.join(dirEks, "manifest.json"), "utf8"));
  const pendengar = { berubah: [], pesan: [], pasang: [] };
  let lastError;

  // ---------- storage ----------
  const panggilCb = (p, cb) => { p.then((v) => { if (cb) cb(v); }); return p; };
  const local = {
    get: (k, cb) => panggilCb(ipc.invoke("st:get", k === undefined ? null : k), cb),
    set: (o, cb) => panggilCb(ipc.invoke("st:set", o).then(() => undefined), cb),
    remove: (k, cb) => panggilCb(ipc.invoke("st:remove", k).then(() => undefined), cb),
    clear: (cb) => panggilCb(ipc.invoke("st:clear").then(() => undefined), cb),
  };
  ipc.on("st:berubah", (_e, ch) => { for (const f of pendengar.berubah.slice()) { try { f(ch, "local"); } catch (e) { console.error(e); } } });

  // ---------- runtime ----------
  const sendMessage = (msg, cb) => {
    const p = ipc.invoke("rt:kirim", msg);
    p.then((r) => { if (cb) { lastError = undefined; cb(r); } }).catch(() => {});
    return p;
  };
  const sendNativeMessage = (_host, msg, cb) => {
    const p = ipc.invoke("host", msg);
    p.then((r) => { if (cb) { lastError = undefined; cb(r); } });
    return p;
  };
  if (peran === "latar") {
    ipc.on("rt:pesan", (_e, { id, msg, sender }) => {
      let dijawab = false, tunda = false;
      const sendResponse = (r) => { if (dijawab) return; dijawab = true; ipc.send("rt:balas", { id, jawab: r }); };
      for (const f of pendengar.pesan.slice()) {
        try { if (f(msg, sender, sendResponse) === true) tunda = true; } catch (e) { console.error(e); }
      }
      if (!dijawab && !tunda) sendResponse(undefined);
    });
    ipc.on("rt:pasang", (_e, d) => { for (const f of pendengar.pasang) { try { f(d); } catch (e) {} } });
  }
  const getURL = (p) => {
    const f = path.join(dirEks, p);
    if (/\.png$/i.test(p)) { try { return "data:image/png;base64," + fs.readFileSync(f).toString("base64"); } catch (e) { return ""; } }
    return "file:///" + f.replace(/\\/g, "/");
  };

  // ---------- tabs (jendela C-CARE tersembunyi milik aplikasi) ----------
  const tab = (op, ...a) => ipc.invoke("tabs", op, ...a);

  return {
    storage: { local, onChanged: { addListener: (f) => pendengar.berubah.push(f), removeListener: (f) => { const i = pendengar.berubah.indexOf(f); if (i >= 0) pendengar.berubah.splice(i, 1); } } },
    runtime: {
      id: "bridging-pcare",
      get lastError() { return lastError; },
      getManifest: () => manifest,
      getURL,
      sendMessage,
      sendNativeMessage,
      onMessage: { addListener: (f) => pendengar.pesan.push(f) },
      onInstalled: { addListener: (f) => pendengar.pasang.push(f) },
      openOptionsPage: () => ipc.invoke("bukaPengaturan"),
      reload: () => ipc.invoke("muatUlangAplikasi"),
    },
    tabs: {
      create: (o) => tab("create", o),
      update: (id, o) => tab("update", id, o),
      remove: (id) => tab("remove", id),
      get: (id) => tab("get", id),
      query: (q) => tab("query", q),
      reload: (id) => tab("reload", id),
      // tabs.group tidak ada: jendela pembaca C-CARE sudah tersembunyi
    },
    notifications: { create: (_id, o) => ipc.invoke("notif", { judul: o && o.title, isi: o && o.message }) },
  };
};
