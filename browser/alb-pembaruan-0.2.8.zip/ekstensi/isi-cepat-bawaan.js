/* Auto Fill C-CARE — isian bawaan yang bisa diubah di Pengaturan → tab Auto Fill.
 * Dipakai bersama oleh isi-cepat.js (halaman C-CARE) dan pengaturan.js. Tanpa data pasien. */
const ISIAN_AUTOFILL = {
  umum: [
    { k: 'KepalaMuka', l: 'Kepala Muka', v: 'Kepala : CA -/-, SI -/-\nMulut : dbn\nLeher : kgb ttb' },
    { k: 'Thorax', l: 'Thorax', v: 'Cor : S1-S2 reguler, murmur (-) gallop (-)\nPulmo : ves +/+ whz -/- ro -/-' },
    { k: 'Abdomen', l: 'Abdomen', v: 'Supel, BU (+)n, NT (-)' },
    { k: 'Extremitas', l: 'Extremitas', v: 'Akral hangat, nadi kuat, CRT < 2' },
    { k: 'Ekg', l: 'EKG', v: 'Tidak dilakukan pemeriksaan' },
    { k: 'Radiologi', l: 'Radiologi', v: 'Tidak dilakukan pemeriksaan', ket: 'Kotak ini hanya ada di CPPT Ruang Tindakan dan Prolanis.' },
    { k: 'TataLaksana', l: 'Tata Laksana', v: 'Edukasi terkait penyakit pasien, Pemberian medikamentosa' },
    { k: 'TataLaksanaRujukan', l: 'Tata Laksana bila rujukan', v: 'Edukasi terkait penyakit pasien, Rujukan ke poli Spesialis', ket: 'Dipakai bila anamnesa menyebut rujukan keluar (bukan rujuk balik/PRB).' },
    { k: 'Pengobatan', l: 'Pengobatan', v: 'Terlampir' },
    { k: 'TindakLanjutPengobatanId', l: 'Tindak Lanjut', v: '1', opsi: [['', 'Tidak diisi'], ['1', 'Pulang'], ['2', 'Pulang Paksa/APS'], ['3', 'Rawat'], ['4', 'Rujuk']] },
    { k: 'StatusKunjunganID', l: 'Status kunjungan', v: '4', opsi: [['', 'Tidak diubah'], ['4', 'Menunggu Obat'], ['5', 'Selesai']], ket: 'Hanya diubah bila status masih kosong / Menunggu Pemeriksaan Dokter.' },
    { k: 'statusIkutTL', l: 'Status ikut Tindak Lanjut', v: '1', opsi: [['1', 'Otomatis'], ['0', 'Mati']], ket: 'Pulang → Menunggu Obat. Rujuk → Selesai (Menunggu Obat bila ada obat) + Rujukan Eksternal, BPJS, keterangan di bawah.' },
    { k: 'KeteranganRujukan', l: 'Keterangan rujukan', v: 'Rujuk Ke Poli Spesialis', ket: 'Diisi ke Keterangan rujukan bila masih kosong.' },
    { k: 'icdOtomatis', l: 'ICD-10 dari anamnesa', v: '1', opsi: [['1', 'Isi otomatis (periksa)'], ['0', 'Mati']], ket: 'Hanya bila Diagnosa masih kosong. Baris "Riwayat …" tidak dibaca; kata yang disangkal (tidak/tdk/-) dilewati.' },
  ],
  sehat: [
    { k: 'AmnesaDokter', l: 'Anamnesa', v: 'Rencana pemeriksaan kesehatan untuk keperluan penerbitan surat sehat\nSaat ini tidak ada keluhan, tanda-tanda vital dan hemodinamik tampak stabil' },
    { k: 'IsButaWarna', l: 'Buta warna', v: 'false', opsi: [['', 'Tidak diisi'], ['false', 'Tidak'], ['true', 'Ya']] },
    { k: 'KodePenyakit', l: 'Diagnosa ICD-10', v: 'Z000 / General medical examination', ket: 'Tulis "KODE / nama" persis seperti di C-CARE, mis. Z000 / General medical examination.' },
    { k: 'TataLaksana', l: 'Tata Laksana', v: 'Setuju untuk pemberian surat sehat\nFit to work' },
    { k: 'StatusKunjunganID', l: 'Status kunjungan', v: '', opsi: [['', 'Tidak diubah'], ['4', 'Menunggu Obat'], ['5', 'Selesai']], ket: 'Hanya diubah bila status masih kosong / Menunggu Pemeriksaan Dokter.' },
    { k: 'statusIkutTL', l: 'Status ikut Tindak Lanjut', v: '1', opsi: [['1', 'Otomatis'], ['0', 'Mati']], ket: 'Pulang → Menunggu Obat. Rujuk → Selesai (Menunggu Obat bila ada obat) + Rujukan Eksternal, BPJS, keterangan di bawah.' },
    { k: 'KeteranganRujukan', l: 'Keterangan rujukan', v: 'Rujuk Ke Poli Spesialis', ket: 'Diisi ke Keterangan rujukan bila masih kosong.' },
  ],
};
/* MCU (/Poli/Mcu/…) — template pemeriksaan dari dr. Arijal (11 Nov 2026). Interpretasi, Saran, dan Kesan disusun
 * otomatis oleh mcu-saran.js dari data pasien; yang di sini hanya kerangka yang diisi ke kotak yang masih kosong. */
ISIAN_AUTOFILL.mcu = [
  { k: 'AmnesaDokter', l: 'Anamnesa (pembuka)', v: 'Pemeriksaan kesehatan berkala (medical check up)\nSaat ini tidak ada keluhan', ket: 'Bila perawat mengisi Keluhan Utama, baris kedua diganti keluhan itu. Riwayat alergi obat dari identitas ditambahkan bila ada.' },
  { k: 'KepalaMuka', l: 'Kepala Muka', v: 'Mata : CA -/-, SI -/-, pupil isokor 3 mm/3 mm\nMulut : faring normal, tonsil T1-T1' },
  { k: 'Thorax', l: 'Thorax', v: 'Pulmo : vesikuler +/+, rh -/-, wh -/-\nCor : BJ I-II reguler, murmur (-), gallop (-)' },
  { k: 'Abdomen', l: 'Abdomen', v: 'Soepel (+), BU (+), NTE (-), turgor baik' },
  { k: 'Extremitas', l: 'Ekstremitas', v: 'Akral hangat, CRT < 2 detik' },
  { k: 'Ekg', l: 'EKG', v: 'Irama sinus, aksis normal, gelombang P dan kompleks QRS normal, tidak tampak perubahan segmen ST dan gelombang T\nKesan EKG : normal', ket: 'Periksa dan sesuaikan dengan rekaman EKG. KESAN ditambahkan di bawahnya.' },
  { k: 'TataLaksana', l: 'Rekomendasi Dokter', v: 'TIDAK ADA OBAT\nEDUKASI POLA HIDUP BERSIH DAN SEHAT', ket: 'Pilihan template: TIDAK ADA OBAT · SURAT SEHAT · EDUKASI POLA HIDUP BERSIH DAN SEHAT · EDUKASI KEBERSIHAN MULUT · TERAPI LANJUT · OBAT ORAL.' },
  { k: 'KodePenyakit', l: 'Diagnosa ICD-10', v: 'Z000 / General medical examination', ket: 'Tulis "KODE / nama" persis seperti di C-CARE.' },
  { k: 'saranOtomatis', l: 'Interpretasi & Saran', v: '1', opsi: [['1', 'Otomatis saat hasil lab terbaca'], ['0', 'Hanya lewat tombol "Susun saran"']] },
  { k: 'batasKarakter', l: 'Batas panjang tiap kotak', v: '1700', ket: 'C-CARE gagal menyimpan (Error 500) bila isian terlalu panjang. 1.712 karakter terbukti tersimpan; isian otomatis diringkas agar muat, dan Simpan diberi peringatan bila ada kotak yang melebihi batas ini.' },
  { k: 'letakSaran', l: 'Letak Interpretasi, Kesan & Saran', v: 'rekomendasi', opsi: [['rekomendasi', 'Diagnosa (ringkas) + Rekomendasi Dokter'], ['template', 'Di bawah Anamnesa; Kesan di bawah EKG']], ket: 'Bawaan mengikuti isian MCU yang sudah ada di C-CARE: Diagnosa berisi daftar interpretasi + KESAN, Rekomendasi Dokter berisi interpretasi + KESAN + SARAN.' },
];
/* Formulir dari CPPT (Persetujuan Tindakan, Edukasi, Surgical Safety Checklist) — bukan poli, isian bawaannya sendiri */
const ISIAN_FORMULIR = [
  { k: 'tkTindakan', l: 'Nama dan tujuan tindakan', v: 'Pemberian tindakan/obat-obatan di IGD', ket: 'Juga dipakai di "Menyatakan SETUJU untuk dilakukan tindakan".' },
  { k: 'tkAlternatif', l: 'Alternatif tindakan', v: 'Konservatif' },
  { k: 'tkRisiko', l: 'Risiko dan komplikasi', v: 'Reaksi alergi atau infeksi' },
  { k: 'tkPrognosis', l: 'Prognosis', v: 'Dubia ad bonam' },
  { k: 'tkBiaya', l: 'Perkiraan biaya', v: 'Tidak ada' },
  { k: 'tkLain', l: 'Lain-lain', v: 'Tidak ada' },
  { k: 'eduProfesi', l: 'Profesi (edukasi)', v: '', ket: 'Kosong = jabatan akun C-CARE yang sedang dipakai (mis. Dokter).' },
  { k: 'eduKontrol', l: 'Kontrol hari ke- (edukasi)', v: '3', ket: 'Tanggal kontrol = hari ini + angka ini.' },
  { k: 'sscRencana', l: 'Rencana asuhan (Surgical Safety)', v: '' },
  { k: 'sscGcs', l: 'GCS sebelum tindakan', v: '4 5 6', ket: 'E V M; total dihitung otomatis. Kosongkan bila tidak ingin diisi.' },
];
/* Ruang Tindakan & Prolanis: susunan CPPT sama dengan Poli Umum, isian bawaannya masing-masing */
ISIAN_AUTOFILL.tindakan = ISIAN_AUTOFILL.umum.map(f => Object.assign({}, f));
ISIAN_AUTOFILL.prolanis = ISIAN_AUTOFILL.umum.map(f => Object.assign({}, f));
ISIAN_AUTOFILL.formulir = ISIAN_FORMULIR;
/* Kamus ICD-10: satu untuk semua poli (disimpan di isian.umum.kamusIcd seperti versi lama) */
const KAMUS_ICD = { k: 'kamusIcd', l: 'Kamus ICD-10', lebar: true, v: [
      'kontrol tensi, darah tinggi, tensi tinggi, hipertensi, ht => I10 / Essential (primary) hypertension',
      'kencing manis, gula darah tinggi, kontrol gula, diabetes, dm => E119 / Type 2 diabetes mellitus without complications',
      'demam berdarah, dbd, dengue => A90 / Dengue fever [classical dengue]',
      'tifoid, tipes, typhoid => A010 / Typhoid fever',
      'batuk pilek, ispa => J069 / Acute upper respiratory infection, unspecified',
      'pilek, flu, hidung tersumbat => J00 / Acute nasopharyngitis [common cold]',
      'nyeri telan, sakit tenggorokan, radang tenggorokan, faringitis => J029 / Acute pharyngitis, unspecified',
      'bronkitis => J209 / Acute bronchitis, unspecified',
      'asma, mengi => J459 / Asthma, unspecified',
      'diare, mencret, gea, gastroenteritis => A09 / Infectious gastroenteritis and colitis, unspecified',
      'gerd, refluks, asam lambung naik => K210 / Gastro-esophageal reflux disease with esophagitis',
      'gastritis => K297 / Gastritis, unspecified',
      'nyeri ulu hati, perih ulu hati, sakit maag, maag, dispepsia => K30 / Functional dyspepsia',
      'sembelit, konstipasi, susah bab => K590 / Constipation',
      'biduran, kaligata, urtikaria => L508 / Other urticaria',
      'dermatitis, eksim, eksem => L309 / Dermatitis, unspecified',
      'kurap, tinea => B354 / Tinea corporis',
      'skabies, kudis, gudik => B86 / Scabies',
      'impetigo => L01 / Impetigo',
      'mata merah, belekan, konjungtivitis => H10 / Conjunctivitis',
      'congek, sakit telinga, otitis => H669 / Otitis media, unspecified',
      'anyang-anyangan, nyeri bak, sakit bak, isk => N390 / Urinary tract infection, site not specified',
      'sakit pinggang, nyeri pinggang, nyeri punggung bawah, low back pain, lbp => M545 / Low back pain',
      'pegal, pegel, nyeri otot, myalgia, badan sakit => M791 / Myalgia',
      'sakit kepala, nyeri kepala, cekot => R51 / Headache',
      'pusing, pening, puyeng => R42 / Dizziness and giddiness',
      'mual, muntah => R11 / Nausea and vomiting',
      'batuk => R05 / Cough',
      'demam, panas, febris => R509 / Fever, unspecified',
      'gatal => L299 / Pruritus, unspecified',
    ].join('\n'), ket: 'Satu baris: kata kunci dipisah koma => KODE / nama (kode persis seperti di C-CARE, tanpa titik). Frasa yang lebih panjang menang ("batuk pilek" → J069, bukan R05 + J00). Kode gejala (R…, L299) dipakai hanya bila tidak ada diagnosis lain. Maks. 3 kode.' };
const JUDUL_PROFIL = { umum: 'Poli Umum', tindakan: 'Ruang Tindakan', prolanis: 'Prolanis', sehat: 'Kunjungan Sehat', formulir: 'Formulir' };
/** JenisPoliId C-CARE → profil isian (poli lain: Auto Fill belum tersedia) */
const POLI_PROFIL = { 1: 'umum', 5: 'tindakan', 8: 'prolanis', 4: 'sehat' };
const PROFIL_POLI = { umum: 1, tindakan: 5, prolanis: 8, sehat: 4 };

/** nilai yang berlaku: bawaan ← template JSON C-CARE lama (bila ada) ← ubahan di Pengaturan */
function nilaiAutofill(isiCepat) {
  const ic = isiCepat || {}, o = {};
  const lama = (ic.template || []).find(t => /c-?\s?care/i.test(t.name || '') && !/d-?health/i.test(t.name || ''));
  Object.keys(ISIAN_AUTOFILL).forEach(p => {
    o[p] = {};
    ISIAN_AUTOFILL[p].forEach(f => { o[p][f.k] = f.v; });
    if (p === 'umum' && lama) lama.fields.forEach(f => { if (f.key in o.umum && f.key !== 'Diagnosa') o.umum[f.key] = String(f.value); });
    if ((p === 'tindakan' || p === 'prolanis') && !ic.pisahPoli) Object.assign(o[p], o.umum);   // sebelum dipisah: ikut Poli Umum
    Object.assign(o[p], ((ic.isian || {})[p]) || {});
  });
  const kamus = ((ic.isian || {}).umum || {}).kamusIcd;
  Object.keys(o).forEach(p => { o[p].kamusIcd = kamus != null ? kamus : KAMUS_ICD.v; });
  return o;
}
/** sekali saja (v3.0.0): isian Poli Umum yang berlaku disalin menjadi isian Ruang Tindakan & Prolanis sendiri. Mengubah ic; true bila berubah. */
function pisahkanIsian(ic) {
  if (!ic || ic.pisahPoli) return false;
  const r = nilaiAutofill(ic).umum; ic.isian = ic.isian || {};
  ['tindakan', 'prolanis'].forEach(p => {
    const o = Object.assign({}, ic.isian[p] || {});
    ISIAN_AUTOFILL[p].forEach(f => { if (!(f.k in o) && r[f.k] !== f.v) o[f.k] = r[f.k]; });
    if (Object.keys(o).length) ic.isian[p] = o;
  });
  ic.pisahPoli = true; return true;
}
