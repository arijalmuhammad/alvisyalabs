/* Scan Jasa C-CARE — inti (dipakai halaman scan dan scan harian otomatis).
 * Alur per tanggal:
 *  1) di tab C-CARE: daftar kunjungan Poli Umum, Gigi, KIA, Kunjungan Sehat, Ruang Tindakan, Prolanis, Gizi (POST /Poli/Index/{id}, /Kia) → id kunjungan, jam periksa, nama pasien, status
 *  2) kunjungan "Selesai": buka /RekapRekamMedis/Detail/{id} (hanya baca) → nama dokter, anamnesa dokter, pemeriksaan fisik
 *  3) hanya kunjungan atas NAMA SAYA yang dipakai. Pasien ganda di tanggal yang sama dengan anamnesa + pemeriksaan
 *     yang sama dihitung 1; bila anamnesa/pemeriksaan berbeda dihitung 2.
 *  4) yang dikirim ke Sheet: tanggal, shift, nama pasien, jenis, kunci sidik (hash). Anamnesa & pemeriksaan TIDAK dikirim.
 * Tidak pernah membuka tautan Batalkan atau mengirim formulir. Pengecualian (v4.6): untuk kunjungan Kunjungan Sehat atas nama
 * saya, /Poli/Ubah/{id} dibaca dengan GET hanya untuk melihat ke mana C-CARE mengarahkan — kunjungan MCU selalu dialihkan
 * ke /Poli/Mcu/{id} (diuji 11 Nov 2026: 4 dari 4 MCU teralih, 17 kunjungan sehat lain tidak). Isi halaman dibuang.
 */
const CCARE = 'https://c-care.ipb.ac.id';
// Sumber kunjungan (diuji 25 Okt 2026). Semua selain Ruang Tindakan masuk kolom POLI UMUM di Rekap Pasien,
// sama seperti cara Rekapan klinik menghitung Kunjungan Sehat & Prolanis (diuji 8 Okt 2026).
const POLI = [
  { id: 1, nama: 'Poli Umum', jenis: 'poli' },
  { id: 2, nama: 'Poli Gigi', jenis: 'poli' },
  { id: 'kia', nama: 'KIA', jenis: 'poli' },          // halaman /Kia, struktur tabel berbeda
  { id: 4, nama: 'Kunjungan Sehat', jenis: 'poli' },  // kunjungan MCU di sini → jenis 'mcu' (lihat cekMcu)
  { id: 5, nama: 'Ruang Tindakan', jenis: 'ugd' },
  { id: 8, nama: 'Poli Prolanis', jenis: 'poli' },
  { id: 7, nama: 'Poli Gizi', jenis: 'poli' },
];
const JAM_SIANG = 14;              // periksa ≥ 14.00 = siang
const GABUNG_MAKS = 5;             // sisa ≤ 5 pasien di shift lain = pasien lewat jam, ikut shift utama
const GABUNG_PERSEN = 0.15;

/* ---------- fungsi murni (diuji di Node) ---------- */
function jamDari(teks) {             // "08 Oktober 2026 19.40.21" → 19
  const m = String(teks || '').match(/(\d{1,2})[.:](\d{2})(?:[.:](\d{2}))?\s*$/);
  return m ? +m[1] : null;
}
const UMUM = ['muhammad', 'mohammad', 'mohamad', 'muhamad', 'muh', 'moh', 'm', 'ahmad', 'siti', 'nur', 's', 'ked', 'biomed', 'sp', 'mkes'];
function normal(s) { return String(s || '').toLowerCase().replace(/\bdr\.?\s*/g, '').replace(/,.*$/, '').replace(/[^a-z ]/g, ' ').replace(/\s+/g, ' ').trim(); }
/** sama bila kata khas kedua nama SALING tercakup ("dr. M. Arijal" = "dr. Muhammad Arijal"); inisial 1 huruf cocok
 *  dengan kata berawalan huruf itu. Nama yang lebih panjang ("dr. Arijal Pratama") TIDAK dianggap sama. */
function samaDokter(a, b) {
  const ta = normal(a).split(' ').filter(t => t && UMUM.indexOf(t) < 0);
  const tb = normal(b).split(' ').filter(t => t && UMUM.indexOf(t) < 0);
  if (!ta.length || !tb.length) return false;
  const cocok = (x, y) => x === y || (x.length === 1 && y[0] === x) || (y.length === 1 && x[0] === y);
  return ta.every(x => tb.some(y => cocok(x, y))) && tb.every(y => ta.some(x => cocok(x, y)));
}
function namaDokter(teks) { return String(teks || '').replace(/\s*-\s*$/, '').replace(/\s+/g, ' ').trim(); }
/** teks bebas → bentuk baku untuk dibandingkan (huruf kecil, tanpa tanda baca, spasi tunggal) */
function baku(s) { return String(s || '').toLowerCase().normalize('NFKD').replace(/[^a-z0-9]+/g, ' ').trim(); }
function rentangTanggal(dari, sampai) {
  if (!dari || !sampai) return [];
  const [a, b] = [dari, sampai].sort();
  const out = []; const d = new Date(a + 'T00:00:00Z'); const z = new Date(b + 'T00:00:00Z');
  while (d <= z && out.length < 62) { out.push(d.toISOString().slice(0, 10)); d.setUTCDate(d.getUTCDate() + 1); }
  return out;
}
function bahanKunci(k) { return [k.tanggal, baku(k.pasien), baku(k.anamnesa), baku(k.pemeriksaan)].join('|'); }

/**
 * kunjungan milik saya: [{tanggal, jenis:'poli'|'ugd'|'mcu', jam, pasien, anamnesa, pemeriksaan, kunci}]
 * → { pasien: [{tanggal, shift, nama, jenis, kunci}], catatan: {tanggal: teks}, ganda: n }
 * Ganda (kunci sama) dihitung 1. Shift per tanggal memakai aturan gabung pasien lewat jam.
 */
function susunPasien(kunjungan) {
  const unik = new Map(); let ganda = 0;
  kunjungan.forEach(k => { if (unik.has(k.kunci)) { ganda++; return; } unik.set(k.kunci, k); });
  const perTgl = {};
  [...unik.values()].forEach(k => (perTgl[k.tanggal] = perTgl[k.tanggal] || []).push(k));
  const pasien = [], catatan = {};
  Object.keys(perTgl).sort().forEach(t => {
    const L = perTgl[t];
    const shiftJam = k => (k.jam === null || k.jam < JAM_SIANG) ? 'Pagi' : 'Siang';
    const poli = L.filter(k => k.jenis === 'poli');           // MCU & UGD tidak ikut aturan gabung pasien lewat jam
    const nP = poli.filter(k => shiftJam(k) === 'Pagi').length, nS = poli.length - nP;
    let paksa = null;
    const besar = Math.max(nP, nS), kecil = Math.min(nP, nS);
    if (kecil > 0 && kecil <= GABUNG_MAKS && kecil < besar * GABUNG_PERSEN) {
      paksa = nP >= nS ? 'Pagi' : 'Siang';
      catatan[t] = kecil + ' pasien lewat jam digabung ke shift ' + paksa.toLowerCase();
    }
    const adaShift = new Set(poli.map(k => paksa || shiftJam(k)));
    L.forEach(k => {
      let s = paksa || shiftJam(k);
      if (k.jenis !== 'poli' && !adaShift.has(s) && adaShift.size === 1) s = [...adaShift][0];   // UGD ikut blok shift hari itu
      pasien.push({ tanggal: t, shift: s, nama: String(k.pasien || '').replace(/\s+/g, ' ').trim(), jenis: k.jenis, kunci: k.kunci });
    });
  });
  pasien.sort((a, b) => a.tanggal.localeCompare(b.tanggal) || (a.shift === b.shift ? 0 : a.shift === 'Pagi' ? -1 : 1));
  return { pasien, catatan, ganda };
}
/** jumlah per tanggal (untuk tampilan) */
function jumlahPerTanggal(pasien) {
  const g = {};
  pasien.forEach(p => {
    const r = g[p.tanggal] = g[p.tanggal] || { tanggal: p.tanggal, pagi: 0, siang: 0, ugd: 0, mcu: 0, tele: 0 };
    if (p.jenis === 'poli') r[p.shift === 'Siang' ? 'siang' : 'pagi']++; else r[p.jenis]++;
  });
  return Object.values(g).sort((a, b) => a.tanggal.localeCompare(b.tanggal));
}



/* ---------- hari libur: Minggu & tanggal merah tidak dihitung jasa ---------- */
// Libur nasional menurut SKB 3 Menteri (bukan cuti bersama). Tahun yang belum ada ditambah di Pengaturan.
const LIBUR_BAWAAN = {
  '2026-01-01': 'Tahun Baru Masehi', '2026-01-16': "Isra Mi'raj", '2026-02-17': 'Tahun Baru Imlek', '2026-03-19': 'Nyepi',
  '2026-03-21': 'Idul Fitri', '2026-03-22': 'Idul Fitri', '2026-04-03': 'Wafat Yesus Kristus', '2026-04-05': 'Paskah',
  '2026-05-01': 'Hari Buruh', '2026-05-14': 'Kenaikan Yesus Kristus', '2026-05-27': 'Idul Adha', '2026-05-31': 'Waisak',
  '2026-06-01': 'Hari Lahir Pancasila', '2026-06-16': 'Tahun Baru Islam', '2026-08-17': 'Proklamasi Kemerdekaan',
  '2026-08-25': 'Maulid Nabi', '2026-12-25': 'Natal',
  // 2027: SKB 3 Menteri 15 Sep 2026 (Menag 1205/2026, Menaker 3/2026, MenPANRB 2/2026) — libur nasional saja
  '2027-01-01': 'Tahun Baru Masehi', '2027-01-05': "Isra Mi'raj", '2027-02-06': 'Tahun Baru Imlek', '2027-03-08': 'Nyepi',
  '2027-03-10': 'Idul Fitri', '2027-03-11': 'Idul Fitri', '2027-03-26': 'Wafat Yesus Kristus', '2027-03-28': 'Paskah',
  '2027-05-01': 'Hari Buruh', '2027-05-06': 'Kenaikan Yesus Kristus', '2027-05-17': 'Idul Adha', '2027-05-20': 'Waisak',
  '2027-06-01': 'Hari Lahir Pancasila', '2027-06-06': 'Tahun Baru Islam', '2027-08-15': 'Maulid Nabi',
  '2027-08-17': 'Proklamasi Kemerdekaan', '2027-12-25': 'Natal', '2027-12-26': "Isra Mi'raj",
};
/** {tanggal: nama} gabungan bawaan + tambahan pengguna ("YYYY-MM-DD nama" per baris) */
function petaLibur(teksTambahan) {
  const o = Object.assign({}, LIBUR_BAWAAN);
  String(teksTambahan || '').split(/\n/).forEach(b => { const m = b.trim().match(/^(\d{4}-\d{2}-\d{2})\s*(.*)$/); if (m) o[m[1]] = m[2] || 'Libur'; });
  return o;
}
/** alasan libur ('Minggu' / nama tanggal merah) atau '' bila hari kerja */
/** hari yang dilewati scan otomatis: Minggu & tanggal yang Anda kecualikan. Libur nasional TIDAK — klinik bisa tetap buka. */
function liburTutup(t, peta) { if (new Date(t + 'T00:00:00Z').getUTCDay() === 0) return 'Minggu'; const n = (peta || {})[t]; return n && !LIBUR_BAWAAN[t] ? n : ''; }
function alasanLibur(t, peta) { if (new Date(t + 'T00:00:00Z').getUTCDay() === 0) return 'Minggu'; return (peta || LIBUR_BAWAAN)[t] || ''; }

/* ---------- fungsi yang dijalankan DI tab C-CARE (chrome.scripting) ---------- */
async function ambilDaftar(tanggal, poliIds) {
  let token = (document.querySelector('input[name=__RequestVerificationToken]') || {}).value;
  if (!token) {
    const h = await (await fetch('/Poli/Index/1', { credentials: 'include' })).text();
    const d = new DOMParser().parseFromString(h, 'text/html');
    if (d.querySelector('input[type=password]')) return { login: true };
    token = (d.querySelector('input[name=__RequestVerificationToken]') || {}).value;
  }
  if (!token) return { login: true };
  const hasil = [];
  for (const id of poliIds) {
    const kia = id === 'kia';
    const q = kia ? new URLSearchParams({ Tanggal: tanggal, __Invariant: '', StatusKunjunganId: '', __RequestVerificationToken: token })
      : new URLSearchParams({ JenisPoliId: id, Tanggal: tanggal, __Invariant: '', StatusKunjunganId: '', __RequestVerificationToken: token });
    const r = await fetch(kia ? '/Kia' : '/Poli/Index/' + id, { method: 'POST', body: q, credentials: 'include' });
    const doc = new DOMParser().parseFromString(await r.text(), 'text/html');
    if (doc.querySelector('input[type=password]')) return { login: true };
    // Poli: No | Tgl Kunjungan | Tgl Pemeriksaan | No RM | Nama Pasien | Status | Aksi
    // KIA : No | Tgl Pemeriksaan | No RM | Nama Pasien | Status | Dokter | Kategori | Aksi
    const k = kia ? { periksa: 1, pasien: 3, status: 4 } : { periksa: 2, pasien: 4, status: 5 };
    doc.querySelectorAll(kia ? '#datatable-kia tbody tr' : '#datatable-poli tbody tr').forEach(tr => {
      if (tr.cells.length < 6) return;
      const det = [...tr.querySelectorAll('a')].map(a => a.getAttribute('href') || '').find(h => /\/RekapRekamMedis\/Detail\/\d+/.test(h));
      if (!det) return;
      hasil.push({ poli: id, kunjungan: det.match(/(\d+)$/)[1], periksa: tr.cells[k.periksa].innerText.trim(), pasien: tr.cells[k.pasien].innerText.trim(), status: tr.cells[k.status].innerText.trim() });
    });
  }
  return { baris: hasil };
}
/** Detail rekam medis (hanya baca): nama dokter, anamnesa dokter, pemeriksaan fisik (gabungan baris pemeriksaan) */
async function ambilDetail(ids, lengkap) {
  const out = {};
  const STOP = /^(ekg|foto ekg|dokumen penunjang|radiologi|laboratorium|diagnosa|tata laksana|pengobatan|tindak lanjut)/i;
  for (let i = 0; i < ids.length; i += 8) {
    await Promise.all(ids.slice(i, i + 8).map(async id => {
      try {
        const h = await (await fetch('/RekapRekamMedis/Detail/' + id, { credentials: 'include' })).text();
        const d = new DOMParser().parseFromString(h, 'text/html');
        if (d.querySelector('input[type=password]')) { out[id] = { login: true }; return; }   // sesi habis di tengah jalan
        const th = [...d.querySelectorAll('th')].find(e => e.textContent.trim() === 'Dokter');
        if (!th) { out[id] = { tanpaTabel: true }; return; }                                    // halaman tidak dikenal
        const r = { dokter: th && th.nextElementSibling ? th.nextElementSibling.textContent : '' };
        if (lengkap && th) {
          let anam = '', pem = [], dalamPem = false;
          [...th.closest('table').querySelectorAll('tr')].forEach(tr => {
            if (tr.cells.length < 2) return;
            const lab = tr.cells[0].textContent.replace(/\s+/g, ' ').trim();
            const isi = tr.cells[1].textContent.replace(/\s+/g, ' ').trim();
            if (/^anamnesa/i.test(lab)) anam = isi;
            if (/^pemeriksaan fisik/i.test(lab)) dalamPem = true;
            else if (STOP.test(lab)) dalamPem = false;
            if (dalamPem) pem.push(lab + ':' + isi);
          });
          r.anamnesa = anam; r.pemeriksaan = pem.join(';');
        }
        out[id] = r;
      } catch (e) { out[id] = null; }
    }));
  }
  return out;
}

/** id kunjungan → 1 (MCU) / 0 (bukan) / null (gagal); {login:true} bila sesi habis. Hanya GET, isi halaman dibuang. */
async function cekMcu(ids) {
  const out = {};
  for (let i = 0; i < ids.length; i += 6) {
    await Promise.all(ids.slice(i, i + 6).map(async id => {
      try {
        const r = await fetch('/Poli/Ubah/' + id, { credentials: 'include' });
        try { r.body && r.body.cancel(); } catch (e) {}
        if (/\/Account\/|Login/i.test(r.url)) { out.login = true; return; }
        out[id] = /\/Poli\/Mcu\//i.test(r.url) ? 1 : 0;
      } catch (e) { out[id] = null; }
    }));
  }
  return out;
}

/* ---------- alur scan (dipakai halaman & latar) ---------- */
async function sidik(teks) {
  const b = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(teks));
  return [...new Uint8Array(b)].slice(0, 12).map(x => x.toString(16).padStart(2, '0')).join('');
}
/* ---------- log aktivitas & galat (chrome.storage.local 'log', maks 300 baris, tanpa data pasien) ---------- */
async function tulisLog(level, sumber, teks, detail) {
  try {
    const waktu = new Date(Date.now() + 7 * 36e5).toISOString().slice(0, 19).replace('T', ' ');
    const versi = chrome.runtime.getManifest().version;
    const { log = [] } = await chrome.storage.local.get('log');
    log.push({ waktu, level, sumber, teks: String(teks).slice(0, 500), detail: detail ? String(detail).slice(0, 1500) : '', versi });
    await chrome.storage.local.set({ log: log.slice(-300) });
  } catch (e) { /* log tidak boleh menggagalkan scan */ }
}

/* ---------- tab C-CARE yang stabil ---------- */
const tungguSiap = (tabId, ms = 30000) => new Promise((res, gagal) => {
  const batas = setTimeout(() => { chrome.tabs.onUpdated.removeListener(f); gagal(new Error('Tab C-CARE tidak selesai dimuat dalam 30 detik.')); }, ms);
  const f = (id, info) => { if (id === tabId && info.status === 'complete') { clearTimeout(batas); chrome.tabs.onUpdated.removeListener(f); res(); } };
  chrome.tabs.onUpdated.addListener(f);
  chrome.tabs.get(tabId).then(t => { if (t.status === 'complete' && !t.discarded) { clearTimeout(batas); chrome.tabs.onUpdated.removeListener(f); res(); } })
    .catch(e => { clearTimeout(batas); chrome.tabs.onUpdated.removeListener(f); gagal(new Error('Tab C-CARE tertutup.')); });
});
async function siapkanTab(t) {
  if (t.discarded) { await chrome.tabs.reload(t.id); }                 // tab "tidur" (Hemat Memori) dibangunkan
  try { await chrome.tabs.update(t.id, { autoDiscardable: false }); } catch (e) {}
  await tungguSiap(t.id);
  return t;
}
/** v4.6: sakelar "Scan jasa" — false = scan, kirim, sinkron Sheet, dan permintaan dari HP berhenti; fitur lain tetap hidup */
const PESAN_SCAN_MATI = 'Scan jasa sedang dimatikan. Nyalakan di Pengaturan → Scan.';
async function scanMati() { return (await chrome.storage.local.get('scanAktif')).scanAktif === false; }
/** tab buatan scan masuk satu grup "Scan jasa" (abu, diciutkan) agar bilah tab tetap rapi */
async function grupkanTab(tabId) {
  try {
    if (!chrome.tabGroups || !chrome.tabs.group) return;
    const t = await chrome.tabs.get(tabId);
    const ada = (await chrome.tabGroups.query({ windowId: t.windowId, title: 'Scan jasa' }))[0];
    const groupId = await chrome.tabs.group(ada ? { groupId: ada.id, tabIds: [tabId] } : { tabIds: [tabId], createProperties: { windowId: t.windowId } });
    await chrome.tabGroups.update(groupId, { title: 'Scan jasa', color: 'grey', collapsed: true });
  } catch (e) { /* grup tab bukan syarat scan */ }
}
async function tabScanBaru() { const t = await chrome.tabs.create({ url: CCARE + '/Poli/Index/1', active: false }); await grupkanTab(t.id); return t; }
/** Tab kerja scan SENDIRI (latar, tidak aktif) — tab C-CARE yang sedang Anda pakai tidak disentuh, sehingga
 *  membuka CPPT / pindah halaman di sana tidak lagi menggagalkan scan. idLama: tab scan sebelumnya (Lanjut setelah Tunda). */
async function tabCcare(buatJikaTidakAda = true, idLama = null) {
  let t = idLama ? await chrome.tabs.get(idLama).catch(() => null) : null;
  if (t && !String(t.url || t.pendingUrl || '').startsWith(CCARE)) t = null;
  let dibuat = false;
  if (!t && buatJikaTidakAda) { t = await tabScanBaru(); dibuat = true; }
  if (!t) { const semua = await chrome.tabs.query({ url: CCARE + '/*' }); t = semua.find(x => x.status === 'complete' && !x.discarded) || semua[0]; }
  if (!t) return null;
  await siapkanTab(t);
  return { id: t.id, dibuat };
}
const GALAT_TAB = /hasil kosong dari tab|Frame with ID|was removed|No tab with id|No frame|tab was closed|Cannot access contents|Receiving end does not exist|The tab was discarded|Tabs cannot be edited right now/i;
/** jalankan fungsi di tab C-CARE. tab = {id} atau angka. Bila tab dimuat ulang/ditutup/tidur → siapkan ulang & coba lagi (maks 3×). */
async function jalankan(tab, func, args) {
  const ref = typeof tab === 'object' ? tab : { id: tab };
  for (let coba = 1; ; coba++) {
    try {
      const h = (await chrome.scripting.executeScript({ target: { tabId: ref.id }, func, args }))[0];
      if (h && h.result != null) return h.result;
      throw new Error('hasil kosong dari tab C-CARE (halaman berpindah/dimuat ulang saat dibaca)');
    } catch (e) {
      const pesan = e && e.message || String(e);
      if (!GALAT_TAB.test(pesan)) throw e;
      if (coba >= 3) throw new Error('Tab C-CARE terus berpindah halaman atau tertutup saat scan. Tekan Mulai scan lagi; jangan menutup tab scan di latar.');
      await tulisLog('awas', 'scan', `Tab C-CARE terganggu (${pesan}) — percobaan ulang ${coba}/2`);
      await new Promise(r => setTimeout(r, 1500 * coba));
      let t = await chrome.tabs.get(ref.id).catch(() => null);
      if (!t) { t = await tabScanBaru(); ref.id = t.id; ref.dibuat = true; }
      await siapkanTab(t);
    }
  }
}
const kunciCache = nama => 'cache:' + normal(nama);
function pangkas(c) { const k = Object.keys(c); if (k.length <= 30000) return c; const o = {}; k.slice(-25000).forEach(x => o[x] = c[x]); return o; }

/**
 * Proses SATU tanggal. lapor(teks) untuk progres; cekHenti() → true untuk membatalkan tanggal ini (tunda/stop).
 * Hasil: { login } | { batal } | { milik: [...], tanpaDokter, dibaca }. Cache diperbarui di tempat (simpan oleh pemanggil).
 */
async function prosesTanggal(tab, tgl, nama, cache, lapor = () => {}, cekHenti = () => false) {
  lapor('membaca daftar kunjungan 7 poli…', 0.02);
  const r = await jalankan(tab, ambilDaftar, [tgl, POLI.map(p => p.id)]);
  if (!r || r.login) return { login: true };
  const selesai = r.baris.filter(b => b.status === 'Selesai');
  lapor('daftar kunjungan terbaca', 0.3);
  // perlu dibuka: yang belum dikenal (cek dokter) + milik saya (ambil anamnesa/pemeriksaan untuk cek ganda)
  // tanpa nama dokter (-1) ikut dibuka ulang: bisa jadi baru dilengkapi klinik, atau dulu terbaca saat sesi habis
  const perlu = [...new Set(selesai.map(b => b.kunjungan).filter(id => !(id in cache) || cache[id] === 1 || cache[id] === -1))];
  const detail = {};
  for (let j = 0; j < perlu.length; j += 30) {
    if (cekHenti()) return { batal: true };
    lapor(`membaca rekam medis ${Math.min(j + 30, perlu.length)}/${perlu.length}…`, 0.3 + 0.7 * j / Math.max(1, perlu.length));
    const bagian = await jalankan(tab, ambilDetail, [perlu.slice(j, j + 30), true]);
    if (Object.values(bagian).some(d => d && d.login)) return { login: true };
    Object.assign(detail, bagian);
  }
  const asing = Object.values(detail).filter(d => d && d.tanpaTabel).length;
  if (asing && asing >= Math.max(3, perlu.length * 0.2)) throw new Error(`Halaman rekam medis C-CARE tidak dikenali (${asing}/${perlu.length}) — kemungkinan tampilan C-CARE berubah. Scan dihentikan agar jumlah tidak salah.`);
  Object.entries(detail).forEach(([id, d]) => { if (!d || d.tanpaTabel) return; const n = namaDokter(d.dokter); cache[id] = n ? (samaDokter(n, nama) ? 1 : 0) : -1; });
  // MCU: kunjungan Kunjungan Sehat atas nama saya yang dialihkan C-CARE ke /Poli/Mcu/
  const calonMcu = selesai.filter(b => b.poli === 4 && cache[b.kunjungan] === 1 && !(('mcu:' + b.kunjungan) in cache)).map(b => b.kunjungan);
  if (calonMcu.length) {
    lapor(`memeriksa ${calonMcu.length} kunjungan sehat (MCU atau bukan)…`, 0.97);
    const m = await jalankan(tab, cekMcu, [calonMcu]);
    if (m.login) return { login: true };
    calonMcu.forEach(id => { if (m[id] === 0 || m[id] === 1) cache['mcu:' + id] = m[id]; });
  }
  lapor('menghitung pasien…', 1);
  const milik = []; let tanpaDokter = 0, dibaca = 0;
  for (const b of selesai) {
    dibaca++;
    if (!(b.kunjungan in cache) || cache[b.kunjungan] === -1) { tanpaDokter++; continue; }
    if (cache[b.kunjungan] !== 1 || !detail[b.kunjungan]) continue;
    const d = detail[b.kunjungan];
    const k = { tanggal: tgl, jenis: b.poli === 4 && cache['mcu:' + b.kunjungan] === 1 ? 'mcu' : POLI.find(p => p.id === b.poli).jenis, jam: jamDari(b.periksa), pasien: b.pasien, anamnesa: d.anamnesa, pemeriksaan: d.pemeriksaan };
    k.kunci = await sidik(bahanKunci(k));
    delete k.anamnesa; delete k.pemeriksaan;            // tidak disimpan maupun dikirim
    milik.push(k);
  }
  return { milik, tanpaDokter, dibaca };
}

const PESAN_ALAMAT = 'Web App tidak menjawab data. Salin ulang Alamat Web App & Kunci dari Sheet (menu Klinik → Alamat & kunci), dan pastikan deployment "Yang memiliki akses: Siapa saja".';
function periksaAlamat(url) {
  if (!url) return 'Alamat Web App belum diisi.';
  if (/\/dev(\?|$)/.test(url)) return 'Alamat berakhiran /dev hanya untuk uji di editor. Pakai alamat yang berakhiran /exec.';
  if (!/^https:\/\/script\.google\.com\/.*\/exec(\?|$)/.test(url)) return 'Alamat Web App harus diawali https://script.google.com/ dan berakhiran /exec.';
  return '';
}
/** fetch dengan pesan yang bisa dipahami bila jaringan putus */
async function ambil(url, opsi) {
  try { return await fetch(url, opsi); }
  catch (e) { throw new Error('Tidak bisa menghubungi Google (internet putus atau diblokir). Data aman di ekstensi — coba lagi nanti.'); }
}
async function bacaJawaban(r) {
  if (r.status >= 500) throw new Error(`Server Google sedang galat (HTTP ${r.status}). Data aman di ekstensi — tekan Kirim lagi beberapa menit lagi.`);
  if (r.status === 404) throw new Error('Alamat Web App tidak ditemukan (HTTP 404). ' + PESAN_ALAMAT);
  const t = await r.text();
  try { return JSON.parse(t); } catch (e) {
    const m = t.match(/tidak ditemukan:\s*(\w+)|not found:\s*(\w+)/i);
    throw new Error(m ? 'Apps Script belum diperbarui (fungsi ' + (m[1] || m[2]) + ' tidak ada) — Terapkan versi baru.' : PESAN_ALAMAT);
  }
}
async function kirimKeSheet(url, kunci, nama, tanggal, pasien) {
  const salah = periksaAlamat(url); if (salah) throw new Error(salah);
  const r = await ambil(url, { method: 'POST', headers: { 'Content-Type': 'text/plain;charset=utf-8' }, body: JSON.stringify({ aksi: 'pasien.kirim', kunci, nama, tanggal, pasien }) });
  const j = await bacaJawaban(r);
  if (!j.ok) throw new Error(j.pesan || 'Gagal');
  return j;
}
/** tanya status tanggal ke Web App (juga dipakai tombol Uji koneksi) */
async function ambilStatusSheet(url, kunci) {
  const salah = periksaAlamat(url); if (salah) throw new Error(salah);
  const r = await ambil(url + (url.includes('?') ? '&' : '?') + 'aksi=status&kunci=' + encodeURIComponent(kunci || ''));
  const j = await bacaJawaban(r);
  if (!j.ok) throw new Error(j.pesan === 'Kunci salah' ? 'Kunci salah — salin ulang dari Sheet (menu Klinik → Alamat & kunci).' : j.pesan || 'Gagal');
  return j;
}


/* ---------- pengaturan ikut akun: tidak hilang saat pindah PC / pasang ulang Chrome ---------- */
// Disalin ke chrome.storage.sync (ikut akun Google di Chrome bila Sinkronisasi aktif). Cadangan: "Kode pasang" dari Sheet.
const KUNCI_SETELAN = ['nama', 'url', 'kunci', 'otomatis', 'jamOtomatis', 'bunyiAktif', 'liburTambahan', 'kirimOtomatis', 'pantauSiap', 'pantauPoli', 'pantauBunyi', 'pantauPer', 'pcareSetelan', 'scanAktif', 'balonAnamnesa', 'cekIcd'];   // pcareAkun (ID/sandi) sengaja TIDAK disinkron
async function simpanSetelanAkun() {
  try {
    const l = await chrome.storage.local.get(KUNCI_SETELAN.concat('isiCepat'));
    if (l.isiCepat) l.isiCepat = { autoSalin: l.isiCepat.autoSalin, bukaDiagnosa: l.isiCepat.bukaDiagnosa, mati: l.isiCepat.mati, poliMati: l.isiCepat.poliMati, tampilTanggal: l.isiCepat.tampilTanggal, formulirBiasa: l.isiCepat.formulirBiasa, cpptBiasa: l.isiCepat.cpptBiasa, suratMati: l.isiCepat.suratMati, favoritMati: l.isiCepat.favoritMati, pintasanMati: l.isiCepat.pintasanMati, resepMati: l.isiCepat.resepMati, duaMati: l.isiCepat.duaMati, pisahPoli: l.isiCepat.pisahPoli };   // template disimpan terpisah
    await chrome.storage.sync.set({ setelan: Object.assign({}, l, { disimpan: Date.now() }) });
    return true;
  } catch (e) { tulisLog('awas', 'setelan', 'Pengaturan belum tersimpan ke akun Chrome: ' + (e.message || e)); return false; }
}
/** isi pengaturan lokal yang kosong dari salinan akun. true bila ada yang dipulihkan */
async function pulihkanSetelan() {
  let setelan;
  try { ({ setelan } = await chrome.storage.sync.get('setelan')); } catch (e) { return false; }
  if (!setelan) return false;
  const l = await chrome.storage.local.get(KUNCI_SETELAN.concat('isiCepat')), o = {};
  KUNCI_SETELAN.forEach(k => { if (setelan[k] !== undefined && setelan[k] !== '' && (l[k] === undefined || l[k] === '')) o[k] = setelan[k]; });
  if (!l.isiCepat) {                                              // isi cepat: sakelar + template dari akun
    const { templateIsi, isianAutofill } = await chrome.storage.sync.get(['templateIsi', 'isianAutofill']).catch(() => ({}));
    if (setelan.isiCepat || templateIsi || isianAutofill) o.isiCepat = Object.assign({}, setelan.isiCepat || {}, templateIsi && templateIsi.length ? { template: templateIsi } : {}, isianAutofill ? { isian: isianAutofill } : {});
  }
  if (!Object.keys(o).length) return false;
  await chrome.storage.local.set(o);
  tulisLog('info', 'setelan', 'Pengaturan dipulihkan dari akun Chrome: ' + Object.keys(o).filter(k => k !== 'kunci').join(', ') + (o.kunci ? ', kunci' : ''));
  return true;
}
/** "SJC1:<base64 JSON {n,u,k}>" dari menu Klinik → Alamat & kunci → {nama,url,kunci} */
function bacaKodePasang(teks) {
  const m = String(teks || '').trim().match(/^SJC1:([A-Za-z0-9+/=_-]+)$/);
  if (!m) return null;
  try {
    const b = atob(m[1].replace(/-/g, '+').replace(/_/g, '/'));
    const j = JSON.parse(new TextDecoder().decode(Uint8Array.from(b, c => c.charCodeAt(0))));
    return j && j.u && j.k ? { nama: j.n || '', url: j.u, kunci: j.k } : null;
  } catch (e) { return null; }
}

if (typeof module !== 'undefined') module.exports = { bacaKodePasang, bacaJawaban, petaLibur, alasanLibur, liburTutup, jamDari, namaDokter, rentangTanggal, samaDokter, baku, bahanKunci, susunPasien, jumlahPerTanggal };
