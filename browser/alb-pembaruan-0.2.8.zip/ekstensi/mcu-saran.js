/* CCare Dokter — penyusun Interpretasi, Saran, dan Kesan MCU (tanpa DOM; dipakai mcu.js, bisa diuji di Node).
 *
 * Masukan  : data({ jk:'L'|'P', umur, tb, bb, imt, lp, sis, dia, nadi, rr, suhu, spo2, visus:'OD 20/30\nOS 20/25',
 *                   butaWarna:true|false|null, riwayat, lab:{ hb:{v,rendah?,tinggi?,bawah?,atas?}, … } })
 * Keluaran : { temuan:[{kode, nama, berat:'ringan'|'bermakna', kalimat, kelompok}], interpretasiLab, interpretasiFisik,
 *              saran (teks bernomor + blok diet), kesan:{nilai, keterangan}|null, diagnosa }
 *
 * Batas klinis (dipakai bila laboratorium tidak memberi nilai rujukan):
 *   IMT  : Asia-Pasifik (PNPK 2025): <18,5 kurang · 18,5–22,9 normal · 23–24,9 BB lebih · 25–29,9 obesitas I · ≥30 obesitas II
 *   LP   : obesitas sentral ≥ 90 cm (L) / ≥ 80 cm (P) — kriteria Asia
 *   TD   : PERHI 2019: normal-tinggi 130–139/85–89 · HT-1 140–159/90–99 · HT-2 160–179/100–109 · HT-3 ≥180/110 · hipotensi <90/60
 *   GDP  : 100–125 GDPT (prediabetes) · ≥126 sugestif DM; GDS ≥200; HbA1c 5,7–6,4 prediabetes · ≥6,5 sugestif DM (PERKENI)
 *   Lemak: Kol total ≥200 (≥240 tinggi) · LDL ≥130 (≥160 tinggi) · HDL <40 L / <50 P · TG ≥150 (≥200 tinggi)
 *   AU >7 (L) / >6 (P) mg/dL · Hb <13 (L) / <12 (P) g/dL (WHO) · Leukosit 4.000–10.000 · Trombosit 150–450 rb
 *   LED >15 (L) / >20 (P) mm/jam · Ureum >50 · Kreatinin >1,3 (L) / >1,1 (P) · SGOT/SGPT >40 U/L
 *
 * KEBIJAKAN TOLERANSI (v4.5.0) — tiga golongan parameter:
 *   A. Batas keputusan (pedoman klinis, TANPA toleransi, rujukan lab diabaikan): gula darah & HbA1c (PERKENI), profil
 *      lemak (kol ≥200, LDL ≥130, HDL <40 L/<50 P, TG ≥150), anemia (WHO: Hb <13 L/<12 P), asam urat (>7 L/>6 P),
 *      tekanan darah, IMT, lingkar perut. Nilai yang "ditandai lab" tetapi belum melewati batas pedoman → zona toleransi.
 *   B. Rentang rujukan statistik (5% orang sehat memang di luar rentang) — DENGAN zona toleransi; baru jadi temuan bila
 *      melewati batas tindakan: leukosit & trombosit ±10%; eritrosit, hematokrit, Hb tinggi ±5%; hitung jenis ±5 poin
 *      (monosit/eosinofil ±2, basofil ±1); MCV 80–100 fL, MCH 26–34 pg, MCHC 31–37; LED s.d. 1,5× batas sesuai usia;
 *      ureum & SGOT/SGPT s.d. 1,1× batas atas; kreatinin s.d. 1,1× batas atas selama eLFG ≥ 60.
 *   C. Fisiologis saat MCU (tidak dilaporkan): BJ urin s.d. 1,030 (puasa), nadi 50–59 x/menit, visus 20/25.
 *   Nilai di zona toleransi TIDAK menjadi temuan, tidak memunculkan saran/diet, tidak memengaruhi Kesan — tetapi tetap
 *   disebut satu baris ("sedikit di luar rujukan, tidak bermakna secara klinis") dan ditampilkan di panel.
 *   Fungsi ginjal dinilai dengan eLFG (CKD-EPI 2021): <60 = temuan; <45 atau <60 + kreatinin tinggi = bermakna.
 */
(function (root) {
  const angka = v => { if (v == null || v === '') return NaN; const n = parseFloat(String(v).replace(',', '.')); return isNaN(n) ? NaN : n; };
  const k1 = n => String(Math.round(n * 10) / 10).replace('.', ',');           // 28.01 → "28"; 1.25 → "1,3"
  const k2 = n => String(Math.round(n * 100) / 100).replace('.', ',');
  const ribuan = n => Math.round(n).toLocaleString('id-ID');
  const gabung = arr => arr.length <= 1 ? (arr[0] || '') : arr.slice(0, -1).join(', ') + ' dan ' + arr[arr.length - 1];
  const kapital = s => s ? s[0].toUpperCase() + s.slice(1) : s;

  /* ---------- nilai lab: pakai rujukan dari laboratorium bila ada, kalau tidak batas bawaan ---------- */
  const BATAS = {
    hb: { L: [13, 17.5], P: [12, 15.5] }, leuko: [4000, 10000], trombo: [150000, 450000], ht: { L: [40, 52], P: [36, 46] },
    led: { L: [0, 15], P: [0, 20] }, gdp: [70, 99], gds: [70, 199], hba1c: [4, 5.6],
    kol: [0, 199], ldl: [0, 129], hdl: { L: [40, 999], P: [50, 999] }, tg: [0, 149],
    au: { L: [3.4, 7], P: [2.4, 6] }, ureum: [10, 50], kreat: { L: [0.6, 1.3], P: [0.5, 1.1] }, sgot: [0, 40], sgpt: [0, 40],
  };
  function batas(kode, jk, lab) {
    const x = lab[kode] || {}, b = BATAS[kode]; let [lo, hi] = Array.isArray(b) ? b : (b ? b[jk === 'P' ? 'P' : 'L'] : [NaN, NaN]);
    if (!isNaN(angka(x.bawah))) lo = angka(x.bawah);
    if (!isNaN(angka(x.atas))) hi = angka(x.atas);
    return [lo, hi];
  }
  const nilai = (lab, k) => angka((lab[k] || {}).v);
  const ada = (lab, k) => !isNaN(nilai(lab, k));

  /* ---------- visus Snellen: "OD 20/30\nOS 20/25" atau "6/9" ---------- */
  function bacaVisus(t) {
    const hasil = []; String(t || '').split(/\n|;|,/).forEach(b => {
      const m = b.match(/(OD|OS|ODS|kanan|kiri)?\s*[:=]?\s*(\d+)\s*\/\s*(\d+)/i); if (!m) return;
      const sisi = /OD|kanan/i.test(m[1] || '') ? 'kanan' : /OS|kiri/i.test(m[1] || '') ? 'kiri' : '';
      hasil.push({ sisi, a: +m[2], b: +m[3], teks: `${m[2]}/${m[3]}` });
    });
    return hasil;
  }

  function susun(d) {
    const jk = d.jk === 'P' ? 'P' : 'L', lab = d.lab || {}, T = [];
    const tambah = (kode, nama, berat, kalimat, kelompok, saran = [], diet = []) => T.push({ kode, nama, berat, kalimat, kelompok, saran, diet });

    /* ===== antropometri ===== */
    const imt = !isNaN(angka(d.imt)) ? angka(d.imt) : (angka(d.bb) && angka(d.tb) ? angka(d.bb) / Math.pow(angka(d.tb) / 100, 2) : NaN);
    const lp = angka(d.lp), sentral = !isNaN(lp) && lp >= (jk === 'P' ? 80 : 90);
    if (!isNaN(imt)) {
      const kat = imt < 18.5 ? 'kurang' : imt < 23 ? '' : imt < 25 ? 'lebih' : imt < 30 ? 'ob1' : 'ob2';
      const ekor = sentral ? `, disertai lingkar perut ${k1(lp)} cm yang menandakan penumpukan lemak di area perut (obesitas sentral)` : '';
      if (kat === 'kurang') tambah('imt', 'Berat badan kurang', 'ringan', `Berat badan tergolong kurang (IMT ${k1(imt)} kg/m²). Asupan makan perlu ditingkatkan agar stamina dan daya tahan tubuh tetap terjaga.`, 'fisik', ['Tingkatkan asupan makan bergizi seimbang sampai IMT mencapai 18,5–22,9 kg/m².'], ['gizi']);
      else if (kat === 'lebih') tambah('imt', 'Berat badan lebih', 'ringan', `Berat badan sedikit di atas ideal (IMT ${k1(imt)} kg/m², kategori berat badan lebih menurut kriteria Asia-Pasifik)${ekor}.`, 'fisik', ['Jaga berat badan agar tidak terus naik; target IMT 18,5–22,9 kg/m².'], ['gizi']);
      else if (kat === 'ob1' || kat === 'ob2') tambah('imt', kat === 'ob1' ? 'Obesitas I' : 'Obesitas II', 'ringan', `IMT ${k1(imt)} kg/m² termasuk obesitas ${kat === 'ob1' ? 'I' : 'II'} (kriteria Asia-Pasifik)${ekor}. Kondisi ini meningkatkan risiko hipertensi, diabetes, dan penyakit jantung di kemudian hari.`, 'fisik', ['Turunkan berat badan secara bertahap, sekitar 5–10% dalam 6 bulan, melalui pengaturan porsi makan dan olahraga.'], ['gizi']);
      else if (sentral) tambah('lp', 'Obesitas sentral', 'ringan', `IMT normal (${k1(imt)} kg/m²), namun lingkar perut ${k1(lp)} cm sudah melewati batas sehat — lemak cenderung menumpuk di area perut.`, 'fisik', ['Kurangi lingkar perut dengan olahraga aerobik teratur dan membatasi makanan manis serta berlemak.'], ['gizi']);
    } else if (sentral) tambah('lp', 'Obesitas sentral', 'ringan', `Lingkar perut ${k1(lp)} cm melewati batas sehat (obesitas sentral).`, 'fisik', [], ['gizi']);

    /* ===== tekanan darah (PERHI 2019) ===== */
    const s = angka(d.sis), di = angka(d.dia);
    if (!isNaN(s) && !isNaN(di)) {
      const td = `${s}/${di} mmHg`, riwHt = /hipertensi|darah tinggi|\bht\b/i.test(d.riwayat || '');
      if (s >= 180 || di >= 110) tambah('td', 'Hipertensi derajat 3', 'bermakna', `Tekanan darah ${td} sangat tinggi (setara hipertensi derajat 3) dan perlu segera ditangani dokter${riwHt ? ', apalagi dengan riwayat hipertensi sebelumnya' : ''}.`, 'fisik', ['Segera konsultasi ke dokter untuk penanganan tekanan darah hari ini.'], ['garam']);
      else if (s >= 160 || di >= 100) tambah('td', 'Hipertensi derajat 2', 'bermakna', `Tekanan darah ${td} termasuk hipertensi derajat 2${riwHt ? ' dan sejalan dengan riwayat hipertensi' : ''}; perlu evaluasi dan pengobatan oleh dokter.`, 'fisik', ['Konsultasi ke dokter untuk evaluasi dan pengobatan hipertensi.'], ['garam']);
      else if (s >= 140 || di >= 90) tambah('td', riwHt ? 'Hipertensi derajat 1' : 'Tekanan darah tinggi (HT-1)', 'ringan', riwHt ? `Tekanan darah ${td} masih di atas target (hipertensi derajat 1) pada peserta dengan riwayat hipertensi.` : `Tekanan darah ${td} berada di rentang hipertensi derajat 1. Satu kali pengukuran belum cukup untuk menegakkan diagnosis, sehingga perlu diukur ulang.`, 'fisik', [riwHt ? 'Kontrol hipertensi rutin dan minum obat sesuai anjuran dokter.' : 'Ukur ulang tekanan darah dalam 1–2 minggu; bila tetap ≥ 140/90 mmHg, konsultasi ke dokter.'], ['garam']);
      else if (s >= 130 || di >= 85) tambah('td', 'Tekanan darah normal-tinggi', 'ringan', `Tekanan darah ${td} di batas atas normal (normal-tinggi). Belum termasuk hipertensi, tetapi sebaiknya dipantau berkala.`, 'fisik', ['Pantau tekanan darah minimal sebulan sekali.'], ['garam']);
      else if (s < 90 || di < 60) tambah('td', 'Tekanan darah rendah', 'ringan', `Tekanan darah ${td} tergolong rendah; perhatikan bila disertai pusing atau mudah lelah.`, 'fisik', ['Cukupi kebutuhan cairan dan hindari berdiri mendadak dari posisi duduk/berbaring.'], ['hipotensi']);
    }
    const nadi = angka(d.nadi), suhu = angka(d.suhu), spo2 = angka(d.spo2);
    if (nadi > 100) tambah('nadi', 'Takikardia', 'ringan', `Denyut nadi ${nadi} x/menit lebih cepat dari normal; dapat dipengaruhi kecemasan, kafein, atau kurang istirahat.`, 'fisik');
    else if (nadi && nadi < 50) tambah('nadi', 'Bradikardia', 'ringan', `Denyut nadi ${nadi} x/menit lebih lambat dari normal; pada orang yang rutin berolahraga hal ini bisa wajar, namun perlu dicocokkan dengan keluhan dan EKG.`, 'fisik');
    if (suhu >= 37.5) tambah('suhu', 'Subfebris/demam', 'ringan', `Suhu tubuh ${k1(suhu)} °C sedikit meningkat saat pemeriksaan.`, 'fisik');
    if (spo2 && spo2 < 92) tambah('spo2', 'Saturasi oksigen rendah', 'bermakna', `Saturasi oksigen ${spo2}% di bawah normal dan perlu dievaluasi lebih lanjut.`, 'fisik');
    else if (spo2 && spo2 < 95) tambah('spo2', 'Saturasi oksigen batas bawah', 'ringan', `Saturasi oksigen ${spo2}% sedikit di bawah normal; sebaiknya diukur ulang dalam keadaan istirahat dan jari hangat.`, 'fisik', ['Ukur ulang saturasi oksigen; konsultasi ke dokter bila tetap < 95% atau ada sesak.']);

    /* ===== visus & buta warna ===== */
    const vs = bacaVisus(d.visus), kurang = vs.filter(x => x.b / x.a > 1.26);          // 20/25 (6/7,5) masih dianggap normal
    if (kurang.length) {
      const sisi = kurang.map(x => x.sisi ? `mata ${x.sisi} ${x.teks}` : x.teks);
      tambah('visus', 'Penurunan tajam penglihatan', 'ringan', `Tajam penglihatan belum optimal (${gabung(sisi)}). Umumnya karena kelainan refraksi yang dapat dikoreksi dengan kacamata.`, 'fisik', ['Periksa mata ke dokter mata atau optik untuk koreksi kacamata.']);
    }
    if (d.butaWarna === true) tambah('butawarna', 'Buta warna', 'bermakna', 'Ditemukan buta warna; perlu dipertimbangkan untuk pekerjaan yang menuntut kemampuan membedakan warna.', 'fisik');

    /* ===== laboratorium ===== */
    const normal = {};                                                        // kelompok → ada nilai & semuanya normal
    const tandai = (kel, abn) => { if (!(kel in normal)) normal[kel] = true; if (abn) normal[kel] = false; };
    const tinggi = k => { const [, hi] = batas(k, jk, lab); return ada(lab, k) && (lab[k].tinggi || nilai(lab, k) > hi); };
    const rendah = k => { const [lo] = batas(k, jk, lab); return ada(lab, k) && (lab[k].rendah || nilai(lab, k) < lo); };
    const tipis = [];                                                         // nilai di zona toleransi: disebut, tidak jadi temuan
    /* golongan B: 'tinggi' / 'rendah' bila melewati batas tindakan, 'tipis' bila hanya melewati rujukan lab, '' bila normal */
    const zona = (v, lo, hi, loAksi, hiAksi) => !isNaN(hi) && v > hiAksi ? 'tinggi' : !isNaN(lo) && v < loAksi ? 'rendah' : ((!isNaN(hi) && v > hi) || (!isNaN(lo) && v < lo)) ? 'tipis' : '';

    // darah rutin
    if (ada(lab, 'hb')) {
      const hb = nilai(lab, 'hb'), abn = hb < (jk === 'P' ? 12 : 13); tandai('darah rutin', abn);            // WHO, bukan rujukan lab
      if (!abn && hb < batas('hb', jk, lab)[0]) tipis.push(`hemoglobin ${k1(hb)} g/dL`);
      if (abn) { const berat = hb < 8 ? 'berat' : hb < 11 ? 'sedang' : 'ringan';
        tambah('hb', `Anemia ${berat}`, hb < 10 ? 'bermakna' : 'ringan', `Kadar hemoglobin ${k1(hb)} g/dL di bawah normal, sesuai anemia ${berat}. Penyebab tersering adalah kurang zat besi, namun perlu dipastikan.`, 'lab', ['Periksa ulang darah rutin dalam 1–3 bulan setelah perbaikan asupan zat besi.'], ['anemia']); }
    }
    if (ada(lab, 'leuko')) {
      const v = nilai(lab, 'leuko'), [l0, h0] = batas('leuko', jk, lab), z = zona(v, l0, h0, l0 * 0.9, h0 * 1.1), hi = z === 'tinggi', lo = z === 'rendah'; tandai('darah rutin', hi || lo);
      if (z === 'tipis') tipis.push(`leukosit ${ribuan(v)}/µL`);
      if (hi) tambah('leuko', 'Leukositosis', 'ringan', `Jumlah leukosit ${ribuan(v)}/µL meningkat, bisa berkaitan dengan infeksi atau peradangan; perlu dicocokkan dengan keluhan.`, 'lab', ['Konsultasikan bila ada demam, batuk, nyeri berkemih, atau keluhan lain.']);
      if (lo) tambah('leuko', 'Leukopenia', 'ringan', `Jumlah leukosit ${ribuan(v)}/µL di bawah normal dan sebaiknya diperiksa ulang.`, 'lab', ['Periksa ulang darah rutin dalam 1 bulan.']);
    }
    if (ada(lab, 'trombo')) {
      const v = nilai(lab, 'trombo'), [l0, h0] = batas('trombo', jk, lab), z = zona(v, l0, h0, l0 * 0.9, h0 * 1.1), hi = z === 'tinggi', lo = z === 'rendah'; tandai('darah rutin', hi || lo);
      if (z === 'tipis') tipis.push(`trombosit ${ribuan(v)}/µL`);
      if (lo) tambah('trombo', 'Trombositopenia', v < 100000 ? 'bermakna' : 'ringan', `Jumlah trombosit ${ribuan(v)}/µL di bawah normal.`, 'lab', ['Periksa ulang trombosit dan konsultasi ke dokter.']);
      if (hi) tambah('trombo', 'Trombositosis', 'ringan', `Jumlah trombosit ${ribuan(v)}/µL di atas normal.`, 'lab', ['Periksa ulang darah rutin dalam 1 bulan.']);
    }
    if (ada(lab, 'ht')) tandai('darah rutin', false);
    if (ada(lab, 'led')) {
      /* batas atas LED naik dengan usia (Westergren: umur/2 pada pria, (umur+10)/2 pada wanita) — kenaikan tipis tidak dilaporkan */
      const um = angka(d.umur), [, hiLab] = batas('led', jk, lab), hiUmur = isNaN(um) ? 0 : (jk === 'P' ? (um + 10) / 2 : um / 2);
      const v = nilai(lab, 'led'), lim = Math.max(hiLab, hiUmur), hi = v > lim * 1.5; tandai('darah rutin', hi);
      if (!hi && v > lim) tipis.push(`LED ${k1(v)} mm/jam`);
      if (hi) tambah('led', 'LED meningkat', 'ringan', `Laju endap darah ${k1(v)} mm/jam meningkat — penanda proses peradangan yang tidak spesifik, perlu dicocokkan dengan kondisi klinis.`, 'lab', [], ['led']);
    }
    // gula darah
    const gdp = nilai(lab, 'gdp'), gds = nilai(lab, 'gds'), a1c = nilai(lab, 'hba1c'), riwDm = /diabetes|kencing manis|\bdm\b/i.test(d.riwayat || '');
    let gula = '';
    if (!isNaN(gdp)) { tandai('gula darah', gdp >= 100); if (gdp >= 126) gula = 'dm'; else if (gdp >= 100) gula = 'pre'; }
    if (!isNaN(gds)) { tandai('gula darah', gds >= 200); if (gds >= 200) gula = 'dm'; }
    if (!isNaN(a1c)) { tandai('gula darah', a1c >= 5.7); if (a1c >= 6.5) gula = 'dm'; else if (a1c >= 5.7 && !gula) gula = 'pre'; }
    if (gula) {
      const nil = [!isNaN(gdp) && `gula darah puasa ${k1(gdp)} mg/dL`, !isNaN(gds) && `gula darah sewaktu ${k1(gds)} mg/dL`, !isNaN(a1c) && `HbA1c ${k1(a1c)}%`].filter(Boolean);
      if (gula === 'dm') tambah('gula', riwDm ? 'Diabetes melitus belum terkontrol' : 'Hiperglikemia (sugestif DM)', 'bermakna', riwDm ? `Kadar gula darah (${gabung(nil)}) masih di atas target pada peserta dengan riwayat diabetes.` : `Kadar gula darah tinggi (${gabung(nil)}), mengarah ke diabetes melitus. Diagnosis perlu dipastikan dengan pemeriksaan ulang.`, 'lab', [riwDm ? 'Kontrol diabetes rutin ke dokter dan patuhi pengobatan.' : 'Konsultasi ke dokter untuk pemeriksaan ulang (gula darah puasa/HbA1c) guna memastikan diagnosis diabetes.'], ['gula']);
      else tambah('gula', gdp >= 100 ? 'Prediabetes (GDPT)' : 'Prediabetes', 'ringan', `Kadar gula darah sedikit di atas normal (${gabung(nil)}), termasuk prediabetes. Belum diabetes, dan pada tahap ini masih bisa kembali normal dengan perubahan gaya hidup.`, 'lab', ['Periksa ulang gula darah puasa dalam 3 bulan.'], ['gula']);
    }
    // lemak
    const kol = nilai(lab, 'kol'), ldl = nilai(lab, 'ldl'), hdl = nilai(lab, 'hdl'), tg = nilai(lab, 'tg'), lemak = [];
    if (!isNaN(kol)) { tandai('profil lemak', kol >= 200); if (kol >= 200) lemak.push(`kolesterol total ${k1(kol)} mg/dL${kol >= 240 ? ' (tinggi)' : ' (batas atas)'}`); }
    if (!isNaN(ldl)) { tandai('profil lemak', ldl >= 130); if (ldl >= 130) lemak.push(`LDL ${k1(ldl)} mg/dL${ldl >= 160 ? ' (tinggi)' : ' (batas atas)'}`); }
    if (!isNaN(hdl)) { const lo = hdl < (jk === 'P' ? 50 : 40); tandai('profil lemak', lo); if (lo) lemak.push(`HDL ${k1(hdl)} mg/dL (rendah)`);
      else if (hdl < angka((lab.hdl || {}).bawah)) tipis.push(`HDL ${k1(hdl)} mg/dL`); }
    if (!isNaN(tg)) { tandai('profil lemak', tg >= 150); if (tg >= 150) lemak.push(`trigliserida ${k1(tg)} mg/dL${tg >= 500 ? ' (sangat tinggi)' : tg >= 200 ? ' (tinggi)' : ' (batas atas)'}`); }
    if (lemak.length) {
      const nm = (kol >= 200 || ldl >= 130) && tg >= 150 ? 'Dislipidemia campuran' : tg >= 150 && !(kol >= 200 || ldl >= 130) ? 'Hipertrigliseridemia' : (kol >= 200 || ldl >= 130) ? 'Hiperkolesterolemia' : 'Dislipidemia (HDL rendah)';
      tambah('lemak', nm, tg >= 500 ? 'bermakna' : 'ringan', `Profil lemak darah belum ideal: ${gabung(lemak)}. Lemak darah yang tinggi dalam jangka panjang mempercepat penyempitan pembuluh darah.`, 'lab', ['Periksa ulang profil lemak dalam 3 bulan setelah perbaikan pola makan dan olahraga.'], ['lemak']);
    }
    // asam urat
    if (ada(lab, 'au')) {
      const v = nilai(lab, 'au'), hi = v > (jk === 'P' ? 6 : 7); tandai('asam urat', hi);
      if (!hi && v > angka((lab.au || {}).atas)) tipis.push(`asam urat ${k1(v)} mg/dL`);
      if (hi) tambah('au', 'Hiperurisemia', 'ringan', `Kadar asam urat ${k1(v)} mg/dL di atas normal (hiperurisemia); bila dibiarkan dapat memicu nyeri sendi (gout) dan batu ginjal.`, 'lab', ['Periksa ulang asam urat dalam 3 bulan.'], ['purin']);
    }
    // ginjal
    const ur = nilai(lab, 'ureum'), kr = nilai(lab, 'kreat'), ginjal = [], um0 = angka(d.umur);
    /* eLFG CKD-EPI 2021 (tanpa ras): 142 × min(Scr/κ,1)^α × max(Scr/κ,1)^−1,200 × 0,9938^umur × 1,012 (wanita) */
    const elfg = !isNaN(kr) && kr > 0 && um0 >= 18 ? Math.round(142 * Math.pow(Math.min(kr / (jk === 'P' ? 0.7 : 0.9), 1), jk === 'P' ? -0.241 : -0.302) * Math.pow(Math.max(kr / (jk === 'P' ? 0.7 : 0.9), 1), -1.2) * Math.pow(0.9938, um0) * (jk === 'P' ? 1.012 : 1)) : NaN;
    let ginjalBerat = '';
    if (!isNaN(ur)) { const [, h0] = batas('ureum', jk, lab), hi = ur > h0 * 1.1; tandai('fungsi ginjal', hi); if (hi) { ginjal.push(`ureum ${k1(ur)} mg/dL`); ginjalBerat = 'ringan'; } else if (ur > h0) tipis.push(`ureum ${k1(ur)} mg/dL`); }
    if (!isNaN(kr)) {
      const [, h0] = batas('kreat', jk, lab), krTinggi = kr > h0;
      if (elfg < 60) { ginjal.push(`kreatinin ${k2(kr)} mg/dL, eLFG ${elfg} mL/menit/1,73 m²`); ginjalBerat = elfg < 45 || krTinggi ? 'bermakna' : (ginjalBerat || 'ringan'); }
      else if (kr > h0 * 1.1) { ginjal.push(`kreatinin ${k2(kr)} mg/dL${isNaN(elfg) ? '' : `, eLFG ${elfg} mL/menit/1,73 m²`}`); ginjalBerat = ginjalBerat || 'ringan'; }
      else if (krTinggi) tipis.push(`kreatinin ${k2(kr)} mg/dL`);
      tandai('fungsi ginjal', elfg < 60 || kr > h0 * 1.1);
    }
    if (ginjal.length) tambah('ginjal', elfg < 60 ? 'Penurunan fungsi ginjal' : 'Peningkatan ureum/kreatinin', ginjalBerat, elfg < 60 ? `Fungsi ginjal menurun (${gabung(ginjal)}). Perlu diperiksa ulang dalam 3 bulan untuk memastikan apakah menetap.` : `Nilai fungsi ginjal sedikit meningkat (${gabung(ginjal)}). Sering karena kurang minum atau asupan protein tinggi, dan perlu diperiksa ulang.`, 'lab', [elfg < 60 ? 'Konsultasi ke dokter; periksa ulang ureum, kreatinin, dan urin rutin dalam 3 bulan.' : 'Perbanyak minum air putih, lalu periksa ulang ureum dan kreatinin.'], elfg < 60 ? ['ginjal'] : []);
    // hati
    const ot = nilai(lab, 'sgot'), pt = nilai(lab, 'sgpt'), hati = [];
    const [, hiOt] = batas('sgot', jk, lab), [, hiPt] = batas('sgpt', jk, lab);
    if (!isNaN(ot)) { const hi = ot > hiOt * 1.1; tandai('fungsi hati', hi); if (hi) hati.push(`SGOT ${k1(ot)} U/L`); else if (ot > hiOt) tipis.push(`SGOT ${k1(ot)} U/L`); }
    if (!isNaN(pt)) { const hi = pt > hiPt * 1.1; tandai('fungsi hati', hi); if (hi) hati.push(`SGPT ${k1(pt)} U/L`); else if (pt > hiPt) tipis.push(`SGPT ${k1(pt)} U/L`); }
    if (hati.length) {
      const berat = ot > 3 * hiOt || pt > 3 * hiPt;
      tambah('hati', 'Peningkatan enzim hati', berat ? 'bermakna' : 'ringan', `Enzim hati meningkat (${gabung(hati)})${berat ? ', lebih dari tiga kali batas normal' : ''}. Sering berkaitan dengan perlemakan hati, obat/jamu, atau alkohol.`, 'lab', ['Hindari alkohol serta obat/jamu tanpa resep; periksa ulang SGOT/SGPT dalam 1–3 bulan.'], ['hati']);
    }

    // parameter darah lain (eritrosit, hitung jenis, indeks eritrosit, Hb/Ht tinggi) — golongan B, lihat KEBIJAKAN TOLERANSI
    const NAMA_LAIN = { eri: ['eritrosit', ' juta/µL'], neut: ['netrofil segmen', '%'], limfo: ['limfosit', '%'], mono: ['monosit', '%'], eos: ['eosinofil', '%'], baso: ['basofil', '%'], mcv: ['MCV', ' fL'], mch: ['MCH', ' pg'], mchc: ['MCHC', '%'], hb: ['hemoglobin', ' g/dL'], ht: ['hematokrit', '%'] };
    const TOL = { eri: { rel: 0.05 }, ht: { rel: 0.05 }, hb: { rel: 0.05 }, neut: { poin: 5 }, limfo: { poin: 5 }, mono: { poin: 2 }, eos: { poin: 2 }, baso: { poin: 1 }, mcv: { lo: 80, hi: 100 }, mch: { lo: 26, hi: 34 }, mchc: { lo: 31, hi: 37 } };
    const lain = [];
    Object.keys(NAMA_LAIN).forEach(k => {
      if (!ada(lab, k)) return; const v = nilai(lab, k), t = TOL[k];
      let lo = angka((lab[k] || {}).bawah), hi = angka((lab[k] || {}).atas);
      if ((k === 'hb' || k === 'ht') && isNaN(hi)) [lo, hi] = batas(k, jk, lab);
      tandai('darah rutin', false);
      if (k === 'hb' && v < hi) return;                                                    // sisi rendah Hb dinilai sebagai anemia (WHO)
      const loA = t.rel ? lo * (1 - t.rel) : t.poin ? lo - t.poin : Math.min(lo, t.lo), hiA = t.rel ? hi * (1 + t.rel) : t.poin ? hi + t.poin : Math.max(hi, t.hi);
      const z = zona(v, lo, hi, loA, hiA), teks = `${NAMA_LAIN[k][0]} ${k1(v)}${NAMA_LAIN[k][1]}`;
      if (z === 'tinggi') lain.push(`${teks} (di atas rujukan)`); else if (z === 'rendah') lain.push(`${teks} (di bawah rujukan)`); else if (z === 'tipis') tipis.push(teks);
    });
    if (lain.length) { tandai('darah rutin', true); tambah('darahlain', 'Parameter darah di luar rujukan', 'ringan', `Beberapa parameter darah di luar rujukan: ${gabung(lain)}. Umumnya tidak bermakna bila tanpa keluhan, namun sebaiknya diperiksa ulang.`, 'lab', ['Periksa ulang darah rutin pada MCU berikutnya atau bila ada keluhan.']); }

    // urinalisis
    const bj = nilai(lab, 'bj');
    if (!isNaN(bj)) { const pekat = bj > 1.030;                 // s.d. 1,030 wajar pada urin pagi/puasa tandai('urinalisis', pekat);
      if (pekat) tambah('bj', 'Urin pekat', 'ringan', `Berat jenis urin ${bj.toFixed(3).replace('.', ',')} lebih tinggi dari normal (urin pekat), umumnya tanda tubuh kurang minum.`, 'lab', ['Perbanyak minum air putih hingga warna urin kuning jernih.']); }
    const U = k => lab[k] && 'positif' in lab[k];
    ['uprot', 'uglu', 'ublood', 'uleu', 'uket', 'unit', 'ubil', 'uuro'].forEach(k => { if (U(k)) tandai('urinalisis', lab[k].positif); });
    if (U('uket') && lab.uket.positif) tambah('uket', 'Ketonuria', T.some(t => t.kode === 'gula' && t.berat === 'bermakna') ? 'bermakna' : 'ringan', `Ditemukan keton dalam urin (${lab.uket.teks})${T.some(t => t.kode === 'gula') ? '; bersama gula darah yang tinggi perlu segera dievaluasi dokter' : ', bisa karena puasa lama atau kurang asupan'}.`, 'lab', ['Konsultasi ke dokter untuk evaluasi keton urin.']);
    if (U('unit') && lab.unit.positif) tambah('unit', 'Nitrit urin positif', 'ringan', `Nitrit urin positif (${lab.unit.teks}), mengarah ke infeksi saluran kemih oleh bakteri.`, 'lab', ['Konsultasi ke dokter bila ada keluhan berkemih; periksa ulang urin rutin.']);
    if (U('ubil') && lab.ubil.positif) tambah('ubil', 'Bilirubin urin positif', 'ringan', `Ditemukan bilirubin dalam urin (${lab.ubil.teks}); perlu dicocokkan dengan fungsi hati.`, 'lab', ['Periksa ulang urin rutin dan fungsi hati.']);
    if (U('uprot') && lab.uprot.positif) tambah('uprot', 'Proteinuria', 'ringan', `Ditemukan protein dalam urin (${lab.uprot.teks}); perlu pemeriksaan urin ulang untuk memastikan.`, 'lab', ['Periksa ulang urin rutin; bila tetap positif, konsultasi ke dokter untuk evaluasi fungsi ginjal.']);
    if (U('uglu') && lab.uglu.positif) tambah('uglu', 'Glukosuria', 'ringan', T.some(t => t.kode === 'gula') ? `Ditemukan glukosa dalam urin (${lab.uglu.teks}), sejalan dengan kadar gula darah yang tinggi.` : `Ditemukan glukosa dalam urin (${lab.uglu.teks}) meskipun gula darah tidak tinggi; bisa karena obat diabetes golongan tertentu atau faktor ginjal, dan perlu diperiksa ulang.`, 'lab', T.some(t => t.kode === 'gula') ? [] : ['Periksa ulang urin rutin dan gula darah puasa.'], T.some(t => t.kode === 'gula') ? ['gula'] : []);
    if (U('ublood') && lab.ublood.positif) tambah('ublood', 'Darah samar dalam urin', 'ringan', `Ditemukan darah samar dalam urin (${lab.ublood.teks}); bisa karena infeksi saluran kemih, batu, atau menstruasi pada wanita, dan perlu diperiksa ulang.`, 'lab', ['Periksa ulang urin rutin dalam 1–2 minggu.']);
    if (U('uleu') && lab.uleu.positif) tambah('uleu', 'Leukosituria', 'ringan', `Leukosit dalam urin meningkat (${lab.uleu.teks}), dapat mengarah ke infeksi saluran kemih.`, 'lab', ['Konsultasikan bila ada nyeri atau anyang-anyangan saat berkemih; periksa ulang urin rutin.']);

    /* ===== kalimat ringkasan ===== */
    const fisik = T.filter(t => t.kelompok === 'fisik'), labT = T.filter(t => t.kelompok === 'lab');
    const okLab = Object.keys(normal).filter(k => normal[k]);
    const adaLab = Object.keys(normal).length > 0;
    const barisTipis = `- Sedikit di luar rujukan, tidak bermakna secara klinis: ${gabung(tipis)}.`;
    let interpretasiLab = '';
    if (adaLab) {
      const baris = labT.map(t => '- ' + t.kalimat);
      if (okLab.length) baris.push(`- ${kapital(gabung(okLab))} dalam batas normal.`);
      if (tipis.length) baris.push(barisTipis);
      interpretasiLab = baris.join('\n');
    }
    const interpretasiFisik = fisik.length ? fisik.map(t => '- ' + t.kalimat).join('\n') : 'Pemeriksaan fisik dan tanda vital dalam batas normal.';

    /* ===== saran (mengikuti template MCU klinik) ===== */
    const metabolik = T.some(t => ['imt', 'lp', 'gula', 'lemak', 'au', 'td', 'hb', 'hati', 'ginjal'].includes(t.kode));
    const butir = [];
    if (T.length) butir.push('Konsul Dokter MCU di Klinik terkait hasil yang abnormal untuk penatalaksanaan selanjutnya.');
    if (metabolik) butir.push('Konsul Ahli Gizi di Klinik untuk pengaturan pola diet sehat.');
    T.forEach(t => t.saran.forEach(x => { if (!butir.includes(x)) butir.push(x); }));
    butir.push('Konsumsi air putih ± 1,5–2,5 L per hari.',
      'Olahraga teratur 3× seminggu selama 50 menit atau 5× seminggu selama 30 menit (jalan santai, senam jantung/diabetes/hipertensi, renang, aerobik, lari, dll).',
      'Istirahat cukup (tidur malam 7–8 jam sehari).',
      'Kelola stres dan hindari kelelahan berlebihan.',
      'Medical check up 1 tahun sekali.');
    const urutDiet = ['gizi', 'garam', 'gula', 'lemak', 'purin', 'anemia', 'ginjal', 'hipotensi', 'hati', 'led'];
    const pakaiDiet = urutDiet.filter(k => T.some(t => t.diet.includes(k)));
    let saran = butir.map((x, i) => `${i + 1}. ${x}`).join('\n');
    if (pakaiDiet.length) saran += '\n\n' + pakaiDiet.map(k => DIET[k]).join('\n\n');
    saran += '\n\n"Tiada Prestasi Tanpa Kesehatan"';

    /* ===== saran Kesan (status kebugaran) + alasannya — ditampilkan di balon panel; keputusan tetap dokter =====
     * Temporary unfit : risiko akut yang perlu ditangani dulu (TD ≥ 180/110, SpO2 < 92%, Hb < 8, trombosit < 100 rb,
     *                   enzim hati > 3× batas).
     * Fit with restriction : HT derajat 2, anemia sedang (Hb 8–<10), buta warna.
     * Fit to work     : selain itu (temuan ringan/terkendali ditindaklanjuti lewat saran).
     * Permanent unfit : tidak pernah disarankan otomatis — butuh penilaian menyeluruh & konteks pekerjaan. */
    const bermakna = T.filter(t => t.berat === 'bermakna');
    const hbN = nilai(lab, 'hb'), trN = nilai(lab, 'trombo'), [, hiOt2] = batas('sgot', jk, lab), [, hiPt2] = batas('sgpt', jk, lab);
    const tu = [], fr = [];
    if (s >= 180 || di >= 110) tu.push(`tekanan darah ${s}/${di} mmHg sangat tinggi dan berisiko kegawatan bila bekerja sebelum ditangani`);
    if (spo2 && spo2 < 92) tu.push(`saturasi oksigen ${spo2}% perlu dievaluasi sebelum bekerja`);
    if (hbN < 8) tu.push(`anemia berat (Hb ${k1(hbN)} g/dL) sangat menurunkan toleransi kerja`);
    if (trN < 100000) tu.push(`trombosit ${ribuan(trN)}/µL meningkatkan risiko perdarahan`);
    if (ot > 3 * hiOt2 || pt > 3 * hiPt2) tu.push('enzim hati lebih dari tiga kali batas normal perlu dicari penyebabnya lebih dulu');
    if ((s >= 160 || di >= 100) && !(s >= 180 || di >= 110)) fr.push('hipertensi derajat 2 sebaiknya terkontrol dulu sebelum pekerjaan fisik berat, shift malam, atau bekerja di ketinggian');
    if (hbN >= 8 && hbN < 10) fr.push(`anemia sedang (Hb ${k1(hbN)} g/dL) menurunkan toleransi kerja fisik berat sampai Hb membaik`);
    if (d.butaWarna === true) fr.push('buta warna membatasi pekerjaan yang menuntut pembedaan warna (instalasi listrik, laboratorium, mengemudi kendaraan dinas)');
    let rekom;
    if (tu.length) rekom = { nilai: 'Temporary unfit', alasan: kapital(gabung(tu)) + '. Kesan dapat dinilai ulang setelah kondisi tertangani.' };
    else if (fr.length) rekom = { nilai: 'Fit with restriction', alasan: kapital(gabung(fr)) + '. Temuan lain ditindaklanjuti lewat saran.' };
    else if (!T.length) rekom = { nilai: 'Fit to work', alasan: `Tanda vital dan pemeriksaan fisik${adaLab ? ', serta seluruh hasil laboratorium,' : ''} dalam batas normal.` };
    else {
      const kecil = n => /^[A-Z][a-z]/.test(n) ? n[0].toLowerCase() + n.slice(1) : n;        // "Obesitas II" → "obesitas II" (singkatan tetap kapital)
      const perlu = bermakna.map(t => kecil(t.nama)), ringan = T.filter(t => t.berat !== 'bermakna').map(t => kecil(t.nama));
      rekom = { nilai: 'Fit to work', alasan: (ringan.length ? `${kapital(gabung(ringan))} bersifat ringan dan dapat diperbaiki dengan perubahan gaya hidup tanpa membatasi pekerjaan. ` : '')
        + (perlu.length ? `${kapital(gabung(perlu))} perlu dikonfirmasi dan ditangani, namun tidak membatasi kemampuan bekerja selama tidak ada keluhan. ` : '')
        + 'Semuanya ditindaklanjuti lewat saran di atas.' };
    }
    if (!adaLab) rekom.alasan += ' Hasil laboratorium belum ada, jadi saran ini bisa berubah.';
    rekom.dasar = [...tu, ...fr].length ? T.filter(t => t.berat === 'bermakna').map(t => t.nama) : T.map(t => t.nama);
    /* ditulis otomatis hanya bila tidak ada temuan bermakna dan sarannya Fit to work */
    const kesan = !bermakna.length && rekom.nilai === 'Fit to work' ? { nilai: 'Fit to work', keterangan: KESAN['Fit to work'] } : null;

    /* versi ringkas — C-CARE gagal menyimpan (Error 500) bila Rekomendasi terlalu panjang; mcu.js memilih tingkat yang muat */
    const kalimatPertama = k => { const m = k.match(/^.*?[^\d]\.(\s|$)|^.*?;/); return (m ? m[0] : k).replace(/[;\s]+$/, '').replace(/([^.])$/, '$1.'); };
    const ringkasBaris = arr => arr.map(t => '- ' + kalimatPertama(t.kalimat)).join('\n');
    const interpretasiFisikSingkat = fisik.length ? ringkasBaris(fisik) : 'Pemeriksaan fisik dan tanda vital dalam batas normal.';
    const interpretasiLabSingkat = adaLab ? [ringkasBaris(labT), okLab.length ? `- ${kapital(gabung(okLab))} dalam batas normal.` : '', tipis.length ? barisTipis : ''].filter(Boolean).join('\n') : '';
    const butirTeks = butir.map((x, i) => `${i + 1}. ${x}`).join('\n');
    const penutup = '\n\n"Tiada Prestasi Tanpa Kesehatan"';
    const saranDietSatuBaris = butirTeks + (pakaiDiet.length ? '\n\n' + pakaiDiet.map(k => DIET_SINGKAT[k]).join('\n') : '') + penutup;
    const saranDietJudul = butirTeks + (pakaiDiet.length ? '\n\nPola makan: ' + gabung(pakaiDiet.map(k => DIET_JUDUL[k])) + ' (rincian bersama Ahli Gizi).' : '') + penutup;

    /* keterangan parameter untuk baris Diagnosa: "Prediabetes (GDP 109 mg/dL, HbA1c 6,2%)" — gaya Hasil MCU klinik */
    const polos = x => x.replace(/\s*\((tinggi|sangat tinggi|batas atas|rendah|di atas rujukan|di bawah rujukan)\)/g, '');
    const KET = {
      hb: () => `Hb ${k1(nilai(lab, 'hb'))} g/dL`, leuko: () => `leukosit ${ribuan(nilai(lab, 'leuko'))}/µL`, trombo: () => `trombosit ${ribuan(nilai(lab, 'trombo'))}/µL`,
      led: () => `LED ${k1(nilai(lab, 'led'))} mm/jam`,
      gula: () => [gdp >= 100 && `GDP ${k1(gdp)} mg/dL`, gds >= 200 && `GDS ${k1(gds)} mg/dL`, a1c >= 5.7 && `HbA1c ${k1(a1c)}%`].filter(Boolean).join(', '),
      lemak: () => lemak.map(polos).join(', '), au: () => `asam urat ${k1(nilai(lab, 'au'))} mg/dL`, ginjal: () => ginjal.join(', '), hati: () => hati.join(', '),
      darahlain: () => lain.map(polos).join(', '), bj: () => `BJ ${bj.toFixed(3).replace('.', ',')}`,
    };
    T.forEach(t => { t.ket = KET[t.kode] ? KET[t.kode]() : (lab[t.kode] && lab[t.kode].teks ? lab[t.kode].teks.toLowerCase() : ''); });
    const diagnosa = ['Medical check up'].concat(T.map(t => t.nama)).join('\n');
    return { tipis, temuan: T, bermakna, interpretasiLab, interpretasiFisik, adaLab, saran, kesan, rekom, diagnosa, interpretasiFisikSingkat, interpretasiLabSingkat, saranDietSatuBaris, saranDietJudul };
  }

  const KESAN = {
    'Fit to work': 'Peserta dinyatakan dalam keadaan sehat dan aman untuk melakukan pekerjaannya.',
    'Fit with restriction': 'Peserta dinyatakan dalam kondisi sehat untuk melakukan suatu pekerjaan, tetapi terdapat batasan-batasan dalam pekerjaan yang ditentukan oleh perusahaan agar tidak memengaruhi kesehatannya.',
    'Temporary unfit': 'Peserta dinyatakan memiliki gangguan kesehatan yang berisiko memengaruhi pekerjaannya, tetapi masih dapat membaik bila ditangani.',
    'Permanent unfit': 'Peserta dinyatakan tidak dapat melakukan pekerjaan karena berisiko menimbulkan bahaya, baik bagi diri karyawan itu sendiri atau bagi pekerja lain di lingkungan kerjanya.',
  };

  /* blok diet — isi dari template MCU klinik (dr. Arijal, 11 Nov 2026), salah ketik kecil dirapikan */
  const DIET = {
    garam: `Diet rendah garam untuk hipertensi:
- Kurangi asupan garam (maksimal 5 g atau 1 sdt/hari) dan natrium "tersembunyi" seperti makanan cepat saji, makanan kemasan, makanan kaleng dan makanan yang diawetkan dengan garam, saus, kecap, mayones, vetsin, dan bumbu instan.
- Kurangi asupan lemak jenuh dan kolesterol seperti jeroan (hati, jantung, paru), margarin, mentega, krim, keju, dan minyak kelapa.
- Perbanyak konsumsi sayur dan buah.`,
    gula: `Diet rendah gula untuk hiperglikemia (prediabetes/diabetes):
- Perbanyak makanan tinggi antioksidan dan serat seperti buah dan sayuran.
- Pilih makanan dengan indeks glikemik rendah seperti kentang, sereal, singkong, gandum, jagung, telur, yogurt, susu skim, susu murni, susu kedelai, sayuran segar (wortel, kembang kol, bayam, selada, tomat, brokoli) dan buah-buahan (apel, pir, beri, jeruk, kiwi).
- Kurangi porsi nasi putih, perbanyak protein tanpa lemak seperti dada ayam atau ikan.
- Hindari makanan dan minuman manis seperti kue manis dan minuman kemasan.`,
    lemak: `Diet rendah lemak untuk hiperkolesterolemia/hipertrigliseridemia:
- Perbanyak buah-buahan (pisang, apel, jeruk) dan sayur-sayuran (wortel, kacang panjang, buncis).
- Konsumsi protein rendah lemak seperti ikan, ayam (tanpa kulit), telur, serta susu rendah lemak.
- Gunakan minyak sehat seperti minyak zaitun atau minyak biji-bijian.
- Hindari daging berlemak, gorengan, makanan kaleng, makanan instan, makanan tinggi gula dan garam, mentega dan minyak kelapa, serta alkohol.`,
    purin: `Diet rendah purin untuk hiperurisemia:
- Perbanyak protein rendah purin seperti ikan, ayam, dan telur, serta sayur dan buah-buahan.
- Pilih minyak sehat seperti minyak zaitun atau minyak biji-bijian.
- Hindari daging merah (sapi, kambing), organ dalam (hati, ginjal), makanan laut (udang dan kerang), makanan instan, makanan tinggi gula dan garam.
- Perbanyak konsumsi air putih.`,
    anemia: `Diet tinggi protein untuk anemia defisiensi zat besi:
- Perbanyak makanan sumber zat besi heme dan non-heme: daging (sapi, domba) dan unggas (ayam, itik, bebek); hati sapi atau hati ayam; telur; seafood (ikan, kerang, udang); sayuran hijau pekat (bayam, sawi hijau, brokoli, kangkung, kale, daun katuk, daun singkong); kacang-kacangan (kacang merah, kedelai, almond, kacang polong, mete, pistachio) beserta tahu dan tempe; biji-bijian (biji bunga matahari, biji labu kuning).
- Konsumsi sumber vitamin C yang membantu penyerapan zat besi, seperti jeruk, lemon, jeruk nipis, stroberi, melon, paprika, tomat, dan jambu biji.
- Hindari teh (tanin), kopi (kafein), serta makanan/minuman tinggi kalsium (susu, kasein, whey, protein kedelai, produk terfortifikasi kalsium) bersamaan dengan makanan sumber zat besi.`,
    ginjal: `Diet protein rendah untuk gangguan fungsi ginjal (non-hemodialisis):
- Dianjurkan: sumber karbohidrat (nasi, mi, bihun, jagung, makaroni, roti, tepung-tepungan, gula, madu, sirup); protein hewani secukupnya (ayam, ikan, telur, hati, susu, daging tanpa lemak); sayur rendah kalium (asparagus, brokoli, kubis, kembang kol, seledri, timun, labu kuning, labu siam, lobak, jamur putih); buah rendah kalium (apel, jeruk bali, anggur, pir, persik, beri, nanas, plum, semangka).
- Dibatasi: karbohidrat kompleks (kentang, ubi, singkong); protein hewani berlemak (daging berlemak, sarden, jeroan); protein nabati tinggi kalium (kacang-kacangan dan olahannya); makanan/minuman kaleng dan yang diawetkan dengan garam (sosis, ham, kornet, ikan asin, daging asap, dendeng, telur asin, bumbu instan, vetsin/MSG, soda kue).
- Bila kalium darah tinggi, batasi peterseli, buncis, bayam, daun pepaya muda, apel, alpukat, jeruk, pisang, dan pepaya.`,
    hipotensi: `Diet untuk hipotensi:
- Makanan tinggi vitamin B12: telur, daging sapi/ayam/kambing tanpa lemak, hati sapi, hati ayam, kerang, yogurt, susu rendah lemak, sereal yang diperkaya vitamin B12.
- Makanan tinggi folat: sayuran hijau (bayam, brokoli, timun, asparagus), kacang-kacangan (mete, kacang polong, almond), biji-bijian, dan buah (pepaya, pisang, alpukat, bit).
- Garam cukup, sekitar 4,5–5 g (1 sdt) per hari.
- Buah yang banyak mengandung air seperti semangka dan jeruk; minum air putih minimal 8 gelas per hari.
- Minuman berkafein (kopi, cokelat, teh) secukupnya sesuai kebutuhan.`,
    hati: `Diet untuk gangguan fungsi hati (SGOT/SGPT meningkat):
- Perbanyak buah tinggi antioksidan dan polifenol (apel, beri, anggur), sayur (brokoli, bayam), biji-bijian utuh (oatmeal), dan karbohidrat kompleks (nasi merah, kentang rebus, roti gandum).
- Pilih protein yang mudah dicerna: putih telur, ikan (salmon, tuna), dada ayam tanpa kulit, tahu, tempe.
- Batasi makanan tinggi gula, pemanis buatan, dan garam/natrium.
- Batasi makanan tinggi lemak: daging merah berlemak, santan, jeroan, kulit ayam, makanan cepat saji.
- Hindari makanan yang menimbulkan gas (ubi, kacang merah, kol, sawi, lobak, ketimun, durian, nangka) serta alkohol, kopi kental, dan minuman bersoda.`,
    led: `Diet untuk LED meningkat:
- Dianjurkan: makanan kaya vitamin C (jeruk, stroberi, blueberry, raspberry, kiwi, jambu biji, pisang, alpukat, brokoli, kale), vitamin E (almond, biji bunga matahari, bayam), omega-3 (minyak ikan, salmon, tuna, makarel, sarden, chia seed), karbohidrat kompleks (nasi merah, oatmeal), rempah alami (kunyit, jahe, bawang putih), dan minyak zaitun.
- Dihindari: makanan tinggi gula (sirup, minuman bersoda, kue manis, pemanis buatan), lemak trans dan jenuh (gorengan, makanan cepat saji, margarin, jeroan, sosis/nugget/kornet/daging asap), makanan tinggi natrium (ikan asin, telur asin, makanan kaleng, vetsin, bumbu instan, saus, kecap, mayones), serta minuman beralkohol.`,
    gizi: `Pengaturan pola makan untuk berat badan:
- Atur porsi makan dengan prinsip "Isi Piringku": setengah piring sayur dan buah, seperempat lauk berprotein, seperempat makanan pokok.
- Batasi gorengan, makanan manis, dan camilan tinggi kalori; utamakan makanan direbus, dikukus, atau dipanggang.`,
  };

  const DIET_SINGKAT = {
    gizi: '- Berat badan: atur porsi "Isi Piringku" (½ piring sayur & buah), batasi gorengan, makanan manis, dan camilan.',
    garam: '- Rendah garam: maks. 1 sdt/hari; kurangi makanan kemasan/kaleng, saus, kecap, MSG, jeroan, dan santan.',
    gula: '- Rendah gula: perbanyak sayur & buah berserat, pilih indeks glikemik rendah, kurangi nasi putih, hindari makanan/minuman manis.',
    lemak: '- Rendah lemak: pilih ikan, ayam tanpa kulit, susu rendah lemak; hindari gorengan, daging berlemak, makanan instan, alkohol.',
    purin: '- Rendah purin: hindari jeroan, daging merah, udang/kerang, makanan instan; perbanyak air putih.',
    anemia: '- Tinggi zat besi: daging, hati, telur, ikan, sayur hijau, kacang-kacangan + vitamin C; jangan bersamaan dengan teh/kopi/susu.',
    ginjal: '- Protein rendah (ginjal): protein secukupnya, batasi makanan tinggi garam/kalium dan makanan awetan.',
    hipotensi: '- Hipotensi: cukupi cairan (≥ 8 gelas/hari), garam cukup, makanan tinggi vitamin B12 & folat.',
    hati: '- Fungsi hati: perbanyak sayur, buah, biji-bijian utuh; batasi lemak, gula, garam; hindari alkohol, kopi kental, soda.',
    led: '- LED meningkat: perbanyak buah sayur kaya vitamin C/E, ikan berminyak; hindari gula, gorengan, makanan olahan, alkohol.',
  };
  const DIET_JUDUL = { gizi: 'pengaturan berat badan', garam: 'rendah garam', gula: 'rendah gula', lemak: 'rendah lemak', purin: 'rendah purin', anemia: 'tinggi zat besi', ginjal: 'protein rendah', hipotensi: 'diet hipotensi', hati: 'diet fungsi hati', led: 'anti-peradangan' };

  /* ---------- pembaca hasil lab dari teks bebas / sel tabel ---------- */
  const PARAM = [
    ['hb', /h(a)?emoglobin|\bhgb\b|^hb\b/i], ['leuko', /^(jumlah\s+)?(leukosit|lekosit)\b|\bwbc\b/i], ['ht', /h(a)?ematokrit|\bhct\b/i],
    ['trombo', /trombosit|\bplt\b/i], ['led', /^led\b|laju endap/i], ['gdp', /glukosa\s+puasa|gula\s+darah\s+puasa|\bgdp\b/i],
    ['gds', /glukosa\s+sewaktu|gula\s+darah\s+sewaktu|\bgds\b/i], ['hba1c', /hba1c/i], ['kol', /kolesterol\s+total|cholesterol\s+total|^kolesterol\b(?!.*(hdl|ldl))/i],
    ['hdl', /\bhdl\b/i], ['ldl', /\bldl\b/i], ['tg', /trigliserid|triglycerid/i], ['au', /asam\s+urat|uric/i],
    ['ureum', /^ureum|\bbun\b/i], ['kreat', /kreatinin|creatinin/i], ['sgot', /sgot|\bast\b/i], ['sgpt', /sgpt|\balt\b/i],
    ['eri', /^eritrosit|\brbc\b/i], ['neut', /netrofil|neutrofil|segmen/i], ['limfo', /limfosit|lymph/i], ['mono', /monosit|mono/i],
    ['eos', /eosinofil|eos/i], ['baso', /basofil|baso/i], ['mchc', /\bmchc\b/i], ['mch', /\bmch\b/i], ['mcv', /\bmcv\b/i],
  ];
  /* urinalisa (hanya dikenali di bawah judul "Urinalisa"/"Urin", atau bila nama memuat kata urin) */
  const PARAM_URIN = [['bj', /^bj\b|berat\s+jenis/i], ['uph', /^ph\b/i], ['uprot', /^protein/i], ['uglu', /^glukosa|^reduksi/i], ['ublood', /darah\s+samar|^blood|^eritrosit/i],
    ['uleu', /^leukosit|^lekosit/i], ['uket', /^keton/i], ['unit', /^nitrit/i], ['ubil', /^bilirubin/i], ['uuro', /^urobilinogen/i], ['uwarna', /^warna/i], ['ukeruh', /^kekeruhan|^kejernihan/i]];
  const bersihAngka = t => { const m = String(t || '').match(/[<>]?\s*\d+(?:[.,]\d+)?/); if (!m) return NaN; let x = m[0].replace(/[<>\s]/g, '');
    if (/^\d{1,3}\.\d{3}$/.test(x)) x = x.replace('.', ''); return angka(x); };       // 7.500 → 7500 (ribuan)
  /* "L: 14 - 16 ; P: 12 - 14 g/dl" → ambil bagian sesuai jenis kelamin; "a - b", "< x", "> x" */
  function rujukan(t, jk) {
    let r = String(t || '');
    /* pemisah L/P bisa ";" (halaman C-CARE) atau "," (cetakan PDF: "L : 14-16, P : 12-14 g/dl"); "-40" = "< 40" */
    const seg = r.split(/;|,\s*(?=[LP]\s*:)/).map(x => x.trim()).find(x => new RegExp('^' + (jk === 'P' ? 'P' : 'L') + '\\s*:', 'i').test(x));
    if (seg) r = seg; r = r.replace(/^[LP]\s*:\s*/i, '');
    const sd = r.match(/^-\s*(\d+[.,]?\d*)/); if (sd) return { atas: angka(sd[1]) };
    const a = r.match(/(\d+[.,]?\d*)\s*[-–]\s*(\d+[.,]?\d*)/); if (a) return { bawah: bersihAngka(a[1]), atas: bersihAngka(a[2]) };
    const lt = r.match(/<\s*=?\s*(\d+[.,]?\d*)/); if (lt) return { atas: angka(lt[1]) };
    const gt = r.match(/>\s*=?\s*(\d+[.,]?\d*)/); if (gt) return { bawah: angka(gt[1]) };
    return {};
  }
  /* baris dari tabel C-CARE ("Nama | Hasil | Nilai Normal") atau tempelan bebas ("Nama  nilai  satuan  rujukan").
   * Kemunculan pertama tiap parameter yang dipakai; parameter tanpa hasil dilewati. */
  function bacaLab(teks, jk) {
    const lab = {}; let bagian = '';
    String(teks || '').split(/\n/).forEach(b => {
      const baris = b.replace(/\t/g, ' | ').replace(/\s{2,}(?=\S)/g, ' | ').trim(); if (!baris) return;
      const sel = baris.split('|').map(x => x.trim()).filter((x, i, a) => x || i < a.length - 1);
      if (sel.length === 1 && !/\d/.test(sel[0])) { bagian = /urin/i.test(sel[0]) ? 'urin' : ''; return; }      // judul kelompok
      const nama = sel[0], urin = bagian === 'urin' || /\burin/i.test(nama);
      const p = urin ? PARAM_URIN.find(([k, re]) => !lab[k] && re.test(nama.replace(/\burin(e)?\b/i, '').trim()))
                     : PARAM.find(([k, re]) => !lab[k] && re.test(nama)); if (!p) return;
      let hasilTeks, rujTeks;
      if (sel.length >= 2) { hasilTeks = sel[1]; rujTeks = sel.slice(2).join(' '); }
      else { const sisa = nama.replace(p[1], ' ').trim(), k = sisa.search(/\b[LP]\s*:|\d+[.,]?\d*\s*[-–]\s*\d|[<>]\s*\d/);
        const m = sisa.match(/^[^\d<>]*([<>]?\s*\d+(?:[.,]\d+)?)/); if (!m || (k >= 0 && sisa.indexOf(m[1]) >= k)) return;
        hasilTeks = sisa.slice(0, sisa.indexOf(m[1]) + m[1].length + 12); rujTeks = k >= 0 ? sisa.slice(k) : ''; }
      if (!String(hasilTeks).trim() || /^[-–]$/.test(String(hasilTeks).trim())) return;
      const x = {};
      if (urin && !['bj', 'uph'].includes(p[0])) {                                                   // hasil kualitatif: Negatif / Positif / +1
        x.teks = hasilTeks.trim(); x.positif = /positif|\+|pos\b|trace|\b[1-4]\+/i.test(x.teks) && !/negatif|neg\b/i.test(x.teks);
        if (p[0] === 'uleu' || p[0] === 'ublood') { const n = x.teks.match(/(\d+)\s*[-–]\s*(\d+)/); if (n && +n[2] > 5) x.positif = true; else if (n) x.positif = false; }
      } else {
        let v = bersihAngka(hasilTeks); if (isNaN(v)) return;
        if (p[0] === 'leuko' && v < 100) v *= 1000;                                   // 7,5 ×10³/µL
        if (p[0] === 'trombo' && v < 2000) v *= 1000;
        if (p[0] === 'bj' && v > 100) v /= 1000;                                      // "1.030" bukan seribu tiga puluh
        x.v = v; const r = rujukan(rujTeks, jk);
        ['bawah', 'atas'].forEach(k => { if (!isNaN(r[k])) { let n = r[k]; if (p[0] === 'leuko' && n < 100) n *= 1000; if (p[0] === 'trombo' && n < 2000) n *= 1000; if (p[0] === 'bj' && n > 100) n /= 1000; x[k] = n; } });
        const tanda = String(hasilTeks).replace(/\S*\/\S*/g, ' ').replace(/[<>]?\s*\d+(?:[.,]\d+)?/, ' ');
        if (/\b(H|HH|tinggi)\b|\*/.test(tanda)) x.tinggi = true;
        if (/\b(LL|rendah)\b|\(L\)|\bL$/.test(tanda.trim())) x.rendah = true;
      }
      lab[p[0]] = x;
    });
    return lab;
  }

  const api = { susun, bacaLab, bacaVisus, KESAN, DIET, kapital };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.MCU_SARAN = api;
})(typeof self !== 'undefined' ? self : this);
