/* Scan Jasa C-CARE — balon (arah C: strip angka + bilah aksi tetap). Pekerjaan scan berjalan di latar. */
const $ = id => document.getElementById(id);
const hariIni = () => new Date(Date.now() + 7 * 36e5).toISOString().slice(0, 10);
const geser = (t, n) => { const d = new Date(t + 'T00:00:00Z'); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };
const awalPeriode = (t, mulai = 3) => { const [y, m, d] = t.split('-').map(Number); return new Date(Date.UTC(y, m - 1 - (d < mulai ? 1 : 0), mulai)).toISOString().slice(0, 10); };
const hari = t => ['Min', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab'][new Date(t + 'T00:00:00Z').getUTCDay()];
const tglId = t => t.split('-').reverse().join('/');
const tglPendek = t => t.slice(8) + '/' + t.slice(5, 7);
const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const kirimPesan = m => new Promise(r => chrome.runtime.sendMessage(m, r));
const IK = {
  ok: '<svg viewBox="0 0 24 24"><path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm-2 15-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg>',
  galat: '<svg viewBox="0 0 24 24"><path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/></svg>',
  awas: '<svg viewBox="0 0 24 24"><path d="M1 21h22L12 2 1 21zm12-3h-2v-2h2v2zm0-4h-2v-4h2v4z"/></svg>',
  info: '<svg viewBox="0 0 24 24"><path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/></svg>',
  jalan: '<svg viewBox="0 0 24 24"><path d="M12 4V1L8 5l4 4V6a6 6 0 0 1 5.66 8l1.46 1.46A8 8 0 0 0 12 4zm0 14a6 6 0 0 1-5.66-8L4.88 8.54A8 8 0 0 0 12 20v3l4-4-4-4v3z"/></svg>',
  tunda: '<svg viewBox="0 0 24 24"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/></svg>',
};
const pesan = (el, jenis, teks) => { el.className = 'pesan ' + jenis; el.innerHTML = IK[jenis] + '<span>' + esc(teks) + '</span>'; el.hidden = !teks; };
// kalimat utama (kabar baik/buruk) + catatan kecil di bawahnya: info = abu-abu, awas = kuning
const pesanCatatan = (el, jenis, teks, catatan) => {
  pesan(el, jenis, teks);
  if (catatan && catatan.length) el.insertAdjacentHTML('beforeend', '<ul class="cat-list">' +
    catatan.map(([j, t]) => `<li class="${j === 'awas' ? 'awas' : 'info'}">${IK[j === 'awas' ? 'awas' : 'info']}<span>${esc(t)}</span></li>`).join('') + '</ul>');
};
const ST = { siap: ['ok', 'Siap'], jalan: ['jalan', 'Memindai'], tunda: ['tunda', 'Ditunda'], selesai: ['ok', 'Selesai'], henti: ['awas', 'Dihentikan'], galat: ['galat', 'Gagal'], mati: ['tunda', 'Scan mati'] };
function strip(k1, n1, k2, n2, st) {
  $('k1').textContent = k1; $('n1').textContent = n1; $('k2').textContent = k2; $('n2').textContent = n2;
  $('st').className = 'st ' + st; $('st').innerHTML = IK[ST[st][0]] + ST[st][1];
}
function tombol(...tampil) { ['fInfo', 'kirimTgl', 'mulai', 'stop', 'fSela', 'tunda', 'lanjut', 'baru', 'kirim'].forEach(id => $(id).hidden = !tampil.includes(id)); }

$('atur').onclick = () => chrome.runtime.openOptionsPage();
$('lihatLog').onclick = () => chrome.tabs.create({ url: chrome.runtime.getURL('pengaturan.html#log') });

/* ---------- kalender periode (tgl 3 s.d. 2) ---------- */
const IK_KAL = {
  kirim: '<svg viewBox="0 0 24 24"><path d="M9 16.2 4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4z"/></svg>',
  scan: '<svg viewBox="0 0 24 24"><path d="M5 20h14v-2H5v2zm7-18-7 7h4v6h6V9h4z"/></svg>',
  jalan: IK.jalan,
};
const BULAN = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
const BLN = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
let geserPeriode = 0;                 // 0 = periode berjalan, -1 = periode lalu, …
let pilih = new Set();
const periodeKe = n => { const a = awalPeriode(hariIni()); const [y, m] = a.split('-').map(Number); const d = new Date(Date.UTC(y, m - 1 + n, 3)); const s = d.toISOString().slice(0, 10); const e = new Date(Date.UTC(y, m + n, 2)).toISOString().slice(0, 10); return [s, e]; };
const peta = () => petaLibur(simpanan.liburTambahan);
function statusTanggal(t) {
  const j = simpanan.job;
  if (j && (j.status === 'jalan' || j.status === 'tunda')) {
    const i = j.daftar.indexOf(t);
    if (i === j.idx) return 'jalan';
    if (i > j.idx) return 'antre';
  }
  const s = (simpanan.statusTgl || {})[t];
  return s ? s.st : '';
}
function gambarKalender(bisaPilih) {
  const [awal, akhir] = periodeKe(geserPeriode), h = hariIni(), pl = peta();
  $('kalJudul').textContent = `${BULAN[+awal.slice(5, 7) - 1]} ${awal.slice(0, 4)} · 3 ${BLN[+awal.slice(5, 7) - 1]} – 2 ${BLN[+akhir.slice(5, 7) - 1]}`;
  $('kalMaju').disabled = geserPeriode >= 0;
  let html = ['Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab', 'Min'].map((x, i) => `<span class="dw${i === 6 ? ' mg' : ''}">${x}</span>`).join('');
  const mulai = geser(awal, -((new Date(awal + 'T00:00:00Z').getUTCDay() + 6) % 7));
  for (let t = mulai; t <= akhir || (new Date(t + 'T00:00:00Z').getUTCDay() !== 1); t = geser(t, 1)) {
    if (t < awal || t > akhir) { html += '<span class="c kosong"></span>'; continue; }
    const libur = alasanLibur(t, pl), st = statusTanggal(t), depan = t > h;
    const k = ['c'];
    if (depan) k.push('depan'); else if (libur && !st) k.push('libur'); else if (st) k.push(st);
    if (bisaPilih && pilih.has(t)) k.push('pilih');
    if (t === h) k.push('hariini');
    const sx = (simpanan.statusTgl || {})[t];
    const tutup = liburTutup(t, pl);
    const judul = `${hari(t)}, ${tglId(t)}` + (libur ? ` · ${libur}` + (tutup ? ' — dikecualikan, tidak dipilih otomatis' : ' — klinik bisa buka, tetap bisa discan') : '') +
      (st === 'kirim' ? ` · di Sheet: ${sx.pasien} pasien` + (sx.sumber ? ` (${sx.sumber})` : '') : st === 'scan' ? ` · discan ${sx.pasien} pasien, belum dikirim` + ((simpanan.belumKirim || {})[t] ? ' — pilih lalu tekan Kirim' : ' — scan ulang untuk mengirim') : st === 'jalan' ? ' · sedang discan' : st === 'antre' ? ' · menunggu giliran' : depan ? ' · belum lewat' : ' · belum discan');
    const mati = !bisaPilih || depan;
    html += `<button class="${k.join(' ')}" data-t="${t}" title="${esc(judul)}" aria-label="${esc(judul)}" aria-pressed="${pilih.has(t)}"${mati ? ' disabled' : ''}><em>${+t.slice(8)}</em>${IK_KAL[st] || ''}</button>`;
  }
  $('kal').innerHTML = html;
  $('kal').querySelectorAll('button.c:not([disabled])').forEach(b => b.onclick = () => { const t = b.dataset.t; pilih.has(t) ? pilih.delete(t) : pilih.add(t); simpanPilihan(); gambarKalender(true); infoPilihan(); });
}
function simpanPilihan() { chrome.storage.local.set({ pilihanTgl: [...pilih] }); }
function infoPilihan() {
  const L = [...pilih].sort();
  $('fInfo').textContent = !L.length ? 'Klik tanggal di kalender' : L.length === 1 ? `${hari(L[0])}, ${tglId(L[0])}` : `${L.length} tanggal dipilih · ${tglPendek(L[0])}–${tglPendek(L[L.length - 1])}`;
  $('mulai').disabled = !L.length;
  const bk = simpanan.belumKirim || {}, siapKirim = L.filter(t => bk[t]);
  $('kirimTgl').hidden = !siapKirim.length || !$('fInfo').isConnected || $('mulai').hidden;
  $('labelKirimTgl').textContent = siapKirim.length > 1 ? `Kirim ${siapKirim.length}` : 'Kirim';
}
$('kalMundur').onclick = () => { geserPeriode--; gambarKalender(true); };
$('kalMaju').onclick = () => { if (geserPeriode < 0) geserPeriode++; gambarKalender(true); };
document.querySelectorAll('#chips button').forEach(b => b.onclick = () => {
  const h = hariIni(), pl = peta(), [awal, akhir] = periodeKe(geserPeriode);
  const kerja = t => t <= h && !liburTutup(t, pl);
  if (b.dataset.c === 'bersih') pilih.clear();
  if (b.dataset.c === 'hari') { geserPeriode = 0; pilih = new Set(kerja(h) ? [h] : []); }
  if (b.dataset.c === 'kemarin') { geserPeriode = 0; const k = geser(h, -1); pilih = new Set(kerja(k) ? [k] : []); }
  if (b.dataset.c === 'belum') { pilih = new Set(rentangTanggal(awal, akhir < h ? akhir : h).filter(t => kerja(t) && statusTanggal(t) !== 'kirim')); }
  simpanPilihan(); gambarKalender(true); infoPilihan();
});

/* ---------- tombol ---------- */
$('mulai').onclick = async () => {
  const tanggal = [...pilih].sort();
  if (!tanggal.length) return;
  pesanSiap = null; $('mulai').disabled = true;
  const r = await kirimPesan({ aksi: 'mulai', tanggal });
  if (!r || !r.ok) { pesan($('galatSiap'), 'galat', (r && r.pesan) || 'Gagal memulai.'); $('mulai').disabled = false; }
};
$('tunda').onclick = () => kirimPesan({ aksi: 'tunda' });
$('lanjut').onclick = () => kirimPesan({ aksi: 'lanjut' });
$('stop').onclick = () => kirimPesan({ aksi: 'stop' });
$('kirimTgl').onclick = async () => {
  const bk = simpanan.belumKirim || {}, tanggal = [...pilih].filter(t => bk[t]).sort();
  if (!tanggal.length) return;
  $('kirimTgl').disabled = true; pesan($('galatSiap'), 'info', `Mengirim ${tanggal.length} tanggal ke Dashboard…`);
  const r = await kirimPesan({ aksi: 'kirimTanggal', tanggal });
  $('kirimTgl').disabled = false;
  pesanSiap = [r && r.ok ? (r.beda ? 'awas' : 'ok') : 'galat', (r && r.pesan) || 'Gagal mengirim.']; pesan($('galatSiap'), pesanSiap[0], pesanSiap[1]);
  if (r && r.ok) { tanggal.forEach(t => pilih.delete(t)); simpanPilihan(); gambarKalender(true); infoPilihan(); }
};
$('kirim').onclick = () => { $('kirim').disabled = true; kirimPesan({ aksi: 'kirim' }); };
$('baru').onclick = async () => { await kirimPesan({ aksi: 'tutupHasil' }); render(null); };

/* ---------- tampilan menurut status pekerjaan ---------- */
let simpanan = {}, pesanSiap = null;          // pesanSiap: hasil Kirim dari kalender, tetap tampil sampai aksi berikutnya
const total = L => (L || []).reduce((a, x) => a + x.pagi + x.siang + x.ugd + x.mcu + x.tele, 0);
function render(job) {
  const st = job ? job.status : 'siap';
  $('vKal').hidden = !(st === 'siap' || st === 'galat' || st === 'jalan' || st === 'tunda');
  $('chips').hidden = !(st === 'siap' || st === 'galat');
  $('vJalan').hidden = !(st === 'jalan' || st === 'tunda');
  $('vHasil').hidden = !(st === 'selesai' || st === 'henti');

  const mati = simpanan.scanAktif === false && (st === 'siap' || st === 'galat');
  $('vMati').hidden = !mati;
  tampilScan();
  if (mati) {
    $('vKal').hidden = true; $('galatSiap').hidden = true; $('lihatLog').hidden = true;
    const tk = simpanan.terakhirKirim;
    strip('Terakhir kirim', tk ? tglPendek(tk.tanggal) : '–', 'Pasien terakhir', tk ? tk.pasien : '–', 'mati');
    tombol('fInfo', 'mulai'); $('fInfo').textContent = 'Scan jasa mati'; $('mulai').disabled = true; $('kirimTgl').hidden = true;
    return;
  }
  if (st === 'siap' || st === 'galat') {
    const tk = simpanan.terakhirKirim;
    strip('Terakhir kirim', tk ? tglPendek(tk.tanggal) : '–', 'Pasien terakhir', tk ? tk.pasien : '–', st);
    if (st === 'galat') pesan($('galatSiap'), 'galat', job.pesan); else if (pesanSiap) pesan($('galatSiap'), pesanSiap[0], pesanSiap[1]); else $('galatSiap').hidden = true;
    $('lihatLog').hidden = st !== 'galat';
    tombol('fInfo', 'mulai'); gambarKalender(true); infoPilihan();
  }
  if (st === 'jalan' || st === 'tunda') {
    strip('Tanggal', `${job.idx} / ${job.daftar.length}`, 'Pasien Anda', total(job.sementara), st);
    $('vJalan').classList.toggle('tunda', st === 'tunda');
    $('bar').style.width = Math.min(99, Math.round(100 * (job.idx + Math.min(1, job.sub || 0)) / job.daftar.length)) + '%';
    pesan($('pesanJalan'), st === 'tunda' ? 'awas' : 'info', (job.otomatis ? 'Otomatis · ' : '') + job.pesan);
    tombol('stop', 'fSela', st === 'tunda' ? 'lanjut' : 'tunda'); gambarKalender(false);
  }
  if (st === 'selesai' || st === 'henti') {
    const h = job.hasil || { jumlah: [], catatan: {}, tanggal: [] };
    strip('Tanggal', `${h.tanggal.length} / ${job.daftar.length}`, 'Pasien Anda', total(h.jumlah), st);
    const peringatan = st === 'henti' || (job.dibaca && !h.jumlah.length);
    $('tbody').innerHTML = h.jumlah.length ? h.jumlah.map(x => `<tr><td>${hari(x.tanggal)}, ${tglId(x.tanggal)}</td><td>${x.pagi || ''}</td><td>${x.siang || ''}</td><td>${x.ugd || ''}</td><td>${x.mcu || ''}</td><td><b>${x.pagi + x.siang + x.ugd + x.mcu + x.tele}</b></td></tr>`).join('')
      : '<tr><td colspan="6" style="text-align:center;color:var(--teks-2)">Tidak ada pasien atas nama Anda.</td></tr>';
    const cat = Object.entries(h.catatan || {}).map(([t, c]) => `${tglPendek(t)}: ${c}`).join(' · ');
    if (job.pesanUtama) { $('catatan').hidden = true; pesanCatatan($('pesanHasil'), peringatan ? 'awas' : 'ok', job.pesanUtama, job.catatanHasil); }
    else { $('catatan').textContent = cat; $('catatan').hidden = !cat; pesan($('pesanHasil'), peringatan || job.tanpaDokter ? 'awas' : 'ok', job.pesan); }
    const k = job.kirim;
    if (!k) { $('pesanKirim').hidden = true; $('kirim').disabled = !h.tanggal.length; }
    else if (k.proses) { pesan($('pesanKirim'), 'info', 'Mengirim ke Dashboard…'); $('kirim').disabled = true; }
    else if (k.ok && k.utama) { pesanCatatan($('pesanKirim'), 'ok', k.utama, k.catatan); $('kirim').disabled = true; }
    else { pesan($('pesanKirim'), k.ok ? (k.beda ? 'awas' : 'ok') : 'galat', k.pesan); $('kirim').disabled = !!k.ok; }
    $('labelKirim').textContent = k && k.ok ? 'Terkirim' : 'Kirim ke Dashboard';
    tombol('baru', 'fSela', 'kirim');
  }
}

function subJudul() {
  const s = simpanan;
  $('sub').textContent = !s.nama ? 'Isi Nama dokter di Pengaturan' : s.nama;
}
/* v4.6.3: sakelar Scan jasa hanya di Pengaturan → Scan; saat mati, popup memberi tombol Nyalakan */
function tampilScan() {}
$('nyalakanScan').onclick = async () => {
  await chrome.storage.local.set({ scanAktif: true });
  kirimPesan({ aksi: 'simpanSetelanAkun' }); kirimPesan({ aksi: 'sinkronStatus', paksa: true });
};
const KUNCI = ['scanAktif', 'nama', 'otomatis', 'jamOtomatis', 'terakhirKirim', 'job', 'statusTgl', 'liburTambahan', 'pilihanTgl', 'belumKirim'];
chrome.storage.local.get(KUNCI, s => {
  simpanan = s; subJudul();
  const h = hariIni(), k = geser(h, -1);
  pilih = new Set((s.pilihanTgl || []).filter(t => t <= h));
  if (!s.pilihanTgl && !liburTutup(k, petaLibur(s.liburTambahan))) pilih.add(k);   // bawaan: kemarin
  render(s.job || null);
  kirimPesan({ aksi: 'pulihkanSetelan' }).then(() => kirimPesan({ aksi: 'sinkronStatus' }));   // pengaturan dari akun Chrome, lalu tanggal di Sheet
});
chrome.storage.onChanged.addListener((c, area) => {
  if (area !== 'local') return;
  Object.keys(c).forEach(k => { if (KUNCI.includes(k)) simpanan[k] = c[k].newValue; });
  if (c.nama || c.otomatis || c.jamOtomatis) subJudul();
  if (c.job || c.terakhirKirim || c.statusTgl || c.liburTambahan || c.belumKirim || c.scanAktif) render(simpanan.job || null);
});

/* sakelar utama Auto Fill (sama dengan Pengaturan → Auto Fill → Aktif): Mati = Auto Fill, Siap dipanggil, daftar ringkas, menu formulir berhenti */
function tampilAf(ic) { const on = !(ic || {}).mati; $('afSakelar').setAttribute('aria-checked', String(on)); $('afTeks').textContent = on ? 'Aktif' : 'Mati'; }
chrome.storage.local.get('isiCepat', s => tampilAf(s.isiCepat));
$('afSakelar').onclick = async () => {
  const { isiCepat = {} } = await chrome.storage.local.get('isiCepat');
  const baru = Object.assign({}, isiCepat, { mati: !isiCepat.mati });
  await chrome.storage.local.set({ isiCepat: baru }); tampilAf(baru);
};
chrome.storage.onChanged.addListener((u, a) => { if (a === 'local' && u.isiCepat) tampilAf(u.isiCepat.newValue); });

const siapTerkini = p => { const o = {}, bc = (p && p.baca) || {}, sl = (p && p.selesai) || {}, kini = Date.now(); Object.entries((p && p.siap) || {}).forEach(([k, x]) => { if (!sl[k] && kini - (bc[String(x.poli)] || 0) < 120000) o[k] = x; }); return o; };   // sama dengan pantau.js
/* status Siap dipanggil satu baris (titik + teks), dari detak pemantau */
async function tampilPantau() {
  const [{ isiCepat, pantau, pantauBaca: pb }, ses] = await Promise.all([chrome.storage.local.get(['isiCepat', 'pantau', 'pantauBaca']), chrome.storage.session ? chrome.storage.session.get('pantauDetak') : {}]);
  if (pantau && pb && pb.tanggal === pantau.tanggal) pantau.baca = Object.assign({}, pantau.baca, pb.baca);
  const d = ses && ses.pantauDetak, n = Object.keys(siapTerkini(pantau)).length, umur = d ? (Date.now() - d.waktu) / 1000 : 1e9;
  let k = '', t;
  if (isiCepat && isiCepat.mati) t = 'Mati — semua fitur berhenti';
  else if (!d || d.keadaan === 'tanpa-tab') t = 'Buka C-CARE untuk memantau pasien siap dipanggil';
  else if (d.keadaan === 'login') { k = 'awas'; t = 'C-CARE perlu login ulang'; }
  else if (d.keadaan === 'luar-jam') t = 'Di luar jam pantau (06.00–22.00 WIB)';
  else if (umur > 15) { k = 'galat'; t = 'Pemantau berhenti — muat ulang tab C-CARE'; }
  else { k = 'ok'; t = null; }
  $('titik').className = k;
  if (t) { $('pantauTeks').textContent = t; return; }
  $('pantauTeks').replaceChildren();
  if (n) { const b = document.createElement('b'); b.textContent = n; $('pantauTeks').append(b, ' pasien siap dipanggil · memantau'); }
  else $('pantauTeks').textContent = d.keadaan === 'sibuk' ? 'Memantau · menunggu Anda selesai mengetik' : d.keadaan === 'hemat' ? 'Memantau · mode hemat' : 'Memantau · belum ada pasien siap dipanggil';
}
tampilPantau(); setInterval(tampilPantau, 1000);
