/* Isi Cepat C-CARE — berjalan di halaman pemeriksaan dokter (…/Ubah/{id}).
 * 1) Anamnesa dokter: salin anamnesa perawat + riwayat alergi/penyakit/obat (bila ada), lalu "Rapikan" (lokal, tanpa internet).
 * 2) Template: isi isian dari template JSON (format ekspor ekstensi Autofill) — hanya isian yang masih kosong, kecuali diminta timpa.
 * 3) Otomatis saat CPPT dibuka: template C-CARE, TTV di kotak bawah Diagnosa, 3 baris obat, status Menunggu Obat; yang sudah berisi → tombol Timpa.
 * Tidak pernah menekan Simpan dan tidak mengirim data pasien ke mana pun. Yang tersimpan di ekstensi hanya template & pengaturan.
 */
(() => {
  if (window.__isiCepatCcare) return; window.__isiCepatCcare = true;
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const bersih = s => String(s == null ? '' : s).replace(/ /g, ' ').replace(/[ \t]+/g, ' ').trim();
  const kosong = v => !bersih(v) || /^[-–—.\s]*$/.test(String(v));
  const negatif = v => /^(tidak ada|tidak|tdk( ada)?|disangkal|negatif|nihil|belum ada|tak ada|\(?-\)?|none|no)\.?$/i.test(bersih(v));
  const ATUR = { autoSalin: true, bukaDiagnosa: true, template: [] };

  /* ---------- label sebuah isian / pasangan label–nilai di halaman ---------- */
  function labelIsian(el) {
    if (el.id) { const l = document.querySelector(`label[for="${CSS.escape(el.id)}"]`); if (l) return bersih(l.textContent); }
    const lb = el.closest('label'); if (lb && bersih(lb.textContent)) return bersih(lb.textContent);
    const tr = el.closest('tr'); if (tr && tr.cells.length >= 2 && !tr.cells[0].contains(el)) return bersih(tr.cells[0].textContent).replace(/\s*\*$/, '');
    const fg = el.closest('.form-group, .mb-3');
    if (fg) { const l = fg.querySelector('label, .control-label, .form-label'); if (l && !l.contains(el)) return bersih(l.textContent); }
    let p = el.previousElementSibling; while (p && !bersih(p.textContent)) p = p.previousElementSibling;
    if (p && p.textContent.length < 60) return bersih(p.textContent);
    return bersih(el.getAttribute('placeholder') || el.name || el.id || '');
  }
  const kunciIsian = el => (labelIsian(el) + ' ' + (el.name || '') + ' ' + (el.id || '')).toLowerCase();

  /* pasangan {label, nilai} dari sebuah dokumen: isian formulir + baris tabel 2 kolom + dt/dd + label/teks statis */
  function pasangan(doc, kecuali) {
    const out = [];
    $$('textarea, input:not([type=hidden]):not([type=checkbox]):not([type=radio]):not([type=button]):not([type=submit]), select', doc).forEach(el => {
      if (el === kecuali) return;
      const v = el.tagName === 'SELECT' ? (el.selectedOptions[0] ? el.selectedOptions[0].textContent : '') : el.value;
      if (!kosong(v)) out.push({ label: labelIsian(el), nama: el.name || el.id || '', nilai: String(v).trim(), ubah: !(el.disabled || el.readOnly) });
    });
    $$('tr', doc).forEach(tr => {
      if (tr.cells.length < 2 || tr.querySelector('input, textarea, select')) return;
      const l = bersih(tr.cells[0].textContent), v = (tr.cells[tr.cells.length === 3 && /^:$/.test(bersih(tr.cells[1].textContent)) ? 2 : 1].innerText || tr.cells[1].textContent || '').trim();
      if (l && l.length < 60 && !kosong(v)) out.push({ label: l, nama: '', nilai: v });
    });
    $$('dt', doc).forEach(dt => { const dd = dt.nextElementSibling; if (dd && dd.tagName === 'DD' && !kosong(dd.textContent)) out.push({ label: bersih(dt.textContent), nama: '', nilai: dd.textContent.trim() }); });
    $$('.form-control-static, .form-control-plaintext, p.form-control', doc).forEach(el => {
      const fg = el.closest('.form-group, .mb-3, .row'); const l = fg && fg.querySelector('label');
      if (l && !kosong(el.textContent)) out.push({ label: bersih(l.textContent), nama: '', nilai: el.textContent.trim() });
    });
    return out.sort((a, b) => (a.ubah ? 1 : 0) - (b.ubah ? 1 : 0));   // isian perawat biasanya terkunci/teks statis → didahulukan
  }

  /* ---------- anamnesa dokter ---------- */
  const RE = {
    perawat: /(anamnes[ae]s?|keluhan)\s*(perawat|bidan|awal|singkat)|anamnes[ae]s?_?perawat|keluhan\s*utama|^keluhan$/i,
    alergi: /alergi/i,
    penyakit: /riwayat\s*penyakit|penyakit\s*(dahulu|terdahulu|kronis|sebelumnya)/i,
    obat: /riwayat\s*(peng)?obat|penggunaan\s*obat|obat\s*(rutin|yang\s*sedang)|riwayat\s*pengobatan/i,
  };
  function isianDokter() {
    const cal = $$('textarea, input[type=text]').filter(el => !el.disabled && !el.readOnly);
    const skor = el => { const k = kunciIsian(el); let s = 0;
      if (/anamnes/i.test(k)) s += 2; if (/dokter|dr\b/i.test(k)) s += 3; if (/perawat|bidan|nurse|awal/i.test(k)) s -= 5;
      if (el.tagName === 'TEXTAREA') s += 1; return s; };
    return cal.map(el => [el, skor(el)]).filter(x => x[1] >= 2).sort((a, b) => b[1] - a[1]).map(x => x[0])[0] || null;
  }
  function idKunjungan() { const m = location.pathname.match(/(\d+)\/?$/); return m ? m[1] : ''; }
  async function dataPerawat(ta) {
    const pilih = (L, re, bukan) => (L.find(p => re.test(p.label + ' ' + p.nama) && !(bukan && bukan.test(p.label + ' ' + p.nama))) || {}).nilai || '';
    const ambil = L => ({ perawat: pilih(L, RE.perawat, /dokter/i), alergi: pilih(L, RE.alergi), penyakit: pilih(L, RE.penyakit), obat: pilih(L, RE.obat), sumber: '' });
    let d = ambil(pasangan(document, ta)); d.sumber = 'pengkajian perawat';
    // C-CARE IPB (diperiksa 28 Okt 2026): Keluhan, RiwayatAlergi, RiwayatPenyakit, RiwayatPengobatan (terkunci, diisi perawat)
    const n = id => { const el = document.getElementById(id); return el && !kosong(el.value) ? el.value.trim() : ''; };
    d.perawat = n('Keluhan') || d.perawat; d.alergi = n('RiwayatAlergi') || d.alergi; d.penyakit = n('RiwayatPenyakit') || d.penyakit; d.obat = n('RiwayatPengobatan') || d.obat;
    if (!d.perawat && idKunjungan()) {                          // belum ada di halaman → baca ringkasan kunjungan yang sama
      try {
        const h = await (await fetch('/RekapRekamMedis/Detail/' + idKunjungan(), { credentials: 'include' })).text();
        const doc = new DOMParser().parseFromString(h, 'text/html');
        if (!doc.querySelector('input[type=password]')) {
          const d2 = ambil(pasangan(doc, null));
          ['perawat', 'alergi', 'penyakit', 'obat'].forEach(k => { if (!d[k] && d2[k]) d[k] = d2[k]; });
          if (d2.perawat) d.sumber = 'ringkasan kunjungan';
        }
      } catch (e) { /* tetap pakai yang ada */ }
    }
    return d;
  }
  function susunAnamnesa(d) {
    const baris = [];
    if (d.perawat) baris.push(d.perawat.trim());
    if (d.alergi && !negatif(d.alergi)) baris.push('Riwayat alergi obat: ' + bersih(d.alergi));
    if (d.penyakit && !negatif(d.penyakit)) baris.push('Riwayat penyakit: ' + bersih(d.penyakit));
    if (d.obat && !negatif(d.obat)) baris.push('Riwayat pengobatan: ' + bersih(d.obat));
    return baris.join('\n');
  }

  /* ---------- Rapikan (lokal, tanpa AI/internet) ---------- */
  const SINGKAT = { yg: 'yang', dgn: 'dengan', dg: 'dengan', tdk: 'tidak', tak: 'tidak', gak: 'tidak', ga: 'tidak', sdh: 'sudah', udah: 'sudah', blm: 'belum',
    krn: 'karena', karna: 'karena', utk: 'untuk', sjk: 'sejak', hr: 'hari', hri: 'hari', mgg: 'minggu', bln: 'bulan', thn: 'tahun', kdg: 'kadang', kdang: 'kadang',
    sblm: 'sebelum', ssdh: 'sesudah', stlh: 'setelah', jg: 'juga', aja: 'saja', sm: 'sama', bbrp: 'beberapa', msh: 'masih', lg: 'lagi', trs: 'terus',
    pd: 'pada', dlm: 'dalam', kpl: 'kepala', prt: 'perut', bab: 'BAB', bak: 'BAK', mual2: 'mual-mual', pusing2: 'pusing-pusing' };
  function rapikan(t) {
    return String(t || '').split(/\n/).map(b => {
      let s = b.replace(/\s+/g, ' ').trim();
      if (!s) return '';
      s = s.replace(/\b([A-Za-z]+2?)\b/g, w => { const r = SINGKAT[w.toLowerCase()]; return r ? r : w; });
      s = s.replace(/\s+([,.;:])/g, '$1').replace(/([,;])(?=\S)/g, '$1 ').replace(/(\d)\s*x\s*\/?\s*(hari|hr)\b/gi, '$1x/hari');
      s = s.replace(/^([a-z])/, c => c.toUpperCase()).replace(/([.!?]\s+)([a-z])/g, (m, a, c) => a + c.toUpperCase());
      return s;
    }).join('\n').replace(/\n{3,}/g, '\n\n').trim();
  }

  /* ---------- isi nilai seperti diketik (memicu skrip C-CARE) ---------- */
  function setNilai(el, v) {
    const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : el.tagName === 'SELECT' ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto, 'value').set.call(el, v);
    el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true }));
  }
  function cariIsian(f) {
    try {
      if (f.searchType === 'name') return $$(`[name="${CSS.escape(f.key)}"]`);
      if (f.searchType === 'id') return $$('#' + CSS.escape(f.key));
      return $$(f.key);
    } catch (e) { return []; }
  }
  function isiTemplate(t, timpa) {
    let isi = 0, lewat = 0, tidak = 0;
    t.fields.forEach(f => {
      const els = cariIsian(f);
      if (!els.length) { tidak++; return; }
      const el = els[0];
      if (el.disabled || el.readOnly) { lewat++; return; }
      if (f.fieldType === 'checkbox' || f.fieldType === 'radio') {
        const mau = String(f.value) === 'true';
        if (el.checked !== mau) { el.checked = mau; el.dispatchEvent(new Event('click', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true })); isi++; } else lewat++;
        return;
      }
      if (el.tagName === 'SELECT') {
        const o = [...el.options].find(o => o.value === String(f.value)) || [...el.options].find(o => bersih(o.textContent).toLowerCase() === bersih(f.value).toLowerCase());
        if (!o) { tidak++; return; }
        const terisi = el.value && el.selectedIndex > 0;
        if (terisi && !timpa) { lewat++; return; }
        setNilai(el, o.value); isi++; return;
      }
      if (!kosong(el.value) && !timpa) { lewat++; return; }
      setNilai(el, f.value); isi++;
    });
    return { isi, lewat, tidak };
  }
  const cocok = t => t.fields.filter(f => cariIsian(f).length).length;


  /* ---------- TTV perawat → teks di kotak bawah Diagnosa ---------- */
  const nilaiAsli = id => { const el = document.getElementById(id); return el && !kosong(el.value) ? String(el.value).trim() : ''; };
  /* TTV di luar batas dewasa (untuk peringatan pada anamnesa baku surat sehat) */
  function ttvTidakNormal() {
    const n = id => parseFloat(nilaiAsli(id).replace(',', '.')), L = [];
    const sis = n('Sistole'), dia = n('Diastole'), nadi = n('Nadi'), rr = n('Respirasi'), suhu = n('Suhu'), spo = n('SaturasiO2');
    if (sis >= 140 || dia >= 90 || sis < 90) L.push(`TD ${nilaiAsli('Sistole')}/${nilaiAsli('Diastole')}`);
    if (nadi > 100 || nadi < 60) L.push('Nadi ' + nilaiAsli('Nadi'));
    if (rr > 20 || rr < 12) L.push('RR ' + nilaiAsli('Respirasi'));
    if (suhu >= 37.5 || suhu < 35) L.push('Suhu ' + nilaiAsli('Suhu'));
    if (spo < 95) L.push('SpO2 ' + nilaiAsli('SaturasiO2'));
    return L;
  }
  function teksTtv() {
    const a = nilaiAsli('Sistole'), b = nilaiAsli('Diastole');
    const L = [a || b ? `TD ${a || '-'}/${b || '-'} mmHg` : '',
      nilaiAsli('Nadi') && `N ${nilaiAsli('Nadi')} x/mnt`, nilaiAsli('Respirasi') && `RR ${nilaiAsli('Respirasi')} x/mnt`,
      nilaiAsli('Suhu') && `S ${nilaiAsli('Suhu').replace('.', ',')} °C`, nilaiAsli('SaturasiO2') && `SpO2 ${nilaiAsli('SaturasiO2')}%`,
      nilaiAsli('BeratBadan') && `BB ${nilaiAsli('BeratBadan')} kg`, nilaiAsli('TinggiBadan') && `TB ${nilaiAsli('TinggiBadan')} cm`,
      nilaiAsli('Imt') && `IMT ${nilaiAsli('Imt').replace('.', ',')}`, nilaiAsli('SkalaNyeri') && `Skala nyeri ${nilaiAsli('SkalaNyeri')}/10`].filter(Boolean);
    if (!L.length) return '';
    const ku = nilaiAsli('KeadaanUmum');
    return (ku ? 'KU: ' + ku + '\n' : '') + 'TTV: ' + L.join(', ');
  }

  /* ---------- diagnosa terkunci setelah obat diisi → buka ---------- */
  const isianDiagnosa = () => $$('#KodePenyakit, #Diagnosa').concat($$('input, select, textarea').filter(el => el.id !== 'KodePenyakit' && el.id !== 'Diagnosa'
    && /diagno|icd|kodepenyakit/i.test((el.name || '') + ' ' + (el.id || '')) && !/keperawatan|perawat/i.test((el.name || '') + ' ' + (el.id || '') + ' ' + labelIsian(el))));
  let dibuka = 0;
  function bukaDiagnosa() {
    let n = 0;
    isianDiagnosa().forEach(el => {
      if (el.disabled) { el.disabled = false; n++; }
      if (el.readOnly && el.type !== 'hidden') { el.readOnly = false; n++; }
      const s2 = el.nextElementSibling;
      if (s2 && /select2/.test(s2.className)) s2.classList.remove('select2-container--disabled');
    });
    if (n) { dibuka += n; panelPesan('Isian Diagnosa dibuka lagi (C-CARE menguncinya setelah obat diisi). Periksa resep tetap sesuai diagnosa.', 'info'); }
  }

  /* ---------- tampilan: alat kecil di bawah anamnesa dokter + panel melayang ---------- */
  const GAYA = `:host{all:initial}*{box-sizing:border-box;font-family:"Source Sans 3","Segoe UI",system-ui,sans-serif}
  .bar{display:flex;flex-wrap:wrap;align-items:center;gap:8px;margin:6px 0 2px;font-size:13px;color:#0F2742}
  button{font:inherit;font-family:"Source Sans 3","Segoe UI",system-ui,sans-serif;font-size:13px;font-weight:600;border-radius:8px;padding:5px 10px;cursor:pointer;border:1px solid #263C92;background:#fff;color:#263C92;display:inline-flex;gap:6px;align-items:center}
  button.utama{background:#263C92;color:#fff}
  button:focus-visible,select:focus-visible{outline:2px solid #263C92;outline-offset:2px}
  svg{width:16px;height:16px;fill:currentColor;flex:none}
  .ket{color:#4F6478;font-size:12px}.ket svg{width:14px;height:14px;vertical-align:-2px}.ket.info{color:#4F6478}.ket.ok{color:#3B7A1E}.ket.awas{color:#B45309}
  .panel{position:fixed;right:16px;bottom:16px;z-index:2147483000;width:300px;background:#fff;border:1px solid #D5E0E0;border-radius:12px;box-shadow:0 6px 24px rgba(15,39,66,.18);color:#0F2742;font-size:13px}
  .kepala{display:flex;align-items:center;gap:8px;padding:8px 10px;border-bottom:1px solid #E3EBEA;font-weight:700}
  .kepala .tutup{margin-left:auto;border:0;padding:2px;color:#4F6478;background:none}
  .isi{padding:10px;display:grid;gap:8px}
  select{font:inherit;font-size:13px;width:100%;padding:6px 8px;border:1px solid #D5E0E0;border-radius:8px;background:#F2F6F6;color:#0F2742}
  label.cek{display:flex;gap:6px;align-items:center;color:#4F6478;font-size:12px}
  .baris{display:flex;gap:8px;align-items:center}
  .chip{position:fixed;right:16px;bottom:16px;z-index:2147483000;border-radius:999px;box-shadow:0 4px 16px rgba(15,39,66,.18);padding:4px 10px;font-size:12px}
  :host-context(html[data-sjc-dua]) .panel{bottom:var(--sjc-bawah,88px)}:host-context(html[data-sjc-dua]) .chip{display:none!important}   /* CPPT dua kolom: chip pindah ke bilah bawah */
  [hidden]{display:none!important}`;
  const IK = {
    salin: '<svg viewBox="0 0 24 24"><path d="M16 1H4a2 2 0 0 0-2 2v14h2V3h12V1zm3 4H8a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h11a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2zm0 16H8V7h11v14z"/></svg>',
    ulang: '<svg viewBox="0 0 24 24"><path d="M17.65 6.35A7.96 7.96 0 0 0 12 4a8 8 0 1 0 7.73 10h-2.08A6 6 0 1 1 12 6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z"/></svg>',
    rapi: '<svg viewBox="0 0 24 24"><path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04a1 1 0 0 0 0-1.41l-2.34-2.34a1 1 0 0 0-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/></svg>',
    isi: '<svg viewBox="0 0 24 24"><path d="M19 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2zm-9 14-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg>',
    awas: '<svg viewBox="0 0 24 24"><path d="M1 21h22L12 2 1 21zm12-3h-2v-2h2v2zm0-4h-2v-4h2v4z"/></svg>',
    info: '<svg viewBox="0 0 24 24"><path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/></svg>',
    tutup: '<svg viewBox="0 0 24 24"><path d="M19 6.41 17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>',
  };
  let panelKet = null, barKet = null, panelRoot = null;
  function panelPesan(t, k, diam) { if (panelKet) { panelKet.textContent = t; panelKet.className = 'ket ' + (k || ''); if (!diam) tampilPanel(); } }
  /* panel tampil sebentar lalu mengecil jadi chip "Auto Fill" (klik = buka lagi); berhenti menghitung saat kursor/fokus di panel */
  let waktuKecil = 0;
  document.addEventListener('sjc-buka-autofill', () => tampilPanel(10000));
  function tampilPanel(ms) {
    if (!panelRoot) return;
    const pn = panelRoot.querySelector('.panel'), cp = panelRoot.getElementById('chip');
    pn.hidden = false; cp.hidden = true; clearTimeout(waktuKecil);
    const lama = ms || (panelRoot.querySelector('.ket.awas') ? 9000 : 5000);
    const kecil = () => { if (pn.matches(':hover') || pn.contains(panelRoot.activeElement)) { waktuKecil = setTimeout(kecil, 1500); return; } pn.hidden = true; cp.hidden = false; };
    waktuKecil = setTimeout(kecil, lama);
  }

  /* ---------- isian Auto Fill: bawaan (isi-cepat-bawaan.js) ← ubahan di Pengaturan → tab Auto Fill ---------- */
  const I = () => nilaiAutofill(ATUR);
  const TEKS_UMUM = ['KepalaMuka', 'Thorax', 'Abdomen', 'Extremitas', 'Ekg', 'Radiologi', 'TataLaksana', 'Pengobatan'];
  /* ---------- ICD-10 dari anamnesa: kamus kata kunci lokal (diedit di Pengaturan) ----------
   * Frasa terpanjang menang & tidak tumpang tindih; kata yang disangkal dilewati; kode gejala (R…, L299)
   * dibuang bila ada diagnosis lain; maks. 3 kode. Tidak memakai internet/AI. */
  function bacaKamus(teks) {
    return String(teks || '').split('\n').map(b => b.split('=>')).filter(x => x.length === 2).map(([kiri, kanan]) => {
      const nilai = bersih(kanan), kode = nilai.split('/')[0].trim().replace(/\./g, '').toUpperCase();
      return { kode, nilai: nilai.includes('/') ? nilai : kode, kata: kiri.split(',').map(k => bersih(k).toLowerCase()).filter(Boolean) };
    }).filter(e => /^[A-Z]\d/.test(e.kode) && e.kata.length);
  }
  const gejala = kode => /^R/.test(kode) || kode === 'L299';
  function tebakIcd(teks, kamus) {
    const t = ' ' + String(teks || '').toLowerCase().replace(/([a-z])2\b/g, '$1').replace(/\s+/g, ' ') + ' ';
    const cocok = [];
    bacaKamus(kamus).forEach((e, urut) => e.kata.forEach(k => {
      const re = new RegExp('(^|[^a-z])(' + k.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + ')(?![a-z])', 'g'); let m;
      while ((m = re.exec(t))) {
        const awal = m.index + m[1].length, akhir = awal + m[2].length;
        const sebelum = t.slice(Math.max(0, awal - 14), awal), sesudah = t.slice(akhir, akhir + 5);
        if (/(tidak|tdk|tanpa|bukan|tak|belum|blm|disangkal|negatif)\s*$/.test(sebelum) || /^\s*\(?\s*-\s*\)?/.test(sesudah)) continue;
        cocok.push({ awal, akhir, urut, kata: m[2], kode: e.kode, nilai: e.nilai });
      }
    }));
    cocok.sort((a, b) => (b.akhir - b.awal) - (a.akhir - a.awal) || a.urut - b.urut);
    const ambil = [];
    cocok.forEach(c => { if (!ambil.some(x => c.awal < x.akhir && x.awal < c.akhir)) ambil.push(c); });
    const unik = []; ambil.sort((a, b) => a.awal - b.awal).forEach(c => { if (!unik.some(u => u.kode === c.kode)) unik.push(c); });
    const pasti = unik.filter(c => !gejala(c.kode));
    return (pasti.length ? pasti : unik).slice(0, 3);
  }
  const STATUS_MENUNGGU_DOKTER = '3', NAMA_STATUS = { 4: 'Menunggu Obat', 5: 'Selesai' };
  /* JenisPoliId (isian tersembunyi C-CARE): Poli/Index/1, 5, 8 → alur umum; 4 (Kunjungan Sehat) → surat sehat. Poli lain: tidak diisi. */
  const POLI_UMUM = ['1', '5', '8'], POLI_SEHAT = ['4'];
  const jenisPoli = () => { const el = document.getElementById('JenisPoliId'); return el ? String(el.value) : ''; };
  /* profil isian per poli (POLI_PROFIL di isi-cepat-bawaan.js); poli yang Auto Fill-nya dimatikan di Pengaturan → tidak diisi */
  const profil = () => { const j = jenisPoli(); return (ATUR.poliMati || {})[j] ? '' : POLI_PROFIL[j] || ''; };
  /* Rujukan keluar dari anamnesa → Tata Laksana rujukan. "Rujuk balik"/PRB (pasien kembali dari spesialis) BUKAN rujukan keluar. */
  function cekRujukan(teks) {
    const t = String(teks || '').replace(/rujuk(an)?\s*balik|\bPRB\b/gi, ' ');
    const m = t.match(/\b(minta|meminta|mau|ingin|perlu|butuh|untuk|pengajuan|perpanjang(an)?|buat|membuat)\s+(surat\s+)?rujuk(an)?\b|\bsurat\s+rujuk(an)?\b|\brujuk(an)?\s+(ke\s+)?(poli(\s+spesialis)?|rs|rumah\s*sakit|spesialis|dokter\s+spesialis|sp\.?\s?[A-Z]{1,4})\b|\bkontrol\s+(ke\s+)?(poli\s+)?(spesialis|sp\.?\s?[A-Z]{1,4}\b)/i);
    return m ? bersih(m[0]) : '';
  }
  /* ---------- satu langkah otomatis saat CPPT dibuka ---------- */
  const tidur = ms => new Promise(r => setTimeout(r, ms));
  function namaIsian(el) { return labelIsian(el).replace(/\s*\*$/, '') || el.name; }
  async function isiOtomatis(timpa) {
    const diisi = [], lewat = [], catatan = [];
    const jenis = profil(), N = I()[jenis] || {};
    const isiTeks = (el, v, nama) => {                                    // isi kotak teks; yang sudah berisi lain → dilewati
      if (!el || el.disabled || el.readOnly) return;
      if (!kosong(el.value) && !timpa) { if (bersih(el.value) !== bersih(v)) lewat.push(nama || namaIsian(el)); return; }
      if (el.value !== v) { setNilai(el, v); diisi.push(nama || namaIsian(el)); }
    };
    // 1. Anamnesa dokter
    const ta = isianDokter();
    if (ta && jenis === 'sehat') { if (N.AmnesaDokter) isiTeks(ta, N.AmnesaDokter, 'Anamnesa'); }
    else if (ta) {                                                         // umum: salinan perawat, dirapikan
      if (kosong(ta.value) || timpa) {
        const d = await dataPerawat(ta), teks = rapikan(susunAnamnesa(d));
        if (teks) { if (ta.value !== teks) { setNilai(ta, teks); diisi.push('Anamnesa'); } }
        else { catatan.push('Anamnesa perawat belum ada.'); if (barKet) { barKet.textContent = 'Anamnesa perawat belum ada di kunjungan ini.'; barKet.className = 'ket awas'; } }
      } else lewat.push('Anamnesa Dokter');
    }
    if (jenis === 'sehat') {
      const abn = ttvTidakNormal();
      if (abn.length && /stabil/i.test(N.AmnesaDokter || '')) catatan.push(`Periksa: ${abn.join(', ')} di luar batas, padahal anamnesa menulis TTV stabil.`);
      // 2a. Buta warna
      const rb = $$('input[type=radio][name="IsButaWarna"]'), ada = rb.find(r => r.checked), mau = rb.find(r => r.value === N.IsButaWarna);
      if (mau && (!ada || timpa) && !mau.checked) { mau.checked = true; mau.dispatchEvent(new Event('click', { bubbles: true })); mau.dispatchEvent(new Event('change', { bubbles: true })); diisi.push('Buta warna: ' + (N.IsButaWarna === 'true' ? 'Ya' : 'Tidak')); }
      else if (mau && ada && ada !== mau && !timpa) lewat.push('Buta warna');
      // 2b. Diagnosa ICD-10 ("KODE / nama")
      const kp = document.getElementById('KodePenyakit'), icdTeks = bersih(N.KodePenyakit), icdId = icdTeks.split('/')[0].trim().replace(/\./g, '');
      if (kp && icdId) {
        const terpilih = [...kp.options].filter(o => o.selected);
        const sudah = terpilih.length === 1 && terpilih[0].value === icdId;
        if (!sudah && (!terpilih.length || timpa)) {
          [...kp.options].forEach(o => { o.selected = false; });
          let o = [...kp.options].find(o => o.value === icdId);
          if (!o) { o = new Option(icdTeks.includes('/') ? icdTeks : icdId, icdId, true, true); kp.appendChild(o); }
          o.selected = true; kp.dispatchEvent(new Event('change', { bubbles: true })); diisi.push('Diagnosa ' + icdId);
        } else if (!sudah) lewat.push('Diagnosa ICD-10');
      }
      // 2c. Tata laksana
      if (N.TataLaksana) isiTeks(document.getElementById('TataLaksana'), N.TataLaksana, 'Tata Laksana');
    } else {
    // 2. Pemeriksaan fisik dll. dari template C-CARE (Diagnosa diisi TTV, bukan template)
    const rujuk = cekRujukan([nilaiAsli('Keluhan'), ta ? ta.value : ''].join('\n'));
    if (rujuk) catatan.push(`Rujukan terbaca di anamnesa ("${rujuk}") — Tata Laksana diisi rujukan. Tindak lanjut & obat tidak diubah, sesuaikan bila perlu.`);
    const TL_RUJUKAN = N.TataLaksanaRujukan;
    TEKS_UMUM.map(k => ({ key: k, value: N[k] })).concat(N.TindakLanjutPengobatanId ? [{ key: 'TindakLanjutPengobatanId', value: N.TindakLanjutPengobatanId }] : []).forEach(f => {
      if (!f.value) return;
      const el = document.getElementsByName(f.key)[0] || document.getElementById(f.key); if (!el || el.disabled || el.readOnly) return;
      if (el.tagName === 'SELECT') {
        const o = [...el.options].find(o => o.value === String(f.value)); if (!o) return;
        if (el.value && el.selectedIndex > 0 && el.value !== o.value && !timpa) { lewat.push(namaIsian(el)); return; }
        if (el.value !== o.value) { setNilai(el, o.value); diisi.push(namaIsian(el)); }
        return;
      }
      if (rujuk && TL_RUJUKAN && el.id === 'TataLaksana') {                           // isi otomatis biasa → boleh diganti versi rujukan
        if (bersih(el.value) === bersih(f.value) && el.value !== TL_RUJUKAN) { setNilai(el, TL_RUJUKAN); diisi.push('Tata Laksana (rujukan)'); return; }
        return isiTeks(el, TL_RUJUKAN, 'Tata Laksana (rujukan)');
      }
      isiTeks(el, f.value);
    });
    // 2d. ICD-10 dari anamnesa (keluhan perawat + baris anamnesa dokter, tanpa baris "Riwayat …")
    const kp = document.getElementById('KodePenyakit');
    if (kp && N.icdOtomatis !== '0') {
      const bahan = [nilaiAsli('Keluhan'), ...(ta ? ta.value.split('\n') : [])].filter(b => b && !/^\s*riwayat\b/i.test(b)).join('\n');
      const tebak = tebakIcd(bahan, N.kamusIcd), terpilih = [...kp.options].filter(o => o.selected);
      if (tebak.length && (!terpilih.length || timpa)) {
        [...kp.options].forEach(o => { o.selected = false; });
        tebak.forEach(c => { let o = [...kp.options].find(o => o.value === c.kode); if (!o) { o = new Option(c.nilai, c.kode, true, true); kp.appendChild(o); } o.selected = true; });
        kp.dispatchEvent(new Event('change', { bubbles: true }));
        diisi.push('Diagnosa ' + tebak.map(c => c.kode).join(', '));
        catatan.push('ICD-10 otomatis dari anamnesa: ' + tebak.map(c => `${c.kode} ("${c.kata}")`).join(', ') + ' — periksa sebelum Simpan.');
      } else if (tebak.length && terpilih.length && !terpilih.every(o => tebak.some(c => c.kode === o.value))) lewat.push('Diagnosa ICD-10');
    }
    }
    // 3. (dihapus) Dulu kotak Diagnosa diisi teks KU/TTV di sini — sekarang kotak Diagnosa dikhususkan untuk
    // mengikuti ICD-10 terpilih (lihat pasangSinkronDiagnosa di cppt-tambahan.js); keduanya dulu rebutan isi
    // field yang sama. TTV sendiri tetap terlihat di kepala pasien lengket (cppt-dua.js).
    // 4. Status kunjungan (hanya dari kosong / Menunggu Pemeriksaan Dokter)
    const st = document.getElementById('StatusKunjunganID'), stAwal = st ? st.value : null, stMau = N.StatusKunjunganID;
    if (stMau && st && [...st.options].some(o => o.value === stMau)) {
      if (!stAwal || stAwal === STATUS_MENUNGGU_DOKTER || timpa) { if (stAwal !== stMau) { setNilai(st, stMau); diisi.push('Status: ' + (NAMA_STATUS[stMau] || stMau)); } }
      else if (stAwal !== stMau) lewat.push('Status kunjungan');
    }
    // 5. Resep: baris kosong kini dijaga cppt-resep.js (tepat satu, di setiap keadaan) — tidak lagi menyiapkan N baris di sini (v4.10.0)
    return { diisi, lewat, catatan };
  }

  async function pasangAlatAnamnesa() {
    const ta = isianDokter();
    if (!ta || ta.dataset.isiCepat) return;
    ta.dataset.isiCepat = '1';
    const host = document.createElement('div'); host.className = 'isi-cepat-alat';
    ta.insertAdjacentElement('afterend', host);
    const r = host.attachShadow({ mode: 'open' });
    const tombol = () => {
      r.innerHTML = `<style>${GAYA}</style><div class="bar">
      <button id="rapi" title="Rapikan singkatan, spasi, dan huruf kapital — di komputer ini, tanpa internet">${IK.rapi}Rapikan</button>
      <button id="ulang" title="Ganti semua isian dengan isi otomatis (anamnesa, pemeriksaan, TTV, diagnosa, tata laksana)">${IK.ulang}Timpa ulang</button>
      <span class="ket" id="ket" role="status"></span></div>`;
      barKet = r.getElementById('ket');
      r.getElementById('rapi').onclick = () => { const a = ta.value, b = rapikan(a); setNilai(ta, b); barKet.textContent = a === b ? 'Sudah rapi.' : 'Dirapikan. Tekan Ctrl+Z di kotak untuk membatalkan.'; barKet.className = 'ket ok'; };
      r.getElementById('ulang').onclick = async () => {               // langsung, tanpa konfirmasi (salah → muat ulang halaman)
        barKet.textContent = 'Menimpa…'; barKet.className = 'ket'; const h = await isiOtomatis(true); tampilHasil(h, true);
        barKet.textContent = h.diisi.length ? 'Ditimpa ulang. Salah? Muat ulang halaman (belum disimpan).' : 'Sudah sesuai isi otomatis.'; barKet.className = 'ket ok';
      };
    };
    tombol();
  }

  function pasangPanel() {
    if (document.getElementById('isi-cepat-panel')) return;
    const host = document.createElement('div'); host.id = 'isi-cepat-panel';
    document.body.appendChild(host);
    panelRoot = host.attachShadow({ mode: 'open' });
    /* jarak ke bawah mengikuti TINGGI ASLI bilah bawah (bisa 1 atau 2 baris tergantung lebar layar) — supaya panel
       Auto Fill tidak pernah menutupi tombol Rujuk eksternal/Simpan di bilah, berapa pun tingginya saat ini. */
    (function tautkanBilah() {
      const bilah = document.querySelector('.sjc-bilah');
      if (!bilah) { setTimeout(tautkanBilah, 500); return; }
      const atur = () => { host.style.setProperty('--sjc-bawah', (bilah.getBoundingClientRect().height + 16) + 'px'); };
      atur(); new ResizeObserver(atur).observe(bilah);
    })();
    panelRoot.innerHTML = `<style>${GAYA}</style><div class="panel" role="dialog" aria-label="Auto Fill C-CARE">
      <div class="kepala">${IK.isi}Auto Fill<button class="tutup" id="kecil" title="Tutup">${IK.tutup}</button></div>
      <div class="isi"><span class="ket" id="ket" role="status">Mengisi otomatis…</span><div id="aksi" class="isi" style="padding:0"></div>
      <span class="ket">Belum disimpan — periksa, lalu tekan Simpan C-CARE.</span></div></div>
      <button class="chip" id="chip" hidden title="Buka ringkasan Auto Fill">${IK.isi}Auto Fill</button>`;
    panelKet = panelRoot.getElementById('ket');
    panelRoot.getElementById('kecil').onclick = () => { clearTimeout(waktuKecil); panelRoot.querySelector('.panel').hidden = true; panelRoot.getElementById('chip').hidden = false; };
    panelRoot.getElementById('chip').onclick = () => tampilPanel(8000);
  }
  function tampilHasil(h, setelahTimpa) {
    if (!panelRoot) return;
    panelPesan(h.diisi.length ? (setelahTimpa ? 'Ditimpa: ' : 'Terisi otomatis: ') + h.diisi.join(', ') + '.' : 'Tidak ada yang perlu diisi.', h.diisi.length ? 'ok' : '');
    const aksi = panelRoot.getElementById('aksi'); aksi.innerHTML = '';
    const esc = s => String(s).replace(/</g, '&lt;');
    const cat = (h.catatan || []).length ? `<span class="ket awas">${IK.awas} ${h.catatan.map(esc).join(' ')}</span>` : '';
    if (!h.lewat.length) { aksi.innerHTML = cat; tampilPanel(); return; }
    aksi.innerHTML = cat + `<span class="ket awas">${IK.info} Sudah berisi, dibiarkan: ${h.lewat.map(esc).join(', ')}.</span>
      <div class="baris"><button id="timpa">Timpa ${h.lewat.length} isian</button></div>`;
    panelRoot.getElementById('timpa').onclick = async () => { panelPesan('Menimpa…'); tampilHasil(await isiOtomatis(true), true); };
    tampilPanel(9000);
  }

  /* ---------- mulai: langsung saat CPPT dibuka, tanpa menunggu klik ---------- */
  chrome.storage.local.get(['isiCepat'], async s => {
    Object.assign(ATUR, s.isiCepat || {});
    if (ATUR.mati || !isianDokter() || !profil()) return;          // hanya Poli/Index/1, 5, 8 & 4
    document.documentElement.dataset.isiCepat = 'aktif';            // mematikan gulir otomatis C-CARE saat (+) Obat (lihat isi-cepat-main.js)
    pasangAlatAnamnesa(); pasangPanel();
    let sedangOtomatis = true;
    if (ATUR.bukaDiagnosa) {
      bukaDiagnosa();
      document.addEventListener('isicepat-icd', () => { if (!sedangOtomatis) panelPesan('Pencarian ICD-10 di Diagnosa dipulihkan (C-CARE mematikannya setelah obat ditambahkan).', 'info', true); });
      new MutationObserver(ms => { if (ms.some(m => m.type === 'attributes' && /diagno|icd|kodepenyakit/i.test((m.target.name || '') + (m.target.id || '')) && !/keperawatan/i.test(m.target.name || ''))) bukaDiagnosa(); })
        .observe(document.body, { subtree: true, attributes: true, attributeFilter: ['disabled', 'readonly'] });
    }
    if (ATUR.autoSalin !== false) tampilHasil(await isiOtomatis(false), false);
    else { panelPesan('Isi otomatis dimatikan di Pengaturan.'); tampilHasil({ diisi: [], lewat: ['semua isian'] }, false); }
    sedangOtomatis = false;
    pasangTindakLanjut();
  });

  /* Tindak Lanjut → Status Kunjungan (+ rujukan). Hanya mengubah isian yang kosong atau yang sebelumnya diisi otomatis; tidak menekan Simpan.
     Pulang → Menunggu Obat. Rujuk → Selesai (Menunggu Obat bila sudah ada obat), Status Rujukan Eksternal, BPJS, keterangan. */
  function pasangTindakLanjut() {
    const tl = document.getElementById('TindakLanjutPengobatanId'), st = document.getElementById('StatusKunjunganID');
    if (!tl || !st) return;
    const oto = { st: null, rujukan: false, bpjs: false, ket: null, tl: null, tlLama: null };
    const tlk = document.getElementById('TataLaksana');
    const TL_RUJUK = 'Rencana merujuk ke FKRTL ke Poli Spesialis';
    const SPESIALIS = ['Penyakit Dalam', 'Bedah', 'Mata', 'Kulit dan Kelamin', 'Jiwa', 'Anak', 'Saraf', 'THT', 'Obstetri dan Ginekologi', 'Paru', 'Jantung', 'Orthopedi'];
    /* Keterangan rujukan mengikuti Tata Laksana selama Tindak Lanjut = Rujuk dan keterangan belum Anda ubah sendiri */
    const ikutKet = () => { const ket = document.getElementById('KeteranganRujukan'); if (!ket || tl.value !== '4' || !tlk) return; if (oto.ket !== null && ket.value !== oto.ket && !kosong(ket.value)) return; const t = bersih(tlk.value); if (t && ket.value !== t) { setNilai(ket, t); oto.ket = t; } };
    let chipSp = null;
    function pasangSpesialis(on) {
      if (!tlk) return;
      if (!on) { if (chipSp) chipSp.hidden = true; return; }
      if (!chipSp) {
        chipSp = document.createElement('div'); chipSp.className = 'isi-cepat-alat isi-sp';
        chipSp.innerHTML = '<span class="isi-sp-l">Poli spesialis:</span><div class="isi-sp-g">' + SPESIALIS.map(n => `<button type="button" data-sp="${n}">${n}</button>`).join('') + '</div>';
        chipSp.addEventListener('click', e => {
          const b = e.target.closest('[data-sp]'); if (!b) return;
          const t = TL_RUJUK + ' ' + b.dataset.sp;
          const isi = tlk.value, ada = new RegExp(TL_RUJUK.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '[^\\n]*');
          setNilai(tlk, ada.test(isi) ? isi.replace(ada, t) : (kosong(isi) ? t : isi.replace(/\s+$/, '') + '\n' + t));
          oto.tl = tlk.value; ikutKet();
          chipSp.querySelectorAll('button').forEach(x => x.setAttribute('aria-pressed', x === b ? 'true' : 'false'));
        });
        const g = document.createElement('style'); g.textContent = '.isi-sp{margin-top:8px}.isi-sp-l{display:block;font-weight:600;color:#4F6478;font-size:13px;margin-bottom:6px}.isi-sp-g{display:grid;grid-template-columns:repeat(auto-fill,minmax(128px,1fr));gap:6px 8px}.isi-sp button{height:28px;padding:0 10px;border:1px solid #D5E0E0;border-radius:8px;background:#fff;color:#0F2742;font-size:13px;font-family:inherit;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;cursor:pointer}.isi-sp button:hover{border-color:#263C92}.isi-sp button[aria-pressed=true]{border-color:#263C92;background:#E8ECF7;color:#263C92;font-weight:600}.isi-sp button:focus-visible{outline:2px solid #263C92;outline-offset:2px}';
        document.head.appendChild(g);
        tlk.after(chipSp);
      }
      chipSp.hidden = false;
    }
    if (tlk) tlk.addEventListener('input', ikutKet);
    const adaObat = () => $$('#GrupResep select').some(s => /\.ObatI[Dd]$/.test(s.name) && s.selectedIndex > 0 && s.value && !/^--/.test(s.value));
    const bolehSt = () => !st.value || st.value === STATUS_MENUNGGU_DOKTER || st.value === oto.st;
    const aturSt = v => { if (st.value !== v && [...st.options].some(o => o.value === v) && bolehSt()) { setNilai(st, v); oto.st = v; return true; } return false; };
    let akhir = '';
    function terapkan(dari) {
      if (ATUR.mati || !profil()) return;
      const N = I()[profil()] || {}; if (N.statusIkutTL === '0') return;
      const v = tl.value, sr = document.getElementById('StatusRujukanId'), ket = document.getElementById('KeteranganRujukan');
      const radio = $$('input[type=radio][name="IsBpjs"]'), bpjs = radio.find(r => r.value === 'true');
      const teks = N.KeteranganRujukan || 'Rujuk Ke Poli Spesialis', ubah = [];
      if (v === '4') {
        if (aturSt(adaObat() ? '4' : '5')) ubah.push('Status ' + (st.value === '4' ? 'Menunggu Obat' : 'Selesai'));
        if (sr && (!sr.value || oto.rujukan) && sr.value !== '1') { setNilai(sr, '1'); oto.rujukan = true; ubah.push('Rujukan Eksternal'); }
        ['rujukanEksternal', 'keteranganRujukan'].forEach(id => { const b = document.getElementById(id); if (b && sr && sr.value === '1' && getComputedStyle(b).display === 'none') b.style.display = ''; });
        if (bpjs && !radio.some(r => r.checked)) { bpjs.checked = true; bpjs.dispatchEvent(new Event('click', { bubbles: true })); bpjs.dispatchEvent(new Event('change', { bubbles: true })); oto.bpjs = true; ubah.push('BPJS'); }
        /* Tata Laksana → "Rencana merujuk ke FKRTL ke Poli Spesialis"; isi lama disimpan untuk dikembalikan bila batal rujuk */
        if (tlk && !new RegExp(TL_RUJUK).test(tlk.value)) {
          const N0 = (N.TataLaksana || ''), lama = tlk.value;
          oto.tlLama = lama;
          setNilai(tlk, kosong(lama) || bersih(lama) === bersih(N0) ? TL_RUJUK : lama.replace(/\s+$/, '') + '\n' + TL_RUJUK);
          oto.tl = tlk.value; ubah.push('Tata Laksana');
        }
        pasangSpesialis(true);
        if (ket && (kosong(ket.value) || ket.value === oto.ket || ket.value === teks)) { oto.ket = ket.value; ikutKet(); if (kosong(ket.value)) { setNilai(ket, teks); oto.ket = teks; } ubah.push('keterangan'); }
      } else if (dari === 'tl' || v !== akhir) {
        if (akhir === '4') {                                                   // batal rujuk: kembalikan yang tadi diisi otomatis
          if (sr && oto.rujukan && sr.value === '1') { setNilai(sr, ''); ['rujukanEksternal', 'keteranganRujukan'].forEach(id => { const b = document.getElementById(id); if (b) b.style.display = 'none'; }); }
          if (bpjs && oto.bpjs && bpjs.checked) bpjs.checked = false;
          if (ket && oto.ket && ket.value === oto.ket) setNilai(ket, '');
          if (tlk && oto.tl !== null && tlk.value === oto.tl && oto.tlLama !== null) setNilai(tlk, oto.tlLama);   // Tata Laksana dikembalikan bila belum Anda ubah
          pasangSpesialis(false);
          oto.rujukan = oto.bpjs = false; oto.ket = null; oto.tl = oto.tlLama = null;
        }
        if (v === '1' && aturSt('4')) ubah.push('Status Menunggu Obat');
      }
      akhir = v;
      if (ubah.length && typeof panelPesan === 'function' && panelRoot) panelPesan('Tindak lanjut ' + (tl.options[tl.selectedIndex] || {}).text + ' → ' + ubah.join(', ') + '. Periksa sebelum Simpan.', 'info');
    }
    akhir = tl.value; if (tl.value === '4') pasangSpesialis(true);
    { const N = I()[profil()] || {}; if (N.StatusKunjunganID && st.value === N.StatusKunjunganID) oto.st = st.value; }   // status bawaan dari Auto Fill = boleh diganti
    tl.addEventListener('change', () => terapkan('tl'));
    document.addEventListener('isicepat-ubah', e => terapkan(/TindakLanjut/i.test(e.detail || '') ? 'tl' : 'obat'));
    document.addEventListener('change', e => { if (e.target.closest && e.target.closest('#GrupResep')) terapkan('obat'); });
  }

  /* sakelar utama dimatikan saat CPPT terbuka → panel & tombol Auto Fill hilang; isian yang sudah terisi tetap (belum disimpan, dokter yang memutuskan) */
  chrome.storage.onChanged.addListener((u, area) => {
    if (area !== 'local' || !u.isiCepat || !(u.isiCepat.newValue || {}).mati) return;
    ATUR.mati = true; delete document.documentElement.dataset.isiCepat;
    document.querySelectorAll('#isi-cepat-panel, .isi-cepat-alat').forEach(e => e.remove());
  });

  // untuk pengembang: struktur halaman TANPA isi (label & nama isian saja) — dipanggil dari Pengaturan
  chrome.runtime.onMessage.addListener((m, _s, balas) => {
    if (!m || m.aksi !== 'strukturHalaman') return;
    balas({
      path: location.pathname.replace(/\d+/g, '{id}'),
      isian: $$('textarea, input:not([type=hidden]), select').map(el => ({ tag: el.tagName.toLowerCase(), type: el.type, name: el.name, id: el.id, label: labelIsian(el).slice(0, 60), terkunci: el.disabled || el.readOnly, select2: !!(el.nextElementSibling && /select2/.test(el.nextElementSibling.className)) })),
      labelStatis: [...new Set(pasangan(document, null).filter(p => !p.nama).map(p => p.label))].slice(0, 80),
      dokter: (isianDokter() || {}).name || null, diagnosa: isianDiagnosa().map(e => e.name || e.id),
    });
  });

  window.__isiCepatUji = { tebakIcd, cekRujukan, teksTtv, rapikan, susunAnamnesa, negatif, isianDokter, dataPerawat, isianDiagnosa };
})();
