/* Dunia halaman (MAIN): mengganti isi tabel daftar pasien C-CARE (DataTables) dengan data terbaru dari daftar-ringkas.js,
 * tanpa memuat ulang halaman. Halaman, urutan, dan kotak cari DataTables dipertahankan. Tidak mengirim apa pun. */
(() => {
  if (window.__sjcDaftarMain) return; window.__sjcDaftarMain = true;
  const norm = s => String(s || '').replace(/\s+/g, ' ').trim().toLowerCase();
  /* tanda pengenal satu baris: id kunjungan + status asli + tautan aksi (batal berobat = tautan Ubah hilang) */
  const tanda = tr => {
    const a = [...tr.querySelectorAll('a[href]')].map(x => x.getAttribute('href')).sort().join(' ');
    const st = [...tr.cells].map(c => c.dataset.sjcAsli || c.textContent).map(norm).find(t => /^menunggu|^selesai|^batal|^dirujuk|^rujuk/.test(t)) || '';
    return a + '|' + st + '|' + (tr.dataset.sjcPoli || '');   // poli asal (Semua poli) ikut dibandingkan
  };
  document.addEventListener('sjc-daftar-ganti', e => {
    let hasil = 'sama';
    try {
      const tb = document.getElementById('datatable-poli'); if (!tb) return;
      const tmp = document.createElement('tbody'); tmp.innerHTML = String(e.detail || '');
      const baru = [...tmp.rows].filter(r => r.cells.length > 1);
      const $ = window.jQuery, pakaiDt = $ && $.fn.dataTable && $.fn.dataTable.isDataTable(tb);
      const lama = pakaiDt ? $(tb).DataTable().rows().nodes().toArray() : [...tb.tBodies[0].rows].filter(r => r.cells.length > 1);
      const a = lama.map(tanda).sort().join('\n'), b = baru.map(tanda).sort().join('\n');
      if (a !== b) {
        if (pakaiDt) { const dt = $(tb).DataTable(); dt.clear(); dt.rows.add(baru); dt.draw(false); }
        else { tb.tBodies[0].replaceChildren(...baru); }
        hasil = 'ganti';
      }
    } catch (x) { hasil = 'galat'; }
    document.dispatchEvent(new CustomEvent('sjc-daftar-hasil', { detail: hasil }));
  });
  /* v4.6.5: semua pasien langsung tampil — tanpa halaman 1, 2, 3 …; bilah halaman & "Showing x of y" disembunyikan */
  const st = document.createElement('style');
  st.textContent = '.dataTables_wrapper .dataTables_paginate,.dataTables_wrapper .dataTables_info,.dataTables_wrapper .dataTables_length{display:none!important}';
  (document.head || document.documentElement).appendChild(st);
  let coba = 0;
  (function semua() {
    const $ = window.jQuery, dts = $ && $.fn.dataTable ? $.fn.dataTable.tables() : [];
    dts.forEach(t => { try { const dt = $(t).DataTable(); if (dt.page.len() !== -1 && dt.rows().count() <= 2000) dt.page.len(-1).draw(false); } catch (x) {} });   // shortcut: >2000 baris tetap berhalaman agar tidak berat
    if (!dts.length && ++coba < 20) setTimeout(semua, 250);
  })();
  /* Tampilan per tahap: semua baris ditaruh di DOM (tanpa halaman) agar bisa dibaca; Off → panjang halaman semula */
  let lenAsli = null;
  document.addEventListener('sjc-daftar-semua', e => {
    try {
      const tb = document.getElementById('datatable-poli'), $ = window.jQuery;
      if (!tb || !($ && $.fn.dataTable && $.fn.dataTable.isDataTable(tb))) return;
      const dt = $(tb).DataTable();
      if (e.detail === 'on') { if (lenAsli === null) lenAsli = dt.page.len(); dt.search('').page.len(-1).draw(false); }
      else if (lenAsli !== null) { dt.page.len(lenAsli).draw(false); lenAsli = null; }
    } catch (x) {}
  });
})();
