/* Penanda aktivitas di tab C-CARE: pembacaan latar (Siap dipanggil) menunggu selama Anda sedang memakai tab ini,
 * dan dibatalkan saat Anda pindah halaman / menekan Simpan — agar tab utama tidak terasa lambat. Tidak membaca isi halaman. */
(() => {
  if (window.__sjcAktivitas) return; window.__sjcAktivitas = true;
  const tandai = () => { window.__sjcAktif = Date.now(); };
  ['pointerdown', 'keydown', 'wheel', 'input'].forEach(ev => document.addEventListener(ev, tandai, { capture: true, passive: true }));
  const batalkan = () => { (window.__sjcCtrl || []).forEach(c => { try { c.abort(); } catch (e) {} }); };
  window.addEventListener('pagehide', batalkan); window.addEventListener('beforeunload', batalkan);
  document.addEventListener('submit', batalkan, true);
  /* CPPT disimpan → pasien keluar dari Siap dipanggil walau status kunjungan tidak diubah (mis. Kunjungan Sehat).
     Dicatat saat Simpan, dipastikan berhasil bila halaman berikutnya (≤ 30 dtk) adalah daftar, bukan CPPT yang sama (gagal validasi). */
  const idUbah = (location.pathname.match(/\/Ubah\/(\d+)/i) || [])[1];
  /* Periksa di C-CARE: struktur CPPT yang Anda buka sendiri dicatat (hanya ada/tidaknya elemen, tanpa isi) */
  if (idUbah) document.addEventListener('DOMContentLoaded', () => {
    const ada = s => !!document.querySelector(s), tl = document.getElementById('TindakLanjutPengobatanId');
    const el = { 'Tombol Simpan': ada('#btn-simpan'), 'ICD-10': ada('#KodePenyakit'), 'Tindak lanjut': !!tl, 'Status kunjungan': ada('#StatusKunjunganID'), 'Status rujukan': ada('#StatusRujukanId'),
      'Pilihan tindak lanjut': !!tl && ['1', '4'].every(v => [...tl.options].some(o => o.value === v)) };
    try { chrome.storage.local.set({ diagCppt: { waktu: Date.now(), el } }); } catch (e) {}
  });
  const catatSimpan = () => { try { sessionStorage.setItem('sjcSimpan', JSON.stringify({ id: idUbah, w: Date.now() })); } catch (x) {} };
  if (idUbah) {
    document.addEventListener('submit', e => { const f = e.target; if (f && f.querySelector && f.querySelector('#btn-simpan')) catatSimpan(); }, true);
    document.addEventListener('click', e => { if (e.target.closest && e.target.closest('#btn-simpan')) catatSimpan(); }, true);   // C-CARE bisa mengirim lewat skrip
  }
  try {
    const c = JSON.parse(sessionStorage.getItem('sjcSimpan') || 'null');
    if (c && Date.now() - c.w < 30000 && c.id !== idUbah && /\/(Poli\/Index|Kia)/i.test(location.pathname)) { sessionStorage.removeItem('sjcSimpan'); chrome.runtime.sendMessage({ aksi: 'cpptDisimpan', id: String(c.id) }).catch(() => {}); }
    else if (c && Date.now() - c.w >= 30000) sessionStorage.removeItem('sjcSimpan');
  } catch (x) {}
  document.addEventListener('click', e => { const a = e.target.closest && e.target.closest('a[href]'); if (a && !a.target && !/^#|^javascript:/i.test(a.getAttribute('href') || '')) batalkan(); }, true);
})();
