/* Memori resep di CPPT C-CARE (hanya untuk dokter pemakai ekstensi ini; tersimpan di komputer ini saja):
 *  - "Obat sering": obat yang paling sering Anda simpan, sekali klik → masuk ke baris resep kosong (atau baris baru).
 *  - Saat obat dipilih: jumlah, dosis (intensitas × jumlah), satuan, sebelum/sesudah makan, keterangan terakhir untuk
 *    obat itu diisi otomatis BILA isian masih kosong (ditandai kuning; Anda tetap bisa mengubah).
 *  - Obat BARU (belum ada instruksi tersimpan): dipelajari saat Anda menekan Simpan CPPT.
 *  - Obat yang SUDAH punya instruksi: instruksi hanya berubah bila Anda klik "Simpan instruksi" di baris itu.
 *    Mengubah isian lalu Simpan CPPT tanpa klik itu → instruksi lama tetap dipakai (hanya isian yang dulu kosong dilengkapi).
 * Bisa dimatikan: Pengaturan → Tampilan → Memori resep.
 *  - Jumlah obat dibandingkan dengan stok di C-CARE SAAT DIKETIK (bukan hanya saat Simpan); bila melebihi, baris ditandai
 *    merah + peringatan jelas, dan Simpan DIBATALKAN selama belum diperbaiki (tidak perlu klik Back lagi — isian lain tidak hilang).
 *  - Obat yang stoknya habis/minus (dikunci C-CARE sendiri): tidak lagi muncul sama sekali di daftar pencarian obat. */
(() => {
  if (!/\/Poli\/Ubah\/\d+/i.test(location.pathname) || window.__sjcResep) return; window.__sjcResep = true;
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const bersih = s => String(s == null ? '' : s).replace(/\s+/g, ' ').trim();
  const nama = n => document.getElementsByName(n)[0];
  const indeksBaris = () => $$('select[name^="ListResep["][name$="].ObatID"]').map(s => +(s.name.match(/ListResep\[(\d+)\]/) || [])[1]).filter(n => !isNaN(n));
  const f = i => ({
    obat: nama(`ListResep[${i}].ObatID`), jumlah: nama(`ListResep[${i}].JumlahObat`), intensitas: nama(`ListResep[${i}].IntensitasDosis`),
    jumlahDosis: nama(`ListResep[${i}].JumlahDosis`), satuan: nama(`ListResep[${i}].SatuanPembagiDosisId`), ket: nama(`ListResep[${i}].Keterangan`),
    makan: $$(`input[type=radio][name="ListResep[${i}].IsSebelumMakan"]`), racikan: document.getElementById('isRacikan_' + i)
  });
  const obatTerpilih = el => el && el.value && el.selectedIndex > 0 && !/^--|^pilih/i.test(el.value) && !/^pilih obat|^-- pilih/i.test(bersih((el.options[el.selectedIndex] || {}).text));
  let MEMORI = {}, ATUR = {};
  const muat = () => new Promise(ok => chrome.storage.local.get(['resepMemori', 'isiCepat'], s => { MEMORI = s.resepMemori || {}; ATUR = s.isiCepat || {}; ok(); }));

  /* ---------- belajar saat Simpan ---------- */
  /* satu baris → memori; isian kosong TIDAK menimpa yang sudah tercatat (memori makin lengkap tiap kali dipakai) */
  const nilaiBaris = x => ({ jumlah: bersih(x.jumlah && x.jumlah.value), intensitas: bersih(x.intensitas && x.intensitas.value), jumlahDosis: bersih(x.jumlahDosis && x.jumlahDosis.value),
    satuan: x.satuan ? x.satuan.value : '', makan: (x.makan.find(r => r.checked) || {}).value || '', ket: bersih(x.ket && x.ket.value) });
  const KUNCI = ['jumlah', 'intensitas', 'jumlahDosis', 'satuan', 'makan', 'ket'];
  /* mode 'simpan' (Simpan CPPT): obat baru → dicatat; obat lama → hanya melengkapi yang kosong, tidak menimpa.
     mode 'tetapkan' (klik Simpan instruksi): instruksi = persis isi baris sekarang. */
  function rekamBaris(i, mode) {
    const x = f(i); if (!obatTerpilih(x.obat) || (x.racikan && x.racikan.checked)) return false;
    const id = x.obat.value, lama = MEMORI[id], m = lama || { n: 0, t: 0 };
    const baru = nilaiBaris(x), sebelum = JSON.stringify(m);
    if (mode === 'tetapkan') KUNCI.forEach(k => { m[k] = baru[k]; });
    else KUNCI.forEach(k => { if (baru[k] && !m[k]) m[k] = baru[k]; });
    m.nama = bersih(x.obat.options[x.obat.selectedIndex].text).replace(/\s*\[[^\]]*\]\s*/g, ' ').replace(/\((Stok|Harga)[^)]*\)/gi, '').replace(/\s+/g, ' ').trim();
    if (mode === 'simpan') { m.n = (m.n || 0) + 1; m.t = Date.now(); }
    MEMORI[id] = m; return JSON.stringify(m) !== sebelum;
  }
  function tulisMemori() {
    const kunci = Object.keys(MEMORI);                                          // batas 150 obat: buang yang paling jarang & lama
    if (kunci.length > 150) kunci.sort((a, b) => (MEMORI[a].n - MEMORI[b].n) || (MEMORI[a].t - MEMORI[b].t)).slice(0, kunci.length - 150).forEach(k => delete MEMORI[k]);
    try { chrome.storage.local.set({ resepMemori: MEMORI }); } catch (e) {}
  }
  let catatTerakhir = 0;
  function catat() {
    if (ATUR.mati || ATUR.resepMati || Date.now() - catatTerakhir < 3000) return;   // klik Simpan + submit = satu kali simpan
    catatTerakhir = Date.now();
    let ubah = false; indeksBaris().forEach(i => { if (rekamBaris(i, 'simpan')) ubah = true; });
    if (ubah) tulisMemori();
  }
  /* mengubah isian TIDAK mengubah instruksi tersimpan; hanya memperbarui keterangan di baris */
  const tundaKet = {};
  const barisDari = el => { const r = el && el.closest && el.closest('tr[id^="Resep_"]'); return r ? +r.id.split('_')[1] : null; };
  const nantiKet = i => { if (i === null || isNaN(i)) return; clearTimeout(tundaKet[i]); tundaKet[i] = setTimeout(() => perbaruiKet(i), 400); };
  ['change', 'input'].forEach(ev => document.addEventListener(ev, e => { if (e.isTrusted && e.target && e.target.closest && e.target.closest('#GrupResep') && !e.target.closest('.sjc-memori-ket')) nantiKet(barisDari(e.target)); }, true));
  document.addEventListener('isicepat-ubah', e => { const m = String(e.detail || '').match(/ListResep_(\d+)__/); if (m) nantiKet(+m[1]); });
  /* ---------- periksa stok sebelum Simpan (mencegah layar eror C-CARE yang mengharuskan Back) ---------- */
  const IK_AWAS = '<svg viewBox="0 0 24 24"><path d="M1 21h22L12 2 1 21zm12-3h-2v-2h2v2zm0-4h-2v-4h2v4z"/></svg>';
  const stokDariOpsi = opt => { const m = bersih(opt && opt.textContent).match(/Stok\s*:?\s*([\d.,]+)/i); return m ? +m[1].replace(/[.,]/g, '') : null; };
  function cekStokBaris(i) {
    const x = f(i); if (!obatTerpilih(x.obat) || (x.racikan && x.racikan.checked)) return null;
    const stok = stokDariOpsi(x.obat.options[x.obat.selectedIndex]), jml = +bersih(x.jumlah && x.jumlah.value) || 0;
    if (stok == null || !jml || jml <= stok) return null;
    return { i, x, stok, jml };
  }
  function tandaiSatu({ x, stok, jml }) {
    x.jumlah.classList.add('sjc-stok-salah');
    const tempat = x.jumlah.closest('td') || x.jumlah.parentElement;
    let d = tempat.querySelector('.sjc-stok-peringatan'); if (!d) { d = document.createElement('div'); d.className = 'sjc-stok-peringatan'; tempat.appendChild(d); }
    d.innerHTML = IK_AWAS + (stok <= 0 ? `<span>Stok habis (${stok}). Tidak bisa diresepkan — pilih yang lain atau minta farmasi memperbarui stok.</span>` : `<span>Stok hanya ${stok}, Anda mengisi ${jml}. Kurangi jumlah sebelum Simpan.</span>`);
  }
  function tandaiStok(masalah) {                                       // dipakai saat klik Simpan: tandai SEMUA baris bermasalah sekaligus
    $$('.sjc-stok-peringatan').forEach(e => e.remove()); $$('.sjc-stok-salah').forEach(e => e.classList.remove('sjc-stok-salah'));
    masalah.forEach(tandaiSatu);
  }
  const bersihkanTandaStok = i => { const x = f(i); if (!x.jumlah) return; x.jumlah.classList.remove('sjc-stok-salah'); const td = x.jumlah.closest('td'); const d = td && td.querySelector('.sjc-stok-peringatan'); if (d) d.remove(); };
  function cekSatuBaris(i) {                                           // real-time (ketik jumlah / ganti obat): hanya baris INI yang ditandai/dibersihkan, baris lain tidak terganggu
    bersihkanTandaStok(i); const m = cekStokBaris(i); if (m) tandaiSatu(m);
  }
  document.addEventListener('input', e => { if (e.target && /^jumlah_obat_(\d+)$/.test(e.target.id || '')) cekSatuBaris(+RegExp.$1); }, true);
  document.addEventListener('change', e => { if (e.target && /^obat_(\d+)$/.test(e.target.id || '')) cekSatuBaris(+RegExp.$1); }, true);
  /* ---------- obat stok habis/minus/duplikat yang tidak bisa dipilih: C-CARE sendiri mengunci opsi ini lewat disabled
     (bukan selalu "(Stok: 0)" — ada juga tanpa angka stok sama sekali, atau stok minus) → dihapus dari daftar, bukan cuma disamarkan. ---------- */
  function bersihkanStokNol(root) {
    (root || document).querySelectorAll('option[disabled]').forEach(o => {
      if (!o.value) return;                 // jangan hapus placeholder "-- Pilih Obat/Satuan --" (value kosong)
      o.remove();
    });
  }
  /* ---------- "Sebelum makan"/"Setelah makan": kata tiap pilihan dibungkus (nowrap) supaya tidak terpotong di tengah frasa
     saat kolom sempit (dua kolom) — C-CARE menaruh radio+teks sebagai anak langsung <td>, bukan di dalam <label>. ---------- */
  function rapikanWaktuMakan(root) {
    (root || document).querySelectorAll('input[type=radio][name$=".IsSebelumMakan"]').forEach(r => {
      const td = r.closest('td'); if (!td || td.dataset.sjcWaktu) return; td.dataset.sjcWaktu = '1';
      [...td.querySelectorAll('input[type=radio]')].forEach(radio => {
        const bungkus = document.createElement('span'); bungkus.className = 'sjc-waktu-opsi';
        radio.parentNode.insertBefore(bungkus, radio); bungkus.appendChild(radio);
        let n = bungkus.nextSibling;
        while (n && !(n.nodeType === 1 && n.tagName === 'INPUT')) { const lanjut = n.nextSibling; bungkus.appendChild(n); n = lanjut; }
      });
    });
  }
  function pasangPenyaringStokNol() {
    const grup = document.getElementById('GrupResep'); if (!grup) { setTimeout(pasangPenyaringStokNol, 500); return; }
    const jalan = () => { bersihkanStokNol(grup); rapikanWaktuMakan(grup); };
    new MutationObserver(jalan).observe(grup, { childList: true, subtree: true });
    jalan();
  }
  pasangPenyaringStokNol();

  /* ---------- tepat SATU baris resep kosong di paling bawah (v4.10.0) ----------
     Akar masalah: C-CARE merender ulang daftar resep setelah simpan/TTD (halaman disegarkan) tanpa baris kosong, dan
     baris yang dipulihkan draf mengisi baris kosong satu-satunya. Dijaga di pengamat bersama #GrupResep, bukan per layar:
     setiap kali daftar berubah (muat, simpan, TTD, muat ulang, hapus baris) → bila tidak ada baris kosong, tambah satu
     lewat TambahResep milik C-CARE. Baris kosong buatan ekstensi dilepas sebelum Simpan (tidak ikut tersimpan). */
  const barisKosong = i => { const x = f(i); return x.obat && !obatTerpilih(x.obat) && !(x.racikan && x.racikan.checked) && !(x.jumlah && bersih(x.jumlah.value)); };
  const bisaUbah = () => { const t = document.getElementById('TambahResep'); return !!(t && t.offsetParent !== null); };
  let menambah = 0, sedangSimpanCppt = false;
  const MIN_BARIS = 5;
  const OTOMATIS = false;   // v4.10.14: (+) resep otomatis dimatikan atas permintaan dr. Arijal; baris ditambah manual dengan (+)
  function jagaKosong() {
    if (!OTOMATIS || sedangSimpanCppt || document.__sjcGeserResep || !bisaUbah() || Date.now() - menambah < 3000) return;
    const idx = indeksBaris().sort((a, b) => a - b), kosong = idx.filter(barisKosong);
    /* v4.10.9: selalu sedikitnya 5 baris resep terbuka (sebelum & sesudah Simpan TTD, yang memuat ulang halaman),
       plus tetap ada satu baris kosong bila kelima baris sudah terisi */
    if (!kosong.length || idx.length < MIN_BARIS) {                       // tambah satu (C-CARE menaruh di paling bawah), lalu ulangi
      menambah = Date.now();
      const sebelum = +((document.getElementById('CounterResep') || {}).value || idx.length);
      document.dispatchEvent(new CustomEvent('sjc-tambah-resep'));
      tunggu(() => (indeksBaris().includes(sebelum) || +((document.getElementById('CounterResep') || {}).value) !== sebelum) ? true : undefined, 6000).then(ada => { menambah = 0; if (ada) nantiJaga(); });
      return;
    }
    /* lebih dari 5 baris dan baris kosong dobel: lepas baris kosong paling bawah (HapusResep C-CARE hanya menghapus baris terakhir) */
    const akhir = idx[idx.length - 1];
    if (kosong.length > 1 && idx.length > MIN_BARIS && barisKosong(akhir)) document.dispatchEvent(new CustomEvent('sjc-hapus-resep'));
  }
  let tundaJaga = 0;
  const nantiJaga = () => { clearTimeout(tundaJaga); tundaJaga = setTimeout(jagaKosong, 600); };
  (function pasangJaga() {
    const grup = document.getElementById('GrupResep'); if (!grup) { setTimeout(pasangJaga, 500); return; }
    new MutationObserver(nantiJaga).observe(grup, { childList: true });  // baris ditambah/dihapus
    setInterval(jagaKosong, 2000);                                        // cadangan: jembatan dunia-utama belum siap saat halaman baru dibuka
    nantiJaga();
  })();
  document.addEventListener('change', e => { if (e.target && /^obat_\d+$/.test(e.target.id || '')) nantiJaga(); }, true);   // baris kosong terisi → siapkan yang baru
  /* (−) C-CARE menghapus baris TERAKHIR. Bila yang terakhir adalah baris kosong (yang selalu dijaga), tombol (−) menghapus
     baris obat di atasnya (yang memang dimaksud dokter), lalu baris kosong dipasang lagi. */
  document.addEventListener('click', e => {
    if (!OTOMATIS || !(e.target.closest && e.target.closest('#HapusResep'))) return;   // hanya perlu bila baris kosong dijaga otomatis
    const idx = indeksBaris().sort((a, b) => a - b), akhir = idx[idx.length - 1];
    if (idx.length > 1 && barisKosong(akhir) && !barisKosong(idx[idx.length - 2])) {
      setTimeout(() => { document.dispatchEvent(new CustomEvent('sjc-hapus-resep')); nantiJaga(); }, 0);   // setelah HapusResep milik C-CARE (baris kosong) selesai
    }
  }, true);
  /* (+) C-CARE selalu menambah baris di paling bawah. Karena baris kosong sudah dijaga, menekan (+) berulang membuat
     baris kosong menumpuk; bila baris bawahnya diisi, baris kosong tertinggal DI TENGAH dan tidak bisa dihapus (−).
     Maka: selama masih ada baris kosong, (+) tidak menambah baris — langsung membawa ke baris kosong itu. */
  document.addEventListener('click', e => {
    if (!(e.target.closest && e.target.closest('#TambahResep'))) return;
    if (document.__sjcGeserResep) { e.preventDefault(); e.stopImmediatePropagation(); return; }
    if (menambah && Date.now() - menambah < 6000) { e.preventDefault(); e.stopImmediatePropagation(); return; }   // baris otomatis sedang dimuat → cegah nomor ganda
    const kosong = indeksBaris().sort((a, b) => a - b).filter(barisKosong);
    if (!kosong.length) return;                                           // tidak ada baris kosong → biarkan C-CARE menambah
    e.preventDefault(); e.stopImmediatePropagation();
    const x = f(kosong[0]), baris = x.obat.closest('tr[id^="Resep_"]') || x.obat.closest('tr');
    const s2 = baris && baris.querySelector('.select2-selection');
    (baris || x.obat).scrollIntoView({ block: 'center', behavior: 'smooth' });
    if (baris) { baris.classList.add('sjc-baris-sorot'); setTimeout(() => baris.classList.remove('sjc-baris-sorot'), 1600); }
    setTimeout(() => { try { if (s2) { s2.focus(); s2.dispatchEvent(new MouseEvent('mousedown', { bubbles: true })); } else x.obat.focus(); } catch (er) {} }, 350);
  }, true);
  /* sebelum Simpan CPPT: lepas baris kosong di paling bawah agar tidak ikut terkirim */
  function lepasKosong() {
    /* v4.10.13: baris kosong di bawah DINONAKTIFKAN (tidak ikut terkirim), bukan dihapus lewat HapusResep: HapusResep yang
       dibungkus antrean ditolak diam-diam saat ada AJAX berjalan (mis. (+) Alkes, cari ICD), sehingga baris obat kosong
       (ObatID kosong) ikut terkirim. Menonaktifkan bersifat seketika; dibuka lagi bila Simpan batal. */
    sedangSimpanCppt = true; clearTimeout(lepasKosong.t);
    lepasKosong.t = setTimeout(() => { $$('[data-sjc-lepas]').forEach(e => { e.disabled = false; e.removeAttribute('data-sjc-lepas'); }); sedangSimpanCppt = false; nantiJaga(); }, 4000);
    const idx = indeksBaris().sort((a, b) => a - b);
    for (let n = idx.length - 1; n >= 0 && barisKosong(idx[n]); n--)   // hanya ekor kosong: indeks yang terkirim tetap berurutan
      $$(`[name^="ListResep[${idx[n]}]."]`).forEach(e => { if (!e.disabled) { e.disabled = true; e.setAttribute('data-sjc-lepas', ''); } });
    const lepas = new Set($$('[data-sjc-lepas]').map(e => e.name.split('.')[0])).size;
    if (Date.now() - (lepasKosong.dicatat || 0) > 3000) lepasKosong.dicatat = Date.now(), console.info(`[SJC] Simpan CPPT: ${idx.length} baris resep, ${lepas} baris kosong tidak dikirim, ${$$('#GrupResepAlkes select[id^="alkes_"]').length} alkes`);
  }
  document.addEventListener('submit', e => {
    if (!(e.target && e.target.querySelector && e.target.querySelector('#btn-simpan'))) return;
    lepasKosong();
    const masalah = indeksBaris().map(cekStokBaris).filter(Boolean);
    if (masalah.length) {
      e.preventDefault(); tandaiStok(masalah);
      const t = masalah[0].x.jumlah; t.scrollIntoView({ block: 'center', behavior: 'smooth' }); setTimeout(() => { try { t.focus(); } catch (e) {} }, 300);
      return;
    }
    catat();
  }, true);
  document.addEventListener('click', e => { if (e.target.closest && e.target.closest('#btn-simpan')) { lepasKosong(); catat(); } }, true);

  /* ---------- isi dari memori saat obat dipilih ---------- */
  const GAYA = document.createElement('style');
  GAYA.textContent = `.sjc-memori{background:#FFF7E6!important;border-color:#E9B872!important}
  .sjc-memori-ket{display:flex;flex-wrap:wrap;align-items:center;gap:8px;margin-top:6px;font:13px/1.4 "Source Sans 3","Segoe UI",system-ui,sans-serif;color:#B45309}
  .sjc-memori-ket button{height:26px;padding:0 10px;border:1px solid #D5E0E0;border-radius:8px;background:#fff;color:#0F2742;font-size:12px;cursor:pointer}
  .sjc-memori-ket button.utama{border-color:#263C92;color:#263C92;font-weight:700}.sjc-memori-ket button:focus-visible{outline:2px solid #263C92;outline-offset:2px}
  .sjc-memori-ket.ok{color:#3B7A1E}.sjc-memori-ket.baru{color:#4F6478}
  .sjc-obat{display:flex;flex-wrap:wrap;align-items:center;gap:6px;margin:8px 0 10px;font:13px/1.3 "Source Sans 3","Segoe UI",system-ui,sans-serif}
  .sjc-obat .l{font-weight:700;color:#0F2742;margin-right:2px;display:inline-flex;align-items:center;gap:4px}
  .sjc-obat .l svg{width:16px;height:16px;fill:#263C92}
  .sjc-obat button{display:inline-flex;align-items:center;gap:6px;height:30px;max-width:260px;padding:0 10px;border:1px solid #D5E0E0;border-radius:999px;background:#fff;color:#0F2742;font-size:13px;cursor:pointer}
  .sjc-obat button span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .sjc-obat button small{color:#4F6478;font-size:12px;white-space:nowrap}
  .sjc-obat button:hover{border-color:#263C92}.sjc-obat button:focus-visible{outline:2px solid #263C92;outline-offset:2px}
  .sjc-obat .pesan{color:#B45309;font-weight:600}
  /* harga tidak perlu dilihat dokter: disembunyikan (nilainya tetap dihitung & dikirim C-CARE) */
  #GrupResep table tr:has(> td [id^="total_harga_obat_"]):not(:has(select)),
  #GrupResep td:has(> [id^="racikan_harga_"]), #GrupResep td:has(> [id^="racikan_total_"]){display:none!important}
  #GrupResep tr.sjc-baris-sorot > td{background:#FFF4E5!important;transition:background .3s}
  .sjc-stok-salah{border-color:#B91C1C!important;background:#FDECEC!important}
  .sjc-stok-peringatan{display:flex;align-items:flex-start;gap:5px;margin-top:4px;font:12px/1.3 "Source Sans 3","Segoe UI",system-ui,sans-serif;color:#B91C1C;font-weight:700}
  .sjc-stok-peringatan svg{width:14px;height:14px;flex:none;margin-top:1px;fill:currentColor}
  /* dirapikan di SEMUA tata letak (satu kolom atau dua kolom cppt-dua.js) — bukan cuma saat dua kolom aktif */
  .sjc-waktu-opsi{display:inline-flex;align-items:center;gap:4px;white-space:nowrap;vertical-align:middle;margin-right:14px}
  /* dropdown Satuan dibuat oleh widget select2 (bukan <select> biasa) — <select> aslinya disembunyikan select2, yang
     tampil adalah <span class="select2-container"> di sebelahnya dengan style="width:100%" bawaan select2 sendiri;
     makanya width di <select> tidak berpengaruh ke tampilan, harus menimpa container select2-nya langsung. */
  span.select2-container:has([id^="select2-ListResep_"][id$="__SatuanPembagiDosisId-container"]){max-width:170px!important;width:170px!important}
  span.select2-container:has([id^="select2-ListResep_"][id$="__SatuanPembagiDosisId-container"]) .select2-selection__rendered{font-size:13px}
  .sjc-draf-pulih{background:#FFF7E6!important;border-color:#E9B872!important}`;
  document.head.appendChild(GAYA);
  const SATUAN = { 1: 'Tablet', 3: 'ml', 5: 'Sendok makan', 6: 'Oles', 7: 'Tetes', 8: 'Bungkus', 9: 'Kapsul', 10: 'Suppos', 1008: 'Sendok obat', 2008: 'Pen' };
  const ringkas = m => [m.intensitas && m.jumlahDosis ? `${m.intensitas} × ${m.jumlahDosis}` : '', SATUAN[m.satuan] || '', m.makan === 'true' ? 'sebelum makan' : m.makan === 'false' ? 'sesudah makan' : '', m.jumlah ? 'jumlah ' + m.jumlah : ''].filter(Boolean).join(' · ');
  function tandai(el) { if (!el) return; el.classList.add('sjc-memori'); const hapus = () => { el.classList.remove('sjc-memori'); el.removeEventListener('input', hapus); }; el.addEventListener('input', hapus); }
  function setNilai(el, v) {
    const proto = el.tagName === 'SELECT' ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto, 'value').set.call(el, v);
    el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true }));
  }
  const kosong = el => el && (!bersih(el.value) || el.classList.contains('sjc-memori'));   // isian dari memori obat sebelumnya boleh ditimpa
  function isiBaris(i) {
    if (ATUR.mati || ATUR.resepMati) return;
    const x = f(i); if (!obatTerpilih(x.obat) || (x.racikan && x.racikan.checked)) return;
    const m = MEMORI[x.obat.value]; if (!m) { dariMemori[i] = false; return perbaruiKet(i); }
    const diisi = [];
    if (m.jumlah && kosong(x.jumlah)) { setNilai(x.jumlah, m.jumlah); x.jumlah.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true })); tandai(x.jumlah); diisi.push('jumlah'); }
    if (m.intensitas && kosong(x.intensitas)) { setNilai(x.intensitas, m.intensitas); tandai(x.intensitas); diisi.push('dosis'); }
    if (m.jumlahDosis && kosong(x.jumlahDosis)) { setNilai(x.jumlahDosis, m.jumlahDosis); tandai(x.jumlahDosis); }
    const s2m = x.satuan && x.satuan.nextElementSibling && x.satuan.nextElementSibling.querySelector && x.satuan.nextElementSibling.querySelector('.sjc-memori');
    if (m.satuan && x.satuan && (!x.satuan.value || s2m) && [...x.satuan.options].some(o => o.value === m.satuan)) {
      document.dispatchEvent(new CustomEvent('sjc-satuan', { detail: JSON.stringify({ id: x.satuan.id, val: m.satuan }) }));   // select2 → lewat jQuery halaman
      if (x.satuan.value !== m.satuan) setNilai(x.satuan, m.satuan);
      const s2 = x.satuan.nextElementSibling; if (s2 && /select2/.test(s2.className)) tandai(s2.querySelector('.select2-selection') || s2);
      diisi.push('satuan');
    }
    if (m.makan && x.makan.length && !x.makan.some(r => r.checked)) { const r = x.makan.find(r => r.value === m.makan); if (r) { r.checked = true; r.dispatchEvent(new Event('change', { bubbles: true })); diisi.push(m.makan === 'true' ? 'sebelum makan' : 'sesudah makan'); } }
    if (m.ket && kosong(x.ket)) { setNilai(x.ket, m.ket); tandai(x.ket); diisi.push('keterangan'); }
    dariMemori[i] = diisi.length > 0; perbaruiKet(i);
  }
  const dariMemori = {}, baruTetap = {};
  const NAMA_K = { jumlah: 'jumlah', intensitas: 'dosis', jumlahDosis: 'dosis', satuan: 'satuan', makan: 'waktu makan', ket: 'keterangan' };
  /* keterangan di bawah baris: dari instruksi / berbeda dari instruksi / obat baru — dengan tombol Simpan instruksi */
  function perbaruiKet(i) {
    const x = f(i); const tempat = x.ket && ((x.ket.closest('td')) || x.ket.parentElement); if (!tempat) return;
    let k = tempat.querySelector('.sjc-memori-ket');
    const buang = () => { if (k) k.remove(); };
    if (ATUR.mati || ATUR.resepMati || !obatTerpilih(x.obat) || (x.racikan && x.racikan.checked)) return buang();
    const m = MEMORI[x.obat.value], v = nilaiBaris(x);
    const adaIsi = KUNCI.some(kk => v[kk]);
    let teks, kelas = '', tombol = [];
    if (!m || !KUNCI.some(kk => m[kk])) {
      if (!adaIsi) return buang();
      teks = 'Obat baru: instruksi akan diingat saat Simpan.'; kelas = 'baru'; tombol = ['tetapkan'];
    } else {
      const beda = [...new Set(KUNCI.filter(kk => (v[kk] || '') !== (m[kk] || '') && !(kk === 'makan' && !v[kk])).map(kk => NAMA_K[kk]))];
      if (beda.length) { teks = 'Berbeda dari instruksi tersimpan (' + beda.join(', ') + '). Tanpa disimpan, instruksi lama tetap dipakai.'; tombol = ['tetapkan']; }
      else if (Date.now() - (baruTetap[i] || 0) < 6000) { teks = 'Instruksi baru tersimpan untuk ' + (m.nama || 'obat ini') + '.'; kelas = 'ok'; }
      else if (dariMemori[i]) { teks = 'Dari instruksi tersimpan — periksa sebelum Simpan.'; }
      else { teks = 'Sesuai instruksi tersimpan.'; kelas = 'ok'; }
      if (dariMemori[i] && [x.jumlah, x.intensitas, x.jumlahDosis, x.ket].some(el => el && el.classList.contains('sjc-memori'))) tombol.push('kosongkan');
    }
    if (!k) { k = document.createElement('div'); tempat.appendChild(k); }
    k.className = 'sjc-memori-ket ' + kelas; k.title = m ? 'Tersimpan: ' + ringkas(m) : '';
    k.innerHTML = '<span></span>' + (tombol.includes('tetapkan') ? '<button type="button" class="utama" data-a="tetapkan">Simpan instruksi</button>' : '') + (tombol.includes('kosongkan') ? '<button type="button" data-a="kosongkan">Kosongkan</button>' : '');
    k.firstChild.textContent = teks;
    k.onclick = e => {
      const a = e.target.closest('button') && e.target.closest('button').dataset.a; if (!a) return;
      if (a === 'tetapkan') { rekamBaris(i, 'tetapkan'); tulisMemori(); dariMemori[i] = false; baruTetap[i] = Date.now(); perbaruiKet(i); }
      if (a === 'kosongkan') {
        [x.jumlah, x.intensitas, x.jumlahDosis, x.ket].forEach(el => { if (el && el.classList.contains('sjc-memori')) { setNilai(el, ''); el.classList.remove('sjc-memori'); } });
        if (x.jumlah) x.jumlah.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true }));
        dariMemori[i] = false; perbaruiKet(i);
      }
    };
  }
  /* obat berubah (select2 → diteruskan isi-cepat-main.js sebagai 'isicepat-ubah'; cadangan: event change asli) */
  const dariObat = n => { const m = String(n || '').match(/^obat_(\d+)$|^ListResep\[(\d+)\]\.ObatID$/); return m ? +(m[1] || m[2]) : null; };
  const tunda = {};
  const jadwal = i => { if (i === null) return; clearTimeout(tunda[i]); tunda[i] = setTimeout(() => { if (!tolakGanda(i)) isiBaris(i); }, 150); };
  /* v4.10.12: satu obat hanya boleh sekali di resep (bukan racikan). Obat yang sama di baris lain → pilihan dibatalkan + pesan. */
  function tolakGanda(i) {
    if (document.__sjcGeserResep) return false;                                  // sedang menggeser (×) → duplikat sesaat itu wajar
    const x = f(i); if (!x.obat || !obatTerpilih(x.obat) || (x.racikan && x.racikan.checked)) return false;
    const urut = indeksBaris().sort((a, b) => a - b);
    const lain = urut.find(j => j !== i && (() => { const y = f(j); return y.obat && obatTerpilih(y.obat) && !(y.racikan && y.racikan.checked) && y.obat.value === x.obat.value; })());
    if (lain === undefined) return false;
    console.warn('[SJC] obat ganda ditolak: baris', i + 1, 'sama dengan baris', lain + 1);
    const namaObat = bersih(x.obat.options[x.obat.selectedIndex].text).replace(/\s*\[[^\]]*\]\s*/g, ' ').replace(/\((Stok|Harga)[^)]*\)/gi, '').replace(/\s+/g, ' ').trim();
    document.dispatchEvent(new CustomEvent('sjc-pilih-obat', { detail: JSON.stringify({ id: x.obat.id, val: x.obat.options[0] ? x.obat.options[0].value : '' }) }));
    pesanBaris(i, `${namaObat} sudah ada di resep nomor ${urut.indexOf(lain) + 1}. Ubah jumlahnya di sana.`);
    return true;
  }
  document.addEventListener('isicepat-ubah', e => jadwal(dariObat(e.detail)));
  document.addEventListener('change', e => { if (e.target && e.target.tagName === 'SELECT') jadwal(dariObat(e.target.id) ?? dariObat(e.target.name)); }, true);

  /* ---------- Obat sering (chip) ---------- */
  const IK_PIL = '<svg viewBox="0 0 24 24"><path d="M4.2 11.3l7.1-7.1a5 5 0 017.1 7.1l-7.1 7.1a5 5 0 01-7.1-7.1zm1.4 1.4a3 3 0 004.3 4.3l3-3-4.3-4.3-3 3zm8.7 0l3-3a3 3 0 00-4.3-4.3l-3 3 4.3 4.3z"/></svg>';
  let bar = null;
  function pasangChip() {
    const grup = document.getElementById('GrupResep'); if (!grup) return;
    const top = Object.entries(MEMORI).sort((a, b) => (b[1].n - a[1].n) || (b[1].t - a[1].t)).slice(0, 8);
    if (!bar) { bar = document.createElement('div'); bar.className = 'sjc-obat'; (grup.closest('table') || grup).before(bar); }
    if (ATUR.mati || ATUR.resepMati || !top.length || !ATUR.obatSering) { bar.hidden = true; return; }   // chip disembunyikan (bawaan); memori aturan pakai tetap jalan
    bar.hidden = false;
    bar.innerHTML = `<span class="l">${IK_PIL}Obat sering</span>` + top.map(([id, m]) => `<button type="button" data-id="${id}" title="${(m.nama || '').replace(/"/g, '&quot;')} — ${ringkas(m).replace(/"/g, '&quot;')}"><span></span><small>${m.n}×</small></button>`).join('') + '<span class="pesan" role="status" aria-live="polite"></span>';
    $$('button[data-id]', bar).forEach((b, k) => { b.firstChild.textContent = top[k][1].nama || 'Obat'; });
  }
  /* PENTING: 'v !== undefined' (bukan 'v') — baris resep pertama punya indeks 0, yang salah dianggap "belum ketemu" bila diperiksa dengan truthy */
  const tunggu = (cek, ms = 6000) => new Promise(ok => { const t0 = Date.now(); (function ulang() { const v = cek(); if (v !== undefined || Date.now() - t0 > ms) ok(v); else setTimeout(ulang, 120); })(); });
  async function pilih(id) {
    const pesan = t => { const p = bar.querySelector('.pesan'); if (p) { p.textContent = t; setTimeout(() => { if (p.textContent === t) p.textContent = ''; }, 5000); } };
    const kosongI = () => indeksBaris().find(i => { const x = f(i); return x.obat && !obatTerpilih(x.obat) && !(x.racikan && x.racikan.checked); });
    let i = kosongI();
    if (i === undefined) {                                                              // tidak ada baris kosong → tambah baris C-CARE
      const sebelum = indeksBaris().length;
      document.dispatchEvent(new CustomEvent('sjc-tambah-resep'));
      i = await tunggu(() => indeksBaris().length > sebelum ? kosongI() : undefined);
      if (i === undefined) { pesan('Baris resep baru belum muncul. Tekan (+) lalu klik lagi.'); return; }
    }
    const sel = f(i).obat;
    const ada = await tunggu(() => [...sel.options].some(o => o.value === String(id)));   // daftar obat dimuat C-CARE (GetObatNonRacikan)
    if (!ada) { pesan('Obat ini tidak ada di daftar obat C-CARE saat ini.'); return; }
    const hasil = await new Promise(ok => {
      const h = e => { document.removeEventListener('sjc-pilih-obat-hasil', h); ok(e.detail); };
      document.addEventListener('sjc-pilih-obat-hasil', h);
      document.dispatchEvent(new CustomEvent('sjc-pilih-obat', { detail: JSON.stringify({ id: sel.id, val: id }) }));
      setTimeout(() => ok('gagal'), 2000);
    });
    if (hasil === 'stok-habis') pesan('Stok obat ini habis di C-CARE.');
    else if (hasil !== 'ok') pesan('Obat belum terpilih. Pilih manual di baris resep.');
    else { jadwal(i); sel.closest('tr') && sel.closest('tr').scrollIntoView({ block: 'nearest', behavior: 'smooth' }); }
  }
  document.addEventListener('click', e => { const b = e.target.closest && e.target.closest('.sjc-obat button[data-id]'); if (b) pilih(b.dataset.id); });
  /* ---------- pulihkan baris resep dari draf (cppt-draf.js), setelah Back/Forward tanpa sengaja ---------- */
  async function pulihBaris(row) {
    const kosongI = () => indeksBaris().find(i => { const x = f(i); return x.obat && !obatTerpilih(x.obat) && !(x.racikan && x.racikan.checked); });
    let i = kosongI();
    if (i === undefined) {
      const sebelum = indeksBaris().length;
      /* dicoba beberapa kali: pada saat ini terpanggil (segera setelah halaman dibuka), jembatan dunia-utama
         (isi-cepat-main.js, yang menjalankan TambahResep() milik C-CARE) mungkin belum siap menerima event pertama */
      for (let coba = 0; coba < 4 && i === undefined; coba++) {
        document.dispatchEvent(new CustomEvent('sjc-tambah-resep'));
        i = await tunggu(() => indeksBaris().length > sebelum ? kosongI() : undefined, 1200);
      }
      if (i === undefined) return;
    }
    const ii = i, obatEl = () => document.getElementById('obat_' + ii);        // elemen diambil ULANG tiap kali (baris bisa digambar ulang C-CARE)
    const ada = await tunggu(() => { const el = obatEl(); return (el && [...el.options].some(o => o.value === String(row.obat))) || undefined; });
    if (!ada) return;                                                          // obat ini sudah tidak ada di daftar C-CARE → lewati, isi manual
    const hasil = await new Promise(ok => {
      const h = e => { document.removeEventListener('sjc-pilih-obat-hasil', h); ok(e.detail); };
      document.addEventListener('sjc-pilih-obat-hasil', h);
      document.dispatchEvent(new CustomEvent('sjc-pilih-obat', { detail: JSON.stringify({ id: 'obat_' + ii, val: row.obat }) }));
      setTimeout(() => ok('gagal'), 2000);
    });
    if (hasil !== 'ok') return;
    await new Promise(r => setTimeout(r, 350));                               // biar isi otomatis dari memori obat (jika ada) selesai dulu, baru ditimpa draf
    const x = f(i);
    ['jumlah', 'intensitas', 'jumlahDosis', 'ket'].forEach(k => { if (row[k] && x[k]) { setNilai(x[k], row[k]); tandai(x[k]); x[k].classList.add('sjc-draf-pulih'); } });
    if (row.satuan && x.satuan) {
      document.dispatchEvent(new CustomEvent('sjc-satuan', { detail: JSON.stringify({ id: x.satuan.id, val: row.satuan }) }));
      if (x.satuan.value !== row.satuan) setNilai(x.satuan, row.satuan);
    }
    if (row.makan && x.makan.length) { const r = x.makan.find(r => r.value === row.makan); if (r) { r.checked = true; r.dispatchEvent(new Event('change', { bubbles: true })); } }
  }
  document.addEventListener('sjc-pulihkan-resep', async e => {
    let baris; try { baris = JSON.parse(e.detail || '[]'); } catch (err) { baris = []; }
    for (const b of baris) await pulihBaris(b);
  });

  /* ---------- jembatan untuk "Salin ke resep" dari Riwayat Kunjungan (cppt-riwayat.js): obat dicocokkan dari NAMA ---------- */
  const dariNamaRiwayat = (opt, nama) => {
    const t = bersih(opt.textContent).replace(/\s*\[[^\]]*\]\s*/g, ' ').replace(/\((Stok|Harga)[^)]*\)/gi, '').trim().toLowerCase();
    const n = String(nama || '').toLowerCase();
    return !!t && !!n && (t === n || t.startsWith(n) || n.startsWith(t));
  };
  document.__sjcSalinSatuResep = async hist => {
    /* obat ini sudah ada di salah satu baris resep (ditambah manual ATAU dari Salin sebelumnya) → jangan duplikat,
       dan jangan sampai menambah baris baru (+) hanya untuk ini */
    const sudahAda = indeksBaris().some(i => { const x = f(i); return x.obat && obatTerpilih(x.obat) && dariNamaRiwayat(x.obat.options[x.obat.selectedIndex], hist.nama); });
    if (sudahAda) return 'duplikat';
    const kosongI = () => indeksBaris().find(i => { const x = f(i); return x.obat && !obatTerpilih(x.obat) && !(x.racikan && x.racikan.checked); });
    let i = kosongI();
    if (i === undefined) {
      const sebelum = indeksBaris().length;
      document.dispatchEvent(new CustomEvent('sjc-tambah-resep'));
      i = await tunggu(() => indeksBaris().length > sebelum ? kosongI() : undefined);
      if (i === undefined) return false;
    }
    const sel = f(i).obat;
    await tunggu(() => sel.options.length > 1);
    const cocok = [...sel.options].find(o => dariNamaRiwayat(o, hist.nama));
    if (!cocok) return false;
    const hasil = await new Promise(ok => {
      const h = e => { document.removeEventListener('sjc-pilih-obat-hasil', h); ok(e.detail); };
      document.addEventListener('sjc-pilih-obat-hasil', h);
      document.dispatchEvent(new CustomEvent('sjc-pilih-obat', { detail: JSON.stringify({ id: sel.id, val: cocok.value }) }));
      setTimeout(() => ok('gagal'), 2000);
    });
    if (hasil !== 'ok') return false;
    await new Promise(r => setTimeout(r, 350));
    const x = f(i);
    if (hist.jumlah && x.jumlah) { setNilai(x.jumlah, hist.jumlah); tandai(x.jumlah); x.jumlah.classList.add('sjc-draf-pulih'); }
    if (hist.intensitas && x.intensitas) { setNilai(x.intensitas, hist.intensitas); tandai(x.intensitas); x.intensitas.classList.add('sjc-draf-pulih'); }
    if (hist.satuan && x.satuan) { document.dispatchEvent(new CustomEvent('sjc-satuan', { detail: JSON.stringify({ id: x.satuan.id, val: hist.satuan }) })); if (x.satuan.value !== hist.satuan) setNilai(x.satuan, hist.satuan); }
    return true;
  };

  /* ---------- (×) hapus resep nomor berapa pun (v4.10.11) ----------
     C-CARE hanya bisa menghapus baris TERAKHIR (HapusResep). Maka: isi baris di bawahnya digeser naik satu per satu
     (obat lewat jQuery/select2 C-CARE, lalu jumlah, dosis, satuan, waktu, keterangan), baru baris terakhir dihapus.
     Baris racikan tidak ikut digeser (isinya berbeda) → hapus manual. Klik (×) dua kali untuk memastikan. */
  const bacaBaris = i => { const x = f(i); return { obat: obatTerpilih(x.obat) ? x.obat.value : '', ...nilaiBaris(x), racik: !!(x.racikan && x.racikan.checked) }; };
  const pilihObat = (i, val) => new Promise(ok => {
    const h = e => { document.removeEventListener('sjc-pilih-obat-hasil', h); ok(e.detail); };
    document.addEventListener('sjc-pilih-obat-hasil', h);
    document.dispatchEvent(new CustomEvent('sjc-pilih-obat', { detail: JSON.stringify({ id: f(i).obat.id, val }) }));
    setTimeout(() => ok('gagal'), 2500);
  });
  async function isiDari(i, d) {
    const x0 = f(i);
    if (!d.obat) {                                                              // sumber kosong → kosongkan baris ini
      if (x0.obat.value) await pilihObat(i, x0.obat.options[0] ? x0.obat.options[0].value : '');
    } else if (await pilihObat(i, d.obat) !== 'ok') return false;
    await new Promise(r => setTimeout(r, 400));                                 // isi otomatis C-CARE/memori selesai dulu, baru ditimpa
    const x = f(i);
    ['jumlah', 'intensitas', 'jumlahDosis', 'ket'].forEach(k => { if (x[k]) setNilai(x[k], d[k] || ''); });
    if (x.satuan) { document.dispatchEvent(new CustomEvent('sjc-satuan', { detail: JSON.stringify({ id: x.satuan.id, val: d.satuan || '' }) })); if (x.satuan.value !== (d.satuan || '')) setNilai(x.satuan, d.satuan || ''); }
    x.makan.forEach(r => { const on = r.value === d.makan; if (r.checked !== on) { r.checked = on; r.dispatchEvent(new Event('change', { bubbles: true })); } });
    return true;
  }
  async function hapusResep(k) {
    const idx = indeksBaris().sort((a, b) => a - b), pos = idx.indexOf(k);
    if (pos < 0 || document.__sjcGeserResep) return;
    const sumber = idx.slice(pos + 1).map(bacaBaris);
    if (bacaBaris(k).racik || sumber.some(d => d.racik)) { pesanBaris(k, 'Baris racikan tidak bisa digeser otomatis — hapus manual dengan (−) dari bawah.'); return; }
    const ob = f(k).obat;
    if (sumber.some(d => d.obat && ![...ob.options].some(o => o.value === d.obat && !o.disabled))) { pesanBaris(k, 'Ada obat di bawah yang tidak tersedia lagi — hapus manual.'); return; }
    document.__sjcGeserResep = true;
    try {
      for (let j = 0; j < sumber.length; j++) if (!(await isiDari(idx[pos + j], sumber[j]))) { pesanBaris(idx[pos + j], 'Gagal menggeser — periksa baris resep ini sebelum Simpan.'); return; }
      const n = indeksBaris().length;
      if (sumber.length) document.dispatchEvent(new CustomEvent('sjc-hapus-resep'));      // buang baris terakhir (kini salinan baris di atasnya)
      else await isiDari(k, { obat: '' });                                                  // baris terakhir → cukup dikosongkan
      if (sumber.length) await tunggu(() => indeksBaris().length < n ? true : undefined, 4000);
      idx.slice(pos).forEach(i => nantiKet(i));
    } finally { document.__sjcGeserResep = false; }
  }
  function pesanBaris(i, t) {
    const r = document.getElementById('Resep_' + i); if (!r) return;
    let p = r.querySelector('.sjc-hapus-pesan'); if (!p) { const o = f(i).obat; p = document.createElement('div'); p.className = 'sjc-hapus-pesan'; p.setAttribute('role', 'alert'); ((o && o.closest('td')) || r.querySelector('td') || r).appendChild(p); }
    p.textContent = t; setTimeout(() => p.remove(), 6000);
  }
  function pasangSilang() {
    $$('#GrupResep tr[id^="Resep_"]').forEach(r => {
      if (r.querySelector('.sjc-hapus-resep')) return;
      const td = r.querySelector('td'); if (!td) return;
      const b = document.createElement('button'); b.type = 'button'; b.className = 'sjc-hapus-resep'; b.textContent = '×';
      b.title = 'Hapus resep ini (klik dua kali)'; b.setAttribute('aria-label', 'Hapus resep nomor ini');
      td.appendChild(b);
    });
  }
  document.addEventListener('click', e => {
    const b = e.target.closest && e.target.closest('.sjc-hapus-resep'); if (!b) return;
    e.preventDefault();
    const r = b.closest('tr[id^="Resep_"]'), i = r ? +r.id.split('_')[1] : NaN; if (isNaN(i)) return;
    if (!b.classList.contains('yakin')) { b.classList.add('yakin'); b.textContent = 'Hapus?'; setTimeout(() => { b.classList.remove('yakin'); b.textContent = '×'; }, 3000); return; }
    b.classList.remove('yakin'); b.textContent = '…'; hapusResep(i).finally(() => { b.textContent = '×'; });
  });
  new MutationObserver(() => pasangSilang()).observe(document.getElementById('GrupResep') || document.body, { childList: true, subtree: true });
  pasangSilang();
  GAYA.textContent += `
  .sjc-hapus-resep{display:block;margin:8px auto 0;min-width:32px;height:32px;padding:0 8px;border:1px solid #E3B4B4;border-radius:8px;background:#fff;color:#B91C1C;font:600 16px/1 "Segoe UI",system-ui,sans-serif;cursor:pointer}
  .sjc-hapus-resep:hover{background:#FBEAEA}.sjc-hapus-resep.yakin{background:#B91C1C;color:#fff;font-size:12px}
  .sjc-hapus-resep:focus-visible{outline:2px solid #B91C1C;outline-offset:2px}
  .sjc-hapus-pesan{margin-top:6px;font:600 13px/1.3 "Segoe UI",system-ui,sans-serif;color:#B91C1C}`;

  chrome.storage.onChanged.addListener((u, area) => { if (area === 'local' && (u.resepMemori || u.isiCepat)) muat().then(pasangChip); });
  muat().then(() => { pasangChip(); indeksBaris().forEach(i => { /* baris yang sudah ada (CPPT dibuka ulang) tidak diubah */ }); });
})();
