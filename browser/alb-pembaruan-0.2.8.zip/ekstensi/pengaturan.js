/* Pengaturan C-CARE — Scan Jasa · Auto Fill (per poli) · Tampilan · Log · Pembaruan. Semua perubahan tersimpan otomatis. */
const $ = id => document.getElementById(id);
const hariIni = () => new Date(Date.now() + 7 * 36e5).toISOString().slice(0, 10);
const geser = (t, n) => { const d = new Date(t + 'T00:00:00Z'); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };
const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const hari = t => ['Min', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab'][new Date(t + 'T00:00:00Z').getUTCDay()];
const jam = () => new Date(Date.now() + 7 * 36e5).toISOString().slice(11, 16).replace(':', '.');
const IK = {
  ok: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm-2 15-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg>',
  mati: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm0 18a8 8 0 1 1 0-16 8 8 0 0 1 0 16z"/></svg>',
  awas: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M1 21h22L12 2 1 21zm12-3h-2v-2h2v2zm0-4h-2v-4h2v4z"/></svg>',
  galat: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/></svg>',
  info: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/></svg>',
  centang: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 16.17 4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>',
  hapus: '<svg viewBox="0 0 24 24" aria-hidden="true" style="width:16px;height:16px"><path d="M19 6.41 17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>',
};
let tutupToast = null;
function pesan(t, k = '') {                                        // pesan singkat di bawah layar
  const e = $('pesan'); if (!t) { e.hidden = true; return; }
  e.textContent = t; e.className = 'toast ' + k; e.hidden = false;
  clearTimeout(tutupToast); tutupToast = setTimeout(() => { e.hidden = true; }, k === 'galat' ? 9000 : 5000);
}
function tulisPesan(el, t, k = '') { el.hidden = !t; el.className = 'pesan ' + k; el.innerHTML = t ? (IK[k] || '') + '<span>' + esc(t) + '</span>' : ''; }
function tandaTersimpan(akun) { const e = $('statusSimpan'); e.className = 'simpan'; e.innerHTML = IK.centang + '<span>Tersimpan ' + jam() + (akun ? ' · juga di akun Chrome' : '') + '</span>'; }
/* sakelar: teks Aktif/Mati di samping (status = warna + posisi + teks) */
function teksSakelar(root) { (root || document).querySelectorAll('.sk input').forEach(i => { const s = i.parentElement.querySelector('.st'); if (s) s.textContent = i.checked ? 'Aktif' : 'Mati'; }); }

$('versi').textContent = 'v' + chrome.runtime.getManifest().version;
$('muatUlang').onclick = () => { pesan('Memuat ulang ekstensi…'); chrome.runtime.reload(); };

/* ---------- keadaan ---------- */
const DAFTAR_POLI = [                                                     // urutan daftar Auto Fill
  { id: 1, n: 'Poli Umum', p: 'umum' }, { id: 5, n: 'Ruang Tindakan', p: 'tindakan' }, { id: 8, n: 'Prolanis', p: 'prolanis' },
  { id: 4, n: 'Kunjungan Sehat', p: 'sehat' },
  { id: '4mcu', n: 'MCU', p: 'mcu' }, // poli C-CARE sama dengan Kunjungan Sehat (4), tapi formnya sendiri (/Poli/Mcu/…) — Auto Fill oleh mcu.js
  { id: 2, n: 'Poli Gigi' }, { id: 7, n: 'Poli Gizi' }, { id: 'kia', n: 'KIA' },
];
let ic = {}, per = {}, pilihan = 'umum';
function aturanPerForm(s) {                                        // sama dengan aturanPer() di pantau.js
  if (s.pantauPer && typeof s.pantauPer === 'object') {
    const o = JSON.parse(JSON.stringify(s.pantauPer));
    if (o[4] && !o['4mcu']) o['4mcu'] = Object.assign({}, o[4]);    // migrasi: MCU baru dipisah dari Kunjungan Sehat — warisi pengaturan lama
    return o;
  }
  const lama = Array.isArray(s.pantauPoli) && s.pantauPoli.length ? s.pantauPoli.map(String) : ['1', '5', '8', '4'], o = {};
  DAFTAR_POLI.forEach(({ id }) => { const on = s.pantauSiap !== false && (lama.includes(String(id)) || (id === '4mcu' && lama.includes('4'))); o[id] = { notif: on, bunyi: on && s.pantauBunyi !== false, cepat: on && id === 1 }; });
  return o;
}

const isiForm = () => chrome.storage.local.get(['url', 'kunci', 'nama', 'terakhir', 'baruDiperbarui', 'liburTambahan', 'bunyiAktif', 'kirimOtomatis', 'isiCepat', 'pantauSiap', 'pantauBunyi', 'pantauPoli', 'pantauPer'], async s => {
  ic = s.isiCepat || {};
  if (pisahkanIsian(ic)) await chrome.storage.local.set({ isiCepat: ic });   // jaga-jaga bila latar belum memisahkan
  per = aturanPerForm(s);
  $('url').value = s.url || ''; $('kunci').value = s.kunci || ''; $('nama').value = s.nama || '';
  $('kirimOtomatis').checked = s.kirimOtomatis !== false; $('bunyiAktif').checked = s.bunyiAktif !== false;
  $('icAktif').checked = !ic.mati; $('icSalin').checked = ic.autoSalin !== false; $('icDiagnosa').checked = ic.bukaDiagnosa !== false;
  $('icTanggal').checked = !ic.tampilTanggal; $('icFormulir').checked = !ic.formulirBiasa; $('icCppt').checked = !ic.cpptBiasa; $('icSurat').checked = !ic.suratMati; $('icFavorit').checked = !ic.favoritMati; $('icPintasan').checked = !ic.pintasanMati; $('icResep').checked = !ic.resepMati; $('icDua').checked = !ic.duaMati; $('icLog').checked = !ic.logMati; tampilFav(); tampilResep(); tampilLog();
  $('liburTambahan').value = s.liburTambahan || ''; tampilLibur();
  $('infoOtomatis').textContent = s.terakhir ? `Terakhir terkirim otomatis: ${hari(s.terakhir)}, ${s.terakhir.split('-').reverse().join('/')}` : '';
  if (s.baruDiperbarui) { $('infoUpdate').hidden = false; $('infoUpdate').innerHTML = IK.ok + `<span>Diperbarui ke v${esc(s.baruDiperbarui)}. Pengaturan Anda tetap.</span>`; chrome.storage.local.remove('baruDiperbarui'); }
  teksSakelar(); tampilDaftar(); tampilRinci();
});
chrome.runtime.sendMessage({ aksi: 'pulihkanSetelan' }, r => {   // pasang ulang / komputer baru: ambil dulu dari akun Chrome
  isiForm();
  if (r && r.dipulihkan) { $('infoUpdate').hidden = false; $('infoUpdate').innerHTML = IK.ok + '<span>Pengaturan dipulihkan dari akun Chrome Anda.</span>'; }
});

/* ---------- simpan ---------- */
let ujiTunda = null;
async function simpan(blok) {
  const s = await chrome.storage.local.get('isiCepat'); ic = Object.assign(s.isiCepat || {}, {
    mati: !$('icAktif').checked, autoSalin: $('icSalin').checked, bukaDiagnosa: $('icDiagnosa').checked,
    tampilTanggal: !$('icTanggal').checked, formulirBiasa: !$('icFormulir').checked, cpptBiasa: !$('icCppt').checked, suratMati: !$('icSurat').checked, favoritMati: !$('icFavorit').checked, pintasanMati: !$('icPintasan').checked, resepMati: !$('icResep').checked, duaMati: !$('icDua').checked, logMati: !$('icLog').checked, poliMati: ic.poliMati || {},
  });
  await chrome.storage.local.set({
    url: $('url').value.trim(), kunci: $('kunci').value.trim(), nama: $('nama').value.trim(),
    bunyiAktif: $('bunyiAktif').checked, kirimOtomatis: $('kirimOtomatis').checked, pantauPer: per,
    liburTambahan: $('liburTambahan').value.split('\n').map(x => x.trim()).filter(x => /^\d{4}-\d{2}-\d{2}/.test(x)).join('\n'),
    isiCepat: ic,
  });
  chrome.runtime.sendMessage({ aksi: 'simpanSetelanAkun' }, r => tandaTersimpan(r && r.ok));
  if (blok === 'sheet' && $('url').value.trim() && $('kunci').value.trim()) { clearTimeout(ujiTunda); ujiTunda = setTimeout(() => ujiKoneksi(true), 300); }
}
const BLOK = { nama: 'profil', url: 'sheet', kunci: 'sheet', kirimOtomatis: 'scan', bunyiAktif: 'scan', icAktif: 'isi', icSalin: 'isi', icDiagnosa: 'isi', icTanggal: 'isi', icFormulir: 'isi', icCppt: 'isi', icSurat: 'isi', icFavorit: 'isi', icPintasan: 'isi', icResep: 'isi', icDua: 'isi', icLog: 'isi' };
Object.keys(BLOK).forEach(id => {
  const el = $(id); let t = null;
  el.addEventListener('change', () => { clearTimeout(t); teksSakelar(); simpan(BLOK[id]); if (id === 'icAktif') { tampilDaftar(); tampilRinci(); } });
  if (el.type !== 'checkbox') el.addEventListener('input', () => { clearTimeout(t); t = setTimeout(() => simpan(BLOK[id]), 800); });
});
$('url').addEventListener('input', () => {                         // Kode pasang (SJC1:…) → nama, alamat, kunci terisi sendiri
  const k = bacaKodePasang($('url').value); if (!k) return;
  $('url').value = k.url; $('kunci').value = k.kunci; if (k.nama) $('nama').value = k.nama;
  tulisPesan($('pesanUji'), 'Kode pasang terbaca — nama, alamat, dan kunci sudah terisi.', 'ok');
  simpan('sheet');
});

/* ---------- tab ---------- */
const TAB = ['pantau', 'bunyi', 'auto', 'tampilan', 'scan', 'pcare', 'log', 'pembaruan'], HASH = { pantau: 'pantau', bunyi: 'bunyi', scan: 'scan', auto: 'autofill', tampilan: 'tampilan', pcare: 'pcare', log: 'log', pembaruan: 'pembaruan' };
function bukaTab(nama, fokus) {
  if (!TAB.includes(nama)) nama = 'pantau';
  TAB.forEach(t => { const b = $('tb-' + t), on = t === nama; b.setAttribute('aria-selected', on); b.tabIndex = on ? 0 : -1; $('tab-' + t).hidden = !on; });
  if (fokus) $('tb-' + nama).focus();
  try { localStorage.setItem('tabPengaturan', nama); } catch (e) {}
  history.replaceState(null, '', '#' + HASH[nama]);
  if (nama === 'auto') requestAnimationFrame(() => tinggiSemua());
}
document.querySelectorAll('.tabs button').forEach(b => b.onclick = () => bukaTab(b.dataset.tab));
document.querySelector('.tabs').onkeydown = e => {
  const i = TAB.indexOf(document.activeElement.dataset.tab); if (i < 0) return;
  if (e.key === 'ArrowRight') bukaTab(TAB[(i + 1) % TAB.length], true);
  else if (e.key === 'ArrowLeft') bukaTab(TAB[(i - 1 + TAB.length) % TAB.length], true);
};
const dariHash = Object.keys(HASH).find(k => '#' + HASH[k] === location.hash);
bukaTab(dariHash || (() => { try { return localStorage.getItem('tabPengaturan') || 'pantau'; } catch (e) { return 'pantau'; } })());

/* ---------- Auto Fill: daftar poli ---------- */
const FORMULIR = { id: 'formulir', n: 'Formulir', p: 'formulir', form: true };
const JENIS_FORM = [['fTK', 'Persetujuan Tindakan Kedokteran', 'Pemberi informasi & dokter = akun Anda, diagnosa dari ICD-10, isian 2–7, identitas pasien, Setuju.'],
  ['fEdu', 'Pemberian Informasi/Edukasi', 'Profesi akun Anda, semua butir edukasi dicentang, tanggal kontrol.'],
  ['fSSC', 'Surgical Safety Checklist', 'Tanggal, diagnosa, GCS & TTV perawat (sebelum tindakan), Time In, semua butir dicentang, Stabil.']];
function statusPoli(x) {
  if (x.form) { if (ic.mati) return { ok: false, t: 'Auto Fill dimatikan' }; const n = JENIS_FORM.filter(([k]) => !(ic.poliMati || {})[k]).length; return { ok: n > 0, t: n ? n + ' dari 3 aktif' : 'Mati' }; }
  if (x.kamus) { const n = String(nilaiAutofill(ic).umum.kamusIcd || '').split('\n').filter(l => l.includes('=>')).length; return { ok: false, t: n + ' baris kata kunci' }; }
  if (ic.mati) return { ok: false, t: 'Auto Fill dimatikan' };
  const af = x.p && !(ic.poliMati || {})[x.id], nt = !!(per[x.id] && per[x.id].notif);
  const t = [af && 'Auto Fill', nt && 'Notif'].filter(Boolean).join(' · ');
  return { ok: !!t, t: t || 'Mati' };
}
function tampilDaftar() {
  const item = x => { const s = statusPoli(x), k = x.kamus ? 'kamus' : String(x.id);
    return `<button type="button" data-k="${k}"${pilihan === k || (pilihan === x.p && !x.kamus) ? ' aria-current="true"' : ''}><span class="n">${esc(x.n)}</span><span class="s${s.ok ? ' ok' : ''}">${x.kamus ? '' : s.ok ? IK.ok : IK.mati}${esc(s.t)}</span></button>`; };
  $('daftarPoli').innerHTML = item({ kamus: true, n: 'Kamus ICD-10' }) + item(FORMULIR) + '<hr>' + DAFTAR_POLI.map(item).join('');
  $('daftarPoli').querySelectorAll('button').forEach(b => b.onclick = () => {
    const x = DAFTAR_POLI.concat(FORMULIR).find(p => String(p.id) === b.dataset.k); pilihan = b.dataset.k === 'kamus' ? 'kamus' : (x.p || b.dataset.k);
    try { localStorage.setItem('poliPengaturan', pilihan); } catch (e) {}
    tampilDaftar(); tampilRinci(); if (innerWidth <= 860) $('rinci').scrollIntoView({ block: 'start' });
  });
}
try { pilihan = localStorage.getItem('poliPengaturan') || 'umum'; } catch (e) {}

/* ---------- Auto Fill: rincian satu poli ---------- */
function tampilRinci() {
  const box = $('rinci');
  if (pilihan === 'kamus') { tampilKamus(box); return; }
  if (pilihan === 'formulir') { tampilFormulir(box); return; }
  const x = DAFTAR_POLI.find(p => p.p === pilihan || String(p.id) === pilihan) || DAFTAR_POLI[0];
  const pp = per[x.id] || {}, af = !(ic.poliMati || {})[x.id], mati = !!ic.mati;
  box.innerHTML = `<div class="kartu"><div class="kk"><h2>${esc(x.n)}</h2>${mati ? '<p>Auto Fill dimatikan di atas — pengaturan poli ini tidak berjalan.</p>' : ''}</div>
    <div class="baris"><div class="t"><b>Auto Fill</b><span>${x.p ? 'Isi CPPT poli ini otomatis saat dibuka.' : 'Susunan CPPT poli ini belum dikenali.'}</span></div>
      ${x.p ? `<label class="sk"><input type="checkbox" role="switch" id="rAf"${af ? ' checked' : ''}${mati ? ' disabled' : ''} aria-label="Auto Fill ${esc(x.n)}"><span class="st"></span></label>` : '<span class="na">Belum tersedia</span>'}</div>
    <div class="baris"><div class="t"><b>Siap dipanggil</b><span>Beri tahu saat pasien pindah ke Menunggu Dokter (perawat selesai).</span></div>
      <div class="sub-sk"><label class="sk kecil">Bunyi <input type="checkbox" role="switch" id="rBunyi"${pp.notif && pp.bunyi ? ' checked' : ''}${!pp.notif || mati ? ' disabled' : ''}></label>
      ${x.id === 'kia' ? '' : `<label class="sk kecil" title="Dibaca tiap ±1,5 detik; tanpa Cepat tiap ±30 detik">Cepat <input type="checkbox" role="switch" id="rCepat"${pp.notif && pp.cepat ? ' checked' : ''}${!pp.notif || mati ? ' disabled' : ''}></label>`}</div>
      <label class="sk"><input type="checkbox" role="switch" id="rNotif"${pp.notif ? ' checked' : ''}${mati ? ' disabled' : ''} aria-label="Siap dipanggil ${esc(x.n)}"><span class="st"></span></label></div>
    ${x.p ? '' : '<p class="kosong-poli">Ingin Auto Fill di poli ini? Buka satu CPPT poli ini di C-CARE, tekan <b>Salin struktur halaman CPPT</b> di bawah, lalu tempel ke percakapan.</p>'}</div>
    ${x.p ? `<div class="kartu ed"><div class="kk"><h2>Isian bawaan</h2><p>Dipakai bila kotak di CPPT masih kosong. Yang berbeda dari bawaan tampil kuning; tekan "Bawaan" untuk mengembalikan.</p></div><div class="ki g2" id="edIsi"></div></div>` : ''}`;
  teksSakelar(box);
  const ubahPer = () => { per[x.id] = { notif: $('rNotif').checked, bunyi: $('rNotif').checked && $('rBunyi').checked, cepat: $('rNotif').checked && !!($('rCepat') && $('rCepat').checked) }; };
  $('rNotif').onchange = () => { if ($('rNotif').checked && !per[x.id]?.notif) { $('rBunyi').checked = true; } ubahPer(); simpan('siap'); tampilDaftar(); tampilRinci(); $('rNotif').focus(); };
  $('rBunyi').onchange = () => { ubahPer(); simpan('siap'); };
  if ($('rCepat')) $('rCepat').onchange = () => { ubahPer(); simpan('siap'); };
  if ($('rAf')) $('rAf').onchange = () => { ic.poliMati = Object.assign({}, ic.poliMati); if ($('rAf').checked) delete ic.poliMati[x.id]; else ic.poliMati[x.id] = true; teksSakelar(box); simpan('isi'); tampilDaftar(); };
  if (x.p) tampilEditor(x.p, $('edIsi'));
  tampilDetak();
}
const tinggi = el => { if (el && el.tagName === 'TEXTAREA' && el.offsetParent) { el.style.height = 'auto'; el.style.height = el.scrollHeight + 2 + 'px'; } };
const tinggiSemua = () => document.querySelectorAll('.ed textarea').forEach(tinggi);
window.addEventListener('resize', tinggiSemua);
function tampilEditor(p, wadah) {
  const nilai = nilaiAutofill(ic)[p];
  wadah.innerHTML = ISIAN_AUTOFILL[p].map(f => {
    const id = `ed-${p}-${f.k}`, v = nilai[f.k] ?? '';
    const isian = f.opsi ? `<select id="${id}">${f.opsi.map(([a, b]) => `<option value="${esc(a)}"${a === v ? ' selected' : ''}>${esc(b)}</option>`).join('')}</select>`
      : f.k === 'KodePenyakit' ? `<input id="${id}" value="${esc(v)}">` : `<textarea id="${id}" rows="1">${esc(v)}</textarea>`;
    return `<div class="fld${f.lebar ? ' penuh' : ''}" data-k="${f.k}"><div class="atas"><label for="${id}">${esc(f.l)}</label><button class="normal" type="button" hidden>Bawaan</button></div>${isian}${f.ket ? `<span class="ket">${esc(f.ket)}</span>` : ''}</div>`;
  }).join('');
  wadah.querySelectorAll('.fld').forEach(fld => {
    const f = ISIAN_AUTOFILL[p].find(z => z.k === fld.dataset.k), el = fld.querySelector('textarea,input,select'), btn = fld.querySelector('.normal');
    const tanda = () => { const ubah = el.value !== f.v; fld.classList.toggle('ubah', ubah); btn.hidden = !ubah; tinggi(el); };
    let t = null;
    const ganti = segera => { tanda(); clearTimeout(t); t = setTimeout(() => simpanIsian(p, f.k, el.value), segera ? 0 : 600); };
    el.addEventListener('input', () => ganti(false)); el.addEventListener('change', () => ganti(true));
    btn.onclick = () => { el.value = f.v; ganti(true); el.focus(); };
    tanda();
  });
}
function tampilFormulir(box) {
  const mati = !!ic.mati, pm = ic.poliMati || {};
  box.innerHTML = `<div class="kartu"><div class="kk"><h2>Formulir</h2><p>Diisi otomatis saat formulir dibuka dari CPPT. Hanya kotak yang masih kosong; tidak pernah menekan Simpan.</p></div>
    ${JENIS_FORM.map(([k, n, ket]) => `<div class="baris"><div class="t"><b>${esc(n)}</b><span>${esc(ket)}</span></div><label class="sk"><input type="checkbox" role="switch" data-f="${k}"${pm[k] ? '' : ' checked'}${mati ? ' disabled' : ''} aria-label="Auto Fill ${esc(n)}"><span class="st"></span></label></div>`).join('')}</div>
    <div class="kartu ed"><div class="kk"><h2>Isian bawaan</h2><p>Yang berbeda dari bawaan tampil kuning; tekan "Bawaan" untuk mengembalikan.</p></div><div class="ki g2" id="edIsi"></div></div>`;
  teksSakelar(box);
  box.querySelectorAll('input[data-f]').forEach(c => c.onchange = () => { ic.poliMati = Object.assign({}, ic.poliMati); if (c.checked) delete ic.poliMati[c.dataset.f]; else ic.poliMati[c.dataset.f] = true; teksSakelar(box); simpan('isi'); tampilDaftar(); });
  tampilEditor('formulir', $('edIsi')); tampilDetak();
}
function tampilKamus(box) {
  const v = nilaiAutofill(ic).umum.kamusIcd, ubah = v !== KAMUS_ICD.v;
  box.innerHTML = `<div class="kartu ed"><div class="kk"><h2>Kamus ICD-10</h2><p>Dipakai semua poli untuk menebak Diagnosa dari anamnesa, hanya bila Diagnosa masih kosong.</p></div>
    <div class="ki"><div class="fld${ubah ? ' ubah' : ''}"><div class="atas"><label for="edKamus">Kata kunci => KODE / nama</label><button class="normal" type="button"${ubah ? '' : ' hidden'}>Bawaan</button></div>
    <textarea id="edKamus" class="mono" rows="3">${esc(v)}</textarea><span class="ket">${esc(KAMUS_ICD.ket || '')}</span></div></div></div>`;
  const el = $('edKamus'), fld = el.closest('.fld'), btn = fld.querySelector('.normal'); let t = null;
  const ganti = segera => { const u = el.value !== KAMUS_ICD.v; fld.classList.toggle('ubah', u); btn.hidden = !u; tinggi(el); clearTimeout(t); t = setTimeout(() => simpanIsian('umum', 'kamusIcd', el.value), segera ? 0 : 600); };
  el.addEventListener('input', () => ganti(false)); btn.onclick = () => { el.value = KAMUS_ICD.v; ganti(true); el.focus(); };
  requestAnimationFrame(() => tinggi(el)); tampilDetak();
}
async function simpanIsian(p, k, v) {
  const s = await chrome.storage.local.get('isiCepat'); ic = s.isiCepat || {};
  const semua = nilaiAutofill(ic); semua[p][k] = v;
  const isian = {};                                               // simpan hanya yang berbeda dari bawaan
  Object.keys(ISIAN_AUTOFILL).forEach(q => ISIAN_AUTOFILL[q].forEach(f => { if (semua[q][f.k] !== f.v) (isian[q] = isian[q] || {})[f.k] = semua[q][f.k]; }));
  if (semua.umum.kamusIcd !== KAMUS_ICD.v) (isian.umum = isian.umum || {}).kamusIcd = semua.umum.kamusIcd;
  ic.isian = isian; ic.template = []; ic.pisahPoli = true;
  await chrome.storage.local.set({ isiCepat: ic });
  const ok = await chrome.storage.sync.set({ isianAutofill: isian, templateIsi: [] }).then(() => true).catch(() => false);
  tandaTersimpan(ok); if (k === 'kamusIcd') tampilDaftar();
}

/* ---------- impor JSON Autofill lama → Poli Umum ---------- */
const cCare = t => /c-?\s?care/i.test(t.name || '') && !/d-?health/i.test(t.name || '');
function bacaTemplate(teks) {
  const j = JSON.parse(teks), L = Array.isArray(j) ? j : [j];
  return L.filter(t => t && Array.isArray(t.fields) && cCare(t)).map(t => ({
    name: String(t.name || 'Tanpa nama').slice(0, 80),
    fields: t.fields.filter(f => f && f.key).map(f => ({ key: String(f.key), value: String(f.value == null ? '' : f.value), fieldType: String(f.fieldType || 'text'), searchType: String(f.searchType || 'name') })),
  }));
}
$('tplImpor').onclick = () => $('tplFile').click();
$('tplFile').onchange = async () => {
  const f = $('tplFile').files[0]; if (!f) return;
  try {
    const baru = bacaTemplate(await f.text());
    if (!baru.length) throw new Error('tidak ada template C-CARE di file ini (template Dhealth dan situs lain diabaikan)');
    const dari = nilaiAutofill({ template: [baru[0]] }).umum; let n = 0;
    for (const fl of ISIAN_AUTOFILL.umum) if (dari[fl.k] !== nilaiAutofill(ic).umum[fl.k]) { await simpanIsian('umum', fl.k, dari[fl.k]); n++; }
    pilihan = 'umum'; tampilDaftar(); tampilRinci();
    tulisPesan($('tplPesan'), n ? `${n} isian Poli Umum diambil dari "${baru[0].name}".` : `Isian "${baru[0].name}" sudah sama dengan yang tersimpan.`, 'ok');
  } catch (e) { tulisPesan($('tplPesan'), 'File bukan JSON template yang dikenali: ' + e.message, 'galat'); }
  $('tplFile').value = '';
};
$('icStruktur').onclick = async () => {
  const tab = (await chrome.tabs.query({ url: 'https://c-care.ipb.ac.id/*/Ubah/*' }))[0];
  if (!tab) { tulisPesan($('tplPesan'), 'Buka dulu halaman CPPT (Ubah) pasien di C-CARE, lalu ulangi.', 'awas'); return; }
  chrome.tabs.sendMessage(tab.id, { aksi: 'strukturHalaman' }, async r => {
    if (!r) { tulisPesan($('tplPesan'), 'Halaman C-CARE belum memuat Auto Fill. Muat ulang halaman itu, lalu ulangi.', 'awas'); return; }
    await navigator.clipboard.writeText(JSON.stringify(r, null, 1));
    tulisPesan($('tplPesan'), `Struktur ${r.isian.length} isian disalin (tanpa data pasien). Tempel ke percakapan.`, 'ok');
  });
};

/* ---------- detak Siap dipanggil ---------- */
async function tampilDetak() {
  const el = $('siapDetak'); if (!el || !chrome.storage.session) return;
  const d = (await chrome.storage.session.get('pantauDetak')).pantauDetak;
  const adaNotif = DAFTAR_POLI.some(({ id }) => per[id] && per[id].notif), tanpaCepat = DAFTAR_POLI.filter(({ id }) => id !== 'kia' && per[id] && per[id].notif && !per[id].cepat).map(x => x.n);
  let j = 'info', t; const umur = d ? Math.round((Date.now() - d.waktu) / 1000) : null;
  if (!$('icAktif').checked || (d && d.keadaan === 'af-mati')) { j = 'mati'; t = 'Siap dipanggil berhenti: Auto Fill dimatikan.'; }
  else if (!adaNotif) { j = 'mati'; t = 'Siap dipanggil mati di semua poli.'; }
  else if (!d) { j = 'awas'; t = 'Siap dipanggil belum berjalan. Buka atau muat ulang tab C-CARE.'; }
  else if (d.keadaan === 'luar-jam') { j = 'mati'; t = 'Siap dipanggil: di luar jam pantau (06.00–22.00 WIB).'; }
  else if (d.keadaan === 'tanpa-tab') { j = 'awas'; t = 'Siap dipanggil menunggu: tab C-CARE belum dibuka.'; }
  else if (d.keadaan === 'login') { j = 'awas'; t = 'Siap dipanggil: C-CARE perlu login ulang.'; }
  else if (umur > 12) { j = 'galat'; t = `Siap dipanggil berhenti ${umur} dtk lalu. Muat ulang tab C-CARE.`; }
  else if (d.keadaan === 'galat') { j = 'awas'; t = 'Siap dipanggil: C-CARE tidak menjawab, mencoba lagi…'; }
  else if (d.keadaan === 'sibuk') { j = 'ok'; t = 'Siap dipanggil berjalan · menunggu Anda selesai mengetik di C-CARE'; }
  else if (d.keadaan === 'lambat') { j = 'awas'; t = 'Siap dipanggil berjalan tanpa Cepat: bisa telat ±10–20 dtk.'; }
  else if (d.keadaan === 'hemat') { j = 'ok'; t = 'Siap dipanggil berjalan · mode hemat: dibaca lebih jarang sampai ada pasien di perawat'; }
  else { j = 'ok'; t = `Siap dipanggil berjalan · dibaca ${umur} dtk lalu · ${((d.ms || 0) / 1000).toFixed(1).replace('.', ',')} dtk per baca`; }
  if (j === 'ok' && d && d.jalur) t += d.jalur === 'langsung' ? ' · langsung dari ekstensi' : ' · lewat tab C-CARE';
  if (j === 'ok' && tanpaCepat.length) { j = 'awas'; t += ` · tanpa Cepat (telat ±10 dtk): ${tanpaCepat.join(', ')}`; }
  const kelas = { ok: 'ok', awas: 'awas', galat: 'galat', mati: '', info: '' }[j], ikon = { ok: IK.ok, awas: IK.awas, galat: IK.galat, mati: IK.mati, info: IK.info }[j];
  el.className = 'detak ' + kelas; el.innerHTML = ikon + '<span>' + esc(t) + '</span>';
}
setInterval(() => { if (!$('tab-pantau').hidden) tampilDetak(); }, 1000);

/* ---------- tanggal dikecualikan ---------- */
const BLN = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
const daftarLibur = () => $('liburTambahan').value.split('\n').map(x => x.trim()).filter(x => /^\d{4}-\d{2}-\d{2}/.test(x)).map(x => ({ t: x.slice(0, 10), n: x.slice(10).trim() }));
function tulisLibur(L) {
  const u = {}; L.forEach(x => u[x.t] = x.n);
  $('liburTambahan').value = Object.keys(u).sort().map(t => (t + ' ' + (u[t] || '')).trim()).join('\n');
  tampilLibur(); simpan('libur');
}
function tampilLibur() {
  const L = daftarLibur();
  $('liburDaftar').innerHTML = L.length ? L.map(x => `<li><b>${hari(x.t)}, ${+x.t.slice(8)} ${BLN[+x.t.slice(5, 7) - 1]} ${x.t.slice(0, 4)}</b>${x.n ? ' · ' + esc(x.n) : ''}<button type="button" data-t="${x.t}" title="Hapus" aria-label="Hapus ${x.t}">${IK.hapus}</button></li>`).join('')
    : '<li class="kosong">Belum ada tanggal</li>';
  $('liburDaftar').querySelectorAll('button').forEach(b => b.onclick = () => tulisLibur(daftarLibur().filter(x => x.t !== b.dataset.t)));
}
$('liburTambah').onclick = () => {
  const t = $('liburTgl').value; if (!t) { $('liburTgl').focus(); return; }
  tulisLibur(daftarLibur().concat({ t, n: $('liburNama').value.trim() || 'Libur' }));
  $('liburTgl').value = ''; $('liburNama').value = '';
};
$('liburNama').addEventListener('keydown', e => { if (e.key === 'Enter') $('liburTambah').click(); });

/* ---------- uji koneksi & pilih nama ---------- */
async function ujiKoneksi(setelahSimpan) {
  $('uji').disabled = true; tulisPesan($('pesanUji'), 'Menguji koneksi ke Web App…', 'info');
  try {
    const j = await ambilStatusSheet($('url').value.trim(), $('kunci').value.trim());
    tulisPesan($('pesanUji'), 'Tersambung ke Sheet — ' + Object.keys(j.data || {}).length + ' tanggal sudah ada di Data Klinik.', 'ok');
    if (setelahSimpan) chrome.runtime.sendMessage({ aksi: 'sinkronStatus', paksa: true });
  } catch (e) { tulisPesan($('pesanUji'), 'Belum tersambung: ' + e.message, 'galat'); }
  $('uji').disabled = false;
}
$('uji').onclick = () => ujiKoneksi(false);
$('cariNama').onclick = async () => {
  $('cariNama').disabled = true; pesan('Mencari nama dokter di C-CARE (3 hari terakhir)…');
  let tab = null;
  try {
    tab = await tabCcare(); const nama = new Set();
    for (let i = 1; i <= 3; i++) {
      const r = await jalankan(tab, ambilDaftar, [geser(hariIni(), -i), [1, 5]]);
      if (!r || r.login) throw new Error('Belum login C-CARE. Login dulu, lalu ulangi.');
      const ids = r.baris.filter(b => b.status === 'Selesai').map(b => b.kunjungan);
      const sampel = ids.filter((_, k) => k % Math.max(1, Math.floor(ids.length / 25)) === 0).slice(0, 25);
      const m = await jalankan(tab, ambilDetail, [sampel, false]);
      Object.values(m).forEach(d => { const n = d && namaDokter(d.dokter); if (n) nama.add(n); });
    }
    $('daftarNama').innerHTML = [...nama].sort().map(n => `<option value="${esc(n)}">`).join('');
    $('nama').focus();
    pesan(nama.size ? 'Pilih nama Anda di kotak Nama dokter — tersimpan otomatis.' : 'Tidak ada kunjungan selesai 3 hari terakhir. Ketik nama Anda persis seperti di C-CARE.', nama.size ? 'ok' : 'awas');
  } catch (e) { pesan(e.message || String(e), 'galat'); }
  if (tab && tab.dibuat) chrome.tabs.remove(tab.id).catch(() => {});
  $('cariNama').disabled = false;
};

/* ---------- log ---------- */
const NAMA_LV = { galat: 'Galat', awas: 'Peringatan', info: 'Info' };
let saring = 'semua', logSemua = [];
function tampilLog() {
  const L = logSemua.filter(x => saring === 'semua' || x.level !== 'info').slice().reverse();
  $('logJumlah').textContent = `${logSemua.length} catatan · ${logSemua.filter(x => x.level === 'galat').length} galat`;
  $('logIsi').innerHTML = L.length ? L.map(x => `<tr><td class="w">${esc(x.waktu)}</td><td><span class="lv lv-${x.level}">${IK[x.level] || ''}${NAMA_LV[x.level] || esc(x.level)}</span></td><td>${esc(x.sumber)}</td><td>${esc(x.teks)}${x.detail ? `<details><summary>Detail teknis</summary><pre>${esc(x.detail)}</pre></details>` : ''}</td><td class="w">${esc(x.versi || '')}</td></tr>`).join('')
    : `<tr><td colspan="5" style="text-align:center;color:var(--teks-2);padding:24px">${saring === 'semua' ? 'Belum ada catatan.' : 'Tidak ada galat atau peringatan.'}</td></tr>`;
}
document.querySelectorAll('.seg2 button').forEach(b => b.onclick = () => { saring = b.dataset.f; document.querySelectorAll('.seg2 button').forEach(x => x.setAttribute('aria-pressed', x === b)); tampilLog(); });
chrome.storage.local.get('log', s => { logSemua = s.log || []; tampilLog(); });
chrome.storage.onChanged.addListener((c, a) => {
  if (a !== 'local') return;
  if (c.log) { logSemua = c.log.newValue || []; tampilLog(); }
  if (c.isiCepat && c.isiCepat.newValue && !!c.isiCepat.newValue.mati !== !!ic.mati) {   // sakelar di balon diubah
    ic = c.isiCepat.newValue; $('icAktif').checked = !ic.mati; teksSakelar(); tampilDaftar(); tampilRinci();
  }
});
$('logSalin').onclick = async () => {
  const m = chrome.runtime.getManifest();
  const teks = `Scan Jasa C-CARE v${m.version} · ${navigator.userAgent.match(/Chrome\/[\d.]+/) || ''}\n` +
    logSemua.slice(-100).map(x => `${x.waktu} [${x.level}] ${x.sumber} v${x.versi || '?'}: ${x.teks}${x.detail ? '\n    ' + x.detail.split('\n').slice(0, 4).join('\n    ') : ''}`).join('\n');
  await navigator.clipboard.writeText(teks);
  pesan('Log disalin (100 catatan terakhir). Tempel ke percakapan untuk diperiksa.', 'ok');
};
$('logHapus').onclick = async () => {
  if (!confirm('Hapus semua catatan log? Catatan yang dihapus tidak bisa dikembalikan.')) return;
  await chrome.storage.local.set({ log: [] }); pesan('Log dihapus.', 'ok');
};
window.addEventListener('hashchange', () => { const k = Object.keys(HASH).find(x => '#' + HASH[x] === location.hash); if (k) bukaTab(k); });

/* ---------- Pantau & Bunyi (selaras CCare Farmasi) ---------- */
document.querySelectorAll('[data-ke]').forEach(b => b.onclick = () => bukaTab(b.dataset.ke, true));
const BUNYI = [
  { grup: 'Unik', id: 'kapsul', nama: 'Kapsul', ket: 'Dua nada naik, lembut' }, { grup: 'Unik', id: 'apotek', nama: 'Apotek', ket: 'Marimba tiga nada' },
  { grup: 'Unik', id: 'panggil', nama: 'Panggil', ket: 'Cepat, mudah terdengar' }, { grup: 'Unik', id: 'ding-dong', nama: 'Ding-dong', ket: 'Bel rumah' },
  { grup: 'Unik', id: 'lonceng', nama: 'Lonceng', ket: 'Satu dentang panjang' }, { grup: 'Unik', id: 'kristal', nama: 'Kristal', ket: 'Akor berkilau' },
  { grup: 'Meme', id: 'meme-tetot', nama: 'Tetot!', ket: 'Bel kuis salah' }, { grup: 'Meme', id: 'meme-tada', nama: 'Ta-da!', ket: 'Fanfare kemenangan' },
  { grup: 'Meme', id: 'meme-wah-wah', nama: 'Wah wah wah', ket: 'Trombon sedih' }, { grup: 'Meme', id: 'meme-tung-tung', nama: 'Tung tung tung', ket: 'Kentongan sahur' },
  { grup: 'Meme', id: 'meme-kring', nama: 'Kring kring', ket: 'Bel sepeda' }, { grup: 'Meme', id: 'meme-boing', nama: 'Boing', ket: 'Pegas kartun' },
  { grup: 'Sendiri', id: 'sendiri', nama: 'Suara sendiri', ket: 'File yang Anda unggah' },
];
const IK_PUTAR = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 5v14l11-7z"/></svg>';
let SB = { aktif: true, pilih: 'kapsul', volume: 80, ulang: 1 };
async function simpanBunyi(ubah) { Object.assign(SB, ubah); await chrome.storage.local.set({ siapBunyi: SB }); tandaTersimpan(false); }
const uji = id => chrome.runtime.sendMessage({ aksi: 'ujiBunyi', bunyi: Object.assign({}, SB, id ? { pilih: id } : {}) });
const tampilSeg = (id, v) => $(id).querySelectorAll('button').forEach(b => b.setAttribute('aria-pressed', String(String(v) === b.dataset.v)));
function gambarBunyi() {
  const w = $('daftarBunyi'); w.replaceChildren(); let grup = '';
  BUNYI.forEach(b => {
    if (b.grup !== grup) { grup = b.grup; const h = document.createElement('h3'); h.textContent = grup === 'Unik' ? 'Bunyi unik' : grup === 'Meme' ? 'Bunyi meme' : 'Milik Anda'; w.append(h); }
    const l = document.createElement('label'); l.className = 'snd';
    l.innerHTML = `<input type="radio" name="bunyiPilih" value="${b.id}"${SB.pilih === b.id ? ' checked' : ''}><span class="nm"><b>${esc(b.nama)}</b><small>${esc(b.ket)}</small></span><button type="button" class="putar" title="Dengar ${esc(b.nama)}" aria-label="Dengar ${esc(b.nama)}">${IK_PUTAR}</button>`;
    l.querySelector('input').onchange = () => { simpanBunyi({ pilih: b.id }); uji(b.id); };
    l.querySelector('.putar').onclick = e => { e.preventDefault(); uji(b.id); };
    w.append(l);
  });
}
async function tampilSendiri() {
  const s = (await chrome.storage.local.get('bunyiSendiri')).bunyiSendiri;
  $('sendiriNama').textContent = s ? s.nama : 'Belum ada'; $('sendiriInfo').textContent = s ? Math.round(s.ukuran / 1024) + ' KB' : '';
  $('sendiriHapus').hidden = !s; const r = document.querySelector('input[name=bunyiPilih][value=sendiri]'); if (r) r.disabled = !s;
}
chrome.storage.local.get(['siapBunyi', 'siapJeda', 'siapNotif'], s => {
  SB = Object.assign(SB, s.siapBunyi || {});
  $('bunyiSiap').checked = SB.aktif !== false; $('volume').value = SB.volume; $('volumeTeks').textContent = SB.volume + '%';
  tampilSeg('ulang', SB.ulang); tampilSeg('siapJeda', s.siapJeda || 2); $('siapNotif').checked = s.siapNotif !== false;
  gambarBunyi(); tampilSendiri(); teksSakelar();
});
$('bunyiSiap').addEventListener('change', () => { teksSakelar(); simpanBunyi({ aktif: $('bunyiSiap').checked }); });
$('volume').addEventListener('input', () => { $('volumeTeks').textContent = $('volume').value + '%'; });
$('volume').addEventListener('change', () => simpanBunyi({ volume: +$('volume').value }).then(() => uji()));
$('ulang').addEventListener('click', e => { const b = e.target.closest('button'); if (!b) return; simpanBunyi({ ulang: +b.dataset.v }); tampilSeg('ulang', b.dataset.v); });
$('siapJeda').addEventListener('click', async e => { const b = e.target.closest('button'); if (!b) return; await chrome.storage.local.set({ siapJeda: +b.dataset.v }); tampilSeg('siapJeda', b.dataset.v); tandaTersimpan(false); });
$('siapNotif').addEventListener('change', async () => { teksSakelar(); await chrome.storage.local.set({ siapNotif: $('siapNotif').checked }); tandaTersimpan(false); });
$('sendiriPilih').onclick = () => $('sendiriFile').click();
$('sendiriFile').onchange = async () => {
  const f = $('sendiriFile').files[0]; $('sendiriFile').value = ''; if (!f) return;
  if (!/^audio\//.test(f.type)) return pesan('Bukan file suara.', 'galat');
  if (f.size > 2 * 1024 * 1024) return pesan('File terlalu besar (maks. 2 MB).', 'galat');
  const data = await new Promise(ok => { const r = new FileReader(); r.onload = () => ok(r.result); r.readAsDataURL(f); });
  await chrome.storage.local.set({ bunyiSendiri: { nama: f.name, ukuran: f.size, data } });
  await simpanBunyi({ pilih: 'sendiri' }); gambarBunyi(); tampilSendiri(); uji('sendiri');
};
$('sendiriHapus').onclick = async () => { await chrome.storage.local.remove('bunyiSendiri'); if (SB.pilih === 'sendiri') await simpanBunyi({ pilih: 'kapsul' }); gambarBunyi(); tampilSendiri(); };

async function tampilFav() { const f = (await chrome.storage.local.get('icdFavorit')).icdFavorit || {}; const n = Object.keys(f).length; $('jumlahFav').textContent = n ? n + ' kode tercatat.' : 'Belum ada yang tercatat.'; $('hapusFav').disabled = !n; }
async function tampilResep() { const f = (await chrome.storage.local.get('resepMemori')).resepMemori || {}; const n = Object.keys(f).length; $('jumlahResep').textContent = n ? n + ' obat tercatat.' : 'Belum ada yang tercatat.'; $('hapusResep').disabled = !n; }
$('hapusResep').onclick = async () => { if (!confirm('Kosongkan memori resep? Memori akan terisi lagi dari CPPT yang Anda simpan berikutnya.')) return; await chrome.storage.local.remove('resepMemori'); tampilResep(); pesan('Memori resep dikosongkan.', 'ok'); };
$('hapusFav').onclick = async () => { if (!confirm('Kosongkan daftar ICD-10 favorit? Daftar akan terisi lagi dari CPPT yang Anda simpan berikutnya.')) return; await chrome.storage.local.remove('icdFavorit'); tampilFav(); pesan('ICD-10 favorit dikosongkan.', 'ok'); };
async function tampilLog() { const l = (await chrome.storage.local.get('logAnamnesa')).logAnamnesa || []; const n = l.length; $('jumlahLog').textContent = n ? n + ' kunjungan tercatat.' : 'Belum ada yang tercatat.'; $('hapusLog').disabled = !n; $('unduhLog').disabled = !n; }
$('hapusLog').onclick = async () => { if (!confirm('Kosongkan log anamnesa? Catatan yang sudah ada akan hilang (tidak bisa dikembalikan).')) return; await chrome.storage.local.remove('logAnamnesa'); tampilLog(); pesan('Log anamnesa dikosongkan.', 'ok'); };
$('unduhLog').onclick = async () => {
  const l = (await chrome.storage.local.get('logAnamnesa')).logAnamnesa || []; if (!l.length) return;
  const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([JSON.stringify(l, null, 1)], { type: 'application/json' }));
  a.download = 'log-anamnesa-' + new Date().toISOString().slice(0, 10) + '.json'; a.click(); URL.revokeObjectURL(a.href);
};

/* ---------- Periksa di C-CARE: jalur baca, struktur daftar, CPPT & surat (dari halaman yang Anda buka sendiri), Simpan ---------- */
const KOLOM_C = ['No', 'Tanggal Kunjungan', 'Tanggal Pemeriksaan', 'Nomor Rekam Medis', 'Nama Pasien', 'Status Pemeriksaan', 'Aksi'];
const STATUS_C = /^(menunggu pemeriksaan (dokter|perawat)|menunggu obat|selesai|rujuk|dirujuk|pulang)/i;
const kapan = w => { if (!w) return ''; const m = Math.round((Date.now() - w) / 60000); return m < 1 ? 'baru saja' : m < 60 ? m + ' mnt lalu' : m < 1440 ? Math.round(m / 60) + ' jam lalu' : Math.round(m / 1440) + ' hari lalu'; };
function tulisPeriksa(baris) {
  const LBL = { ok: 'Lulus', awas: 'Perlu dicek', galat: 'Gagal', info: 'Belum ada data' }, IKP = { ok: IK.ok, awas: IK.awas, galat: IK.galat, info: IK.info };
  $('periksaDaftar').innerHTML = baris.map(([k, judul, ket]) => `<li class="p-${k}">${IKP[k]}<b>${esc(judul)}</b><em>${LBL[k]}</em><span>${esc(ket)}</span></li>`).join('');
}
async function periksaCcare() {
  const b = $('periksaMulai'); b.disabled = true; b.textContent = 'Memeriksa…';
  const [d, s, ses] = await Promise.all([chrome.runtime.sendMessage({ aksi: 'periksaDaftar' }).catch(e => ({ galat: String(e.message || e) })),
    chrome.storage.local.get(['diagCppt', 'diagSurat', 'diagSimpan']), chrome.storage.session.get('pantauDetak')]);
  const det = ses.pantauDetak || {}, out = [];
  out.push(det.jalur === 'langsung' ? ['ok', 'Jalur baca', 'Langsung dari ekstensi: tab C-CARE tidak dipakai, tidak menunggu Anda selesai mengetik.']
    : det.jalur === 'tab' ? ['awas', 'Jalur baca', 'Lewat tab C-CARE (C-CARE menolak jalur langsung). Tetap berfungsi; pembacaan menunggu saat Anda mengetik.']
    : ['info', 'Jalur baca', 'Pemantau belum membaca. Buka tab C-CARE dan nyalakan Siap dipanggil.']);
  if (d && d.galat) out.push(['galat', 'Daftar poli', d.galat]);
  else if (d) {
    const kurang = KOLOM_C.filter(k => !d.kolom.includes(k));
    out.push(kurang.length ? ['galat', 'Kolom daftar poli', 'Tidak ditemukan: ' + kurang.join(', ') + '. Ringkas daftar & pemantau bisa salah baca.'] : ['ok', 'Kolom daftar poli', '7 kolom sesuai (Poli Umum, filter yang sedang aktif).']);
    const asing = Object.keys(d.status).filter(t => !STATUS_C.test(t));
    out.push(!d.baris ? ['info', 'Status pemeriksaan', 'Daftar kosong pada filter saat ini.'] : asing.length ? ['awas', 'Status pemeriksaan', 'Status baru belum dikenal: ' + asing.join(', ')] : ['ok', 'Status pemeriksaan', Object.entries(d.status).map(([t, n]) => t + ' ' + n).join(' · ')]);
    out.push(['ok', 'Batal berobat', d.tanpaUbah ? d.tanpaUbah + ' kunjungan tanpa tombol Ubah dikenali sebagai batal berobat.' : 'Tidak ada kunjungan batal pada filter saat ini.']);
    if (!d.token) out.push(['galat', 'Token formulir', 'Token C-CARE tidak ditemukan — pembacaan cepat akan gagal.']);
  }
  const c = s.diagCppt;
  if (!c) out.push(['info', 'Halaman CPPT', 'Buka satu CPPT pasien Anda, lalu periksa lagi.']);
  else { const hilang = Object.entries(c.el).filter(([, v]) => !v).map(([k]) => k); out.push(hilang.length ? ['galat', 'Halaman CPPT', 'Tidak ditemukan: ' + hilang.join(', ') + ' · ' + kapan(c.waktu)] : ['ok', 'Halaman CPPT', 'Simpan, ICD-10, tindak lanjut, status, rujukan ditemukan · ' + kapan(c.waktu)]); }
  out.push(s.diagSimpan ? ['ok', 'Simpan CPPT terdeteksi', 'Pasien keluar dari Siap dipanggil setelah Simpan · terakhir ' + kapan(s.diagSimpan.waktu)] : ['info', 'Simpan CPPT terdeteksi', 'Belum ada Simpan CPPT sejak versi ini. Simpan satu CPPT, lalu periksa lagi.']);
  out.push(!s.diagSurat ? ['info', 'Surat istirahat', 'Buka CPPT dengan baris Surat istirahat aktif, lalu periksa lagi.'] : s.diagSurat.ok ? ['ok', 'Surat istirahat', 'Formulir surat sakit C-CARE terbaca (Diagnosa, Tmt, Tst) · ' + kapan(s.diagSurat.waktu)] : ['galat', 'Surat istirahat', 'Formulir surat sakit berubah — isian tidak ditemukan.']);
  tulisPeriksa(out); b.disabled = false; b.textContent = 'Periksa lagi';
}
$('periksaMulai').onclick = periksaCcare;

/* ---------- ICD-10 favorit 1–10 (diatur sendiri; cari langsung ke C-CARE /Ajax/Penyakit) ---------- */
const IKI = { naik: '<svg viewBox="0 0 24 24"><path d="M7.4 15.4L12 10.8l4.6 4.6L18 14l-6-6-6 6z"/></svg>', turun: '<svg viewBox="0 0 24 24"><path d="M7.4 8.6L12 13.2l4.6-4.6L18 10l-6 6-6-6z"/></svg>', hapus: '<svg viewBox="0 0 24 24"><path d="M19 6.4L17.6 5 12 10.6 6.4 5 5 6.4 10.6 12 5 17.6 6.4 19 12 13.4 17.6 19 19 17.6 13.4 12z"/></svg>' };
let icdPilihan = [];
const simpanIcd = async () => { await chrome.storage.local.set({ icdPilihan }); };
const teksIcd = x => x && x.kode ? x.kode + ' · ' + String(x.teks || '').replace(/^[A-Z]\d+(\.\d+)?\s*\/\s*/, '') : '';
async function cariIcd(q) {
  try {
    const r = await fetch('https://c-care.ipb.ac.id/Ajax/Penyakit?q=' + encodeURIComponent(q) + '&id=', { credentials: 'include' });
    const d = await r.json(); if (d && d.stat == true) return d.res.slice(0, 8).map(x => ({ kode: x.ID, teks: x.Value }));
  } catch (e) {}
  const { icdFavorit = {} } = await chrome.storage.local.get('icdFavorit');          // cadangan: riwayat Anda sendiri
  const t = q.toLowerCase(); return Object.entries(icdFavorit).filter(([k, x]) => (k + ' ' + x.teks).toLowerCase().includes(t)).slice(0, 8).map(([k, x]) => ({ kode: k, teks: x.teks, lokal: true }));
}
function gambarIcd() {
  const ol = $('icdDaftar'); ol.innerHTML = '';
  for (let i = 0; i < 12; i++) {
    const x = icdPilihan[i], li = document.createElement('li'); li.className = x && x.kode ? 'ada' : '';
    li.innerHTML = `<span class="no">${i + 1}</span><span class="sel"><button type="button" class="isi" aria-label="Ganti ICD-10 nomor ${i + 1}"></button><input type="search" aria-label="ICD-10 nomor ${i + 1}" placeholder="Ketik kode atau nama ICD-10"></span><button type="button" class="ib" data-a="naik" aria-label="Naikkan" title="Naikkan">${IKI.naik}</button><button type="button" class="ib" data-a="turun" aria-label="Turunkan" title="Turunkan">${IKI.turun}</button><button type="button" class="ib" data-a="hapus" aria-label="Hapus" title="Hapus">${IKI.hapus}</button>`;
    const inp = li.querySelector('input'); inp.value = teksIcd(x);
    /* v4.6.4: kode terisi tampil sebagai teks penuh (boleh 2 baris, tidak terpotong); klik → jadi kolom cari */
    const isi = li.querySelector('.isi');
    if (x && x.kode) { isi.innerHTML = `<b>${x.kode}</b><span>${String(x.teks || '').replace(/^[A-Z]\d+(\.\d+)?\s*\/\s*/, '').replace(/[&<>]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]))}</span>`; inp.hidden = true; }
    else isi.hidden = true;
    isi.addEventListener('click', () => { isi.hidden = true; inp.hidden = false; inp.focus(); inp.select(); });
    li.querySelector('[data-a=naik]').disabled = !x || i === 0; li.querySelector('[data-a=turun]').disabled = !x || !icdPilihan[i + 1]; li.querySelector('[data-a=hapus]').disabled = !x;
    let waktu = 0, daftar = null;
    const tutup = () => { if (daftar) { daftar.remove(); daftar = null; } };
    inp.addEventListener('input', () => {
      clearTimeout(waktu); const q = inp.value.trim(); if (q.length < 2) { tutup(); return; }
      waktu = setTimeout(async () => {
        const hasil = await cariIcd(q); tutup(); daftar = document.createElement('ul'); daftar.className = 'icd-hasil';
        daftar.innerHTML = hasil.length ? hasil.map((h, k) => `<li><button type="button" data-k="${k}"></button></li>`).join('') : '<li class="k">Tidak ditemukan. Pastikan C-CARE sudah login di Chrome.</li>';
        daftar.querySelectorAll('button').forEach(b => { const h = hasil[+b.dataset.k]; b.textContent = teksIcd(h) + (h.lokal ? '  (riwayat Anda)' : ''); b.onclick = async () => { icdPilihan[i] = { kode: h.kode, teks: h.teks }; icdPilihan = icdPilihan.filter(Boolean); await simpanIcd(); gambarIcd(); $('icdKet').textContent = 'Tersimpan.'; }; });
        li.appendChild(daftar);
      }, 250);
    });
    inp.addEventListener('blur', () => setTimeout(() => { tutup(); inp.value = teksIcd(icdPilihan[i]); if (icdPilihan[i]) { inp.hidden = true; isi.hidden = false; } }, 200));
    inp.addEventListener('keydown', e => { if (e.key === 'Escape') inp.blur(); });
    li.addEventListener('click', async e => {
      const b = e.target.closest('[data-a]'); if (!b || b.disabled) return;
      if (b.dataset.a === 'hapus') icdPilihan.splice(i, 1);
      else { const j = b.dataset.a === 'naik' ? i - 1 : i + 1; [icdPilihan[i], icdPilihan[j]] = [icdPilihan[j], icdPilihan[i]]; }
      icdPilihan = icdPilihan.filter(Boolean); await simpanIcd(); gambarIcd();
    });
    ol.appendChild(li);
  }
}
$('icdIsiSering').onclick = async () => {
  const { icdFavorit = {} } = await chrome.storage.local.get('icdFavorit');
  const top = Object.entries(icdFavorit).sort((a, b) => b[1].n - a[1].n || b[1].t - a[1].t).slice(0, 12).map(([k, x]) => ({ kode: k, teks: x.teks }));
  if (!top.length) { $('icdKet').textContent = 'Belum ada riwayat ICD-10 yang tersimpan.'; return; }
  icdPilihan = top; await simpanIcd(); gambarIcd(); $('icdKet').textContent = top.length + ' ICD-10 tersering dimasukkan — ubah urutan sesuai keinginan.';
};
$('icdKosong').onclick = async () => { icdPilihan = []; await simpanIcd(); gambarIcd(); $('icdKet').textContent = 'Kosong — CPPT memakai 12 yang paling sering.'; };
chrome.storage.local.get('icdPilihan').then(s => { icdPilihan = (s.icdPilihan || []).filter(x => x && x.kode); gambarIcd(); });

/* v4.6: sakelar Scan jasa & Balon anamnesa (tersimpan sendiri, ikut akun Chrome) */
(() => {
  const ids = ['scanAktif', 'balonAnamnesa', 'cekIcd'];
  chrome.storage.local.get(ids, s => { ids.forEach(id => { if ($(id)) $(id).checked = s[id] !== false; }); teksSakelar(); });
  ids.forEach(id => $(id) && $(id).addEventListener('change', async () => {
    await chrome.storage.local.set({ [id]: $(id).checked }); teksSakelar();
    chrome.runtime.sendMessage({ aksi: 'simpanSetelanAkun' });
    if (id === 'scanAktif' && $(id).checked) chrome.runtime.sendMessage({ aksi: 'sinkronStatus', paksa: true });
  }));
  chrome.storage.onChanged.addListener((c, a) => { if (a === 'local') ids.forEach(id => { if (c[id] && $(id)) { $(id).checked = c[id].newValue !== false; teksSakelar(); } }); });
})();
