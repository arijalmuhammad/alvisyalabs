/* CCare Dokter v4.10.0 — Memori resep 3 slot (CPPT /Poli/Ubah).
 * "Simpan ke memori" → Slot 1/2/3: menyimpan baris resep OBAT dan ALKES (BMHP) yang sedang terisi: item, jumlah, satuan,
 * aturan pakai, keterangan. Slot berisi diberi nama singkat (mis. "ISPA dewasa"); menimpa slot berisi minta konfirmasi.
 * "Pakai memori" → pilih slot → baris diisi lewat tombol/fungsi C-CARE sendiri (TambahResep, (+) Alkes), lalu ditambahkan
 * di bawah resep yang sudah ada. Baris kosong (+) tetap dijaga cppt-resep.js.
 * Disimpan di chrome.storage.local per akun dokter (nama pengguna C-CARE). Tanpa data pasien: hanya isian resep.
 * Racikan belum ikut memori (susunan barisnya berbeda). */
(() => {
  if (!/\/Poli\/Ubah\/\d+/i.test(location.pathname) || window.__sjcSlot) return; window.__sjcSlot = true;
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const bersih = s => String(s == null ? '' : s).replace(/\s+/g, ' ').trim();
  const tidur = ms => new Promise(r => setTimeout(r, ms));
  const tunggu = (cek, ms = 6000) => new Promise(ok => { const t0 = Date.now(); (function ulang() { const v = cek(); if (v !== undefined || Date.now() - t0 > ms) ok(v); else setTimeout(ulang, 120); })(); });
  const JUMLAH_SLOT = 3;

  /* akun dokter: nama pengguna C-CARE di panel samping, cadangan baris "TTD Dokter" */
  function akun() {
    const a = document.querySelector('.user-panel .info, .user-panel p, .navbar .user-menu .hidden-xs');
    let t = bersih(a && a.textContent).replace(/\s+-\s+.*$/, '');
    if (!t) { const tr = $$('#Pemeriksaan_tab tr').find(r => r.cells[0] && /^\s*TTD\s*Dokter/i.test(r.cells[0].textContent)); t = bersih(tr && tr.cells[1] && tr.cells[1].textContent); }
    return (t || 'bersama').toLowerCase().slice(0, 80);
  }

  /* ---------- baca baris ---------- */
  const grupObat = () => document.getElementById('GrupResep');
  const grupAlkes = () => document.getElementById('GrupResepAlkes') || (document.getElementById('TambahResepAlkes') || { closest: () => null }).closest('table')?.querySelector('tbody');
  const kunci = n => String(n || '').replace(/\[\d+\]/g, '[]').replace(/_\d+$/, '_');                     // ListResep[3].ObatID → ListResep[].ObatID
  const barisDi = g => g ? [...g.children].filter(tr => tr.tagName === 'TR' && tr.querySelector('select')) : [];
  const pokok = tr => tr.querySelector('select[name$="ObatID"], select[name*="Alkes"], select[id^="obat_"], select[id^="alkes_"]') || tr.querySelector('select');
  const terpilih = el => el && el.value && el.selectedIndex > 0 && !/^--|^pilih/i.test(el.value) && !/^pilih|^-- pilih/i.test(bersih((el.options[el.selectedIndex] || {}).text));
  const lewati = el => !el.name || el.type === 'hidden' || el.type === 'button' || el.type === 'submit' || el.type === 'file' || el.readOnly || el.disabled || /harga|total|counter/i.test(el.name);
  function bacaBaris(tr) {
    const p = pokok(tr); if (!terpilih(p)) return null;
    if (tr.querySelector('input[id^="isRacikan_"]:checked, input[name$="IsRacikan"][value="true"]:checked')) return null;   // racikan: belum didukung
    const isian = {};
    $$('select, input, textarea', tr).forEach(el => {
      if (el === p || lewati(el)) return;
      const k = kunci(el.name);
      if (el.type === 'radio') { if (el.checked) isian[k] = { r: el.value }; return; }
      if (el.type === 'checkbox') { isian[k] = { c: el.checked }; return; }
      const v = el.tagName === 'SELECT' ? el.value : bersih(el.value);
      if (v !== '') isian[k] = el.tagName === 'SELECT' ? { s: v, x: bersih((el.options[el.selectedIndex] || {}).text) } : { v };
    });
    return { k: kunci(p.name), id: p.value, nama: bersih(p.options[p.selectedIndex].text).replace(/\s*\((Stok|Harga)[^)]*\)/gi, '').trim(), isian };
  }
  const bacaSemua = () => ({ obat: barisDi(grupObat()).map(bacaBaris).filter(Boolean), alkes: barisDi(grupAlkes()).map(bacaBaris).filter(Boolean) });

  /* ---------- isi baris ---------- */
  const pilihJq = (el, val) => new Promise(ok => {                         // lewat jQuery C-CARE (select2 + hitung harga ikut jalan)
    if (!el.id) { el.value = val; el.dispatchEvent(new Event('change', { bubbles: true })); return ok(el.value === String(val) ? 'ok' : 'gagal'); }
    const h = e => { document.removeEventListener('sjc-pilih-obat-hasil', h); ok(e.detail); };
    document.addEventListener('sjc-pilih-obat-hasil', h);
    document.dispatchEvent(new CustomEvent('sjc-pilih-obat', { detail: JSON.stringify({ id: el.id, val: String(val) }) }));
    setTimeout(() => ok('gagal'), 2500);
  });
  function setIsian(el, n) {
    if (n.r !== undefined) { if (el.value === n.r) { el.checked = true; el.dispatchEvent(new Event('change', { bubbles: true })); } return; }
    if (n.c !== undefined) { if (el.checked !== n.c) el.click(); return; }
    if (n.s !== undefined) {
      if (el.id) document.dispatchEvent(new CustomEvent('sjc-satuan', { detail: JSON.stringify({ id: el.id, val: n.s }) }));
      if (el.value !== n.s && [...el.options].some(o => o.value === n.s)) { el.value = n.s; el.dispatchEvent(new Event('change', { bubbles: true })); }
      return;
    }
    const d = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(el), 'value'); d && d.set ? d.set.call(el, n.v) : (el.value = n.v);
    ['input', 'keyup', 'change'].forEach(t => el.dispatchEvent(new Event(t, { bubbles: true })));
  }
  const kosongDi = g => barisDi(g).find(tr => { const p = pokok(tr); return p && !terpilih(p) && !tr.querySelector('input[id^="isRacikan_"]:checked'); });
  async function barisBaru(jenis) {
    const g = jenis === 'obat' ? grupObat() : grupAlkes(); if (!g) return null;
    const ada = kosongDi(g); if (ada) return ada;                           // pakai baris kosong yang sudah ada (resep: dijaga cppt-resep.js)
    const sebelum = barisDi(g).length;
    if (jenis === 'obat') document.dispatchEvent(new CustomEvent('sjc-tambah-resep'));
    else { const t = document.getElementById('TambahResepAlkes'); if (!t) return null; t.click(); }   // tombol (+) Alkes milik C-CARE
    return await tunggu(() => barisDi(g).length > sebelum ? kosongDi(g) : undefined) || null;
  }
  async function isiSatu(jenis, b) {
    const tr = await barisBaru(jenis); if (!tr) return 'baris';
    const p = pokok(tr);
    const opsi = await tunggu(() => [...p.options].find(o => o.value === String(b.id)) || undefined);   // daftar dimuat C-CARE lewat AJAX
    if (!opsi) return 'tidak-ada';
    if (opsi.disabled) return 'stok-habis';
    const h = await pilihJq(p, b.id); if (h !== 'ok') return h;
    await tidur(400);                                                       // isi otomatis C-CARE/memori aturan pakai selesai dulu, baru ditimpa isi slot
    const el = $$('select, input, textarea', tr).filter(x => x !== p && !lewati(x));
    Object.entries(b.isian).forEach(([k, n]) => el.filter(x => kunci(x.name) === k).forEach(x => setIsian(x, n)));
    return 'ok';
  }

  /* ---------- penyimpanan ---------- */
  let DATA = {};
  const muat = () => new Promise(ok => chrome.storage.local.get('memoriSlot', s => { DATA = s.memoriSlot || {}; ok(); }));
  const slotAkun = () => { const a = akun(); const l = (DATA[a] || []).slice(0, JUMLAH_SLOT); while (l.length < JUMLAH_SLOT) l.push(null); return l; };
  const tulis = l => new Promise(ok => { DATA[akun()] = l; chrome.storage.local.set({ memoriSlot: DATA }, ok); });
  const ringkas = s => !s ? 'Kosong' : [s.obat.length && s.obat.length + ' obat', s.alkes.length && s.alkes.length + ' alkes'].filter(Boolean).join(' · ') || 'Kosong';

  /* ---------- tampilan: satu baris di atas tabel resep + balon slot ---------- */
  const g0 = grupObat(); if (!g0) return;

  /* v4.10.19: C-CARE tidak menampilkan ulang resep ALKES yang sudah tersimpan (obat ditampilkan ulang). Simpan berikutnya
     pada kunjungan yang sama (mis. Simpan TTD dari tablet) lalu mengirim alkes kosong dan alkes hilang di Farmasi.
     Alkes yang terkirim saat Simpan diingat per kunjungan (6 jam) dan dipasang kembali saat halaman dibuka lagi. */
  const KUNJ = (location.pathname.match(/\/Poli\/Ubah\/(\d+)/i) || [])[1], KUNCI_ALKES = 'sjcAlkesTerkirim';
  const bacaIngat = () => { try { const o = JSON.parse(localStorage.getItem(KUNCI_ALKES) || '{}'), t = Date.now() - 6 * 3600e3; Object.keys(o).forEach(k => { if (!(o[k].t > t)) delete o[k]; }); return o; } catch (e) { return {}; } };
  const ingatAlkes = () => {
    const o = bacaIngat(), a = barisDi(grupAlkes()).map(bacaBaris).filter(Boolean);
    if (a.length) o[KUNJ] = { t: Date.now(), a }; else delete o[KUNJ];   // dikosongkan sengaja oleh dokter → jangan dipasang lagi
    try { localStorage.setItem(KUNCI_ALKES, JSON.stringify(o)); } catch (e) { /* penuh/diblok */ }
  };
  document.addEventListener('click', e => { if (e.target.closest && e.target.closest('#btn-simpan, button[type=submit]')) ingatAlkes(); }, true);
  document.addEventListener('submit', ingatAlkes, true);
  (async () => {
    const ing = bacaIngat()[KUNJ]; if (!ing || !ing.a.length) return;
    await tidur(2500);                                                    // tunggu baris obat & select2 C-CARE siap
    if (barisDi(grupAlkes()).map(bacaBaris).filter(Boolean).length) return;   // C-CARE sudah menampilkan alkes → tidak perlu
    let ok = 0; for (const b of ing.a) if (await isiSatu('alkes', b) === 'ok') ok++;
    console.info(`[SJC] alkes tersimpan dipasang kembali: ${ok}/${ing.a.length} (kunjungan ${KUNJ})`);
    const g = grupAlkes(), t = g && g.closest('table');
    if (ok && t) { const d = document.createElement('div'); d.className = 'sjc-alkes-pulih'; d.setAttribute('role', 'status');
      d.style.cssText = 'margin:6px 0;padding:8px 12px;border-radius:8px;background:#E8F4F2;color:#0A6B65;font:13px/1.4 system-ui,sans-serif';
      d.textContent = `${ok} resep alkes dari Simpan sebelumnya dipasang kembali (C-CARE tidak menampilkannya ulang). Hapus bila tidak dipakai.`;
      t.before(d); }
  })();
  const gaya = document.createElement('style');
  gaya.textContent = `.sjc-slot{position:relative;display:flex;align-items:center;flex-wrap:wrap;gap:8px;margin:8px 0;font:13px/1.4 "Source Sans 3","Source Sans Pro",system-ui,sans-serif;color:#0F2742}
  .sjc-slot .l{display:inline-flex;align-items:center;gap:4px;color:#4F6478;font-weight:600}.sjc-slot .l svg{width:16px;height:16px;fill:currentColor}
  .sjc-slot>button{height:32px;padding:0 12px;border:1px solid #263C92;border-radius:8px;background:#fff;color:#263C92;font-family:inherit;font-size:13px;font-weight:600;cursor:pointer}
  .sjc-slot>button[aria-expanded="true"]{background:#E8ECF7}
  .sjc-slot button:focus-visible,.sjc-slot input:focus-visible{outline:2px solid #263C92;outline-offset:2px}
  .sjc-slot .pesan{color:#4F6478}.sjc-slot .pesan.ok{color:#3B7A1E}.sjc-slot .pesan.awas{color:#B45309}
  .sjc-slot-balon{position:absolute;left:0;top:calc(100% + 4px);z-index:40;width:360px;max-width:calc(100vw - 32px);padding:8px;border:1px solid #D5E0E0;border-radius:12px;background:#fff;box-shadow:0 8px 24px rgba(15,39,66,.16)}
  .sjc-slot-balon[hidden]{display:none}
  .sjc-slot-balon h4{margin:4px 8px 8px;font-size:13px;font-weight:600;color:#4F6478}
  .sjc-slot-baris{display:grid;grid-template-columns:auto minmax(0,1fr) auto;align-items:center;gap:4px 8px;padding:8px;border-top:1px solid #E3EBEA}
  .sjc-slot-baris .no{width:24px;height:24px;border-radius:12px;background:#E8ECF7;color:#263C92;font-weight:700;display:grid;place-items:center;font-variant-numeric:tabular-nums}
  .sjc-slot-baris input{width:100%;height:32px;padding:0 8px;border:1px solid #D5E0E0;border-radius:8px;background:#F2F6F6;font:inherit;color:#0F2742}
  .sjc-slot-baris b{font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .sjc-slot-baris small{grid-column:2;color:#4F6478}
  .sjc-slot-baris button{grid-row:1/3;grid-column:3;height:32px;padding:0 12px;border:1px solid #263C92;border-radius:8px;background:#263C92;color:#fff;font-family:inherit;font-size:13px;font-weight:600;cursor:pointer}
  .sjc-slot-baris button.garis{background:#fff;color:#263C92}
  .sjc-slot-baris button:disabled{border-color:#D5E0E0;background:#F2F6F6;color:#8C97B5;cursor:default}
  .sjc-slot-konfirmasi{grid-column:1/-1;display:flex;align-items:center;flex-wrap:wrap;gap:8px;margin-top:4px;padding:8px;border-radius:8px;background:#FFF4E5;color:#B45309}
  .sjc-slot-konfirmasi span{flex:1 1 100%}
  .sjc-slot-konfirmasi button:first-of-type{margin-left:auto}
  .sjc-slot-konfirmasi button{grid-row:auto;grid-column:auto}`;
  document.head.appendChild(gaya);
  const IK = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M17 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V7l-4-4zm2 16H5V5h11.17L19 7.83V19zm-7-7a3 3 0 1 0 0 6 3 3 0 0 0 0-6zM6 6h9v4H6z"/></svg>';
  const bar = document.createElement('div'); bar.className = 'sjc-slot';
  bar.innerHTML = `<span class="l">${IK}Memori resep</span><button type="button" data-m="simpan" aria-haspopup="dialog" aria-expanded="false">Simpan ke memori</button><button type="button" data-m="pakai" aria-haspopup="dialog" aria-expanded="false">Pakai memori</button><span class="pesan" role="status" aria-live="polite"></span><div class="sjc-slot-balon" role="dialog" hidden></div>`;
  (g0.closest('table') || g0).before(bar);
  const balon = bar.querySelector('.sjc-slot-balon'), pesanEl = bar.querySelector('.pesan');
  const pesan = (t, k) => { pesanEl.textContent = t; pesanEl.className = 'pesan' + (k ? ' ' + k : ''); clearTimeout(pesan.t); pesan.t = setTimeout(() => { if (pesanEl.textContent === t) pesanEl.textContent = ''; }, 8000); };
  let modus = null;
  function tutup() { balon.hidden = true; modus = null; $$('button[data-m]', bar).forEach(b => b.setAttribute('aria-expanded', 'false')); }
  function buka(m) {
    if (modus === m) return tutup();
    modus = m; $$('button[data-m]', bar).forEach(b => b.setAttribute('aria-expanded', String(b.dataset.m === m)));
    balon.setAttribute('aria-label', m === 'simpan' ? 'Simpan resep ke slot' : 'Pakai resep dari slot');
    gambar(); balon.hidden = false; const f = balon.querySelector('input, button:not(:disabled)'); if (f) f.focus();
  }
  function gambar() {
    const l = slotAkun(), kini = bacaSemua();
    balon.innerHTML = `<h4>${modus === 'simpan' ? 'Simpan ' + ringkas(kini) + ' ke' : 'Pakai memori'}</h4>`;
    l.forEach((s, i) => {
      const r = document.createElement('div'); r.className = 'sjc-slot-baris';
      const nama = s && s.nama ? s.nama : 'Slot ' + (i + 1);
      r.innerHTML = `<span class="no">${i + 1}</span>`;
      if (modus === 'simpan') {
        const inp = document.createElement('input'); inp.type = 'text'; inp.maxLength = 40; inp.value = s && s.nama ? s.nama : ''; inp.placeholder = 'Slot ' + (i + 1); inp.setAttribute('aria-label', 'Nama slot ' + (i + 1));
        inp.addEventListener('change', async () => { if (!s) return; const l2 = slotAkun(); l2[i] = Object.assign({}, l2[i], { nama: bersih(inp.value) }); await tulis(l2); });   // ganti nama tanpa mengubah isi
        r.appendChild(inp);
        const sm = document.createElement('small'); sm.textContent = ringkas(s); r.appendChild(sm);
        const b = document.createElement('button'); b.type = 'button'; b.textContent = s ? 'Timpa' : 'Simpan'; if (s) b.className = 'garis';
        b.disabled = !kini.obat.length && !kini.alkes.length;
        b.onclick = () => {
          if (!s) return simpanKe(i, inp.value);
          if (r.querySelector('.sjc-slot-konfirmasi')) return;
          const k = document.createElement('div'); k.className = 'sjc-slot-konfirmasi'; k.setAttribute('role', 'alert');
          k.innerHTML = `<span>Isi lama "${nama.replace(/</g, '&lt;')}" (${ringkas(s)}) akan diganti.</span>`;
          const ya = document.createElement('button'); ya.type = 'button'; ya.textContent = 'Timpa slot'; ya.onclick = () => simpanKe(i, inp.value);
          const tidak = document.createElement('button'); tidak.type = 'button'; tidak.className = 'garis'; tidak.textContent = 'Batal'; tidak.onclick = () => { k.remove(); b.focus(); };
          k.append(ya, tidak); r.appendChild(k); ya.focus();
        };
        r.appendChild(b);
      } else {
        const t = document.createElement('b'); t.textContent = nama; r.appendChild(t);
        const sm = document.createElement('small'); sm.textContent = ringkas(s); r.appendChild(sm);
        const b = document.createElement('button'); b.type = 'button'; b.textContent = 'Pakai'; b.disabled = !s; b.onclick = () => pakai(i); r.appendChild(b);
      }
      balon.appendChild(r);
    });
  }
  async function simpanKe(i, nama) {
    const kini = bacaSemua(); if (!kini.obat.length && !kini.alkes.length) return pesan('Belum ada obat atau alkes yang dipilih.', 'awas');
    const l = slotAkun(); l[i] = { nama: bersih(nama) || (l[i] && l[i].nama) || '', obat: kini.obat, alkes: kini.alkes, t: Date.now() };
    await tulis(l); tutup(); pesan(`Tersimpan di ${l[i].nama || 'Slot ' + (i + 1)}: ${ringkas(l[i])}.`, 'ok');
  }
  let sibuk = false;
  async function pakai(i) {
    const s = slotAkun()[i]; if (!s || sibuk) return; sibuk = true; tutup();
    const nama = s.nama || 'Slot ' + (i + 1); pesan(`Mengisi dari ${nama}…`);
    const gagal = [];
    for (const [jenis, daftar] of [['obat', s.obat], ['alkes', s.alkes]]) for (const b of daftar) {
      const h = await isiSatu(jenis, b);
      if (h !== 'ok') gagal.push(b.nama + ({ 'tidak-ada': ' (tidak ada di daftar)', 'stok-habis': ' (stok habis)', baris: ' (baris tidak bisa ditambah)' }[h] || ''));
    }
    sibuk = false;
    const terisi = s.obat.length + s.alkes.length - gagal.length;
    pesan(gagal.length ? `${terisi} terisi dari ${nama}. Belum terisi: ${gagal.join(', ')}.` : `${ringkas(s)} terisi dari ${nama}. Periksa sebelum Simpan.`, gagal.length ? 'awas' : 'ok');
  }
  bar.addEventListener('click', e => { const b = e.target.closest('button[data-m]'); if (b) { e.preventDefault(); buka(b.dataset.m); } });
  document.addEventListener('click', e => { if (!balon.hidden && !bar.contains(e.target)) tutup(); });
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && !balon.hidden) { const m = modus; tutup(); const b = bar.querySelector(`button[data-m="${m}"]`); if (b) b.focus(); } });
  chrome.storage.onChanged.addListener((u, a) => { if (a === 'local' && u.memoriSlot) muat().then(() => { if (!balon.hidden) gambar(); }); });
  chrome.storage.local.get('isiCepat', s => { if ((s.isiCepat || {}).mati) bar.hidden = true; });   // Isi cepat dimatikan seluruhnya → ikut disembunyikan
  muat();
})();
