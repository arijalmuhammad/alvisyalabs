const $ = (id) => document.getElementById(id);
const tabs = $('tabs'), baru = $('baru');
['mundur', 'maju', 'muat', 'beranda', 'atur', 'baru'].forEach((id) => $(id).onclick = () => cd.kirim(id));
$('ext').onclick = (e) => { const r = $('ext').getBoundingClientRect(); cd.kirim('popup', Math.round(r.right)); };
$('menu').onclick = () => { const r = $('menu').getBoundingClientRect(); cd.kirim('menu', { x: Math.round(r.left), y: Math.round(r.bottom) }); };
$('pasang').onclick = () => cd.kirim('mulaiUlang');
let kabarSampai = 0, urlTerakhir = '';
cd.dengar('kabar', (t) => { kabarSampai = Date.now() + 6000; $('url').innerHTML = ''; const s = document.createElement('span'); s.id = 'kabar'; s.textContent = t; $('url').append(s); setTimeout(() => { if (Date.now() >= kabarSampai) tulisUrl(urlTerakhir); }, 6100); });
function tulisUrl(u) {
  urlTerakhir = u; if (Date.now() < kabarSampai) return;
  const m = u.match(/^(https?:\/\/)([^/]+)(.*)$/);
  $('url').innerHTML = ''; if (m) { const h = document.createElement('b'); h.textContent = m[2]; $('url').append(h, document.createTextNode(m[3])); } else $('url').textContent = u.startsWith('chrome-extension://') ? 'Alvisya Dokter' : u;
}
cd.dengar('popup', (b) => $('ext').classList.toggle('a', b));
cd.dengar('galat', (t) => { $('galat').textContent = t; $('galat').style.display = 'block'; });
cd.dengar('keadaan', (k) => {
  [...tabs.querySelectorAll('.t')].forEach((n) => n.remove());
  for (const t of k.tab) {
    const b = document.createElement('div');
    b.className = 't' + (t.id === k.aktif ? ' a' : '') + (t.muat ? ' muat' : '');
    b.setAttribute('role', 'tab'); b.setAttribute('aria-selected', t.id === k.aktif); b.tabIndex = 0; b.title = t.judul;
    const s = document.createElement('span'); s.textContent = t.judul.replace(/^https?:\/\//, '') || 'Tab baru';
    const x = document.createElement('button'); x.className = 'x'; x.textContent = '×'; x.setAttribute('aria-label', 'Tutup tab'); x.title = 'Tutup (Ctrl+W)';
    x.onclick = (e) => { e.stopPropagation(); cd.kirim('tutup', t.id); };
    b.onclick = () => cd.kirim('pilih', t.id);
    b.onauxclick = (e) => { if (e.button === 1) cd.kirim('tutup', t.id); };
    b.onkeydown = (e) => { if (e.key === 'Enter' || e.key === ' ') cd.kirim('pilih', t.id); };
    b.append(s, x); tabs.insertBefore(b, baru);
  }
  $('mundur').disabled = !k.mundur; $('maju').disabled = !k.maju;
  tulisUrl(k.url);
  $('pasang').hidden = !k.siapPasang; $('pasang').title = k.siapPasang || '';
  $('ext').disabled = $('atur').disabled = !k.ekstensi;
});

/* Ctrl+F / F3: cari di halaman aktif (findInPage Electron) */
const kotakCari = $('cari'), isiCari = $('cariIsi');
let tundaCari = 0;
function bukaCari() { kotakCari.hidden = false; $('url').hidden = true; isiCari.focus(); isiCari.select(); if (isiCari.value) cd.kirim('cari', { teks: isiCari.value }); }
function tutupCari() { if (kotakCari.hidden) return; kotakCari.hidden = true; $('url').hidden = false; $('cariHasil').textContent = ''; cd.kirim('cariTutup'); }
const cariLagi = (maju) => { if (isiCari.value) cd.kirim('cari', { teks: isiCari.value, maju, lanjut: true }); };
cd.dengar('cari', bukaCari);
cd.dengar('cariTutup', () => { kotakCari.hidden = true; $('url').hidden = false; $('cariHasil').textContent = ''; });
cd.dengar('hasilCari', (h) => { $('cariHasil').textContent = h.dari ? `${h.ke}/${h.dari}` : 'Tidak ada'; });
isiCari.addEventListener('input', () => { clearTimeout(tundaCari); tundaCari = setTimeout(() => { if (!isiCari.value) $('cariHasil').textContent = ''; cd.kirim('cari', { teks: isiCari.value }); }, 120); });
isiCari.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') { e.preventDefault(); cariLagi(!e.shiftKey); }
  else if (e.key === 'Escape') { e.preventDefault(); tutupCari(); }
});
document.addEventListener('keydown', (e) => { if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'f') { e.preventDefault(); bukaCari(); } else if (e.key === 'F3') { e.preventDefault(); kotakCari.hidden ? bukaCari() : cariLagi(!e.shiftKey); } });
$('cariNaik').onclick = () => cariLagi(false); $('cariTurun').onclick = () => cariLagi(true); $('cariX').onclick = tutupCari;

/* Bilah alamat bisa diketik: klik / Ctrl+L → isian; Enter = buka (C-CARE di sini, situs lain di browser biasa); Esc = batal */
const alamat = $('alamat');
function ketikAlamat() { if (!kotakCari.hidden) tutupCari(); $('url').hidden = true; alamat.hidden = false; alamat.value = urlTerakhir.startsWith('chrome-extension://') ? '' : urlTerakhir; alamat.focus(); alamat.select(); }
function selesaiAlamat() { alamat.hidden = true; $('url').hidden = false; }
$('url').addEventListener('click', ketikAlamat);
alamat.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') { e.preventDefault(); const v = alamat.value; selesaiAlamat(); cd.kirim('buka', v); }
  else if (e.key === 'Escape') { e.preventDefault(); selesaiAlamat(); cd.kirim('cariTutup'); }
});
alamat.addEventListener('blur', () => setTimeout(selesaiAlamat, 100));
cd.dengar('alamat', ketikAlamat);
document.addEventListener('keydown', (e) => { if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'l') { e.preventDefault(); ketikAlamat(); } });
