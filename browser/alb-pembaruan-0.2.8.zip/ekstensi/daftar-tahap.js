/* Tampilan per tahap (arah B) untuk daftar poli C-CARE:
 *   Menunggu dokter · Di perawat · Menunggu obat · Selesai & batal (dilipat) — urut jam kunjungan.
 * Dibangun dari baris tabel C-CARE yang asli (tetap ada, hanya disembunyikan). Tombol Batalkan & Cetak meneruskan klik ke
 * tombol C-CARE yang asli (konfirmasi C-CARE tetap muncul). Periksa = tautan Ubah C-CARE. Tidak membaca/mengirim data ke mana pun.
 * Sakelar "Per tahap" di samping Tampilkan; Off = tabel C-CARE seperti biasa. */
(() => {
  const rute = location.pathname.match(/^\/Poli\/Index\/(\d+)/i);
  if (!rute || window.__sjcTahap) return; window.__sjcTahap = true;
  const tabel = document.getElementById('datatable-poli'); if (!tabel || !tabel.tBodies[0]) return;
  const poliIni = rute[1];
  const NAMA = { 1: 'Umum', 2: 'Gigi', 4: 'Sehat', '4mcu': 'MCU', 5: 'Tindakan', 8: 'Prolanis', 7: 'Gizi', kia: 'KIA' };
  const norm = s => String(s || '').replace(/\s+/g, ' ').trim();
  const esc = t => String(t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const IK = {
    dokter: '<svg viewBox="0 0 24 24"><path d="M12 2a10 10 0 100 20 10 10 0 000-20zm0 18a8 8 0 110-16 8 8 0 010 16zm.5-13H11v6l5.2 3.2.8-1.3-4.5-2.7z"/></svg>',
    perawat: '<svg viewBox="0 0 24 24"><path d="M12 12a4 4 0 100-8 4 4 0 000 8zm0-6a2 2 0 110 4 2 2 0 010-4zm0 8c-2.7 0-8 1.3-8 4v2h16v-2c0-2.7-5.3-4-8-4zm-6 4c.2-.7 3.3-2 6-2s5.8 1.3 6 2H6z"/></svg>',
    obat: '<svg viewBox="0 0 24 24"><path d="M4.2 11.3l7.1-7.1a5 5 0 017.1 7.1l-7.1 7.1a5 5 0 01-7.1-7.1zm1.4 1.4a3 3 0 004.3 4.3l3-3-4.3-4.3-3 3zm8.7 0l3-3a3 3 0 00-4.3-4.3l-3 3 4.3 4.3z"/></svg>',
    selesai: '<svg viewBox="0 0 24 24"><path d="M12 2a10 10 0 100 20 10 10 0 000-20zm0 18a8 8 0 110-16 8 8 0 010 16zm-1.5-5.6L7 10.9l-1.4 1.4 4.9 4.9 8-8L17 7.8z"/></svg>',
    batal: '<svg viewBox="0 0 24 24"><path d="M12 2a10 10 0 100 20 10 10 0 000-20zM4 12a8 8 0 0112.9-6.3L5.7 16.9A8 8 0 014 12zm8 8c-1.8 0-3.5-.6-4.9-1.7L18.3 7.1A8 8 0 0112 20z"/></svg>',
    edit: '<svg viewBox="0 0 24 24"><path d="M3 17.2V21h3.8L17.8 9.9l-3.7-3.7L3 17.2zM5.9 19H5v-.9l9.1-9.1.9.9L5.9 19zM20.7 7a1 1 0 000-1.4l-2.3-2.3a1 1 0 00-1.4 0l-1.8 1.8 3.7 3.7L20.7 7z"/></svg>',
    cetak: '<svg viewBox="0 0 24 24"><path d="M19 8h-1V3H6v5H5a3 3 0 00-3 3v6h4v4h12v-4h4v-6a3 3 0 00-3-3zM8 5h8v3H8V5zm8 14H8v-4h8v4zm2-4v-2H6v2H4v-4a1 1 0 011-1h14a1 1 0 011 1v4h-2z"/></svg>',
    bawah: '<svg viewBox="0 0 24 24"><path d="M7.4 8.6L12 13.2l4.6-4.6L18 10l-6 6-6-6z"/></svg>',
    atas: '<svg viewBox="0 0 24 24"><path d="M7.4 15.4L12 10.8l4.6 4.6L18 14l-6-6-6 6z"/></svg>',
    cari: '<svg viewBox="0 0 24 24"><path d="M15.5 14h-.79l-.28-.27A6.47 6.47 0 0016 9.5 6.5 6.5 0 109.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/></svg>'
  };
  const GAYA = `:host{all:initial;display:block;margin:8px 0 16px}
  *{box-sizing:border-box;font-family:"Source Sans 3","Source Sans Pro","Segoe UI",system-ui,sans-serif}
  .kotak{background:#fff;border:1px solid #D5E0E0;border-radius:12px;overflow:hidden;color:#0F2742;font-size:15px;line-height:1.35}
  .atasan{display:flex;align-items:center;gap:8px;padding:8px 12px;border-bottom:1px solid #D5E0E0}
  .cari{flex:1;display:flex;align-items:center;gap:6px;height:36px;padding:0 10px;border:1px solid #D5E0E0;border-radius:8px;background:#F2F6F6;color:#4F6478}
  .cari svg{width:18px;height:18px;fill:currentColor}.cari input{flex:1;min-width:0;border:0;background:none;font:inherit;font-size:14px;color:#0F2742;outline:none}
  .cari:focus-within{border-color:#263C92;box-shadow:0 0 0 2px rgba(38,60,146,.18)}
  .jml{color:#4F6478;font-size:13px;white-space:nowrap;font-variant-numeric:tabular-nums}
  .gh{display:flex;align-items:center;gap:8px;width:100%;padding:8px 16px;background:#F2F6F6;border:0;border-top:1px solid #D5E0E0;font-size:14px;font-weight:700;line-height:1.3;color:#0F2742;text-align:left}
  .gh:first-child{border-top:0}.gh svg{width:16px;height:16px;fill:currentColor;flex:none}
  .gh .n{color:#4F6478;font-weight:600;font-variant-numeric:tabular-nums}.gh .ket{margin-left:auto;color:#4F6478;font-weight:600;font-size:13px}
  button.gh{cursor:pointer}button.gh:focus-visible{outline:2px solid #263C92;outline-offset:-2px}
  .gh.dokter svg{color:#B45309}.gh.obat svg{color:#1D4ED8}.gh.selesai svg{color:#3B7A1E}.gh.perawat svg{color:#4F6478}
  .br{display:grid;grid-template-columns:52px minmax(0,1fr) 92px 172px;align-items:center;gap:12px;padding:6px 16px;border-top:1px solid #E3EBEA;min-height:48px}
  .br.dokter{box-shadow:inset 3px 0 #B45309}
  .jam{color:#4F6478;font-variant-numeric:tabular-nums}
  .nm{display:block;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .rm{color:#4F6478;font-size:13px;font-variant-numeric:tabular-nums}
  .br.batal .nm{text-decoration:line-through;color:#4F6478}.tbt{color:#4F6478;font-size:13px}
  .baru{display:inline-block;width:8px;height:8px;margin-right:6px;border-radius:50%;background:#B91C1C;vertical-align:middle}
  .poli{justify-self:start;padding:0 6px;border:1px solid #D5E0E0;border-radius:6px;background:#F2F6F6;color:#4F6478;font-size:12px;font-weight:600;line-height:20px;white-space:nowrap}
  .aksi{display:flex;justify-content:flex-end;gap:6px}
  .utama{display:inline-flex;align-items:center;gap:6px;height:32px;padding:0 12px;border-radius:8px;background:#263C92;color:#fff;border:1px solid #263C92;font-size:13px;font-weight:600;line-height:1;text-decoration:none;white-space:nowrap}
  .utama.dua{background:#fff;color:#263C92}.utama svg{width:16px;height:16px;fill:currentColor}
  .ib{width:32px;height:32px;display:inline-grid;place-items:center;border:1px solid #D5E0E0;border-radius:8px;background:#fff;color:#4F6478;cursor:pointer;padding:0}
  .ib svg{width:18px;height:18px;fill:currentColor}.ib.m{color:#B91C1C}.ib:hover{background:#F2F6F6}
  a:focus-visible,.ib:focus-visible{outline:2px solid #263C92;outline-offset:2px}
  .kosong{padding:12px 16px;color:#4F6478;font-size:14px;border-top:1px solid #E3EBEA}
  .tanpa-poli .br{grid-template-columns:52px minmax(0,1fr) 172px}.tanpa-poli .poli{display:none}
  @media (max-width:640px){.br,.tanpa-poli .br{grid-template-columns:44px minmax(0,1fr) auto;gap:8px;padding:6px 12px}.br .poli,.br .ib{display:none}.gh{padding:8px 12px}}`;
  const TAHAP = [
    { k: 'dokter', judul: 'Menunggu dokter', ket: 'urut jam kunjungan' },
    { k: 'perawat', judul: 'Di perawat', ket: 'berikutnya' },
    { k: 'obat', judul: 'Menunggu obat' },
    { k: 'selesai', judul: 'Selesai & batal', lipat: true }
  ];
  const tahapDari = (st, adaUbah) => {
    const t = st.toLowerCase();
    if (!adaUbah) return 'selesai';                                       // batal berobat: tombol Ubah hilang
    if (/menunggu/.test(t) && /dokter/.test(t)) return 'dokter';
    if (/menunggu/.test(t) && /perawat/.test(t)) return 'perawat';
    if (/obat|farmasi/.test(t)) return 'obat';
    return 'selesai';
  };
  /* satu baris C-CARE → data tampilan; tautan asli disimpan untuk diteruskan */
  function baca(tr) {
    const c = tr.cells; if (c.length < 6) return null;
    const a = [...tr.querySelectorAll('a[href]')], ubah = a.find(x => /\/Ubah\/\d+/i.test(x.getAttribute('href')));
    const batal = a.find(x => /Batal/i.test(x.getAttribute('href') || '')), cetak = a.find(x => /Detail\/\d+/i.test(x.getAttribute('href') || ''));
    const nmSel = c[4].cloneNode(true); nmSel.querySelectorAll('.sjc-baru,.sjc-poli').forEach(x => x.remove());
    const st = norm(c[5].dataset.sjcAsli || c[5].textContent);
    return { tr, ubah, batal, cetak, nama: norm(nmSel.textContent), rm: norm(c[3].textContent), jam: (norm(c[2].textContent).match(/(\d{1,2})[.:](\d{2})(?:[.:]\d{2})?$/) || []).slice(1, 3).join('.'),
      poli: tr.dataset.sjcPoli || poliIni, baru: !!c[4].querySelector('.sjc-baru'), st, tahap: tahapDari(st, !!ubah), batalBerobat: !ubah };
  }
  let host = null, akar = null, aktif = false, cari = '', bukaSelesai = false, tandaAkhir = '';
  try { bukaSelesai = sessionStorage.getItem('sjcTahapSelesai') === '1'; } catch (e) {}
  function pasang() {
    if (host) return;
    host = document.createElement('div'); host.id = 'ccare-dokter-tahap';
    akar = host.attachShadow({ mode: 'open' });
    akar.innerHTML = `<style>${GAYA}</style><div class="kotak"><div class="atasan"><label class="cari">${IK.cari}<input type="search" placeholder="Cari nama atau No. RM" aria-label="Cari pasien"></label><span class="jml" aria-live="polite"></span></div><div class="isi"></div></div>`;
    const bungkus = tabel.closest('.dataTables_wrapper') || tabel;
    bungkus.before(host);
    akar.querySelector('input').addEventListener('input', e => { cari = e.target.value.trim().toLowerCase(); tandaAkhir = ''; gambar(); });
    akar.addEventListener('click', e => {
      const b = e.target.closest('[data-a]'); if (!b) return;
      if (b.dataset.a === 'lipat') { bukaSelesai = !bukaSelesai; try { sessionStorage.setItem('sjcTahapSelesai', bukaSelesai ? '1' : '0'); } catch (x) {} tandaAkhir = ''; gambar(); return; }
      const d = peta.get(b.dataset.id); if (!d) return;
      const asli = b.dataset.a === 'batal' ? d.batal : b.dataset.a === 'cetak' ? d.cetak : null;
      if (asli) { e.preventDefault(); asli.click(); }                         // diteruskan ke tombol C-CARE (konfirmasi C-CARE tetap)
    });
  }
  const peta = new Map();
  function gambar() {
    if (!aktif || !akar) return;
    const semua = [...tabel.tBodies[0].rows].map(baca).filter(Boolean);
    const lihat = cari ? semua.filter(d => (d.nama + ' ' + d.rm).toLowerCase().includes(cari)) : semua;
    const banyakPoli = new Set(semua.map(d => d.poli)).size > 1;
    const tanda = JSON.stringify([lihat.map(d => [d.nama, d.rm, d.jam, d.poli, d.st, d.baru, d.tahap, !!d.ubah, d.ubah && d.ubah.getAttribute('href')]), bukaSelesai, banyakPoli]);
    if (tanda === tandaAkhir) return; tandaAkhir = tanda;
    peta.clear();
    const kelompok = Object.fromEntries(TAHAP.map(t => [t.k, []]));
    lihat.forEach((d, i) => { d.id = String(i); peta.set(d.id, d); kelompok[d.tahap].push(d); });
    const urut = (a, b) => (a.jam ? a.jam.padStart(5, '0') : '99.99').localeCompare(b.jam ? b.jam.padStart(5, '0') : '99.99');   // tanpa jam → paling bawah
    const baris = d => `<div class="br ${d.tahap}${d.batalBerobat ? ' batal' : ''}"><span class="jam">${esc(d.jam)}</span>
      <span style="min-width:0"><span class="nm" title="${esc(d.nama)}" tabindex="0" data-det="${d.cetak ? ((d.cetak.getAttribute('href') || '').match(/(\d+)\s*$/) || [])[1] || '' : ''}">${d.baru ? '<span class="baru" title="Pasien baru"></span>' : ''}${esc(d.nama)}</span><span class="rm">${esc(d.rm)}${d.batalBerobat ? ' · <span class="tbt">Batal berobat</span>' : d.tahap === 'selesai' ? ' · <span class="tbt">' + esc(d.st) + '</span>' : ''}</span></span>
      <span class="poli">${esc(NAMA[d.poli] || d.poli)}</span>
      <span class="aksi">${d.ubah ? `<a class="utama${d.tahap === 'dokter' ? '' : ' dua'}" href="${esc(d.ubah.getAttribute('href'))}">${IK.edit}${d.tahap === 'dokter' ? 'Periksa' : 'Buka'}</a>` : ''}${d.batal ? `<button type="button" class="ib m" data-a="batal" data-id="${d.id}" title="Batalkan kunjungan" aria-label="Batalkan kunjungan">${IK.batal}</button>` : ''}${d.cetak ? `<button type="button" class="ib" data-a="cetak" data-id="${d.id}" title="Cetak / rincian" aria-label="Cetak">${IK.cetak}</button>` : ''}</span></div>`;
    let h = '';
    TAHAP.forEach(t => {
      const isi = kelompok[t.k].sort(urut);
      if (t.lipat) {
        h += `<button type="button" class="gh ${t.k}" data-a="lipat" aria-expanded="${bukaSelesai}">${IK[t.k]}${t.judul} <span class="n">${isi.length}</span><span class="ket">${bukaSelesai ? IK.atas : IK.bawah}</span></button>`;
        if (bukaSelesai) h += isi.map(baris).join('') || '<div class="kosong">Belum ada.</div>';
      } else {
        h += `<div class="gh ${t.k}">${IK[t.k]}${t.judul} <span class="n">${isi.length}</span>${t.ket && isi.length ? `<span class="ket">${t.ket}</span>` : ''}</div>`;
        h += isi.map(baris).join('') || `<div class="kosong">${t.k === 'dokter' ? 'Tidak ada pasien menunggu dokter.' : 'Tidak ada.'}</div>`;
      }
    });
    akar.querySelector('.isi').innerHTML = h;
    akar.querySelector('.kotak').classList.toggle('tanpa-poli', !banyakPoli);
    akar.querySelector('.jml').textContent = (cari ? lihat.length + ' dari ' : '') + semua.length + ' pasien';
  }
  function setel(on) {
    aktif = on;
    const bungkus = tabel.closest('.dataTables_wrapper') || tabel;
    if (on) { pasang(); host.hidden = false; bungkus.style.display = 'none'; document.dispatchEvent(new CustomEvent('sjc-daftar-semua', { detail: 'on' })); tandaAkhir = ''; setTimeout(gambar, 50); }
    else { if (host) host.hidden = true; bungkus.style.display = ''; document.dispatchEvent(new CustomEvent('sjc-daftar-semua', { detail: 'off' })); }
  }
  /* tabel C-CARE berubah (pembaruan senyap, Semua poli, ringkas) → gambar ulang */
  let tunda = 0;
  new MutationObserver(() => { clearTimeout(tunda); tunda = setTimeout(gambar, 120); }).observe(tabel, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ['data-sjc-asli', 'data-sjc-poli'] });
  /* sakelar di samping Tampilkan */
  function sakelar(on) {
    const form = (document.querySelector('input[name=Tanggal]') || {}).form, kirim = form && form.querySelector('[type=submit], button:not([type=button])');
    if (!kirim || document.getElementById('sjcTahap')) return;
    const w = document.createElement('span'); w.className = 'sjc-gabung';
    w.innerHTML = '<label title="Kelompokkan pasien per tahap: Menunggu dokter, Di perawat, Menunggu obat, Selesai"><input type="checkbox" role="switch" id="sjcTahap"><span class="sjc-sk" aria-hidden="true"></span>Per tahap</label>';
    kirim.after(w);
    const cb = w.querySelector('input'); cb.checked = on;
    cb.addEventListener('change', () => { chrome.storage.local.set({ tampilTahap: cb.checked }); setel(cb.checked); });
    if (!document.getElementById('sjc-gabung-gaya')) {                       // gaya sakelar (sama dengan "Semua poli")
      const g = document.createElement('style'); g.id = 'sjc-tahap-gaya';
      g.textContent = '.sjc-gabung{display:inline-flex;align-items:center;gap:8px;margin-left:12px;vertical-align:middle;font:14px/1.3 "Source Sans 3","Source Sans Pro",system-ui,sans-serif;color:#0F2742}.sjc-gabung label{display:inline-flex;align-items:center;gap:8px;margin:0;font-weight:600;cursor:pointer;white-space:nowrap}.sjc-gabung input{position:absolute;opacity:0;width:1px;height:1px}.sjc-sk{position:relative;width:34px;height:20px;border-radius:999px;background:#C9D6D6;transition:background .15s;flex:none}.sjc-sk::after{content:"";position:absolute;top:2px;left:2px;width:16px;height:16px;border-radius:50%;background:#fff;box-shadow:0 1px 2px rgba(15,39,66,.3);transition:transform .15s}.sjc-gabung input:checked+.sjc-sk{background:#263C92}.sjc-gabung input:checked+.sjc-sk::after{transform:translateX(14px)}.sjc-gabung input:focus-visible+.sjc-sk{outline:2px solid #263C92;outline-offset:2px}';
      document.head.appendChild(g);
    }
  }
  chrome.storage.local.get(['tampilTahap', 'isiCepat'], s => {
    if ((s.isiCepat || {}).mati) return;
    const on = s.tampilTahap !== false;                                       // bawaan: On
    sakelar(on); if (on) setel(true);
  });
  chrome.storage.onChanged.addListener((u, area) => { if (area === 'local' && u.isiCepat && (u.isiCepat.newValue || {}).mati && aktif) setel(false); });
})();
