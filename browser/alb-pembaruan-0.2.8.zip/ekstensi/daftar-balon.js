/* CCare Dokter v4.6 — Balon anamnesa di daftar Poli.
 * Kursor berhenti ≥ 400 ms di nama pasien (atau nama difokus keyboard) → balon: keluhan utama, tanda vital, alergi.
 * Sumber: /RekapRekamMedis/Detail/{id} (halaman baca saja). Satu permintaan per pasien, hanya saat diminta,
 * disimpan di memori tab ini saja (hilang saat tab ditutup / dimuat ulang). Kursor yang hanya melintas tidak memicu permintaan.
 */
(() => {
  if (window.__sjcBalon) return; window.__sjcBalon = true;
  if (matchMedia('(hover: none)').matches) return;                       // layar sentuh: tidak aktif

  let aktif = true;
  const baca = s => { aktif = s.balonAnamnesa !== false && !((s.isiCepat || {}).mati); if (!aktif) sembunyi(); };
  chrome.storage.local.get(['balonAnamnesa', 'isiCepat'], baca);
  chrome.storage.onChanged.addListener((c, a) => { if (a === 'local' && (c.balonAnamnesa || c.isiCepat)) chrome.storage.local.get(['balonAnamnesa', 'isiCepat'], baca); });

  const JEDA = 400;
  const memori = new Map();                                              // id → data | Promise
  let timer = null, kendali = null, selKini = null, calon = null;

  /* ---------- balon (shadow DOM, melayang) ---------- */
  const host = document.createElement('div');
  host.style.cssText = 'position:fixed;left:0;top:0;z-index:2147483000;pointer-events:none';
  const root = host.attachShadow({ mode: 'open' });
  root.innerHTML = `<style>
    :host{--kuning-tipis:#FEF3C7;--utama:#263C92;--teks:#0F2742;--teks-2:#4F6478;--garis:#D5E0E0;--pemisah:#E3EBEA;--putih:#fff;--isian:#F2F6F6;--merah:#B91C1C;--merah-tipis:#FDECEC;--kuning:#B45309}
    @media (prefers-color-scheme: dark){:host{--teks:#E6EEF0;--teks-2:#9DB0B8;--garis:#2A3D44;--pemisah:#1E3036;--putih:#15252B;--isian:#1B2E35;--merah:#F87171;--merah-tipis:#3A1A1A;--kuning:#FBBF24;--kuning-tipis:#3A2E12}}
    .b{box-sizing:border-box;width:340px;max-width:calc(100vw - 16px);background:var(--putih);color:var(--teks);border:1px solid var(--garis);border-radius:12px;
       box-shadow:0 8px 24px rgba(15,39,66,.16);padding:12px;font:13px/1.45 "Source Sans 3","Source Sans Pro",system-ui,-apple-system,"Segoe UI",sans-serif;
       opacity:0;transform:translateY(-2px);transition:opacity .15s ease-out,transform .15s ease-out}
    .b.on{opacity:1;transform:none}
    @media (prefers-reduced-motion: reduce){.b{transition:none}}
    .lbl{font-size:12px;font-weight:600;color:var(--teks-2);margin:0 0 2px}
    .ku{font-size:14px;font-weight:600;margin:0}
    .rps{margin:2px 0 0;color:var(--teks-2);display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
    .ttv{display:grid;grid-auto-flow:column;grid-auto-columns:minmax(0,1fr);margin:10px 0 0;border:1px solid var(--pemisah);border-radius:8px;overflow:hidden}
    .ttv span{min-width:0;padding:4px 6px;border-left:1px solid var(--pemisah);font-variant-numeric:tabular-nums;white-space:nowrap}
    .ttv span:first-child{border-left:0}
    .ttv small{display:block;font-size:11px;color:var(--teks-2)}
    .ttv b{font-weight:600}
    .ttv span.aw{background:var(--kuning-tipis)}.ttv span.aw b{color:var(--kuning)}
    .ttv span.kr{background:var(--merah-tipis)}.ttv span.kr b{color:var(--merah)}
    .ttv i{display:block;font-style:normal;font-size:11px;font-weight:600;color:inherit}
    .ttv span.aw i{color:var(--kuning)}.ttv span.kr i{color:var(--merah)}
    .al{display:flex;align-items:center;gap:6px;margin:10px 0 0;font-weight:600}
    .al.ada{color:var(--merah);background:var(--merah-tipis);border-radius:8px;padding:4px 8px}
    .al.tidak{color:var(--teks-2);font-weight:400}
    svg{width:16px;height:16px;fill:currentColor;flex:none}
    .redup{color:var(--teks-2)}
    .sk{height:12px;border-radius:6px;background:var(--isian);margin:6px 0}
    .sk.a{width:55%}.sk.b2{width:90%}.sk.c{width:70%}
  </style><div class="b" role="tooltip" id="b"></div>`;
  const kotak = root.getElementById('b');
  (document.body || document.documentElement).appendChild(host);

  const esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const IK_AL = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M1 21h22L12 2 1 21zm12-3h-2v-2h2v2zm0-4h-2v-4h2v4z"/></svg>';
  const kosong = v => !v || /^[-–.\s]*$/.test(v);

  function letakkan(sel) {
    const r = sel.getBoundingClientRect(), baris = (sel.closest('tr') || sel.closest('.br') || sel).getBoundingClientRect();
    const w = kotak.offsetWidth, h = kotak.offsetHeight, vw = innerWidth, vh = innerHeight;
    let x = Math.min(Math.max(8, r.left), vw - w - 8);
    let y = baris.bottom + 6;                                            // di bawah baris (baris yang ditunjuk tidak tertutup)
    if (y + h > vh - 8) y = Math.max(8, baris.top - h - 6);              // tidak muat → di atas baris
    host.style.transform = `translate(${Math.round(x)}px,${Math.round(y)}px)`;
  }
  function tampil(sel, html) {
    kotak.innerHTML = html; letakkan(sel);
    requestAnimationFrame(() => kotak.classList.add('on'));
  }
  function sembunyi() {
    clearTimeout(timer); timer = null; calon = null;
    if (kendali) { kendali.abort(); kendali = null; }
    selKini = null; kotak.classList.remove('on'); kotak.innerHTML = '';
  }

  function isi(d) {
    if (d.galat) return '<p class="redup">Tidak dapat memuat anamnesa.</p>';
    const n = v => parseFloat(String(v).replace(',', '.'));
    /* abnormal: kuning = perlu perhatian, merah = kritis; selalu dengan teks "tinggi/rendah" (bukan warna saja) */
    const nilaiTd = () => { const a = n(d.sis), b = n(d.dia); return a >= 180 || b >= 110 ? ['kr', 'tinggi'] : a >= 140 || b >= 90 ? ['aw', 'tinggi'] : a < 90 || b < 60 ? ['aw', 'rendah'] : null; };
    const ttv = [
      d.sis && d.dia ? ['TD', `${d.sis}/${d.dia}`, nilaiTd()] : null,
      d.nadi ? ['Nadi', d.nadi, n(d.nadi) > 120 ? ['kr', 'tinggi'] : n(d.nadi) > 100 ? ['aw', 'tinggi'] : n(d.nadi) < 50 ? ['aw', 'rendah'] : null] : null,
      d.rr ? ['RR', d.rr, n(d.rr) > 24 ? ['aw', 'tinggi'] : n(d.rr) < 12 ? ['aw', 'rendah'] : null] : null,
      d.suhu ? ['Suhu', d.suhu, n(d.suhu) >= 39 ? ['kr', 'tinggi'] : n(d.suhu) >= 37.5 ? ['aw', 'tinggi'] : n(d.suhu) < 35.5 ? ['aw', 'rendah'] : null] : null,
      d.spo2 ? ['SpO₂', d.spo2 + '%', n(d.spo2) < 92 ? ['kr', 'rendah'] : n(d.spo2) < 95 ? ['aw', 'rendah'] : null] : null,
    ].filter(Boolean);
    const ku = kosong(d.ku) ? '' : d.ku, rps = kosong(d.rps) ? '' : d.rps;
    return (ku ? `<p class="lbl">Keluhan utama</p><p class="ku">${esc(ku)}</p>${rps ? `<p class="rps">${esc(rps)}</p>` : ''}`
               : '<p class="lbl">Keluhan utama</p><p class="redup">Belum ada anamnesa.</p>')
      + (ttv.length ? `<div class="ttv">${ttv.map(([k, v, a]) => `<span${a ? ` class="${a[0]}"` : ''}><small>${k}</small><b>${esc(v)}</b>${a ? `<i>${a[1] === 'tinggi' ? '↑' : '↓'} ${a[1]}</i>` : ''}</span>`).join('')}</div>` : '')
      + (kosong(d.alergi) ? '<p class="al tidak">Alergi obat: tidak ada</p>' : `<p class="al ada">${IK_AL}Alergi: ${esc(d.alergi)}</p>`);
  }
  const KERANGKA = '<div class="sk a"></div><div class="sk b2"></div><div class="sk c"></div>';

  /* ---------- data: Detail rekam medis (baca saja) ---------- */
  async function ambil(id, signal) {
    const h = await (await fetch('/RekapRekamMedis/Detail/' + id, { credentials: 'include', signal })).text();
    const doc = new DOMParser().parseFromString(h, 'text/html');
    if (doc.querySelector('input[type=password]')) return { galat: true };
    const tr = [...doc.querySelectorAll('tr')].filter(t => t.cells.length >= 2);
    const teks = el => (el ? el.textContent : '').replace(/\s+/g, ' ').trim();
    const nilai = re => { const t = tr.find(x => re.test(teks(x.cells[0]))); return t ? teks(t.cells[1]) : ''; };
    const i = tr.findIndex(x => /^Data Subyektif/i.test(teks(x.cells[0])));
    let ku = '', rps = '';
    if (i >= 0) {
      ku = teks(tr[i].cells[1]);
      const lanjut = tr.slice(i + 1, i + 3).filter(x => !teks(x.cells[0])).map(x => teks(x.cells[1])).filter(v => !kosong(v));
      rps = lanjut.join(' ');
    }
    if (kosong(ku)) { const ad = nilai(/^Anamnesa Dokter/i); if (!kosong(ad)) ku = ad; }
    return { ku: ku.slice(0, 160), rps: rps.slice(0, 260), alergi: nilai(/^Riwayat Alergi/i).slice(0, 80),
      sis: nilai(/^Sistole/i), dia: nilai(/^Diastole/i), nadi: nilai(/^Nadi/i), rr: nilai(/^Respirasi/i), suhu: nilai(/^Suhu/i), spo2: nilai(/^Saturasi/i) };
  }

  /* ---------- sel nama pasien ---------- */
  function idBaris(tr) {
    const a = tr && [...tr.querySelectorAll('a[href]')].find(x => /\/RekapRekamMedis\/Detail\/\d+/.test(x.getAttribute('href')));
    return a ? a.getAttribute('href').match(/(\d+)\s*$/)[1] : null;
  }
  /* sumber elemen: tabel C-CARE asli, atau tampilan "Per tahap" (shadow DOM daftar-tahap.js, nama ber-data-det) */
  function dariPath(e) {
    for (const n of (e.composedPath ? e.composedPath() : [e.target])) { if (n && n.dataset && n.dataset.det) return n; if (n === document) break; }
    return selNama(e.target);
  }
  const idDari = sel => sel ? (sel.dataset && sel.dataset.det) || idBaris(sel.parentElement) : null;
  function selNama(el) {
    const td = el && el.closest && el.closest('td');
    const tbl = td && td.closest('table');
    if (!tbl || !tbl.tHead) return null;
    const ths = [...tbl.tHead.rows[0].cells];
    const kol = ths.findIndex(th => /nama\s*pasien|^pasien$/i.test(th.textContent.trim()));
    if (kol < 0 || td.cellIndex !== kol) return null;
    return idBaris(td.parentElement) ? td : null;
  }
  function tandaiFokus() {                                               // nama pasien bisa dijangkau keyboard
    document.querySelectorAll('table tbody td').forEach(td => { if (!td.hasAttribute('tabindex') && selNama(td)) td.setAttribute('tabindex', '0'); });
  }
  let tundaTanda = null;
  new MutationObserver(() => { clearTimeout(tundaTanda); tundaTanda = setTimeout(tandaiFokus, 300); }).observe(document.body, { childList: true, subtree: true });
  tandaiFokus();

  function minta(sel) {
    if (!aktif) return;
    const id = idDari(sel); if (!id) return;
    selKini = sel;
    const ada = memori.get(id);
    if (ada && !(ada instanceof Promise)) return tampil(sel, isi(ada));
    tampil(sel, KERANGKA);
    if (kendali) kendali.abort();
    kendali = new AbortController(); const sinyal = kendali.signal;
    ambil(id, sinyal).then(d => { memori.set(id, d); if (selKini === sel) tampil(sel, isi(d)); })
      .catch(e => { if (e && e.name === 'AbortError') return; if (selKini === sel) tampil(sel, isi({ galat: true })); });   // tidak diulang otomatis
  }

  /* v4.6.1: balon hanya selama kursor DI ATAS TEKS nama (bukan seluruh sel yang lebar). Kursor menjauh, keluar jendela,
   * klik, atau gulir → balon hilang. Fokus keyboard (Tab) tetap memunculkan balon; fokus karena klik mouse tidak. */
  let viaFokus = false;
  function zona(sel) {                                                   // kotak teks nama (+6 px), bukan lebar sel
    try {
      const rg = document.createRange(); rg.selectNodeContents(sel);
      const rs = [...rg.getClientRects()].filter(r => r.width && r.height);
      if (rs.length) return { l: Math.min(...rs.map(r => r.left)) - 6, r: Math.max(...rs.map(r => r.right)) + 6, t: Math.min(...rs.map(r => r.top)) - 6, b: Math.max(...rs.map(r => r.bottom)) + 6 };
    } catch (e) {}
    const r = sel.getBoundingClientRect(); return { l: r.left, r: r.right, t: r.top, b: r.bottom };
  }
  const di = (z, x, y) => x >= z.l && x <= z.r && y >= z.t && y <= z.b;
  let jalanGerak = false, xy = [0, 0];
  document.addEventListener('mousemove', e => {
    xy = [e.clientX, e.clientY];
    if (jalanGerak) return; jalanGerak = true;
    requestAnimationFrame(() => {
      jalanGerak = false;
      const [x, y] = xy, sel = dariPathTitik(x, y);
      if (selKini && !viaFokus && !di(zona(selKini), x, y)) sembunyi();
      if (calon && !di(zona(calon), x, y)) sembunyi();
      if (sel && sel !== selKini && sel !== calon && di(zona(sel), x, y)) {
        sembunyi(); calon = sel; viaFokus = false;
        timer = setTimeout(() => { calon = null; minta(sel); }, JEDA);   // hanya melintas → tidak ada permintaan
      }
    });
  }, { passive: true });
  /* elemen nama di bawah kursor (menembus shadow DOM tampilan Per tahap) */
  function dariPathTitik(x, y) {
    let el = document.elementFromPoint(x, y);
    while (el && el.shadowRoot) { const d = el.shadowRoot.elementFromPoint(x, y); if (!d || d === el) break; el = d; }
    for (let n = el; n; n = n.parentNode || n.host) { if (n.dataset && n.dataset.det) return n; if (n === document) break; }
    return selNama(el);
  }
  document.addEventListener('mouseout', e => { if (!e.relatedTarget && (selKini || calon) && !viaFokus) sembunyi(); }, true);   // keluar jendela
  addEventListener('blur', () => { if (selKini || calon) sembunyi(); });
  document.addEventListener('mousedown', () => { if (selKini || calon) sembunyi(); }, true);
  const onFokus = e => {
    const sel = dariPath(e);
    if (sel && sel.matches(':focus-visible')) { if (sel === selKini) return; sembunyi(); viaFokus = true; minta(sel); }   // hanya fokus keyboard
    else if (selKini && viaFokus) { sembunyi(); viaFokus = false; }
  };
  document.addEventListener('focusin', onFokus, true);
  /* fokus yang berpindah di dalam tampilan Per tahap (shadow DOM) tidak sampai ke document → dengarkan di akarnya juga */
  setInterval(() => { const h = document.getElementById('ccare-dokter-tahap'); if (h && h.shadowRoot && !h.__sjcBalon) { h.__sjcBalon = true; h.shadowRoot.addEventListener('focusin', onFokus, true); } }, 1000);
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && selKini) sembunyi(); }, true);
  addEventListener('scroll', () => { if (selKini && viaFokus) letakkan(selKini); else if (selKini || calon) sembunyi(); }, true);
  addEventListener('resize', () => { if (selKini) letakkan(selKini); });
})();
