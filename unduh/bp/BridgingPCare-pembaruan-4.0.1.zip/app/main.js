// ===== BRIDGING PCARE — aplikasi laptop (Klinik IPB Dramaga) =====
// Satu jendela: bilah aplikasi + PCare (dan C-CARE) tampil di dalamnya. Bot 1.9.9 berjalan di halaman PCare
// seperti dulu; data kunjungan dibaca dari jendela C-CARE tersembunyi. Tidak perlu Chrome.
// Semua file tinggal di folder aplikasi (portabel): ekstensi\ data\ log\ cadangan\.
"use strict";
const { app, BrowserWindow, WebContentsView, ipcMain, session, shell, safeStorage, Notification, clipboard, net } = require("electron");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const zlib = require("zlib");

// ---------- folder ----------
const DIR = app.isPackaged ? path.dirname(process.execPath) : path.resolve(process.env.BR_DIR || path.join(__dirname, "..", "uji-app"));
const APPDIR = __dirname;
const EKS = path.join(DIR, "ekstensi");
const DATA = path.join(DIR, "data");
const LOG = path.join(DIR, "log");
const CAD = path.join(DIR, "cadangan");
const DEV = !app.isPackaged;
const ASAL_PCARE = (DEV && process.env.BR_PCARE) || "https://pcarejkn.bpjs-kesehatan.go.id/eclaim/";
const ASAL_CCARE = (DEV && process.env.BR_CCARE) || "https://c-care.ipb.ac.id/";
const PARTISI = "persist:bridging";
const TINGGI_BILAH = 52;
for (const d of [DATA, LOG]) fs.mkdirSync(d, { recursive: true });
// v3.4.0: profil browser (cache, cookie, GPU) SELALU di disk lokal pengguna. Dulu di folder aplikasi; bila folder itu
// di Google Drive/OneDrive, setiap baca-tulis cache lewat sinkronisasi awan → aplikasi kaku & membeku beberapa detik.
const T0 = Date.now();
const LOKAL = path.join(process.env.LOCALAPPDATA || app.getPath("appData"), "BridgingPCare");
app.setPath("userData", DEV ? path.join(DATA, "browser") : path.join(LOKAL, "browser"));
// kunci enkripsi password (DPAPI, di file "Local State") dibawa dari profil lama supaya password tersimpan tetap terbaca
try {
  const baru = path.join(app.getPath("userData"), "Local State"), lama = path.join(DATA, "browser", "Local State");
  if (!DEV && !fs.existsSync(baru) && fs.existsSync(lama)) { fs.mkdirSync(path.dirname(baru), { recursive: true }); fs.copyFileSync(lama, baru); }
} catch (e) {}
const DI_AWAN = /google drive|my drive|onedrive|dropbox|icloud/i.test(DIR) || (process.platform === "win32" && /^[g-z]:\\(my drive|shared drives|bersama)/i.test(DIR));
app.setAppUserModelId("id.alvisya.bridgingpcare");

const ada = (f) => { try { fs.accessSync(f); return true; } catch (e) { return false; } };
const bacaJson = (f, d) => { try { return JSON.parse(fs.readFileSync(f, "utf8")); } catch (e) { return d; } };
const tulisJson = (f, v) => { fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f + ".tmp", JSON.stringify(v)); fs.renameSync(f + ".tmp", f); };
// v3.4.0: tulis TANPA menahan aplikasi (async); satu penulisan berjalan sekaligus, yang terakhir menang
let sedangTulis = false, tulisLagi = false;
async function tulisJsonAsinkron(f, ambil) {
  if (sedangTulis) { tulisLagi = true; return; }
  sedangTulis = true;
  try { await fs.promises.mkdir(path.dirname(f), { recursive: true }); await fs.promises.writeFile(f + ".tmp", JSON.stringify(ambil())); await fs.promises.rename(f + ".tmp", f); } catch (e) {}
  sedangTulis = false;
  if (tulisLagi) { tulisLagi = false; tulisJsonAsinkron(f, ambil); }
}
const versiDi = (d) => (bacaJson(path.join(d, "manifest.json"), {}) || {}).version || "";
const lebihBaru = (a, b) => { const x = String(a).split("."), y = String(b).split("."); for (let i = 0; i < 4; i++) { const p = +x[i] || 0, q = +y[i] || 0; if (p !== q) return p > q; } return false; };
const jam = () => { const d = new Date(), p = (x) => String(x).padStart(2, "0"); return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`; };

// ---------- file bot: folder ekstensi\ (bisa diperbarui) — diisi dari bawaan aplikasi bila kosong / lebih lama ----------
function salinFolder(src, dst) {
  fs.mkdirSync(dst, { recursive: true });
  for (const e of fs.readdirSync(src, { withFileTypes: true })) {
    const a = path.join(src, e.name), b = path.join(dst, e.name);
    if (e.isDirectory()) salinFolder(a, b); else fs.copyFileSync(a, b);
  }
}
function siapkanEkstensi() {
  const bawaan = path.join(APPDIR, "ekstensi");
  const vAda = versiDi(EKS), vBawa = versiDi(bawaan);
  // hanya saat folder bot kosong, atau aplikasi baru membawa bot yang lebih baru (versi yang dikembalikan manual tetap dihormati)
  const sudah = simpan.__bawaanTerpasang === vBawa;
  simpan.__bawaanTerpasang = vBawa; tulisSimpan();
  if (vAda && (sudah || !lebihBaru(vBawa, vAda))) return;
  gantiFolder(EKS, (tmp) => salinFolder(bawaan, tmp), vAda);
  catat("INFO", `File bot disiapkan dari aplikasi: ${vAda || "(kosong)"} → ${vBawa}`);
}
// ganti folder tujuan dengan isi baru; yang lama ke cadangan\<versi>-<waktu> (simpan 5)
function gantiFolder(tujuan, isi, versiLama, awalan = "") {
  const tmp = tujuan + ".baru";
  fs.rmSync(tmp, { recursive: true, force: true });
  isi(tmp);
  if (ada(tujuan)) {
    fs.mkdirSync(CAD, { recursive: true });
    const cad = path.join(CAD, `${awalan}${versiLama || "lama"}-${new Date().toISOString().replace(/[-:T]/g, "").slice(0, 14)}`);
    try { fs.renameSync(tujuan, cad); }
    catch (e) { salinFolder(tujuan, cad); salinFolder(tmp, tujuan); fs.rmSync(tmp, { recursive: true, force: true }); pangkasCadangan(); return; }
  }
  fs.renameSync(tmp, tujuan);
  pangkasCadangan();
}
function pangkasCadangan() {
  let d = []; try { d = fs.readdirSync(CAD).filter((n) => fs.statSync(path.join(CAD, n)).isDirectory()); } catch (e) { return; }
  d.sort((a, b) => a.slice(a.lastIndexOf("-")).localeCompare(b.slice(b.lastIndexOf("-"))));
  while (d.length > 5) fs.rmSync(path.join(CAD, d.shift()), { recursive: true, force: true });
}

// ---------- penyimpanan (pengganti chrome.storage.local) ----------
const FILE_SIMPAN = path.join(DATA, "penyimpanan.json");
const simpan = bacaJson(FILE_SIMPAN, {}) || {};
let timerSimpan = null;
const tulisSimpan = () => { clearTimeout(timerSimpan); timerSimpan = setTimeout(() => tulisJsonAsinkron(FILE_SIMPAN, () => simpan), 600); };
const salin = (v) => (v === undefined ? undefined : JSON.parse(JSON.stringify(v)));
function siarkan(ch) {
  if (!Object.keys(ch).length) return;
  for (const wc of require("electron").webContents.getAllWebContents()) { if (!wc.isDestroyed()) wc.send("st:berubah", ch); }
}
ipcMain.handle("st:get", (_e, k) => {
  if (k === null || k === undefined) return salin(simpan);
  const out = {};
  if (typeof k === "string") { if (k in simpan) out[k] = salin(simpan[k]); }
  else if (Array.isArray(k)) { for (const x of k) if (x in simpan) out[x] = salin(simpan[x]); }
  else for (const x of Object.keys(k)) out[x] = x in simpan ? salin(simpan[x]) : k[x];
  return out;
});
ipcMain.handle("st:set", (_e, o) => {
  const ch = {};
  for (const [k, v] of Object.entries(o || {})) { ch[k] = { oldValue: salin(simpan[k]), newValue: salin(v) }; simpan[k] = salin(v); }
  tulisSimpan(); siarkan(ch);
});
ipcMain.handle("st:remove", (_e, k) => {
  const ch = {};
  for (const x of [].concat(k || [])) if (x in simpan) { ch[x] = { oldValue: simpan[x] }; delete simpan[x]; }
  tulisSimpan(); siarkan(ch);
});
ipcMain.handle("st:clear", () => {
  const ch = {}; for (const x of Object.keys(simpan)) { ch[x] = { oldValue: simpan[x] }; delete simpan[x]; }
  tulisSimpan(); siarkan(ch);
});

function resetLogin(situs) {
  const ch = {};
  if ((simpan["loginCoba_" + situs] || []).length) { ch["loginCoba_" + situs] = { oldValue: simpan["loginCoba_" + situs], newValue: [] }; simpan["loginCoba_" + situs] = []; }
  if (simpan["loginDijeda_" + situs]) { ch["loginDijeda_" + situs] = { oldValue: simpan["loginDijeda_" + situs], newValue: null }; simpan["loginDijeda_" + situs] = null; }
  if (simpan["loginKunci_" + situs] && simpan["loginKunci_" + situs].at) { ch["loginKunci_" + situs] = { oldValue: simpan["loginKunci_" + situs], newValue: {} }; simpan["loginKunci_" + situs] = {}; }
  if (Object.keys(ch).length) { tulisSimpan(); siarkan(ch); }
}

// ---------- pesan ke "background" (background.js berjalan di jendela latar tersembunyi) ----------
let latar = null, keluar = false;
const tunggu = new Map();
let nomor = 0;
const siapLatar = [];
let latarSiap = false;
ipcMain.handle("rt:kirim", (e, msg) => new Promise((res) => {
  const kirim = () => {
    if (!latar || latar.isDestroyed()) return res(undefined);
    const id = ++nomor;
    tunggu.set(id, res);
    latar.webContents.send("rt:pesan", { id, msg, sender: { tab: { id: e.sender.id, url: e.sender.getURL() }, url: e.sender.getURL() } });
  };
  latarSiap ? kirim() : siapLatar.push(kirim);
}));
ipcMain.on("rt:balas", (_e, { id, jawab }) => { const f = tunggu.get(id); if (f) { tunggu.delete(id); f(jawab); } });

function buatLatar() {
  const gen = path.join(DATA, "gen");
  fs.mkdirSync(gen, { recursive: true });
  const url = "file:///" + path.join(EKS, "background.js").replace(/\\/g, "/");
  fs.writeFileSync(path.join(gen, "latar.html"), `<!doctype html><meta charset="utf-8"><title>latar</title><script src="${url}"></script>`);
  latar = new BrowserWindow({
    show: false,
    webPreferences: { preload: path.join(APPDIR, "preload-ekstensi.js"), contextIsolation: false, nodeIntegration: false, sandbox: false,
      webSecurity: false, backgroundThrottling: false, additionalArguments: [`--br-eks=${EKS}`, "--br-peran=latar"] },
  });
  latar.webContents.on("console-message", (e) => {   // v4.0.0: Electron 45 memakai objek event
    const d = { lvl: e.level, m: e.message, line: e.lineNumber, src: e.sourceId };
    if (d.lvl === "error" || d.lvl >= 3) catat("ERROR", `[latar] ${d.m} @${path.basename(String(d.src))}:${d.line}`);
  });
  latar.webContents.once("did-finish-load", () => {
    latarSiap = true;
    while (siapLatar.length) siapLatar.shift()();
    const v = versiDi(EKS), lama = simpan.__versiTerpasang;
    if (v !== lama) {
      latar.webContents.send("rt:pasang", lama ? { reason: "update", previousVersion: lama } : { reason: "install" });
      simpan.__versiTerpasang = v; tulisSimpan();
    }
  });
  latar.loadFile(path.join(gen, "latar.html"));
}

// ---------- "tab" = jendela C-CARE tersembunyi (pembaca data kunjungan) ----------
const tab = new Map();   // id webContents → BrowserWindow
const prefKonten = () => ({ partition: PARTISI, preload: path.join(APPDIR, "preload-konten.js"), contextIsolation: true, nodeIntegration: false, spellcheck: false,
  sandbox: false, backgroundThrottling: false, additionalArguments: [`--br-eks=${EKS}`].concat(DEV ? [] : ["--br-terkemas"]) });
function infoTab(wc) { return { id: wc.id, windowId: 1, url: wc.getURL(), status: wc.isLoading() ? "loading" : "complete", active: false }; }
function cariWc(id) { return require("electron").webContents.fromId(id); }
ipcMain.handle("tabs", (_e, op, a, b) => {
  if (op === "create") {
    const w = new BrowserWindow({ show: DEV && !!process.env.BR_TAMPIL_PEKERJA, width: 1100, height: 760, webPreferences: prefKonten() });
    w.webContents.setAudioMuted(true);
    w.webContents.setWindowOpenHandler(() => ({ action: "deny" }));
    const id = w.webContents.id;
    tab.set(id, w);
    w.on("closed", () => tab.delete(id));
    w.loadURL(a && a.url && a.url !== "about:blank" ? a.url : "about:blank").catch(() => {});
    return infoTab(w.webContents);
  }
  const wc = cariWc(a);
  if (op === "query") {
    const pola = [].concat((a && a.url) || []).map((p) => new RegExp("^" + p.replace(/[.+?^${}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*") + "$"));
    return require("electron").webContents.getAllWebContents().filter((w) => !w.isDestroyed() && (!pola.length || pola.some((r) => r.test(w.getURL())))).map(infoTab);
  }
  if (!wc || wc.isDestroyed()) throw new Error("No tab with id: " + a);
  if (op === "get") return infoTab(wc);
  if (op === "update") { if (b && b.url) wc.loadURL(b.url).catch(() => {}); return infoTab(wc); }
  if (op === "reload") { wc.reload(); return; }
  if (op === "remove") { const w = tab.get(a); if (w && !w.isDestroyed()) w.destroy(); return; }
});

// ---------- jendela utama ----------
let utama = null, viewPcare = null, viewCcare = null, tampil = "pcare", pengaturan = null;
// v3.1.0: area tengah (PCare/C-CARE) dilaporkan oleh tampilan aplikasi (kolom Antrean kiri, Data pasien kanan)
let areaTengah = null;
function aturUkuran() {
  if (!utama) return;
  const b = utama.getContentBounds(), w = b.width, h = b.height;
  const a = areaTengah;
  const r = a && a.width > 50 ? { x: Math.round(a.x), y: Math.round(a.y), width: Math.max(0, Math.min(Math.round(a.width), w - Math.round(a.x))), height: Math.max(0, Math.min(Math.round(a.height), h - Math.round(a.y))) }
    : { x: 0, y: TINGGI_BILAH, width: w, height: Math.max(0, h - TINGGI_BILAH) };
  for (const [nama, v] of [["pcare", viewPcare], ["ccare", viewCcare]]) {
    if (!v) continue;
    v.setBounds(nama === tampil && v.siap ? r : { x: 0, y: TINGGI_BILAH, width: 0, height: 0 });   // belum siap → tulisan "Membuka…" di UI terlihat
  }
}
function buatView(url) {
  const v = new WebContentsView({ webPreferences: prefKonten() });
  v.setBackgroundColor("#FFFFFF");
  v.webContents.once("dom-ready", () => { v.siap = true; aturUkuran(); if (url === ASAL_PCARE) catat("INFO", `Halaman PCare tampil ${Date.now() - T0} ms sesudah aplikasi mulai.`); });
  setTimeout(() => { if (!v.siap) { v.siap = true; aturUkuran(); } }, 15000);   // jaga-jaga: halaman lambat tetap ditampilkan
  v.webContents.setWindowOpenHandler(({ url: u }) => {
    if (/^https:\/\/(pcarejkn\.bpjs-kesehatan\.go\.id|c-care\.ipb\.ac\.id)\//i.test(u))
      return { action: "allow", overrideBrowserWindowOptions: { autoHideMenuBar: true, webPreferences: { partition: PARTISI } } };
    if (/^https:\/\//.test(u)) shell.openExternal(u);
    return { action: "deny" };
  });
  for (const ev of ["did-navigate", "did-navigate-in-page", "did-finish-load", "page-title-updated"]) v.webContents.on(ev, kirimStatus);
  v.webContents.on("render-process-gone", (_e, d) => keluar || catat("ERROR", `halaman ${url} berhenti: ${d.reason}`));
  // v3.0.5: perbesar/perkecil tampilan (Ctrl + / Ctrl - / Ctrl 0 / Ctrl+roda mouse), diingat per situs
  const kunciZoom = "__zoom_" + (url === ASAL_CCARE ? "ccare" : "pcare");
  const terapkanZoom = () => { try { v.webContents.setZoomFactor(simpan[kunciZoom] || 1); } catch (e) {} kirimStatus(); };
  v.webContents.on("did-finish-load", terapkanZoom);
  v.webContents.on("before-input-event", (e, inp) => {
    if (inp.type !== "keyDown" || !(inp.control || inp.meta)) return;
    const k = inp.key;
    if (k === "-" || k === "_") { e.preventDefault(); ubahZoom(v, -1); }
    else if (k === "=" || k === "+") { e.preventDefault(); ubahZoom(v, +1); }
    else if (k === "0") { e.preventDefault(); ubahZoom(v, 0); }
  });
  v.webContents.on("zoom-changed", (_e, arah) => ubahZoom(v, arah === "in" ? +1 : -1));
  v.kunciZoom = kunciZoom;
  v.webContents.loadURL(url).catch(() => {});
  utama.contentView.addChildView(v);
  return v;
}
const TINGKAT_ZOOM = [0.67, 0.75, 0.8, 0.9, 1, 1.1, 1.25];
function ubahZoom(v, arah) {
  if (!v) return;
  const kini = simpan[v.kunciZoom] || 1;
  let i = TINGKAT_ZOOM.findIndex((z) => Math.abs(z - kini) < 0.01); if (i < 0) i = TINGKAT_ZOOM.indexOf(1);
  const baru = arah === 0 ? 1 : TINGKAT_ZOOM[Math.min(TINGKAT_ZOOM.length - 1, Math.max(0, i + arah))];
  simpan[v.kunciZoom] = baru; tulisSimpan();
  v.webContents.setZoomFactor(baru);
  kirimStatus();
}
function statusSitus(v, polaLogin) {
  if (!v || v.webContents.isDestroyed()) return "—";
  const u = v.webContents.getURL();
  if (!u || u === "about:blank") return "memuat";
  if (polaLogin.test(u)) return "belum";
  return "masuk";
}
function kirimStatus() {
  if (!utama || utama.isDestroyed()) return;
  utama.webContents.send("ui:status", {
    tampil,
    pcare: statusSitus(viewPcare, /\/eclaim\/login/i),
    ccare: statusSitus(viewCcare, /\/Account\/Login/i),
    bisaKembali: !!(tampilView() && tampilView().webContents.navigationHistory.canGoBack()),
    zoom: Math.round(((tampilView() && simpan[tampilView().kunciZoom]) || 1) * 100),
    url: (() => { try { return tampilView().webContents.getURL(); } catch (e) { return ""; } })(),   // v3.3: bilah halaman
  });
}
const tampilView = () => (tampil === "ccare" ? viewCcare : viewPcare);
const pastikanCcare = () => { if (!viewCcare && utama) { viewCcare = buatView(ASAL_CCARE); aturUkuran(); } return viewCcare; };
function buatUtama() {
  utama = new BrowserWindow({
    width: 1366, height: 860, minWidth: 1100, minHeight: 640, title: "Bridging PCARE – Klinik IPB", icon: path.join(APPDIR, "icon.png"),
    autoHideMenuBar: true, show: false, backgroundColor: "#F5F8F8",   // v3.3.2: tanpa kilatan putih saat dibuka
    webPreferences: { preload: path.join(APPDIR, "preload-ui.js"), contextIsolation: true, nodeIntegration: false, sandbox: true, spellcheck: false },
  });
  utama.setMenuBarVisibility(false);
  utama.loadFile(path.join(APPDIR, "ui", "utama.html"));
  // v3.3.2: jendela tampil SECEPATNYA (hanya UI ringan); halaman PCare/C-CARE dan bot dimuat SESUDAH jendela tampil,
  // supaya klik ikon langsung terasa. Sebelumnya jendela menunggu PCare, C-CARE, dan bot latar dimuat bersamaan.
  utama.once("ready-to-show", () => {
    const uk = DEV && /^(\d+)x(\d+)$/.exec(process.env.BR_UKURAN || "");
    if (uk) { utama.setContentSize(+uk[1], +uk[2]); utama.show(); } else { utama.maximize(); utama.show(); }
    catat("INFO", `Jendela tampil ${Date.now() - T0} ms sesudah aplikasi mulai${DI_AWAN ? " (folder aplikasi di penyimpanan awan — lambat)" : ""}.`);
    setTimeout(() => {
      try { buatLatar(); } catch (e) { catat("ERROR", "bot latar gagal dibuat: " + e.message); }
      viewPcare = buatView(ASAL_PCARE);
      // v3.3.2: halaman C-CARE baru dibuka saat tab C-CARE diklik (lebih ringan). Pencarian bot memakai jendela latar sendiri.
      aturUkuran(); kirimStatus();
      setTimeout(pintasan, 3000);
    }, 50);
  });
  // v3.0.4: di Windows, ukuran isi jendela sesudah maximize/restore kadang baru benar sesaat kemudian.
  // Dulu tampilan PCare bisa lebih tinggi dari jendela → bagian bawah halaman/popup terpotong dan tidak bisa di-scroll.
  const aturNanti = () => { aturUkuran(); setTimeout(aturUkuran, 60); setTimeout(aturUkuran, 300); setTimeout(aturUkuran, 1000); };
  for (const ev of ["resize", "resized", "maximize", "unmaximize", "restore", "enter-full-screen", "leave-full-screen", "show"]) utama.on(ev, aturNanti);
  require("electron").screen.on("display-metrics-changed", aturNanti);
  utama.on("closed", () => { utama = null; app.quit(); });
  aturUkuran();
}
ipcMain.handle("ui:tampil", (_e, v) => { tampil = v === "ccare" ? "ccare" : "pcare"; if (tampil === "ccare") pastikanCcare(); aturUkuran(); tampilView()?.webContents.focus(); kirimStatus(); });
ipcMain.handle("ui:muatUlang", () => tampilView()?.webContents.reload());
// v3.2.7: bersihkan cache browser (berkas halaman, gambar, skrip). Login (cookie) & data bot TIDAK dihapus.
ipcMain.handle("ui:bersihCache", async () => {
  try {
    const ses = session.fromPartition(PARTISI);
    const sebelum = await ses.getCacheSize();
    await ses.clearCache();
    await ses.clearStorageData({ storages: ["shadercache", "cachestorage", "serviceworkers"] });
    catat("INFO", `Cache browser dibersihkan (${Math.round(sebelum / 1048576)} MB). Login tetap.`);
    return { ok: true, mb: Math.round(sebelum / 1048576) };
  } catch (e) { return { ok: false, pesan: e.message }; }
});
ipcMain.handle("ui:kembali", () => { if (!tampilView()) return; const n = tampilView().webContents.navigationHistory; if (n.canGoBack()) n.goBack(); });
ipcMain.handle("ui:beranda", () => { const v = tampilView(); if (v) v.webContents.loadURL(tampil === "ccare" ? ASAL_CCARE : ASAL_PCARE).catch(() => {}); });
ipcMain.handle("ui:zoom", (_e, arah) => ubahZoom(tampilView(), arah));
ipcMain.handle("ui:area", (_e, a) => { areaTengah = a; aturUkuran(); });
ipcMain.handle("ui:bukaCcare", (_e, p) => {
  const u = /^\//.test(String(p || "")) ? ASAL_CCARE.replace(/\/$/, "") + p : ASAL_CCARE;
  const baru = !viewCcare;
  pastikanCcare();
  if (!baru || u !== ASAL_CCARE) viewCcare.webContents.loadURL(u).catch(() => {});
  tampil = "ccare"; aturUkuran(); kirimStatus();
});
ipcMain.handle("ui:salin", (_e, t) => { clipboard.writeText(String(t || "")); return true; });
ipcMain.handle("ui:info", () => ({ versi: app.getVersion(), bot: versiDi(EKS), folder: DIR, diAwan: DI_AWAN }));
ipcMain.handle("ui:salinLog", () => {
  const t = `=== Log Bridging PCare (aplikasi ${app.getVersion()}, bot ${versiDi(EKS)}) · disalin ${new Date().toLocaleString("id-ID")} ===\n` + (ekorLog(800) || "(log kosong)");
  clipboard.writeText(t);
  return true;
});
ipcMain.handle("notif", (_e, { judul, isi }) => { try { new Notification({ title: judul || "Bridging PCare", body: isi || "", icon: path.join(APPDIR, "icon.png") }).show(); } catch (e) {} if (utama) utama.flashFrame(true); });

// ---------- Pengaturan (halaman pengaturan.html milik bot) ----------
ipcMain.handle("bukaPengaturan", () => {
  if (pengaturan && !pengaturan.isDestroyed()) { pengaturan.show(); pengaturan.focus(); return; }
  pengaturan = new BrowserWindow({
    width: 980, height: 820, title: "Pengaturan – Bridging PCARE", parent: utama || undefined, icon: path.join(APPDIR, "icon.png"), autoHideMenuBar: true,
    webPreferences: { preload: path.join(APPDIR, "preload-ekstensi.js"), contextIsolation: false, nodeIntegration: false, sandbox: false,
      additionalArguments: [`--br-eks=${EKS}`, "--br-peran=halaman"] },
  });
  pengaturan.setMenuBarVisibility(false);
  pengaturan.loadFile(path.join(EKS, "pengaturan.html"));
  pengaturan.on("closed", () => { pengaturan = null; });
});
ipcMain.handle("muatUlangAplikasi", () => { catat("INFO", "Aplikasi dimulai ulang (pembaruan)."); setTimeout(() => { app.relaunch(); app.exit(0); }, 800); });

// =====================================================================
// "HOST": password (terenkripsi Windows), log, pembaruan — dulu BridgingPCare.exe, kini di dalam aplikasi
// =====================================================================
const fileKred = (s) => path.join(DATA, `kredensial-${s}.bin`);
// uji pengembangan di Linux tanpa keyring: penyandian sementara (tidak pernah aktif di aplikasi terpasang)
const ujiTanpaKunci = () => !app.isPackaged && process.env.BR_UJI && !safeStorage.isEncryptionAvailable();
const sandikan = (t) => (ujiTanpaKunci() ? Buffer.from("UJI:" + Buffer.from(t).toString("base64")) : safeStorage.encryptString(t));
const bukaSandi = (b) => (ujiTanpaKunci() ? Buffer.from(b.toString().slice(4), "base64").toString() : safeStorage.decryptString(b));
const fileSetel = path.join(DATA, "pengaturan.json");
const situsSah = /^(pcare|ccare)$/;
const setel = () => bacaJson(fileSetel, {}) || {};

const polaRahasia = /(pass(word)?|kata ?sandi)\s*[:=]\s*\S+/gi;
const samarkan = (s) => String(s).replace(polaRahasia, "$1=***").replace(/(?<!\d)(\d{9,16})(?!\d)/g, (m) => "*".repeat(m.length - 4) + m.slice(-4));
let sudahBersih = false;
// v3.4.0: log dikumpulkan lalu ditulis tiap 1 detik secara async (dulu tiap baris ditulis langsung → aplikasi tertahan)
let antreLog = [], timerLog = null;
function siramLog(sinkron) {
  clearTimeout(timerLog); timerLog = null;
  if (!antreLog.length) return Promise.resolve();
  const isi = antreLog.join(""); antreLog = [];
  const f = path.join(LOG, `bot-${jam().slice(0, 10)}.log`);
  if (sinkron) { try { fs.mkdirSync(LOG, { recursive: true }); fs.appendFileSync(f, isi); } catch (e) {} return Promise.resolve(); }
  return fs.promises.mkdir(LOG, { recursive: true }).then(() => fs.promises.appendFile(f, isi)).catch(() => {});
}
function tulisLog(baris) {
  try {
    let b = String(baris).replace(/[\r\n]+/g, " ");
    if (b.length > 2000) b = b.slice(0, 2000) + "…";
    antreLog.push(samarkan(b) + "\n");
    if (!timerLog) timerLog = setTimeout(() => siramLog(false), 1000);
    if (!sudahBersih) {
      sudahBersih = true;
      const batas = Date.now() - 60 * 864e5;
      for (const n of fs.readdirSync(LOG)) { const p = path.join(LOG, n); if (fs.statSync(p).mtimeMs < batas) fs.rmSync(p, { force: true }); }
    }
  } catch (e) {}
}
const catat = (tingkat, pesan) => tulisLog(`${jam()} [APP] ${tingkat} ${pesan}`);
function ekorLog(n) {
  siramLog(true);   // baris terbaru ikut tersalin
  let nama = []; try { nama = fs.readdirSync(LOG).filter((x) => /^bot-.*\.log$/.test(x)).sort(); } catch (e) {}
  let baris = [];
  for (let i = nama.length - 1; i >= 0 && baris.length < n; i--) baris = fs.readFileSync(path.join(LOG, nama[i]), "utf8").replace(/\n+$/, "").split("\n").concat(baris);
  return baris.slice(-n).join("\n");
}

async function tangani(p) {
  const gagal = (pesan) => ({ ok: false, pesan });
  switch (p && p.cmd) {
    case "info":
      return { ok: true, versi: app.getVersion(), folder: DIR, ekstensiVersi: versiDi(EKS), kred: { pcare: ada(fileKred("pcare")), ccare: ada(fileKred("ccare")) },
        urlPembaruan: setel().urlPembaruan || "", folderLog: LOG, portabel: true };
    case "kredSimpan": {
      if (!situsSah.test(p.situs) || !p.user || !p.pass) return gagal("situs, nama pengguna, dan password wajib diisi");
      if (!safeStorage.isEncryptionAvailable() && !ujiTanpaKunci()) return gagal("Enkripsi Windows tidak tersedia di laptop ini.");
      fs.writeFileSync(fileKred(p.situs), sandikan(JSON.stringify({ user: p.user, pass: p.pass, disimpan: new Date().toISOString() })));
      catat("INFO", `Kredensial ${p.situs} disimpan (terenkripsi Windows).`);
      return { ok: true };
    }
    case "kredAmbil": {
      if (!situsSah.test(p.situs)) return gagal("situs tidak dikenal");
      if (!ada(fileKred(p.situs))) return gagal("belum ada password tersimpan untuk " + p.situs + " (⚙️ Pengaturan → Login otomatis)");
      try { const k = JSON.parse(bukaSandi(fs.readFileSync(fileKred(p.situs)))); return { ok: true, user: k.user, pass: k.pass }; }
      catch (e) { return gagal("password tidak bisa dibuka (laptop / akun Windows berbeda?). Simpan ulang di Pengaturan."); }
    }
    case "kredHapus":
      if (!situsSah.test(p.situs)) return gagal("situs tidak dikenal");
      fs.rmSync(fileKred(p.situs), { force: true });
      catat("INFO", `Kredensial ${p.situs} dihapus.`);
      return { ok: true };
    case "log":
      for (const b of p.baris || []) tulisLog(b);
      return { ok: true };
    case "logBaca":
      return { ok: true, teks: ekorLog(p.n > 0 && p.n <= 2000 ? p.n : 300), folder: LOG };
    case "bukaFolder": {
      const f = { log: LOG, ekstensi: EKS, aplikasi: DIR, data: DATA }[p.apa];
      if (!f) return gagal("folder tidak dikenal");
      fs.mkdirSync(f, { recursive: true }); shell.openPath(f);
      return { ok: true };
    }
    case "aturUrl": { const s = setel(); s.urlPembaruan = String(p.url || "").trim(); tulisJson(fileSetel, s); return { ok: true }; }
    case "cekPembaruan": {
      try { const i = await infoPembaruan(); return { ok: true, versiBaru: i.versi, catatan: i.catatan || "", lebihBaru: lebihBaru(i.versi, versiDi(EKS)) || lebihBaru(i.versi, app.getVersion()) }; }
      catch (e) { return gagal(e.message); }
    }
    case "pasangUrl": {
      try {
        const i = await infoPembaruan();
        const r = await net.fetch(i.zip); if (!r.ok) return gagal("unduh gagal: HTTP " + r.status);
        const data = Buffer.from(await r.arrayBuffer());
        if (i.sha256 && crypto.createHash("sha256").update(data).digest("hex").toLowerCase() !== String(i.sha256).toLowerCase()) return gagal("File pembaruan rusak / tidak cocok (SHA-256 berbeda). Tidak dipasang.");
        return pasangZip(data);
      } catch (e) { return gagal("unduh gagal: " + e.message); }
    }
    case "pasangZip":
      try { return pasangZip(Buffer.from(String(p.b64 || ""), "base64")); } catch (e) { return gagal("Pemasangan gagal: " + e.message); }
    case "kembalikan": return kembalikan();
  }
  return gagal("perintah tidak dikenal: " + (p && p.cmd));
}
ipcMain.handle("host", (_e, p) => tangani(p));

async function infoPembaruan() {
  const u = setel().urlPembaruan;
  if (!u) throw new Error('Alamat pembaruan online belum diatur. Pakai "Pilih file pembaruan" untuk ZIP.');
  if (!/^https:\/\//.test(u)) throw new Error("Alamat pembaruan harus https://");
  const r = await net.fetch(u); if (!r.ok) throw new Error("cek pembaruan gagal: HTTP " + r.status);
  const i = await r.json();
  if (!i || !i.versi || !/^https:\/\//.test(i.zip || "")) throw new Error("isi file pembaruan tidak sah");
  return i;
}

// ZIP sederhana (tanpa pustaka luar): baca direktori pusat, isi "simpan" atau "deflate"
function bacaZip(buf) {
  let e = buf.length - 22;
  while (e >= 0 && buf.readUInt32LE(e) !== 0x06054b50) e--;
  if (e < 0) throw new Error("bukan file ZIP yang sah");
  const n = buf.readUInt16LE(e + 10);
  let o = buf.readUInt32LE(e + 16);
  const isi = [];
  for (let i = 0; i < n; i++) {
    if (buf.readUInt32LE(o) !== 0x02014b50) throw new Error("ZIP rusak");
    const metode = buf.readUInt16LE(o + 10), ukur = buf.readUInt32LE(o + 20);
    const ln = buf.readUInt16LE(o + 28), le = buf.readUInt16LE(o + 30), lc = buf.readUInt16LE(o + 32), lokal = buf.readUInt32LE(o + 42);
    const nama = buf.slice(o + 46, o + 46 + ln).toString("utf8").replace(/\\/g, "/");
    o += 46 + ln + le + lc;
    if (nama.endsWith("/")) continue;
    const mulai = lokal + 30 + buf.readUInt16LE(lokal + 26) + buf.readUInt16LE(lokal + 28);
    const mentah = buf.slice(mulai, mulai + ukur);
    isi.push({ nama, data: () => (metode === 0 ? mentah : metode === 8 ? zlib.inflateRawSync(mentah) : (() => { throw new Error("metode ZIP tidak didukung"); })()) });
  }
  return isi;
}
const relAman = (r) => r && !r.split("/").includes("..") && !r.startsWith("/") && !/^[a-z]:/i.test(r);
function tulisIsi(isi, akar, tujuan) {
  for (const f of isi) {
    if (!f.nama.startsWith(akar)) continue;
    const rel = f.nama.slice(akar.length);
    if (!relAman(rel)) continue;
    const t = path.join(tujuan, ...rel.split("/"));
    fs.mkdirSync(path.dirname(t), { recursive: true });
    fs.writeFileSync(t, f.data());
  }
}
// ZIP pembaruan boleh berisi: folder bot (manifest.json "Bridging PCare") dan/atau folder app\ (kode aplikasi)
function pasangZip(buf) {
  const isi = bacaZip(buf);
  const man = isi.find((f) => /(^|\/)manifest\.json$/.test(f.nama) && f.nama.split("/").length <= 3 && /Bridging PCare/.test(f.data().toString("utf8")));
  const pkg = isi.find((f) => /(^|\/)app\/package\.json$/.test(f.nama) && /Bridging PCare/.test(f.data().toString("utf8")));
  if (!man && !pkg) return { ok: false, pesan: "ZIP ini bukan pembaruan Bridging PCare." };
  const pesan = [];
  const vLama = versiDi(EKS);
  let vBaru = vLama;
  if (man) {
    const akar = man.nama.slice(0, -"manifest.json".length);
    vBaru = JSON.parse(man.data().toString("utf8")).version;
    gantiFolder(EKS, (tmp) => tulisIsi(isi, akar, tmp), vLama);
    pesan.push(`Bot ${vLama} → ${vBaru}.`);
  }
  if (pkg) {
    if (!app.isPackaged) pesan.push("(kode aplikasi dilewati: mode uji)");
    else {
      const akar = pkg.nama.slice(0, -"package.json".length);
      const vApp = JSON.parse(pkg.data().toString("utf8")).version;
      gantiFolder(APPDIR, (tmp) => tulisIsi(isi, akar, tmp), app.getVersion(), "app-");
      pesan.push(`Aplikasi ${app.getVersion()} → ${vApp}.`);
    }
  }
  catat("INFO", "Pembaruan dipasang: " + pesan.join(" "));
  return { ok: true, versiLama: vLama, versiBaru: vBaru, pesan: "Terpasang. " + pesan.join(" ") + " Aplikasi dimulai ulang." };
}
function kembalikan() {
  let d = []; try { d = fs.readdirSync(CAD).filter((n) => !n.startsWith("app-") && ada(path.join(CAD, n, "manifest.json"))); } catch (e) {}
  if (!d.length) return { ok: false, pesan: "belum ada cadangan versi sebelumnya" };
  d.sort((a, b) => a.slice(a.lastIndexOf("-")).localeCompare(b.slice(b.lastIndexOf("-"))));
  const terakhir = path.join(CAD, d[d.length - 1]);
  const vKini = versiDi(EKS);
  gantiFolder(EKS, (tmp) => salinFolder(terakhir, tmp), vKini);
  fs.rmSync(terakhir, { recursive: true, force: true });
  const v = versiDi(EKS);
  catat("INFO", `Dikembalikan ke versi bot ${v} (dari ${vKini}).`);
  return { ok: true, versiBaru: v, pesan: `Dikembalikan ke versi ${v}. Aplikasi dimulai ulang.` };
}

// ---------- pintasan Desktop (sekali, dan diperbarui bila folder dipindah) ----------
function pintasan() {
  if (process.platform !== "win32" || !app.isPackaged) return;
  try {
    const lnk = path.join(app.getPath("desktop"), "Bridging PCare.lnk");
    let lama = null; try { lama = shell.readShortcutLink(lnk); } catch (e) {}
    if (!lama || path.resolve(lama.target) !== path.resolve(process.execPath))
      shell.writeShortcutLink(lnk, lama ? "replace" : "create", { target: process.execPath, cwd: DIR, description: "Bridging PCARE – Klinik IPB", icon: process.execPath, iconIndex: 0 });
  } catch (e) { catat("PERINGATAN", "Pintasan Desktop gagal: " + e.message); }
}

// ---------- mulai ----------
if (!app.requestSingleInstanceLock()) app.quit();
else {
  app.on("second-instance", () => { if (utama) { if (utama.isMinimized()) utama.restore(); utama.focus(); } });
  process.on("uncaughtException", (e) => catat("ERROR", "aplikasi: " + (e && e.stack || e)));
  app.whenReady().then(() => {
    const ses = session.fromPartition(PARTISI);
    // v3.0.1: identitas browser TIDAK disamarkan (versi 3.0.0 menghapus "Electron" dari user-agent sehingga tidak
    // cocok dengan sinyal browser lain — Cloudflare PCare menolak). Mesin Chromium terbaru dipakai apa adanya.
    ses.setPermissionRequestHandler((_wc, izin, cb) => cb(["clipboard-sanitized-write", "notifications"].includes(izin)));
    // gaya panel bot (panel.css) dipasang di halaman PCare & C-CARE
    app.on("web-contents-created", (_e, wc) => {
      // sesudah berhasil masuk: hitungan percobaan login & kunci login direset (agar login berikutnya tidak tertahan)
      wc.on("did-navigate", (_ev, url) => {
        const situs = /^https:\/\/pcarejkn\.bpjs-kesehatan\.go\.id\/eclaim\//i.test(url) ? (/\/eclaim\/login/i.test(url) ? "" : "pcare")
          : /^https:\/\/c-care\.ipb\.ac\.id\//i.test(url) ? (/\/Account\/Login/i.test(url) ? "" : "ccare") : "";
        // v3.0.6: baru dianggap berhasil masuk bila 8 detik kemudian halaman itu masih bukan halaman login
        // (dulu langsung direset, sehingga pengalihan sesaat bisa membuat login otomatis mencoba terus)
        if (situs) setTimeout(() => {
          if (wc.isDestroyed()) return;
          const u = wc.getURL();
          if (situs === "pcare" ? /\/eclaim\//i.test(u) && !/\/eclaim\/login/i.test(u) : /c-care\.ipb\.ac\.id\//i.test(u) && !/\/Account\/Login/i.test(u)) resetLogin(situs);
        }, 8000);
      });
      wc.on("dom-ready", () => {
        if (/^https:\/\/(pcarejkn\.bpjs-kesehatan\.go\.id\/eclaim\/|c-care\.ipb\.ac\.id\/)/i.test(wc.getURL()) || (DEV && process.env.BR_UJI_CSS))
          try { wc.insertCSS(fs.readFileSync(path.join(EKS, "panel.css"), "utf8")); } catch (e) {}
      });
    });
    for (const k of Object.keys(simpan)) if (/^loginKunci_/.test(k)) delete simpan[k];   // kunci login sesi lalu
    try { siapkanEkstensi(); } catch (e) { catat("ERROR", "file bot gagal disiapkan: " + e.message); }
    catat("INFO", `Dibuka: aplikasi ${app.getVersion()}, bot ${versiDi(EKS)}, folder ${DIR}`);
    buatUtama();   // v3.3.2: bot latar, PCare, C-CARE, dan pintasan dibuat sesudah jendela tampil
  });
  app.on("window-all-closed", () => app.quit());
  app.on("before-quit", () => { keluar = true; siramLog(true); try { tulisJson(FILE_SIMPAN, simpan); } catch (e) {} });
}
