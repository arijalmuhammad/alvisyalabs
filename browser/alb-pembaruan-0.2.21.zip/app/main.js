// AlvisyaLabs Browser — C-CARE di jendela sendiri (Chromium Electron) dengan ekstensi CCare Dokter termuat.
const { app, BaseWindow, BrowserWindow, WebContentsView, session, protocol, ipcMain, shell, Notification, nativeImage, Menu, dialog, net } = require('electron');
const crypto = require('crypto');
const { bacaZip, petakan } = require('./zip.js');
const path = require('path');
const fs = require('fs');

const BERANDA = 'https://c-care.ipb.ac.id/';
const BOLEH = (u) => /^https:\/\/c-care\.ipb\.ac\.id(\/|$)/.test(u) || u.startsWith('chrome-extension://') || u === 'about:blank';
const TINGGI_BAR = 76;
const URL_PEMBARUAN = 'https://alvisya.my.id/browser/versi.json';   // {versi, zip, sha256, catatan}
const CEK_TIAP = 6 * 3600_000;

// Portabel: data & ekstensi di sebelah EXE (paket Windows); saat pengembangan di folder proyek.
const AKAR = app.isPackaged ? path.dirname(process.execPath) : path.join(__dirname, '..');
if (!app.requestSingleInstanceLock()) { app.quit(); process.exit(0); }
app.setPath('userData', path.join(AKAR, 'data'));
const LOG = require('./log.js');
LOG.mulai(path.join(AKAR, 'data', 'log'));
process.on('uncaughtException', (e) => LOG.tulis('aplikasi', 'GALAT', (e && e.stack) || e));
process.on('unhandledRejection', (e) => LOG.tulis('aplikasi', 'GALAT', 'janji ditolak: ' + ((e && e.stack) || e)));
app.on('web-contents-created', (e, w) => LOG.pantau(w, w.getType() === 'window' ? 'halaman' : w.getType()));
app.on('child-process-gone', (e, d) => LOG.tulis('aplikasi', 'GALAT', `proses ${d.type} berhenti: ${d.reason} (kode ${d.exitCode})`));
const AKAR_APP = path.join(__dirname, '..');                         // resources\app (berisi app\ dan package.json)
const ANTRE = path.join(AKAR, 'data', 'pembaruan');                   // paket yang menunggu dipasang saat aplikasi dibuka ulang

/* ---------- pembaruan: paket ditaruh di antrean, dipasang saat mulai (tidak mengganggu tab yang sedang dipakai) ---------- */
function pasangAntrean() {
  const daftar = path.join(ANTRE, 'daftar.json');
  if (!fs.existsSync(daftar)) return false;
  let ubahApp = false;
  try {
    const { file } = JSON.parse(fs.readFileSync(daftar, 'utf8'));
    const cadangan = path.join(AKAR, 'data', 'cadangan', 'v' + app.getVersion());
    if (file.some((f) => !f.startsWith('ekstensi/'))) {                // simpan versi aplikasi yang sekarang dulu
      fs.rmSync(cadangan, { recursive: true, force: true });
      fs.cpSync(path.join(AKAR_APP, 'app'), path.join(cadangan, 'app'), { recursive: true });
      fs.copyFileSync(path.join(AKAR_APP, 'package.json'), path.join(cadangan, 'package.json'));
    }
    if (file.some((f) => f.startsWith('ekstensi/'))) fs.rmSync(path.join(AKAR, 'ekstensi'), { recursive: true, force: true });
    for (const f of file) {
      const tujuan = f.startsWith('ekstensi/') ? path.join(AKAR, f) : path.join(AKAR_APP, f);
      fs.mkdirSync(path.dirname(tujuan), { recursive: true });
      fs.copyFileSync(path.join(ANTRE, 'isi', f), tujuan);
      if (!f.startsWith('ekstensi/')) ubahApp = true;
    }
  } catch (e) { console.error('pembaruan gagal dipasang', e); LOG.tulis('pembaruan', 'GALAT', 'gagal dipasang: ' + (e.stack || e)); }
  fs.rmSync(ANTRE, { recursive: true, force: true });
  return ubahApp;
}
if (pasangAntrean()) { app.relaunch(); app.exit(0); }                 // kode aplikasi berubah → jalankan versi baru

const lebihBaru = (a, b) => { const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number); for (let i = 0; i < 3; i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0); return false; };
let siapPasang = null;                                               // keterangan paket yang menunggu dibuka ulang
function antrekan(buf, ket) {
  const peta = petakan(bacaZip(buf));
  fs.rmSync(ANTRE, { recursive: true, force: true });
  for (const f of peta) { const t = path.join(ANTRE, 'isi', f.tujuan); fs.mkdirSync(path.dirname(t), { recursive: true }); fs.writeFileSync(t, f.data); }
  fs.writeFileSync(path.join(ANTRE, 'daftar.json'), JSON.stringify({ ket, file: peta.map((f) => f.tujuan) }));
  siapPasang = ket; kirimBar();
  return peta;
}
let sedangCek = false;
async function cekPembaruan(manual) {
  if (sedangCek) return; sedangCek = true;
  try {
    const r = await net.fetch(URL_PEMBARUAN + '?t=' + Date.now(), { cache: 'no-store' });
    if (!r.ok) throw new Error('server menjawab ' + r.status);
    const v = await r.json();
    if (!lebihBaru(v.versi, app.getVersion())) { if (manual) beritahu(`Sudah versi terbaru (${app.getVersion()}).`); return; }
    if (!/^https:\/\/alvisya\.my\.id\//.test(v.zip || '')) throw new Error('alamat paket tidak dikenal');
    const buf = Buffer.from(await (await net.fetch(v.zip, { cache: 'no-store' })).arrayBuffer());
    if (crypto.createHash('sha256').update(buf).digest('hex') !== String(v.sha256).toLowerCase()) throw new Error('paket rusak (sidik SHA-256 tidak cocok)');
    antrekan(buf, 'Versi ' + v.versi + (v.catatan ? ' — ' + v.catatan : ''));
  } catch (e) { LOG.tulis('pembaruan', 'WARN', 'gagal memeriksa: ' + (e.message || e)); if (manual) beritahu('Gagal memeriksa pembaruan: ' + (e.message || e)); }
  finally { sedangCek = false; }
}
async function pembaruanZip() {
  const { canceled, filePaths } = await dialog.showOpenDialog(jendela, { title: 'Pilih ZIP pembaruan', filters: [{ name: 'ZIP', extensions: ['zip'] }], properties: ['openFile'] });
  if (canceled || !filePaths[0]) return;
  try { antrekan(fs.readFileSync(filePaths[0]), 'Dari ' + path.basename(filePaths[0])); }
  catch (e) { beritahu('ZIP tidak bisa dipakai: ' + (e.message || e)); }
}
function beritahu(t) { if (bar && !bar.webContents.isDestroyed()) bar.webContents.send('kabar', t); }
protocol.registerSchemesAsPrivileged([{ scheme: 'aldesk', privileges: { supportFetchAPI: true, corsEnabled: true, bypassCSP: true } }]);
Menu.setApplicationMenu(null);
// Lebih ringan: semua tab C-CARE berbagi satu proses (hemat RAM saat banyak tab), tanpa pemeriksa ejaan.
app.commandLine.appendSwitch('process-per-site');

let jendela, bar, ses, ekstensiId, popup = null, skripUtama = [], halJembatan = null;
const tab = new Map();          // id webContents → WebContentsView
let aktif = null;
const notif = new Map();         // id → Notification
const SESI = Date.now().toString(36);   // satu nilai per kali aplikasi dibuka (runtime.onStartup tiruan)
const klien = new Map();         // id konteks shim → { antre: [], tunggu: fungsi|null, terakhir }

/* ---------- ekstensi: salin dari folder ekstensi\ lalu tambal (shim + tanpa skrip PCare) ---------- */
function siapkanEkstensi() {
  const sumber = path.join(AKAR, 'ekstensi');
  const jalan = path.join(app.getPath('userData'), 'ekstensi-jalan');
  if (!fs.existsSync(path.join(sumber, 'manifest.json'))) throw new Error('Folder "ekstensi" (berisi manifest.json CCare Dokter) tidak ditemukan di ' + sumber);
  fs.rmSync(jalan, { recursive: true, force: true });
  fs.cpSync(sumber, jalan, { recursive: true });
  fs.copyFileSync(path.join(__dirname, 'shim.js'), path.join(jalan, 'aldesk-shim.js'));
  const m = JSON.parse(fs.readFileSync(path.join(jalan, 'manifest.json'), 'utf8'));
  // Aplikasi ini hanya untuk C-CARE: skrip & izin PCare tidak dimuat.
  m.content_scripts = (m.content_scripts || []).filter((c) => !(c.matches || []).some((x) => x.includes('pcarejkn')));
  // Electron belum menjalankan content script world "MAIN" → dikeluarkan dari manifest, disuntikkan sendiri saat halaman siap.
  skripUtama = m.content_scripts.filter((c) => c.world === 'MAIN').map((c) => ({
    pola: c.matches.map(polaKe), kode: c.js.map((f) => fs.readFileSync(path.join(jalan, f), 'utf8')).join('\n;\n'), awal: c.run_at === 'document_start' }));
  m.content_scripts = m.content_scripts.filter((c) => c.world !== 'MAIN');
  m.host_permissions = (m.host_permissions || []).filter((x) => !x.includes('pcarejkn'));
  m.permissions = (m.permissions || []).filter((p) => !['notifications', 'tabGroups'].includes(p));   // dikerjakan shim
  const bg = m.background && m.background.service_worker;
  if (bg) {
    fs.writeFileSync(path.join(jalan, 'aldesk-latar.js'), `importScripts('aldesk-shim.js', ${JSON.stringify(bg)});\n`);
    m.background.service_worker = 'aldesk-latar.js';
  }
  fs.writeFileSync(path.join(jalan, 'manifest.json'), JSON.stringify(m, null, 1));
  fs.copyFileSync(path.join(__dirname, 'jembatan.js'), path.join(jalan, 'aldesk-jembatan.js'));
  for (const f of fs.readdirSync(jalan).filter((f) => f.endsWith('.html'))) {   // halaman ekstensi: shim dulu
    const p = path.join(jalan, f);
    const h = fs.readFileSync(p, 'utf8');
    if (h.includes('<script')) fs.writeFileSync(p, h.replace('<script', '<script src="aldesk-shim.js"></script>\n<script'));
  }
  fs.writeFileSync(path.join(jalan, 'aldesk-jembatan.html'), '<!doctype html><meta charset="utf-8"><title>jembatan</title><script src="aldesk-jembatan.js"></script>');
  return jalan;
}

async function muatEkstensi() {
  const ex = ses.extensions;
  if (ekstensiId) { try { ex.removeExtension(ekstensiId); } catch (e) { /* abaikan */ } }
  const e = await ex.loadExtension(siapkanEkstensi(), { allowFileAccess: true });
  ekstensiId = e.id;
  if (halJembatan && !halJembatan.isDestroyed()) halJembatan.destroy();
  halJembatan = new BrowserWindow({ show: false, webPreferences: { session: ses, sandbox: true } });   // tak terlihat, hanya penerus pesan
  await halJembatan.loadURL(`chrome-extension://${ekstensiId}/aldesk-jembatan.html`);
  kirimBar();
  return e;
}

/* ---------- tab ---------- */
function infoTab(v) {
  const w = v.webContents;
  return { id: w.id, windowId: 1, index: [...tab.keys()].indexOf(w.id), url: w.getURL(), title: w.getTitle(), active: aktif === w.id,
    status: w.isLoading() ? 'loading' : 'complete', discarded: false, pinned: false, highlighted: aktif === w.id, incognito: false };
}
function aturUkuran() {
  const [l, t] = jendela.getContentSize();
  bar.setBounds({ x: 0, y: 0, width: l, height: TINGGI_BAR });
  for (const v of tab.values()) v.setBounds({ x: 0, y: TINGGI_BAR, width: l, height: Math.max(0, t - TINGGI_BAR) });
}
function bukaTab(url = BERANDA, jadikanAktif = true) {
  const v = new WebContentsView({ webPreferences: { session: ses, sandbox: true, contextIsolation: true, backgroundThrottling: true, spellcheck: false } });
  const w = v.webContents;
  tab.set(w.id, v);
  jendela.contentView.addChildView(v, 1);
  v.setVisible(false);
  w.setWindowOpenHandler(({ url: u }) => { if (BOLEH(u)) bukaTab(u, true); else shell.openExternal(u); return { action: 'deny' }; });
  w.on('will-navigate', (e, u) => { if (!BOLEH(u)) { e.preventDefault(); shell.openExternal(u); } });
  for (const ev of ['did-start-loading', 'did-stop-loading', 'page-title-updated', 'did-navigate', 'did-navigate-in-page']) w.on(ev, kirimBar);
  const ubah = (info) => { if (!w.isDestroyed()) kejadianBaru({ jenis: 'tabUbah', id: w.id, info, tab: infoTab(v) }); };
  w.on('did-start-loading', () => ubah({ status: 'loading' }));
  w.on('did-navigate', (e, u) => ubah({ url: u }));
  w.on('did-navigate-in-page', (e, u, utama) => { if (utama) ubah({ url: u }); });
  w.on('page-title-updated', (e, t) => ubah({ title: t }));
  w.on('did-stop-loading', () => ubah({ status: 'complete' }));
  w.on('before-input-event', (e, i) => tombolPintas(e, i, w));
  w.on('found-in-page', (e, h) => { if (aktif === w.id && h.finalUpdate) bar.webContents.send('hasilCari', { ke: h.activeMatchOrdinal, dari: h.matches }); });
  aturUkuran();
  w.loadURL(url);
  w.on('dom-ready', () => { const u = w.getURL(); for (const k of skripUtama) if (k.pola.some((r) => r.test(u))) w.executeJavaScript(k.kode).catch(() => {}); });
  w.on('did-fail-load', (e, kode, ket, u, utama) => {
    if (!utama || kode === -3) return;   // -3 = dibatalkan (pindah halaman), bukan galat
    w.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent(`<!doctype html><title>Tidak tersambung</title><body style="font:16px 'Segoe UI',sans-serif;color:#0F2742;display:grid;place-items:center;height:90vh;margin:0"><div style="max-width:440px"><h1 style="font-size:22px">C-CARE belum bisa dibuka</h1><p>Periksa koneksi internet, lalu tekan <b>F5</b> atau tombol muat ulang.</p><p style="color:#5B6B7C;font-size:13px">${ket} (${kode})</p><p><a href="${u.replace(/"/g, '')}" style="color:#0b7a72">Coba lagi</a></p></div>`));
  });
  if (jadikanAktif || aktif === null) pilihTab(w.id); else kirimBar();
  return infoTab(v);
}
function pilihTab(id) {
  if (!tab.has(id)) return;
  if (aktif && tab.has(aktif) && aktif !== id) { tab.get(aktif).webContents.stopFindInPage('clearSelection'); bar.webContents.send('cariTutup'); }
  aktif = id;
  for (const [k, v] of tab) v.setVisible(k === id);
  tab.get(id).webContents.focus();
  kirimBar();
}
function tutupTab(id) {
  const v = tab.get(id); if (!v) return;
  const urut = [...tab.keys()], i = urut.indexOf(id);
  tab.delete(id);
  kejadianBaru({ jenis: 'tabTutup', id });
  jendela.contentView.removeChildView(v);
  v.webContents.close();
  if (tab.size === 0) { bukaTab(); return; }
  if (aktif === id) pilihTab(urut[i + 1] ?? urut[i - 1]); else kirimBar();
}
function kirimBar() {
  if (!bar || bar.webContents.isDestroyed()) return;
  const w = aktif && tab.get(aktif) ? tab.get(aktif).webContents : null;
  bar.webContents.send('keadaan', {
    tab: [...tab.values()].map((v) => ({ id: v.webContents.id, judul: v.webContents.getTitle() || v.webContents.getURL(), muat: v.webContents.isLoading() })),
    aktif, url: w ? w.getURL() : '', versi: app.getVersion(), siapPasang, mundur: !!w && w.navigationHistory.canGoBack(), maju: !!w && w.navigationHistory.canGoForward(), ekstensi: !!ekstensiId,
  });
}
function tombolPintas(e, i, w) {
  if (i.type !== 'keyDown') return;
  const k = i.key.toLowerCase(), ctrl = i.control || i.meta;
  if (k === 'f5' || (ctrl && k === 'r')) { w.reload(); e.preventDefault(); }
  else if (ctrl && k === 't') { bukaTab(); e.preventDefault(); }
  else if (ctrl && k === 'l') { bar.webContents.focus(); bar.webContents.send('alamat'); e.preventDefault(); }
  else if ((ctrl && k === 'f') || k === 'f3') { bar.webContents.focus(); bar.webContents.send('cari'); e.preventDefault(); }
  else if (ctrl && k === 'w') { tutupTab(w.id); e.preventDefault(); }
  else if (i.alt && k === 'arrowleft') { if (w.navigationHistory.canGoBack()) w.navigationHistory.goBack(); e.preventDefault(); }
  else if (ctrl && k === 'tab') { const u = [...tab.keys()]; pilihTab(u[(u.indexOf(aktif) + (i.shift ? u.length - 1 : 1)) % u.length]); e.preventDefault(); }
  else if (ctrl && (k === '=' || k === '+')) { w.setZoomLevel(w.getZoomLevel() + 0.5); e.preventDefault(); }
  else if (ctrl && k === '-') { w.setZoomLevel(w.getZoomLevel() - 0.5); e.preventDefault(); }
  else if (ctrl && k === '0') { w.setZoomLevel(0); e.preventDefault(); }
}

/* ---------- popup ekstensi (pengganti ikon di bilah Chrome) ---------- */
function bukaPopup(x) {
  if (popup) { tutupPopup(); return; }
  const m = JSON.parse(fs.readFileSync(path.join(app.getPath('userData'), 'ekstensi-jalan', 'manifest.json'), 'utf8'));
  const hal = (m.action && m.action.default_popup) || 'popup.html';
  popup = new WebContentsView({ webPreferences: { session: ses, sandbox: true, spellcheck: false } });
  popup.setBorderRadius?.(10);
  jendela.contentView.addChildView(popup);
  const [l] = jendela.getContentSize();
  popup.setBounds({ x: Math.max(8, Math.min(l - 428, x - 400)), y: TINGGI_BAR - 4, width: 420, height: 560 });
  popup.webContents.loadURL(`chrome-extension://${ekstensiId}/${hal}`);
  popup.webContents.on('did-finish-load', async () => {     // tinggi mengikuti isi popup
    try { const h = await popup.webContents.executeJavaScript('document.documentElement.scrollHeight'); const b = popup.getBounds(); popup.setBounds({ ...b, height: Math.min(Math.max(h, 200), jendela.getContentSize()[1] - TINGGI_BAR) }); } catch (e) { /* abaikan */ }
  });
  popup.webContents.on('before-input-event', (e, i) => { if (i.key === 'Escape') tutupPopup(); });
  popup.webContents.setWindowOpenHandler(({ url: u }) => { if (BOLEH(u)) bukaTab(u, true); else shell.openExternal(u); tutupPopup(); return { action: 'deny' }; });
  popup.webContents.focus();
  popup.webContents.on('blur', () => setTimeout(() => { if (popup && !popup.webContents.isFocused()) tutupPopup(); }, 150));
  bar.webContents.send('popup', true);
}
function tutupPopup() {
  if (!popup) return;
  jendela.contentView.removeChildView(popup); popup.webContents.close(); popup = null;
  bar.webContents.send('popup', false);
}

/* ---------- jembatan shim: aldesk://x/<aksi> ---------- */
function kejadianBaru(e) {
  const kini = Date.now();
  for (const [id, k] of klien) {
    if (!k.tunggu && kini - k.terakhir > 60_000) { klien.delete(id); continue; }   // konteks sudah mati
    k.antre.push(e); if (k.tunggu) { const f = k.tunggu; k.tunggu = null; f(); }
  }
}
const polaKe = (p) => new RegExp('^' + p.replace(/[.+?^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '.*') + '$');
function cocokQuery(t, q) {
  if (q.url && ![].concat(q.url).some((p) => polaKe(p).test(t.url))) return false;
  if (q.active !== undefined && q.active !== t.active) return false;
  if (q.status && q.status !== t.status) return false;
  if (q.windowId !== undefined && q.windowId >= 0 && q.windowId !== 1) return false;
  if (q.title && !polaKe(q.title).test(t.title)) return false;
  return true;
}
async function jembatan(aksi, d) {
  switch (aksi) {
    case 'tabsCreate': {
      if (d.url && !/^[a-z-]+:/.test(d.url)) d.url = `chrome-extension://${ekstensiId}/${d.url.replace(/^\//, '')}`;
      const t = bukaTab(d.url || BERANDA, d.active !== false); t.url = t.pendingUrl = d.url || BERANDA; return t;
    }
    case 'tabsRemove': d.forEach((id) => tutupTab(id)); return {};
    case 'tabsQuery': return [...tab.values()].map(infoTab).filter((t) => cocokQuery(t, d));
    case 'tabsGet': { const v = tab.get(d.id); if (!v) return { galat: 'No tab with id: ' + d.id + '.' }; return infoTab(v); }
    case 'tabsUpdate': {
      const id = d.id ?? aktif, v = tab.get(id); if (!v) return { galat: 'No tab with id: ' + id + '.' };
      if (d.o.url) v.webContents.loadURL(d.o.url);
      if (d.o.active) pilihTab(id);
      return infoTab(v);
    }
    case 'tabsReload': { const v = tab.get(d.id ?? aktif); if (v) v.webContents.reload(); return {}; }
    case 'sesi': return { sesi: SESI };
    case 'fokus': if (jendela.isMinimized()) jendela.restore(); jendela.focus(); return {};
    case 'muatUlangEkstensi': setTimeout(async () => { await muatEkstensi(); for (const v of tab.values()) v.webContents.reload(); }, 300); return {};
    case 'notifBuat': case 'notifUbah': {
      const lama = notif.get(d.id);
      if (aksi === 'notifUbah' && !lama) return { ada: false };
      const o = { ...(lama ? lama.__opsi : {}), ...d.opsi };
      if (lama) lama.close();
      const n = new Notification({ title: o.title || 'CCare', body: o.message || '', silent: !!o.silent, icon: o.iconUrl ? await ikon(o.iconUrl) : undefined });
      n.__opsi = o;
      n.on('click', () => { jendela.show(); jendela.focus(); kejadianBaru({ jenis: 'notifKlik', id: d.id }); });
      notif.set(d.id, n); n.show();
      return { ada: true };
    }
    case 'notifHapus': { const n = notif.get(d.id); if (n) { n.close(); notif.delete(d.id); } return { ada: !!n }; }
    case 'kejadian': {
      let k = klien.get(d.klien); if (!k) klien.set(d.klien, k = { antre: [], tunggu: null, terakhir: 0 });
      if (!k.antre.length) await new Promise((r) => { k.tunggu = r; setTimeout(() => { if (k.tunggu === r) { k.tunggu = null; r(); } }, 25_000); });
      k.terakhir = Date.now();
      const a = k.antre; k.antre = []; return a;
    }
  }
  return { galat: 'aksi tidak dikenal: ' + aksi };
}
async function ikon(u) {
  try {
    const m = u.match(/^chrome-extension:\/\/[^/]+\/(.+)$/);
    if (m) return nativeImage.createFromPath(path.join(app.getPath('userData'), 'ekstensi-jalan', decodeURIComponent(m[1])));
  } catch (e) { /* abaikan */ }
  return undefined;
}

/* ---------- mulai ---------- */
app.whenReady().then(async () => {
  ses = session.fromPartition('persist:ccare');
  ses.setSpellCheckerEnabled(false);
  ses.setPermissionRequestHandler((wc, izin, ok) => ok(['notifications', 'clipboard-sanitized-write', 'fullscreen', 'fileSystem'].includes(izin)));
  ses.protocol.handle('aldesk', async (req) => {
    let d = null; try { d = JSON.parse(await req.text() || 'null'); } catch (e) { /* abaikan */ }
    let hasil; try { hasil = await jembatan(new URL(req.url).pathname.slice(1), d); } catch (e) { hasil = { galat: String(e.message || e) }; }
    return new Response(JSON.stringify(hasil ?? {}), { headers: { 'content-type': 'application/json', 'access-control-allow-origin': '*' } });
  });

  jendela = new BaseWindow({ width: 1366, height: 860, minWidth: 900, minHeight: 600, title: 'AlvisyaLabs Browser', backgroundColor: '#ffffff', icon: path.join(__dirname, 'ikon.png') });
  jendela.maximize();
  bar = new WebContentsView({ webPreferences: { preload: path.join(__dirname, 'bar-preload.js'), sandbox: true, contextIsolation: true } });
  jendela.contentView.addChildView(bar);
  bar.webContents.loadFile(path.join(__dirname, 'bar.html'));
  bar.webContents.on('did-finish-load', kirimBar);
  jendela.on('resize', aturUkuran);
  jendela.on('closed', () => app.quit());

  LOG.pantauJaringan(ses);
  try { await muatEkstensi(); LOG.tulis('aplikasi', 'INFO', `mulai: AlvisyaLabs Browser ${app.getVersion()}, Electron ${process.versions.electron}, ekstensi ${ses.extensions.getExtension(ekstensiId)?.version}`); } catch (e) { console.error(e); LOG.tulis('ekstensi', 'GALAT', 'gagal dimuat: ' + (e.stack || e)); bar.webContents.once('did-finish-load', () => bar.webContents.send('galat', String(e.message || e))); }
  bukaTab(BERANDA, true);
  if (fs.existsSync(path.join(ANTRE, 'daftar.json'))) { try { siapPasang = JSON.parse(fs.readFileSync(path.join(ANTRE, 'daftar.json'), 'utf8')).ket; } catch (e) { /* abaikan */ } }
  if (app.isPackaged) { setTimeout(() => cekPembaruan(false), 15_000); setInterval(() => cekPembaruan(false), CEK_TIAP); }

  ipcMain.on('bar', (e, aksi, a) => {
    const w = aktif && tab.get(aktif) ? tab.get(aktif).webContents : null;
    if (aksi === 'pilih') pilihTab(a);
    else if (aksi === 'tutup') tutupTab(a);
    else if (aksi === 'baru') bukaTab();
    else if (aksi === 'mundur' && w && w.navigationHistory.canGoBack()) w.navigationHistory.goBack();
    else if (aksi === 'maju' && w && w.navigationHistory.canGoForward()) w.navigationHistory.goForward();
    else if (aksi === 'muat' && w) w.reload();
    else if (aksi === 'beranda' && w) w.loadURL(BERANDA);
    else if (aksi === 'buka' && w && typeof a === 'string') {          // alamat diketik di bilah alamat
      let u = a.trim(); if (!u) return;
      if (u.startsWith('/')) u = 'https://c-care.ipb.ac.id' + u;                    // mis. /Poli/Index/1
      else if (/^c-care\.ipb\.ac\.id/i.test(u)) u = 'https://' + u;
      else if (!/^[a-z][a-z0-9+.-]*:/i.test(u)) u = /^[\w-]+(\.[\w-]+)+(\/|$)/.test(u) ? 'https://' + u : 'https://www.google.com/search?q=' + encodeURIComponent(u);
      if (BOLEH(u)) w.loadURL(u); else if (/^https?:/i.test(u)) shell.openExternal(u);   // situs lain → browser biasa
      w.focus();
    }
    else if (aksi === 'popup' && ekstensiId) bukaPopup(a);
    else if (aksi === 'atur' && ekstensiId) bukaTab(`chrome-extension://${ekstensiId}/pengaturan.html`);
    else if (aksi === 'cari' && w) { if (a && a.teks) w.findInPage(a.teks, { forward: a.maju !== false, findNext: !a.lanjut }); else w.stopFindInPage('clearSelection'); }
    else if (aksi === 'cariTutup' && w) { w.stopFindInPage('keepSelection'); w.focus(); }
    else if (aksi === 'menu') Menu.buildFromTemplate([
      { label: 'Periksa pembaruan', click: () => cekPembaruan(true) },
      { label: 'Perbarui dari ZIP…', click: () => pembaruanZip() },
      { label: 'Buka folder log', click: () => shell.openPath(LOG.folder()) },
      { type: 'separator' },
      { label: 'AlvisyaLabs Browser ' + app.getVersion(), enabled: false },
    ]).popup({ window: jendela, x: a?.x, y: a?.y });
    else if (aksi === 'cekPembaruan') cekPembaruan(true);
    else if (aksi === 'zip') pembaruanZip();
    else if (aksi === 'mulaiUlang') { app.relaunch(); app.exit(0); }
  });
});
if (process.env.CD_UJI) global.__cd = { tab, jembatan, bukaTab, pilihTab, get aktif() { return aktif; }, get jendela() { return jendela; }, get bar() { return bar; }, get ekstensiId() { return ekstensiId; }, get popup() { return popup; }, bukaPopup };
app.on('second-instance', () => { if (jendela) { if (jendela.isMinimized()) jendela.restore(); jendela.focus(); } });
