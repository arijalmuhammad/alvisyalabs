/* Isi Cepat C-CARE — bagian yang harus berjalan di konteks halaman (jQuery & select2 milik C-CARE).
 * Masalah C-CARE: setiap baris obat/racikan/alkes ditambahkan, potongan HTML dari /Poli/AddResep menjalankan
 * $("select").select2({width:'100%'}) untuk SEMUA select — termasuk Diagnosa (#KodePenyakit) — sehingga pencarian
 * ICD-10 (/Ajax/Penyakit) hilang dan Diagnosa tampak terkunci. Di sini Diagnosa dipasang ulang dengan pengaturan aslinya;
 * diagnosa yang sudah dipilih tetap terpilih. Tidak menyimpan apa pun.
 */
(() => {
  const $ = window.jQuery;
  if (!$ || window.__isiCepatIcd) return; window.__isiCepatIcd = true;
  const OPSI = {
    placeholder: '-- Pilih --', width: '100%', minimumInputLength: 2,
    ajax: {
      url: '/Ajax/Penyakit', dataType: 'json', delay: 250,
      data: p => ({ q: p.term, id: null }),
      processResults: d => (d && d.stat == true) ? { results: $.map(d.res, it => ({ id: it.ID, text: it.Value })) } : { results: [] },
    },
  };
  function adaAjax(el) { try { const s = el.data('select2'); return !!(s && s.options && s.options.get('ajax')); } catch (e) { return false; } }
  function pulihkan() {
    const el = $('#KodePenyakit');
    if (!el.length || adaAjax(el)) return;
    try { if (el.data('select2')) el.select2('destroy'); } catch (e) {}
    el.select2(OPSI);
    document.dispatchEvent(new CustomEvent('isicepat-icd', { detail: 'dipulihkan' }));
  }
  $(document).ajaxComplete((_e, _x, s) => { if (s && /\/Poli\/Add(Resep|Racikan|ResepAlkes|UploadResep)/i.test(s.url || '')) setTimeout(pulihkan, 60); });
  // cadangan: bila ada skrip lain yang memasang ulang select2 di luar AJAX
  setInterval(pulihkan, 3000);
})();

/* C-CARE menggulir halaman 2 detik ke baris obat baru tiap (+) Obat (fungsi scrollInto). Dimatikan selama Isi cepat aktif. */
(function () {
  const asli = window.scrollInto;
  if (typeof asli !== 'function') return;
  window.scrollInto = function (id) {
    if (document.documentElement.dataset.isiCepat === 'aktif') return;   // diset oleh isi-cepat.js bila Isi cepat tidak dimatikan
    return asli.apply(this, arguments);
  };
})();

/* Tindak Lanjut & resep memakai select2 (perubahan lewat jQuery tidak memicu event asli) → teruskan ke isi-cepat.js */
(function () {
  const $ = window.jQuery; if (!$ || window.__isiCepatTl) return; window.__isiCepatTl = true;
  $(document).on('change', '#TindakLanjutPengobatanId, #KodePenyakit, #GrupResep select', e => document.dispatchEvent(new CustomEvent('isicepat-ubah', { detail: e.target.id || e.target.name || '' })));
})();

/* Memori resep (cppt-resep.js): pilih obat di baris resep lewat jQuery agar select2 & GetHargaObatSatuan C-CARE ikut berjalan;
 * tambah baris resep memakai fungsi C-CARE sendiri (TambahResep). Tidak menyimpan apa pun. */
(function () {
  const $ = window.jQuery; if (!$ || window.__sjcResepMain) return; window.__sjcResepMain = true;
  document.addEventListener('sjc-pilih-obat', e => {
    let hasil = 'gagal';
    try {
      const d = JSON.parse(e.detail || '{}'), el = $('#' + d.id);
      const o = el.find('option').filter((_, x) => x.value === String(d.val));
      if (!o.length) hasil = 'tidak-ada'; else if (o.prop('disabled')) hasil = 'stok-habis';
      else { el.val(String(d.val)).trigger('change'); hasil = el.val() === String(d.val) ? 'ok' : 'gagal'; }
    } catch (x) {}
    document.dispatchEvent(new CustomEvent('sjc-pilih-obat-hasil', { detail: hasil }));
  });
  document.addEventListener('sjc-satuan', e => { try { const d = JSON.parse(e.detail || '{}'); $('#' + d.id).val(String(d.val)).trigger('change'); } catch (x) {} });
  /* TambahResep C-CARE memuat baris lewat AJAX dan baru menaikkan CounterResep sesudahnya. Panggilan kedua sebelum itu
     (klik (+) beruntun, penjaga baris otomatis, atau saat C-CARE masih memuat) membuat nomor & indeks resep ganda.
     Maka SEMUA panggilan TambahResep/HapusResep diantrekan: baru jalan bila CounterResep sudah berubah dan tidak ada AJAX. */
  (function antrekanResep() {
    const asliT = window.TambahResep, asliH = window.HapusResep;
    if (typeof asliT !== 'function' || asliT.__sjc) return;
    const cnt = () => document.getElementById('CounterResep');
    let sejak = 0, nilai = null, antre = 0;
    const sibuk = () => (sejak && Date.now() - sejak < 6000 && cnt() && cnt().value === nilai) || (window.jQuery && jQuery.active > 0);
    const T = function () {
      if (sibuk()) {                                        // satu panggilan susulan saja; tekan beruntun digabung
        if (!antre) { const t0 = Date.now(); antre = setInterval(() => { if (!sibuk() || Date.now() - t0 > 8000) { clearInterval(antre); antre = 0; if (!sibuk()) T(); } }, 150); }
        return;
      }
      sejak = Date.now(); nilai = cnt() ? cnt().value : null;
      return asliT.apply(this, arguments);
    };
    T.__sjc = true; window.TambahResep = T;
    if (typeof asliH === 'function') { const H = function () { if (sibuk()) return; return asliH.apply(this, arguments); }; H.__sjc = true; window.HapusResep = H; }
  })();
  document.addEventListener('sjc-tambah-resep', () => { try { if (typeof window.TambahResep === 'function') window.TambahResep(); } catch (x) {} });
  document.addEventListener('sjc-hapus-resep', () => { try { if (typeof window.HapusResep === 'function') window.HapusResep(); } catch (x) {} });   // hapus baris TERAKHIR (fungsi C-CARE)
})();
