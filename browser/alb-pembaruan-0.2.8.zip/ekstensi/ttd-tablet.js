/* CCare Dokter v4.8.4 — Tablet tanda tangan (Pengaturan → Tampilan → Tablet tanda tangan).
 * PC   : saat CPPT pasien dibuka, nomor kunjungan (hanya angka) dikirim ke relay Apps Script milik Anda.
 * Tablet (ekstensi ini juga terpasang): tiap 3 detik membaca relay → membuka form Informasi Rencana Asuhan pasien itu,
 *        kerangka C-CARE disembunyikan, tombol "Simpan tanda tangan" besar di bawah (menekan Simpan C-CARE saat Anda ketuk).
 *        Setelah tersimpan: layar "Menunggu pasien berikutnya" menutupi C-CARE (catatan pasien sebelumnya tidak terlihat).
 * Ekstensi tidak membuat, menyalin, atau mengisi tanda tangan; tidak menekan Simpan sendiri. */
(() => {
  if (window.top !== window || window.__sjcTablet) return; window.__sjcTablet = true;
  const RE_FORM = /\/Poli\/FormInformasiRencanaAsuhan\/(\d+)/i, POLA_URL = /^https:\/\/script\.google\.com\/macros\/s\/[\w-]+\/exec$/, POLA_T = /^[\w-]{20,64}$/;
  const relay = (c, q) => new Promise(ok => { try { chrome.runtime.sendMessage({ aksi: 'relayTtd', url: `${c.url}?t=${c.t}&${q}` }, r => ok(chrome.runtime.lastError ? null : r)); } catch (e) { ok(null); } });
  const ss = { get: k => { try { return sessionStorage.getItem(k) || ''; } catch (e) { return ''; } }, set: (k, v) => { try { v ? sessionStorage.setItem(k, v) : sessionStorage.removeItem(k); } catch (e) {} } };

  /* pemasangan dari kode QR di Pengaturan PC: https://c-care.ipb.ac.id/#sjcTablet=<base64url {u,t}> */
  const h = location.hash.match(/^#sjcTablet=([\w-]+)$/);
  if (h) {
    try {
      const c = JSON.parse(atob(h[1].replace(/-/g, '+').replace(/_/g, '/')));
      if (POLA_URL.test(c.u) && POLA_T.test(c.t)) { const cfg = { url: c.u, t: c.t, peran: 'tablet' }; chrome.storage.local.set({ ttdTablet: cfg }); history.replaceState(null, '', location.pathname + location.search); ss.set('sjcTtdJeda', ''); return jalan(cfg); }
    } catch (e) {}
  }
  chrome.storage.local.get('ttdTablet', s => jalan(s.ttdTablet || {}));

  function jalan(c) {
    if (!POLA_URL.test(c.url || '') || !POLA_T.test(c.t || '')) return;
    if (c.peran === 'pc') return kirim(c);
    if (c.peran === 'tablet') tablet(c);
  }

  /* PC: pengiriman ke relay, pemantauan, dan lencana status ada di ttd-depan.js (v4.10.0) */
  function kirim() {}

  /* ---------- Tablet ---------- */
  function tablet(c) {
    if (document.querySelector('input[type=password]')) return;   // halaman login C-CARE: biarkan petugas masuk dulu
    if (ss.get('sjcTtdJeda')) return pilJeda();
    const kini = (location.pathname.match(RE_FORM) || [])[1] || '';
    let selesai = ss.get('sjcTtdSelesai');
    const sebelum = ss.get('sjcTtdBuka');
    if (kini) ss.set('sjcTtdBuka', kini);
    else if (sebelum) { selesai = sebelum; ss.set('sjcTtdSelesai', sebelum); ss.set('sjcTtdBuka', ''); }   // C-CARE mengalihkan setelah Simpan
    const st = document.createElement('style');
    st.textContent = `.main-header,.main-sidebar,.main-footer,.content-header,.breadcrumb{display:none!important}
      .content-wrapper{margin-left:0!important;padding-top:0!important;min-height:0!important}body{padding-bottom:96px!important;background:#F5F8F8!important}
      .sjc-tb-bar{position:fixed;left:0;right:0;bottom:0;z-index:2147482500;display:flex;gap:12px;align-items:center;padding:12px 16px;background:#fff;border-top:1px solid #D5E0E0;font:15px/1.4 "Source Sans 3","Source Sans Pro",system-ui,sans-serif;color:#4F6478}
      .sjc-tb-bar .simpan{flex:1;min-height:56px;border:0;border-radius:12px;background:#263C92;color:#fff;font:700 20px/1 "Source Sans 3","Source Sans Pro",system-ui,sans-serif;cursor:pointer}
      .sjc-tb-bar .simpan:focus-visible,.sjc-tb-tunggu button:focus-visible{outline:3px solid #0F2742;outline-offset:3px}
      .sjc-tb-tunggu{position:fixed;inset:0;z-index:2147483600;display:grid;place-items:center;background:#F5F8F8;font:16px/1.5 "Source Sans 3","Source Sans Pro",system-ui,sans-serif;color:#0F2742;text-align:center}
      .sjc-tb-tunggu main{width:min(480px,calc(100vw - 32px))}.sjc-tb-tunggu h1{font-size:24px;margin:16px 0 8px}.sjc-tb-tunggu p{margin:0 0 24px;color:#4F6478}
      .sjc-tb-tunggu svg{width:48px;height:48px;fill:#3B7A1E}.sjc-tb-tunggu .ulang{min-height:48px;padding:0 20px;border:1px solid #263C92;border-radius:8px;background:#fff;color:#263C92;font:600 16px/1 "Source Sans 3","Source Sans Pro",system-ui,sans-serif;cursor:pointer}
      .sjc-tb-st{display:flex;gap:6px;align-items:center;justify-content:center;margin-top:24px;font-size:14px;color:#4F6478}.sjc-tb-st i{width:8px;height:8px;border-radius:50%;background:#3B7A1E}.sjc-tb-st.putus i{background:#B91C1C}
      .sjc-tb-jeda{border:0;background:none;color:#4F6478;text-decoration:underline;font:14px "Source Sans 3","Source Sans Pro",system-ui,sans-serif;cursor:pointer;margin-top:8px}
      .sjc-tb-pindah{position:fixed;left:16px;right:16px;top:16px;z-index:2147482600;display:flex;gap:12px;align-items:center;padding:12px 16px;border:1px solid #E9B872;border-radius:12px;background:#FFF5E6;color:#B45309;font:600 15px/1.4 "Source Sans 3",system-ui,sans-serif}
      .sjc-tb-pindah button{margin-left:auto;min-height:40px;padding:0 14px;border:1px solid #B45309;border-radius:8px;background:#fff;color:#B45309;font:600 14px/1 "Source Sans 3","Source Sans Pro",system-ui,sans-serif;cursor:pointer}`;
    document.head.appendChild(st);
    const IK_OK = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm-2 15-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg>';
    let layar = null, menggambar = false;
    if (kini) siapkanForm();
    try { navigator.wakeLock && navigator.wakeLock.request('screen').catch(() => {}); } catch (e) {}

    function siapkanForm() {
      const kanvas = document.querySelector('canvas'); if (kanvas) { kanvas.addEventListener('pointerdown', () => { menggambar = true; }); setTimeout(() => kanvas.scrollIntoView({ block: 'center' }), 300); }
      const asli = [...document.querySelectorAll('button[type=submit], input[type=submit], button')].find(b => /^\s*simpan\s*$/i.test(b.textContent || b.value || ''));
      const bar = document.createElement('div'); bar.className = 'sjc-tb-bar';
      bar.innerHTML = '<button type="button" class="simpan">Simpan tanda tangan</button>';
      bar.querySelector('.simpan').addEventListener('click', () => { if (asli) asli.click(); });   // diketuk petugas/pasien = menekan Simpan C-CARE
      document.body.appendChild(bar);
    }
    function tunggu(sudah) {
      if (!layar) {
        layar = document.createElement('div'); layar.className = 'sjc-tb-tunggu'; layar.setAttribute('role', 'dialog'); layar.setAttribute('aria-modal', 'true');
        layar.innerHTML = `<main>${IK_OK}<h1></h1><p></p><button type="button" class="ulang" hidden>Buka lagi form pasien ini</button><div class="sjc-tb-st" role="status"><i></i><span>Terhubung ke PC dokter</span></div><button type="button" class="sjc-tb-jeda">Jeda mode tablet (petugas)</button></main>`;
        layar.querySelector('.ulang').addEventListener('click', () => { ss.set('sjcTtdSelesai', ''); location.href = '/Poli/FormInformasiRencanaAsuhan/' + selesai; });
        layar.querySelector('.sjc-tb-jeda').addEventListener('click', () => { ss.set('sjcTtdJeda', '1'); location.reload(); });
        document.body.appendChild(layar);
      }
      layar.querySelector('svg').style.display = sudah ? '' : 'none';
      layar.querySelector('h1').textContent = sudah ? 'Tanda tangan tersimpan' : 'Menunggu pasien';
      layar.querySelector('p').textContent = sudah ? 'Terima kasih. Form pasien berikutnya muncul otomatis.' : 'Form tanda tangan muncul saat dokter membuka CPPT pasien.';
      layar.querySelector('.ulang').hidden = !sudah;
    }
    function status(ok) { const s = document.querySelector('.sjc-tb-st'); if (!s) return; s.classList.toggle('putus', !ok); s.querySelector('span').textContent = ok ? 'Terhubung ke PC dokter' : 'Terputus — mencoba lagi'; }
    function pindah(id) { ss.set('sjcTtdSelesai', ''); location.href = '/Poli/FormInformasiRencanaAsuhan/' + id; }
    function tawarPindah(id) {   // pasien sedang menggambar: jangan buang tanda tangannya
      if (document.querySelector('.sjc-tb-pindah')) return;
      const b = document.createElement('div'); b.className = 'sjc-tb-pindah'; b.setAttribute('role', 'alert');
      b.innerHTML = '<span>Dokter sudah membuka pasien berikutnya. Simpan dulu tanda tangan ini.</span><button type="button">Lewati, buka pasien berikutnya</button>';
      b.querySelector('button').addEventListener('click', () => pindah(id)); document.body.appendChild(b);
    }
    if (!kini) tunggu(!!selesai);
    async function cek() {
      const r = await relay(c, 'get');
      if (!r || !r.ok) return status(false);
      status(true);
      const id = r.id || '';
      if (kini) { if (id && id !== kini) (menggambar ? tawarPindah : pindah)(id); return; }
      if (id && id !== selesai) return pindah(id);
      tunggu(!!selesai && id === selesai);
    }
    cek(); setInterval(cek, 3000);
  }

  function pilJeda() {   // petugas memakai C-CARE biasa di tablet; satu ketukan untuk kembali ke mode tablet
    const b = document.createElement('button'); b.type = 'button'; b.textContent = 'Lanjutkan mode tablet';
    b.style.cssText = 'position:fixed;right:16px;bottom:16px;z-index:2147482500;min-height:44px;padding:0 16px;border:1px solid #263C92;border-radius:8px;background:#fff;color:#263C92;font:600 15px/1 "Source Sans 3",system-ui,sans-serif;cursor:pointer;box-shadow:0 4px 12px rgba(15,39,66,.16)';
    b.addEventListener('click', () => { ss.set('sjcTtdJeda', ''); location.reload(); });
    document.body.appendChild(b);
  }
})();
