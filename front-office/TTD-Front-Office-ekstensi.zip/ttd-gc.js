/* TTD Front Office 1.0 — tombol "TTD GC" di kolom Aksi daftar kunjungan C-CARE.
 * Klik → nomor kunjungan dikirim ke tablet FO (relay); tablet membuka Form General Consent C-CARE untuk ditandatangani.
 * Ekstensi tidak membuat, mengisi, atau menekan Simpan tanda tangan. Yang dikirim hanya nomor kunjungan. */
(() => {
  if (window.top !== window || window.__sjcGc) return; window.__sjcGc = true;
  const POLA_URL = /^https:\/\/script\.google\.com\/macros\/s\/[\w-]+\/exec$/, POLA_T = /^[\w-]{20,64}$/;
  const st = document.createElement('style');
  st.textContent = `.sjc-gc{display:inline-flex;align-items:center;gap:4px;min-height:30px;margin:2px 4px;padding:0 10px;border:1px solid #263C92;border-radius:8px;background:#fff;color:#263C92;font:600 13px "Source Sans 3","Source Sans Pro",system-ui,sans-serif;white-space:nowrap;cursor:pointer;vertical-align:middle}
    .sjc-gc:hover{background:#EEF1F8}.sjc-gc:focus-visible{outline:2px solid #263C92;outline-offset:2px}
    .sjc-gc[data-st="menunggu"]{border-color:#F3D3A6;background:#FFF4E5;color:#B45309}
    .sjc-gc[data-st="sudah"]{border-color:#C5DFB8;background:#E7F2E1;color:#3B7A1E;cursor:default}
    .sjc-gc[data-st="gagal"]{border-color:#EFC2C2;background:#FBEAEA;color:#B91C1C}`;
  document.head.appendChild(st);

  let cfg = null, aktif = null;   // aktif = { id, tombol, awal, timer }
  const relay = q => new Promise(ok => { try { chrome.runtime.sendMessage({ aksi: 'relayTtd', url: `${cfg.url}?t=${cfg.t}&${q}` }, r => ok(chrome.runtime.lastError ? null : r)); } catch (e) { ok(null); } });
  const jam = ms => { const d = new Date(+ms); return String(d.getHours()).padStart(2, '0') + '.' + String(d.getMinutes()).padStart(2, '0'); };
  const SUDAH = 'sjcGcSudah';
  const bacaSudah = () => { try { return JSON.parse(sessionStorage.getItem(SUDAH) || '{}'); } catch (e) { return {}; } };
  const catatSudah = (id, w) => { const s = bacaSudah(); s[id] = w; try { sessionStorage.setItem(SUDAH, JSON.stringify(s)); } catch (e) {} };

  function atur(b, keadaan, teks) { b.dataset.st = keadaan; b.textContent = teks; }

  /* nomor kunjungan baris ini, dari tautan Aksi milik C-CARE (urutan keyakinan) */
  function idBaris(tr) {
    const pola = [/\/FormGeneralConsent\/(\d+)/, /\/(?:Poli|Kia)\/Ubah\/(\d+)/, /\/BatalkanKunjungan\/(\d+)/, /\/ExportKunjungan\/(\d+)/];
    const href = [...tr.querySelectorAll('a[href]')].map(a => a.getAttribute('href'));
    for (const p of pola) for (const h of href) { const m = h.match(p); if (m) return m[1]; }
    return '';
  }

  function berhenti() { if (aktif) { clearTimeout(aktif.timer); aktif = null; } }

  async function minta(id, b) {
    if (!cfg) { atur(b, 'gagal', 'Atur tablet dulu'); chrome.runtime.sendMessage({ aksi: 'bukaPengaturan' }); return; }
    if (aktif && aktif.id === id) {   // klik kedua = batalkan permintaan
      berhenti(); await relay('set=0'); atur(b, '', 'TTD GC'); return;
    }
    if (aktif) { atur(aktif.tombol, '', 'TTD GC'); berhenti(); }
    atur(b, 'menunggu', 'Mengirim…');
    const r0 = await relay('get');
    const awal = r0 && r0.ok ? (r0.signedW || 0) : 0;
    const k = await relay('set=' + id);
    if (!k || !k.ok) { atur(b, 'gagal', 'Gagal kirim · coba lagi'); console.warn('[TTD-GC] relay gagal', k && k.galat); return; }
    atur(b, 'menunggu', 'Menunggu TTD… (klik = batal)');
    aktif = { id, tombol: b, awal, timer: 0, mulai: Date.now() };
    const putar = async () => {
      if (!aktif || aktif.id !== id) return;
      const r = await relay('get');
      if (!aktif || aktif.id !== id) return;
      if (r && r.ok && String(r.signed) === id && (r.signedW || 0) !== aktif.awal) {
        catatSudah(id, r.signedW); atur(b, 'sudah', '✓ GC ' + jam(r.signedW)); berhenti(); return;
      }
      if (Date.now() - aktif.mulai > 15 * 60e3) { atur(b, '', 'TTD GC'); berhenti(); return; }   // 15 menit tanpa TTD: berhenti memantau
      aktif.timer = setTimeout(putar, 1500);
    };
    aktif.timer = setTimeout(putar, 1500);
  }

  function pasang() {
    const sudah = bacaSudah();
    document.querySelectorAll('table tbody tr').forEach(tr => {
      if (tr.querySelector('.sjc-gc')) return;
      const id = idBaris(tr); if (!id) return;
      const sel = tr.cells[tr.cells.length - 1]; if (!sel) return;
      const b = document.createElement('button');
      b.type = 'button'; b.className = 'sjc-gc'; b.title = 'Kirim form General Consent kunjungan ini ke tablet Front Office';
      if (sudah[id]) atur(b, 'sudah', '✓ GC ' + jam(sudah[id])); else atur(b, '', 'TTD GC');
      if (aktif && aktif.id === id) { aktif.tombol = b; atur(b, 'menunggu', 'Menunggu TTD… (klik = batal)'); }
      b.addEventListener('click', e => { e.preventDefault(); e.stopPropagation(); if (b.dataset.st !== 'sudah') minta(id, b); });
      sel.appendChild(b);
    });
  }

  chrome.storage.local.get('ttdTablet', s => {
    const c = s.ttdTablet || {};
    if (c.peran === 'pc' && POLA_URL.test(c.url || '') && POLA_T.test(c.t || '')) cfg = c;
    pasang();
    new MutationObserver(() => pasang()).observe(document.body, { childList: true, subtree: true });   // DataTables: ganti halaman/cari
  });
})();
