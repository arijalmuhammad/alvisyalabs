// ===== Service worker: klasifikasi golongan obat ONLINE untuk Riwayat Alergi =====
// Sumber: RxNav / RxClass (US National Library of Medicine), kode ATC WHO.
// Yang dikirim HANYA kata nama obat (mis. "amoksisilin"), tanpa identitas pasien.
// Hasil disimpan di cache agar tidak bertanya ulang.

const RX = "https://rxnav.nlm.nih.gov/REST";

// Kode ATC -> kategori alergi obat di PCare
function atcKeKategori(ids) {
  const has = (p) => ids.some((id) => id.startsWith(p));
  if (ids.includes("B01AC06") || ids.includes("N02BA01") || has("N02BA")) return "Aspirin";
  if (has("J01")) return "Antibiotik";
  if (has("M01A") || has("N02BB")) return "Antiinflamasi Non Steroid";   // N02BB: metamizol dkk.
  if (has("H02") || has("D07") || has("R03BA") || has("S01BA") || has("R01AD")) return "Kortikosteroid";
  if (has("A10A")) return "Insulin";
  return ids.length ? "Obat-Obatan Lain" : null;
}

async function getJSON(url) {
  const r = await fetch(url, { headers: { Accept: "application/json" } });
  if (!r.ok) throw new Error("HTTP " + r.status);
  return r.json();
}

async function atcByName(name) {
  const j = await getJSON(`${RX}/rxclass/class/byDrugName.json?relaSource=ATC&drugName=${encodeURIComponent(name)}`);
  return (j.rxclassDrugInfoList?.rxclassDrugInfo || []).map((x) => x.rxclassMinConceptItem?.classId).filter(Boolean);
}

async function klasifikasi(term) {
  const cache = (await chrome.storage.local.get("atcCache")).atcCache || {};
  const key = term.toLowerCase();
  if (cache[key]) return cache[key];

  let hasil = { term, kategori: null, nama: null, atc: [] };
  // 1) coba langsung sebagai nama generik
  let ids = await atcByName(term).catch(() => []);
  let nama = term;
  // 2) bila tidak ketemu: pencocokan perkiraan (ejaan Indonesia / nama dagang) -> bahan aktif -> ATC
  if (!ids.length) {
    const ap = await getJSON(`${RX}/approximateTerm.json?maxEntries=1&term=${encodeURIComponent(term)}`).catch(() => null);
    const cand = ap?.approximateGroup?.candidate?.[0];
    if (cand && parseFloat(cand.score || "0") >= 5) {
      const rel = await getJSON(`${RX}/rxcui/${cand.rxcui}/related.json?tty=IN+PIN+MIN`).catch(() => null);
      const ingr = (rel?.relatedGroup?.conceptGroup || []).flatMap((g) => g.conceptProperties || []).map((c) => c.name);
      for (const n of ingr.slice(0, 3)) {
        const a = await atcByName(n).catch(() => []);
        if (a.length) { ids = ids.concat(a); nama = n; }
      }
    }
  }
  hasil = { term, kategori: atcKeKategori(ids), nama: ids.length ? nama : null, atc: [...new Set(ids)].slice(0, 4) };
  cache[key] = hasil;
  await chrome.storage.local.set({ atcCache: cache });
  return hasil;
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type !== "klasifikasiObat") return;
  klasifikasi(String(msg.term || "").slice(0, 60))
    .then(sendResponse)
    .catch((e) => sendResponse({ term: msg.term, kategori: null, error: String(e) }));
  return true; // jawaban asinkron
});

// =====================================================================
// Ambil data kunjungan dari C-CARE secara otomatis lewat TAB LATAR BELAKANG.
// PCare mengirim {nama, kelamin, usia, tgl}. Empat tab C-CARE (Poli Umum, Ruang Tindakan,
// Prolanis, KIA) dibuka BERSAMAAN; masing-masing mencari pasien pada tanggal tsb.
// Bila ditemukan di tepat satu poli, kunjungannya dibuka & diekstrak, lalu semua tab ditutup.
// =====================================================================
const CC_POLI = [   // dicari BERSAMAAN; Poli Gigi (/2) & Kunjungan Sehat (/4) tidak dicari; Poli Gizi (/7) dicari sejak v1.9.1
  ["UMUM", "Poli Umum", "https://c-care.ipb.ac.id/Poli/Index/1"],
  ["TINDAKAN", "Ruang Tindakan", "https://c-care.ipb.ac.id/Poli/Index/5"],
  ["PROLANIS", "Poli Prolanis", "https://c-care.ipb.ac.id/Poli/Index/8"],
  ["KIA", "Poli KIA", "https://c-care.ipb.ac.id/Kia"],
  ["GIZI", "Poli Gizi", "https://c-care.ipb.ac.id/Poli/Index/7"],   // v1.9.1
  ["GIGI", "Poli Gigi", "https://c-care.ipb.ac.id/Poli/Index/2", true],        // v1.9.6: info saja, tidak dikirim otomatis
  ["SEHAT", "Kunjungan Sehat", "https://c-care.ipb.ac.id/Poli/Index/4", true], // v1.9.6: info saja (tidak ke PCare)
];
const POLI_INFO = new Set(CC_POLI.filter((p) => p[3]).map((p) => p[0]));
const BR_nama = (s) => String(s || "").toLowerCase().replace(/[^a-z]/g, "");
const namaPoli = (k) => (CC_POLI.find((p) => p[0] === k) || [, k])[1];

// tunggu beberapa kunci storage terisi (atau waktu habis); kembalikan {kunci: nilai}
// v1.9.8: tab latar bot dimasukkan ke satu grup tab bernama "Bot C-CARE", warna abu-abu, diciutkan
async function kelompokkan(ids) {
  try {
    if (!chrome.tabs.group) return;
    const { botGrup } = await chrome.storage.local.get("botGrup");
    let gid = null;
    if (botGrup) { try { await chrome.tabGroups.get(botGrup); gid = botGrup; } catch (e) {} }
    const tab0 = await chrome.tabs.get(ids[0]);
    if (gid != null) { const g = await chrome.tabGroups.get(gid); if (g.windowId !== tab0.windowId) gid = null; }
    gid = await chrome.tabs.group(gid != null ? { tabIds: ids, groupId: gid } : { tabIds: ids });
    await chrome.tabGroups.update(gid, { title: "Bot C-CARE", color: "grey", collapsed: true });
    await chrome.storage.local.set({ botGrup: gid });
  } catch (e) {}
}

function tungguKunci(keys, ms) {
  return new Promise(async (resolve) => {
    const dapat = {};
    const cek = () => keys.every((k) => k in dapat);
    function on(ch) {
      if (ch.run && ch.run.newValue && ch.run.newValue.dihentikan) { dapat.__batal = true; return selesai(); }   // v1.9.5: Berhenti
      for (const k of keys) if (ch[k] && ch[k].newValue !== undefined) dapat[k] = ch[k].newValue; if (cek()) selesai(); }
    function selesai() { clearTimeout(t); chrome.storage.onChanged.removeListener(on); resolve(dapat); }
    const t = setTimeout(selesai, ms);
    chrome.storage.onChanged.addListener(on);
    const awal = await chrome.storage.local.get(keys);   // bisa saja sudah terisi lebih dulu
    Object.assign(dapat, awal);
    if (cek()) selesai();
  });
}

// Putuskan kunjungan mana yang dibuka setelah SEMUA poli selesai dicari
function putuskan(req, semuaHasil) {
  if (semuaHasil.some((t) => t.login)) return { gagal: "C-CARE belum login. Login dulu di https://c-care.ipb.ac.id/ lalu ⏭ Lanjut." };
  // v1.9.7: pendaftaran PCare "Konseling" (kunjungan sehat) dicatat klinik di C-CARE sebagai Poli Gizi dan/atau Kunjungan Sehat
  const konseling = /konseling|sehat/i.test(req.poliPcare || "");
  const boleh = (k) => !POLI_INFO.has(k) || (konseling && k === "SEHAT");
  const hasil = semuaHasil.filter((t) => boleh(t.poli));
  const info = semuaHasil.filter((t) => !boleh(t.poli));
  const persis = hasil.flatMap((t) => (t.persis || []).map((x) => ({ ...x, poli: t.poli })));
  const mirip = hasil.flatMap((t) => (t.mirip || []).map((x) => ({ ...x, poli: t.poli })));
  const galat = hasil.filter((t) => t.galat).map((t) => t.galat);
  const ket = galat.length ? ` (Catatan: ${galat.join("; ")}.)` : "";
  if (persis.length === 1) return { pilih: persis[0], namaBeda: "" };
  // v1.9.7: Konseling — pasien yang sama ada di Poli Gizi DAN Kunjungan Sehat: pakai kunjungan Poli Gizi
  if (konseling && persis.length === 2 && persis.some((x) => x.poli === "GIZI") && persis.some((x) => x.poli === "SEHAT"))
    return { pilih: persis.find((x) => x.poli === "GIZI"), namaBeda: "" };
  if (persis.length > 1) return { gagal: `${req.nama} ditemukan ${persis.length}× pada ${req.tgl}: ${persis.map((x) => namaPoli(x.poli)).join(", ")}. Bila pasien memang punya beberapa kunjungan hari ini (tiap kunjungan = 1 pendaftaran PCare), buka kunjungan yang sesuai antrean ${req.antrean || "ini"} (cocokkan dokter/urutan) di C-CARE → Kirim → ⏭ Lanjut. Kunjungan yang sudah terpakai tidak akan dipilih lagi untuk antrean berikutnya.` };
  if (mirip.length === 1) return { pilih: mirip[0], namaBeda: mirip[0].nama };
  if (konseling && mirip.length === 2 && mirip.some((x) => x.poli === "GIZI") && mirip.some((x) => x.poli === "SEHAT") &&
      BR_nama(mirip[0].nama) === BR_nama(mirip[1].nama)) return { pilih: mirip.find((x) => x.poli === "GIZI"), namaBeda: mirip.find((x) => x.poli === "GIZI").nama };
  if (mirip.length > 1) return { gagal: `${req.nama} tidak ditemukan persis pada ${req.tgl}. Nama yang mirip: ${mirip.slice(0, 5).map((x) => `${x.nama} (${namaPoli(x.poli)})`).join("; ")}. Buka kunjungan yang benar di C-CARE → Kirim → ⏭ Lanjut.` };
  const diInfo = info.filter((t) => (t.persis || []).length || (t.mirip || []).length).map((t) => namaPoli(t.poli));
  if (diInfo.length) return { gagal: `${req.nama} ada di C-CARE pada ${req.tgl}, tetapi tercatat di ${diInfo.join(" / ")}, sedangkan di PCare didaftarkan ke ${req.poliPcare || "poli lain"}. Periksa pendaftarannya, atau kerjakan manual.` };
  if (galat.length) return { gagal: `Pencarian C-CARE untuk ${req.nama} BELUM LENGKAP, jadi belum bisa disebut "tidak ada": ${galat.join("; ")}. Klik ⏭ Lanjut untuk mencoba lagi.` };
  const dp = hasil.reduce((a, t) => a + (t.dipakai || 0), 0);
  if (dp) return { gagal: `Kunjungan C-CARE ${req.nama} pada ${req.tgl} sudah terpakai untuk antrean PCare lain hari ini (${dp} kunjungan). Periksa apakah antrean ${req.antrean || "ini"} ganda, atau kunjungan keduanya belum dibuat di C-CARE.` };
  return { gagal: `${req.nama} tidak ditemukan pada ${req.tgl} di semua poli C-CARE (${CC_POLI.map((p) => p[1]).join(", ")}), juga tidak ada nama yang mirip. Cek apakah pasien sudah didaftarkan di C-CARE pada tanggal itu, atau namanya sangat berbeda dari PCare.${ket}` };
}

// v3.3.2 LEBIH RINGAN: cari dulu HANYA di poli yang sesuai pendaftaran PCare (biasanya 1 jendela, bukan 7).
// Poli lain baru dicari bila di poli itu tidak ada kunjungan dengan nama PERSIS (aturan keputusan tetap sama).
function poliPrioritas(poliPcare) {
  const p = String(poliPcare || "").toLowerCase();
  if (/konseling|sehat/.test(p)) return ["GIZI", "SEHAT"];
  if (/umum/.test(p)) return ["UMUM"];
  if (/tindakan/.test(p)) return ["TINDAKAN"];
  if (/prolanis/.test(p)) return ["PROLANIS"];
  if (/kia|kb|ibu|anak|hamil/.test(p)) return ["KIA"];
  if (/gizi/.test(p)) return ["GIZI"];
  if (/gigi/.test(p)) return ["GIGI"];
  return [];
}
async function ambilCcare(req) {
  const id = "r" + Date.now();
  const tabs = {};          // kode poli -> tabId
  const bersihkan = async (kecuali) => {
    for (const t of Object.values(tabs)) if (t !== kecuali) { try { await chrome.tabs.remove(t); } catch (e) {} }
  };
  let batal = false;
  const cariDi = async (kode) => {
    for (const k of kode) tabs[k] = (await chrome.tabs.create({ url: "about:blank", active: false })).id;
    await kelompokkan(Object.values(tabs));
    const isi = {};
    for (const k of kode) isi["ccareReq_" + tabs[k]] = { ...req, id, tabId: tabs[k], stage: "cari", poli: k, mulai: Date.now() };
    await chrome.storage.local.set(isi);
    for (const k of kode) chrome.tabs.update(tabs[k], { url: CC_POLI.find((p) => p[0] === k)[2] });
    const keys = kode.map((k) => `ccareCari_${id}_${k}`);
    const dapat = await tungguKunci(keys, 60000);
    if (dapat.__batal) batal = true;
    await chrome.storage.local.remove(keys);
    return kode.map((k) => dapat[`ccareCari_${id}_${k}`] || { poli: k, galat: `${namaPoli(k)} tidak selesai dicari (waktu habis)` });
  };
  try {
    // v1.9.0: kunjungan C-CARE yang hari ini sudah dipakai untuk antrean PCare lain tidak dipilih lagi
    const dipakai = (await chrome.storage.local.get("ccareDipakai")).ccareDipakai || {};
    const d0 = new Date(), hariIni = `${d0.getFullYear()}-${String(d0.getMonth() + 1).padStart(2, "0")}-${String(d0.getDate()).padStart(2, "0")}`;
    const pakai = (h) => { try { const k = dipakai[new URL(h).pathname.toLowerCase()]; return !!k && k.tgl === hariIni; } catch (e) { return false; } };
    const bersihHasil = (hasil) => hasil.map((t) => ({ ...t, persis: (t.persis || []).filter((x) => !pakai(x.href)), mirip: (t.mirip || []).filter((x) => !pakai(x.href)),
      dipakai: [...(t.persis || []), ...(t.mirip || [])].filter((x) => pakai(x.href)).length }));
    // 1) poli sesuai pendaftaran PCare dulu
    const utama = poliPrioritas(req.poliPcare).filter((k) => CC_POLI.some((p) => p[0] === k));
    let hasil = [], keputusan = null, cepat = false;
    if (utama.length) {
      hasil = await cariDi(utama);
      if (batal) { await bersihkan(); return { ok: false, batal: true, pesan: "dihentikan" }; }
      const k1 = putuskan(req, bersihHasil(hasil));
      if (k1.pilih && !k1.namaBeda) { keputusan = k1; cepat = true; }
    }
    // 2) belum pasti → cari di poli lainnya (bersamaan), lalu putuskan dari SEMUA hasil
    if (!keputusan) {
      const sisa = CC_POLI.map(([k]) => k).filter((k) => !utama.includes(k));
      hasil = hasil.concat(await cariDi(sisa));
      if (batal) { await bersihkan(); return { ok: false, batal: true, pesan: "dihentikan" }; }
      keputusan = putuskan(req, bersihHasil(hasil));
    }
    const namaTerlihat = [...new Set(hasil.flatMap((t) => [...(t.persis || []), ...(t.mirip || [])].map((x) => x.nama)).filter(Boolean))];
    logKeFile([`${jamBG()} [BG v${VERSI_BG}] INFO cari C-CARE ${req.antrean || ""}${cepat ? " (cepat)" : ""}: ` + hasil.map((t) => `${t.poli}=${(t.persis || []).length}/${(t.mirip || []).length}${t.galat ? "(galat)" : ""}`).join(" ") + (keputusan.gagal ? " → gagal" : ` → ${keputusan.pilih.poli}`)]);
    if (keputusan.gagal) { await bersihkan(); return { ok: false, pesan: keputusan.gagal, namaTerlihat }; }
    const { pilih, namaBeda } = keputusan;
    if (!pilih.href) { await bersihkan(); return { ok: false, pesan: `${req.nama} ditemukan di ${namaPoli(pilih.poli)}, tetapi tautan kunjungannya tidak ditemukan pada baris tabel.` }; }
    // 3) buka kunjungan terpilih di tab poli itu; tab lain ditutup
    const vt = tabs[pilih.poli];
    await bersihkan(vt);
    await chrome.storage.local.set({ ["ccareReq_" + vt]: { ...req, id, tabId: vt, stage: "visit", namaBeda, poliTemu: pilih.poli, mulai: Date.now() } });
    chrome.tabs.update(vt, { url: pilih.href });
    const r = await tungguKunci(["ccareRes_" + id], 30000);
    if (r.__batal) { await bersihkan(); return { ok: false, batal: true, pesan: "dihentikan" }; }
    await chrome.storage.local.remove(["ccareRes_" + id]);
    try { await chrome.tabs.remove(vt); } catch (e) {}
    return r["ccareRes_" + id] || { ok: false, pesan: "Waktu habis saat membaca halaman kunjungan C-CARE." };
  } finally {
    await chrome.storage.local.remove(Object.values(tabs).map((t) => "ccareReq_" + t));
    await bersihkan();
  }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === "siapaSaya") { sendResponse({ tabId: sender.tab ? sender.tab.id : null }); return; }
  if (msg?.type === "ambilCcare") { ambilCcare(msg.req).then(sendResponse).catch((e) => sendResponse({ ok: false, pesan: String(e) })); return true; }
});


// Panggil Anda (mis. kotak Cloudflare perlu dicentang manual) lewat notifikasi Windows
chrome.runtime.onMessage.addListener((msg) => {
  if (msg?.type !== "panggil") return;
  try { chrome.notifications.create("br-panggil-" + Date.now(), { type: "basic", iconUrl: "icon128.png", title: msg.judul, message: msg.pesan, priority: 2, requireInteraction: false }); } catch (e) {}
});


// =====================================================================
// v2.0.0 — jembatan ke aplikasi Windows BridgingPCare.exe (native messaging)
// password (DPAPI), file log, pembaruan
// =====================================================================
const HOST = "id.alvisya.bridging_pcare";
function keHost(pesan) {
  return new Promise((res) => {
    try {
      chrome.runtime.sendNativeMessage(HOST, pesan, (r) => {
        if (chrome.runtime.lastError) res({ ok: false, tanpaHost: true, pesan: "aplikasi BridgingPCare.exe belum terpasang / tidak bisa dihubungi (" + chrome.runtime.lastError.message + ")" });
        else res(r || { ok: false, pesan: "tidak ada jawaban dari aplikasi" });
      });
    } catch (e) { res({ ok: false, tanpaHost: true, pesan: String(e) }); }
  });
}
const jamBG = () => { const d = new Date(), p = (x) => String(x).padStart(2, "0"); return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`; };
let antreLog = [], timerLog = null;
function logKeFile(baris) {
  antreLog.push(...baris.map((x) => String(x).replace(/(?<!\d)(\d{9,16})(?!\d)/g, (m) => "*".repeat(m.length - 4) + m.slice(-4))));
  if (timerLog) return;
  timerLog = setTimeout(async () => {
    timerLog = null;
    const kirimkan = antreLog.splice(0, 500);
    if (!kirimkan.length) return;
    const r = await keHost({ cmd: "log", baris: kirimkan });
    if (!r.ok) {   // aplikasi belum terpasang: simpan sementara (maks. 1000 baris) agar tetap bisa disalin dari Pengaturan
      const s = (await chrome.storage.local.get("logCadangan")).logCadangan || [];
      await chrome.storage.local.set({ logCadangan: s.concat(kirimkan).slice(-1000) });
    }
  }, 1500);
}
const VERSI_BG = chrome.runtime.getManifest().version;
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type === "host") { keHost(msg.pesan || {}).then(sendResponse); return true; }
  if (msg?.type === "logFile") { logKeFile(msg.baris || []); return; }
  if (msg?.type === "bukaPengaturan") { chrome.runtime.openOptionsPage(); return; }
  if (msg?.type === "muatUlangEkstensi") { logKeFile([`${jamBG()} [BG v${VERSI_BG}] INFO ekstensi dimuat ulang (pembaruan)`]); setTimeout(() => chrome.runtime.reload(), 1600); sendResponse({ ok: true }); return; }
});
self.addEventListener("error", (e) => logKeFile([`${jamBG()} [BG v${VERSI_BG}] ERROR ${e.message} @${e.lineno}`]));
self.addEventListener("unhandledrejection", (e) => logKeFile([`${jamBG()} [BG v${VERSI_BG}] ERROR promise: ${e.reason && (e.reason.stack || e.reason.message) || e.reason}`]));
chrome.runtime.onInstalled.addListener((d) => logKeFile([`${jamBG()} [BG v${VERSI_BG}] INFO ekstensi ${d.reason === "update" ? "diperbarui dari " + d.previousVersion : d.reason}`]));
// sesudah pembaruan: tab PCare & C-CARE yang terbuka dimuat ulang agar memakai file bot yang baru
chrome.runtime.onInstalled.addListener(async (d) => {
  if (d.reason !== "update") return;
  try {
    const tabs = await chrome.tabs.query({ url: ["https://pcarejkn.bpjs-kesehatan.go.id/*", "https://c-care.ipb.ac.id/*"] });
    for (const t of tabs) chrome.tabs.reload(t.id);
  } catch (e) {}
});
