// Preload halaman PCare / C-CARE (dunia terpisah dari halaman, seperti content script ekstensi).
"use strict";
const { ipcRenderer, webFrame } = require("electron");
const fs = require("fs");
const path = require("path");
const vm = require("vm");
const arg = (n) => { const a = process.argv.find((x) => x.startsWith(`--${n}=`)); return a ? a.slice(n.length + 3) : ""; };
const dirEks = arg("br-eks");

const SITUS = [
  { cocok: /^https:\/\/pcarejkn\.bpjs-kesehatan\.go\.id\/eclaim\//i, utama: ["pcare-main.js"], js: ["common.js", "pcare.js"] },
  { cocok: /^https:\/\/c-care\.ipb\.ac\.id\//i, utama: [], js: ["common.js", "ccare.js"] },
];
const s = SITUS.find((x) => x.cocok.test(location.href));
if (s && dirEks) {
  globalThis.chrome = require("./shim.js")(ipcRenderer, { dirEks, peran: "konten" });
  // skrip dunia HALAMAN (document_start)
  for (const f of s.utama) webFrame.executeJavaScript(fs.readFileSync(path.join(dirEks, f), "utf8")).catch(() => {});
  // skrip bot (document_idle): semua file berbagi satu lingkup, seperti content script
  const jalan = () => {
    const kode = s.js.map((f) => `// ==== ${f} ====\n` + fs.readFileSync(path.join(dirEks, f), "utf8")).join("\n;\n");
    const uji = process.env.BR_UJI && !process.argv.some((a) => a === "--br-terkemas") ? ";globalThis.__dalam=(k)=>eval(k);" : "";   // hanya uji pengembangan
    try { vm.runInThisContext(`(function(){\n${kode}\n;try{globalThis.BR=BR}catch(e){}${uji}\n})`, { filename: "bot-" + s.js.join("+") })(); }
    catch (e) { ipcRenderer.invoke("host", { cmd: "log", baris: [`[APP] ERROR bot gagal dimuat di ${location.pathname}: ${e && e.stack || e}`] }); }
  };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", () => setTimeout(jalan, 0));
  else setTimeout(jalan, 0);
}
// hanya untuk uji pengembangan (tidak aktif di aplikasi terpasang)
if (s && process.env.BR_UJI && !process.argv.some((a) => a === "--br-terkemas")) {
  require("electron").contextBridge.exposeInMainWorld("__uji", {
    jalankan: (kode) => vm.runInThisContext(`(async()=>{${kode}})()`).then((r) => JSON.parse(JSON.stringify(r === undefined ? null : r))),
  });
}
