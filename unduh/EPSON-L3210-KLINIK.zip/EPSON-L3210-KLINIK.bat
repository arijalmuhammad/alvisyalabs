<# : EPSON-L3210-KLINIK.bat - file gabungan Batch + PowerShell. JANGAN ubah baris ini.
@echo off
title Epson L3210 - Klinik
fltmc >nul 2>&1 && goto :admin
if "%~1"=="" powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
if not "%~1"=="" powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -ArgumentList '%*' -Verb RunAs"
exit /b
:admin
cd /d "%~dp0"
set "L3210_SELF=%~f0"
set "L3210_DIR=%~dp0"
set "L3210_ARGS=%*"
powershell -NoProfile -ExecutionPolicy Bypass -Command "iex ([IO.File]::ReadAllText($env:L3210_SELF))"
set "RC=%errorlevel%"
if "%~1"=="" pause
exit /b %RC%
#>

# =====================================================================
#  EPSON L3210 - KLINIK  (driver resmi Epson + printer bersama di jaringan)
#
#  Klik dua kali file ini -> pilih menu:
#    1  PC PRINTER  : PC yang dicolok kabel USB printer (taruh driver resmi
#                     Epson .exe di folder yang sama dengan file ini)
#    2  PC LAIN     : PC lain di klinik, mencetak lewat jaringan
#    3  PERBAIKI    : bersihkan antrean cetak macet
#    4  CEK         : cek komponen Windows (penting untuk Windows Lite)
#    5  DRIVER SAJA : pasang driver + printer USB di PC ini, tanpa dibagikan
#    6  PINDAH      : PC lain pindah ke PC printer yang baru
#    7  TES CETAK   : status printer + halaman uji
#    8  LEPAS       : hapus sambungan / hentikan berbagi di PC ini
#    9  GANTI NAMA  : ganti nama printer
#    0  DIAGNOSA    : cek lengkap + laporan ke Desktop
#    S  SCAN ULANG  : hapus daftar tersimpan, cari PC printer yang menyala
#
#  Silent (tanpa pertanyaan, dari CMD Administrator):
#    EPSON-L3210-KLINIK.bat printer
#    EPSON-L3210-KLINIK.bat printer NAMA-LOKASI
#    EPSON-L3210-KLINIK.bat lain PC-A,PC-B        (beberapa PC printer: pisahkan koma)
#    EPSON-L3210-KLINIK.bat perbaiki
#    EPSON-L3210-KLINIK.bat driver
#    EPSON-L3210-KLINIK.bat pindah NAMA-PC-PRINTER-BARU
#    EPSON-L3210-KLINIK.bat lepas
#    EPSON-L3210-KLINIK.bat rename Printer Apotek
# =====================================================================

$ErrorActionPreference = 'Stop'
$Dir       = $env:L3210_DIR
$ShareName = 'L3210'
# Akun khusus cetak di PC printer (bukan admin, disembunyikan dari layar login).
# PC lain memakainya otomatis agar tidak perlu login manual. Ganti sandi di sini jika perlu.
$PrintUser = 'cetakl3210'
$PrintPass = 'Klinik#L3210'
$DrvShare  = 'L3210DRV$'
$AddrFile  = Join-Path $Dir 'ALAMAT-PRINTER.txt'
$LogFile   = Join-Path $env:TEMP 'epson-l3210-klinik.log'
$argv      = @("$env:L3210_ARGS" -split '\s+' | Where-Object { $_ })
$Silent    = $argv.Count -gt 0
$Mode      = if ($argv.Count -gt 0) { $argv[0].ToLower() } else { '' }
$Server    = if ($argv.Count -gt 1) { $argv[1..($argv.Count - 1)] -join ' ' } else { '' }
Start-Transcript -Path $LogFile -Append | Out-Null

function Say($m, $c = 'Gray') { Write-Host $m -ForegroundColor $c }
function Ok($m)   { Say "[OK] $m" Green }
function Warn($m) { Say "[!]  $m" Yellow }
function Fail($m) {
    Say "[X]  $m" Red
    Say "Log lengkap: $LogFile"
    Stop-Transcript | Out-Null
    exit 1
}
function Ask($q, $default = '') {
    if ($Silent) { return $default }
    $a = Read-Host $q
    if ([string]::IsNullOrWhiteSpace($a)) { return $default }
    return $a.Trim()
}
function Yes($q, $default) { return ((Ask $q $default) -match '^[yY]') }

# ---------------------------------------------------------------- KOMPONEN WINDOWS
function Get-Components {
    foreach ($s in 'Spooler', 'LanmanServer', 'LanmanWorkstation', 'MpsSvc') {
        $svc = Get-Service $s -ErrorAction SilentlyContinue
        [pscustomobject]@{ Komponen = $s; Status = $(if ($svc) { "$($svc.Status) / $($svc.StartType)" } else { 'TIDAK ADA' }) }
    }
    foreach ($m in 'PrintManagement', 'NetConnection') {
        [pscustomobject]@{ Komponen = $m; Status = $(if (Get-Module -ListAvailable $m) { 'ada' } else { 'TIDAK ADA' }) }
    }
}

function Assert-Components([string[]]$need) {
    $all  = @(Get-Components)
    $miss = @($all | Where-Object { $need -contains $_.Komponen -and $_.Status -eq 'TIDAK ADA' })
    if ($miss.Count -gt 0) {
        $all | Format-Table -AutoSize | Out-String | Write-Host
        $names = ($miss | ForEach-Object Komponen) -join ', '
        if ($names -match 'Spooler') {
            Fail "Windows di PC ini tidak punya fitur cetak ($names). Windows Lite ini harus diganti, PC ini tidak bisa mencetak."
        }
        if ($names -match 'LanmanServer') {
            Fail "Windows di PC ini tidak bisa membagikan printer ($names). Colokkan printer ke PC lain yang komponennya lengkap."
        }
        Fail "Komponen Windows hilang: $names. Kirim tampilan ini ke pembuat paket."
    }
}

# Windows Lite sering mematikan layanan: aktifkan lagi.
function Enable-Svc($name) {
    $svc = Get-Service $name -ErrorAction SilentlyContinue
    if (-not $svc) { return }
    if ($svc.StartType -ne 'Automatic') { Set-Service $name -StartupType Automatic }
    if ((Get-Service $name).Status -ne 'Running') { Start-Service $name }
}

# ---------------------------------------------------------------- BANTUAN
function Get-L3210Driver {
    Get-PrinterDriver -ErrorAction SilentlyContinue | Where-Object Name -like '*L3210*' | Select-Object -First 1
}
function Get-LocalL3210 {
    Get-Printer -ErrorAction SilentlyContinue |
        Where-Object { $_.DriverName -like '*L3210*' -and $_.Type -eq 'Local' -and $_.PortName -notlike '\\*' } |
        Sort-Object @{ Expression = { $_.PortName -eq (Get-L3210UsbPort) }; Descending = $true } | Select-Object -First 1
}
# Perangkat USB Epson (Vendor ID 04B8) yang terlihat oleh Windows.
function Get-EpsonUsb {
    Get-CimInstance Win32_PnPEntity -ErrorAction SilentlyContinue |
        Where-Object { $_.DeviceID -like 'USB\VID_04B8*' -or $_.DeviceID -like 'USBPRINT\EPSON*' -or $_.Name -like '*L3210*' }
}

# Port USB (USB001, USB002, ...) yang dipakai printer L3210, dibaca dari registry Windows.
function Get-L3210UsbPort {
    $base = 'HKLM:\SYSTEM\CurrentControlSet\Control\DeviceClasses\{28d78fad-5a12-11d1-ae5b-0000f803a8c2}'
    Get-ChildItem $base -ErrorAction SilentlyContinue | Where-Object { $_.PSChildName -match 'L3210' } | ForEach-Object {
        Get-ChildItem $_.PSPath -Recurse -ErrorAction SilentlyContinue | Where-Object PSChildName -eq 'Device Parameters' | ForEach-Object {
            $p = Get-ItemProperty $_.PSPath -ErrorAction SilentlyContinue
            if ($p.'Port Number') { '{0}{1:D3}' -f $p.'Base Name', [int]$p.'Port Number' }
        }
    } | Select-Object -First 1
}

function Show-UsbStatus {
    $dev = @(Get-EpsonUsb)
    if ($dev.Count -eq 0) { Warn 'USB: printer Epson TIDAK terlihat oleh Windows.'; return $false }
    foreach ($d in $dev) {
        $state = if ($d.ConfigManagerErrorCode -eq 0) { 'normal' } elseif ($d.ConfigManagerErrorCode -eq 28) { 'BELUM ADA DRIVER' } else { "error kode $($d.ConfigManagerErrorCode)" }
        Say "USB: $($d.Name)  -> $state"
    }
    $port = Get-L3210UsbPort
    if ($port) { Say "USB: port printer $port" }
    return $true
}

# Driver resmi Epson lewat Windows Update (otomatis, butuh internet, printer harus tercolok & menyala).
function Install-DriverFromWU {
    $svc = Get-Service wuauserv -ErrorAction SilentlyContinue
    if (-not $svc) { Warn 'Windows Update tidak ada di Windows ini (dibuang Windows Lite).'; return $false }
    $oldType = $svc.StartType
    try {
        if ($oldType -eq 'Disabled') { Set-Service wuauserv -StartupType Manual }
        Start-Service wuauserv -ErrorAction SilentlyContinue
        Say 'Mencari driver Epson L3210 lewat Windows Update (butuh internet, 1-5 menit)...' Cyan
        $session  = New-Object -ComObject Microsoft.Update.Session
        $searcher = $session.CreateUpdateSearcher()
        $searcher.ServerSelection = 2
        $searcher.Online = $true
        $res  = $searcher.Search("IsInstalled=0 and Type='Driver'")
        $coll = New-Object -ComObject Microsoft.Update.UpdateColl
        foreach ($u in $res.Updates) {
            if ("$($u.DriverModel) $($u.DriverHardwareID) $($u.Title)" -match 'L3210') { [void]$coll.Add($u) }
        }
        if ($coll.Count -eq 0) { Warn 'Windows Update tidak menemukan driver L3210.'; return $false }
        foreach ($u in $coll) { if (-not $u.EulaAccepted) { $u.AcceptEula() } }
        $dl = $session.CreateUpdateDownloader(); $dl.Updates = $coll; [void]$dl.Download()
        $in = $session.CreateUpdateInstaller();  $in.Updates = $coll; [void]$in.Install()
        Ok 'Driver dari Windows Update dipasang.'
    } catch {
        Warn "Windows Update gagal: $($_.Exception.Message)"
        return $false
    } finally {
        if ($oldType -eq 'Disabled') {
            Stop-Service wuauserv -Force -ErrorAction SilentlyContinue
            Set-Service wuauserv -StartupType Disabled
        }
    }
    return [bool](Get-L3210Driver)
}

function Get-ErrCode($err) {
    try {
        $c = $err.Exception.ErrorData.CimInstanceProperties['error_Code'].Value
        if ($c) { return ('0x{0:X8}' -f [int64]$c) }
    } catch { }
    return ('0x{0:X8}' -f $err.Exception.HResult)
}
function Get-ErrHint($code) {
    switch -Regex ($code) {
        '00000005$'                 { 'Akses ditolak: jalankan lagi menu 1 (versi terbaru) di PC printer agar akun cetak dibuat.' }
        '0000052E$|0000056A$'       { 'Login ke PC printer ditolak: jalankan lagi menu 1 (versi terbaru) di PC printer.' }
        '00000BCB$|00000BC4$'       { 'Windows memblokir pemasangan driver dari jaringan.' }
        '0000011B$'                 { 'PC ini dan PC printer beda tingkat update keamanan Windows; skrip mencoba jalur cadangan.' }
        '00000002$|00000709$|00000043$' { 'Printer bersama tidak ditemukan: jalankan menu 1 di PC printer dan pastikan printer menyala.' }
        default                     { '' }
    }
}

function Test-LocalUser($name) {
    & cmd.exe /c "net user $name >nul 2>&1"
    return ($LASTEXITCODE -eq 0)
}

# Akun cetak di PC printer: dibuat/diperbarui, sandi tidak kedaluwarsa, disembunyikan dari layar login.
function Set-PrintAccount {
    $path = "WinNT://$env:COMPUTERNAME/$PrintUser,user"
    if ((Test-LocalUser $PrintUser)) {
        & net.exe user $PrintUser $PrintPass /active:yes | Out-Null
    } else {
        & net.exe user $PrintUser $PrintPass /add /expires:never /passwordchg:no /comment:"Akun cetak printer klinik" | Out-Null
    }
    if (-not (Test-LocalUser $PrintUser)) { Warn 'Akun cetak tidak bisa dibuat; PC lain mungkin diminta login manual.'; return }
    try {
        $u = [ADSI]$path
        $u.UserFlags.Value = [int]$u.UserFlags.Value -bor 0x10000
        $u.CommitChanges()
    } catch { }
    try {
        # Akun cetak harus anggota grup Users agar boleh mengakses printer dan folder driver lewat jaringan.
        $users = (New-Object Security.Principal.SecurityIdentifier 'S-1-5-32-545').Translate([Security.Principal.NTAccount]).Value.Split('\')[-1]
        & cmd.exe /c "net localgroup `"$users`" $PrintUser /add >nul 2>&1"
    } catch { }
    $hide = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon\SpecialAccounts\UserList'
    New-Item -Path $hide -Force | Out-Null
    Set-ItemProperty -Path $hide -Name $PrintUser -Value 0 -Type DWord
    Ok "Akun cetak '$PrintUser' siap (untuk PC lain, otomatis)."
}

# Salin driver terpasang ke folder bersama tersembunyi, untuk jalur cadangan di PC lain.
function Publish-Driver {
    try {
        $drv = Get-L3210Driver
        $src = Split-Path -Parent $drv.InfPath
        $dst = Join-Path $env:ProgramData 'L3210-Klinik\driver'
        New-Item -ItemType Directory -Force -Path $dst | Out-Null
        Copy-Item (Join-Path $src '*') $dst -Recurse -Force
        Set-Content -Path (Join-Path $dst 'nama-driver.txt') -Value $drv.Name
        $everyone = (New-Object Security.Principal.SecurityIdentifier 'S-1-1-0').Translate([Security.Principal.NTAccount]).Value
        & cmd.exe /c "net share $DrvShare /delete /y >nul 2>&1"
        & cmd.exe /c "net share $DrvShare=`"$dst`" /grant:`"$everyone`",READ >nul 2>&1"
        if ($LASTEXITCODE -eq 0) { Ok 'Driver disiapkan untuk PC lain (jalur cadangan).' }
        else { Warn 'Folder driver tidak bisa dibagikan; jalur cadangan di PC lain tidak tersedia.' }
    } catch { Warn "Driver tidak bisa disiapkan untuk PC lain: $($_.Exception.Message)" }
}

# Daftar PC printer klinik di ALAMAT-PRINTER.txt, satu baris per PC printer: NAMA|IP|LOKASI
function Read-Servers {
    $list = @()
    if (Test-Path $AddrFile) {
        $old = @{}
        foreach ($line in Get-Content $AddrFile) {
            if ($line -match '^(SERVER|IP)=(.*)$') { $old[$Matches[1]] = $Matches[2].Trim(); continue }
            $f = $line.Split('|')
            if ($f[0].Trim()) {
                $list += [pscustomobject]@{ Name = $f[0].Trim(); IP = "$($f[1])".Trim(); Lokasi = "$($f[2])".Trim() }
            }
        }
        if ($old['SERVER']) { $list += [pscustomobject]@{ Name = $old['SERVER']; IP = "$($old['IP'])"; Lokasi = '' } }
    }
    return , $list
}
function Save-Server($name, $ip, $lokasi) {
    $all  = Read-Servers
    $list = @($all | Where-Object { $_.Name -ne $name })
    $list += [pscustomobject]@{ Name = $name; IP = "$ip"; Lokasi = "$lokasi" }
    Set-Content -Path $AddrFile -Value @($list | ForEach-Object { "$($_.Name)|$($_.IP)|$($_.Lokasi)" })
}
function Format-Server($s) {
    if ($s.Lokasi) { return "$($s.Name)  ($($s.Lokasi))" }
    return "$($s.Name)"
}

function Test-Port($h, $p = 445) {
    try {
        $c = New-Object Net.Sockets.TcpClient
        $r = $c.BeginConnect($h, $p, $null, $null)
        $ok = $r.AsyncWaitHandle.WaitOne(3000) -and $c.Connected
        $c.Close()
        return $ok
    } catch { return $false }
}
function Get-MyIP {
    [Net.NetworkInformation.NetworkInterface]::GetAllNetworkInterfaces() |
        Where-Object { $_.OperationalStatus -eq 'Up' -and $_.NetworkInterfaceType -ne 'Loopback' } |
        Sort-Object @{ Expression = { $_.GetIPProperties().GatewayAddresses.Count -gt 0 }; Descending = $true } |
        ForEach-Object { $_.GetIPProperties().UnicastAddresses } |
        Where-Object { $_.Address.AddressFamily -eq 'InterNetwork' -and $_.Address.ToString() -notlike '169.254.*' } |
        Select-Object -First 1 | ForEach-Object { $_.Address.ToString() }
}
function Set-Default($printerName) {
    Set-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows NT\CurrentVersion\Windows' -Name LegacyDefaultPrinterMode -Value 1 -Type DWord
    (New-Object -ComObject WScript.Network).SetDefaultPrinter($printerName)
    Ok "Printer default: $printerName"
}
function Print-TestPage($printerName) {
    & rundll32.exe 'printui.dll,PrintUIEntry' /k /n "$printerName"
    Ok 'Halaman uji dikirim.'
}

# ---------------------------------------------------------------- 1. PC PRINTER
function Install-EpsonDriver {
    # Hanya installer Epson L3210 versi offline; installer "Web" dan .exe lain di folder ini diabaikan.
    $exe = Get-ChildItem $Dir -Filter *.exe -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -like '*L3210*' -and $_.Name -notlike '*Web*' } |
        Sort-Object @{ Expression = { $_.Name -like '*x64*' }; Descending = $true }, @{ Expression = 'Length'; Descending = $true } |
        Select-Object -First 1
    if (-not $exe) { return $false }
    Unblock-File $exe.FullName -ErrorAction SilentlyContinue
    Say "Menjalankan installer resmi Epson: $($exe.Name)"
    Say 'Jika jendela Epson muncul: pilih L3210, klik Setuju/OK/Next sampai selesai (sekali saja).' Cyan
    Start-Process $exe.FullName -Wait
    if (-not (Get-L3210Driver)) {
        if ($Silent) { for ($i = 0; $i -lt 120 -and -not (Get-L3210Driver); $i++) { Start-Sleep -Seconds 5 } }
        else { Read-Host 'Tekan Enter setelah jendela installer Epson selesai' | Out-Null }
    }
    return [bool](Get-L3210Driver)
}

# Urutan sumber driver: sudah terpasang -> installer Epson di folder ini -> Windows Update.
function Install-L3210Driver {
    if (Get-L3210Driver) { return }
    if (Install-EpsonDriver) { return }
    if (Install-DriverFromWU) { return }
    $page = 'https://www.epson.co.id/Printer-InkTank/L-Series/Epson-EcoTank-L3210/s/SPT_C11CJ68501'
    if (-not $Silent) { Start-Process $page }
    Fail ("Driver belum bisa dipasang otomatis. Unduh 'Printer Driver' Windows 64-bit dari situs resmi Epson " +
          "(halaman sudah dibuka: $page), taruh file .exe-nya di folder yang sama dengan file ini, lalu jalankan lagi.")
}

# Pastikan printer terlihat di USB, pasang driver, dan buat printer lokalnya.
function Install-LocalPrinter {
    # 1) Pastikan Windows melihat printer di USB.
    if (-not (Get-EpsonUsb)) {
        Say 'Nyalakan printer dan colok kabel USB ke PC ini (tunggu sampai 60 detik)...' Cyan
        for ($i = 0; $i -lt 12 -and -not (Get-EpsonUsb); $i++) { Start-Sleep -Seconds 5 }
    }
    if (-not (Show-UsbStatus)) {
        Fail ("Windows tidak melihat printer di USB. Cek: (1) printer MENYALA, lampu power hijau tidak berkedip; " +
              "(2) kabel USB dicolok LANGSUNG ke port belakang PC, bukan hub/port depan; (3) coba port USB lain; " +
              "(4) coba kabel USB lain. Lalu jalankan lagi.")
    }

    # 2) Pasang driver (installer Epson di folder ini, atau otomatis lewat Windows Update).
    Install-L3210Driver
    $drv = Get-L3210Driver
    Ok "Driver terpasang: $($drv.Name)"

    # 3) Minta Windows memindai ulang perangkat, lalu tunggu printer muncul.
    try { & pnputil.exe /scan-devices | Out-Null } catch { }
    $printer = Get-LocalL3210
    for ($i = 0; $i -lt 12 -and -not $printer; $i++) { Start-Sleep -Seconds 5; $printer = Get-LocalL3210 }

    # 4) Masih belum muncul: buat printer manual di port USB milik L3210.
    if (-not $printer) {
        $port = Get-L3210UsbPort
        if (-not $port) {
            $usb = @(Get-PrinterPort -ErrorAction SilentlyContinue | Where-Object Name -like 'USB*')
            if ($usb.Count -eq 1) { $port = $usb[0].Name }
        }
        if ($port) {
            Say "Membuat printer manual di port $port ..."
            Add-Printer -Name $drv.Name -DriverName $drv.Name -PortName $port
            $printer = Get-LocalL3210
        }
    }
    if (-not $printer) {
        Show-UsbStatus | Out-Null
        Fail 'Printer terlihat di USB tetapi belum bisa dibuat. Cabut kabel USB 10 detik, colok lagi, lalu jalankan lagi. Jika tetap gagal, foto layar ini.'
    }
    return $printer
}

function Invoke-Printer {
    Say '=== 1. PC PRINTER (kabel USB dicolok di PC ini) ===' Cyan
    Assert-Components @('Spooler', 'LanmanServer', 'PrintManagement')
    Enable-Svc Spooler
    Enable-Svc LanmanServer

    $printer = @(Install-LocalPrinter)[-1]
    Ok "Printer terdeteksi: $($printer.Name) ($($printer.PortName))"

    Get-Printer -ErrorAction SilentlyContinue |
        Where-Object { $_.Type -eq 'Local' -and $_.Shared -and $_.ShareName -eq $ShareName -and $_.Name -ne $printer.Name } |
        ForEach-Object { Set-Printer -Name $_.Name -Shared $false; Warn "Berbagi dipindah dari antrean lama: $($_.Name)" }
    Set-Printer -Name $printer.Name -Shared $true -ShareName $ShareName
    Ok "Printer dibagikan: \\$env:COMPUTERNAME\$ShareName"
    Set-PrintAccount
    Publish-Driver

    if (Get-Service MpsSvc -ErrorAction SilentlyContinue) {
        # Grup firewall "File and Printer Sharing" (nama netral bahasa).
        & netsh.exe advfirewall firewall set rule group="@FirewallAPI.dll,-28502" new enable=Yes | Out-Null
        Ok 'Firewall berbagi printer dibuka.'
    }
    if (Get-Module -ListAvailable NetConnection) {
        Get-NetConnectionProfile -ErrorAction SilentlyContinue | Where-Object NetworkCategory -eq 'Public' | ForEach-Object {
            try {
                Set-NetConnectionProfile -InterfaceIndex $_.InterfaceIndex -NetworkCategory Private
                Ok "Jaringan '$($_.Name)' diubah ke Private agar printer terlihat PC lain."
            } catch { Warn "Profil jaringan '$($_.Name)' tidak bisa diubah: $($_.Exception.Message)" }
        }
    }
    # PC printer tidak boleh tidur saat dicolok listrik.
    & powercfg.exe /change standby-timeout-ac 0 | Out-Null
    Ok 'Mode tidur (sleep) saat dicolok listrik dimatikan.'

    $ip = Get-MyIP
    $lokasi = if ($Silent) { $Server } else { Ask 'Nama LOKASI printer ini (contoh: Apotek, Pendaftaran) [boleh kosong]' '' }
    if ($lokasi) { Set-Printer -Name $printer.Name -Location $lokasi }
    try {
        Save-Server $env:COMPUTERNAME $ip $lokasi
        Ok 'PC printer ini dicatat di ALAMAT-PRINTER.txt (daftar PC printer klinik).'
    } catch { Warn "ALAMAT-PRINTER.txt tidak bisa ditulis: $($_.Exception.Message)" }

    if (Yes 'Jadikan printer default di PC ini? (y/N) [Enter = tidak, pilih printer saat Ctrl+P]' 'n') { Set-Default $printer.Name }
    if (Yes 'Cetak halaman uji sekarang? (y/N)' 'n') { Print-TestPage $printer.Name }

    Say ''
    Say '================================================================' Green
    Say " SELESAI. NAMA PC PRINTER:  $env:COMPUTERNAME     (IP: $ip)" Green
    Say '================================================================' Green
    Say 'Catat nama di atas. Di PC lain: jalankan file ini, pilih 2, lalu pilih/ketik nama tersebut.' Cyan
    Say 'Punya printer di lokasi lain? Jalankan menu 1 juga di PC printer itu dari folder yang sama.' Cyan
}

# ---------------------------------------------------------------- 2. PC LAIN
function Get-Conn($target) {
    Get-Printer -ErrorAction SilentlyContinue | Where-Object {
        $_.Type -eq 'Connection' -and ($_.ComputerName -eq $target -or $_.Name -like "\\$target\*") -and
        ($_.ShareName -eq $ShareName -or $_.Name -eq "\\$target\$ShareName")
    } | Select-Object -First 1
}

# Login ke PC printer memakai akun cetak. Mengembalikan 0 bila berhasil, atau nomor error Windows.
function Connect-Auth($target, $hostName) {
    $out = (& cmd.exe /c "net use \\$target\IPC$ /user:$hostName\$PrintUser `"$PrintPass`" 2>&1") -join ' '
    if ($LASTEXITCODE -eq 0) { return 0 }
    if (" $out " -match '\s(\d{1,5})\s') { return [int]$Matches[1] }
    return -1
}
function Get-AuthHint($n) {
    switch ($n) {
        1326    { 'Akun/sandi cetak ditolak: jalankan menu 1 versi TERBARU di PC printer (versi file harus sama di semua PC).' }
        86      { 'Sandi cetak salah: jalankan menu 1 versi TERBARU di PC printer.' }
        1385    { 'Akun cetak tidak diizinkan masuk lewat jaringan: jalankan lagi menu 1 di PC printer.' }
        1219    { 'PC ini sudah tersambung ke PC printer dengan akun lain: restart PC ini lalu ulangi.' }
        53      { 'PC printer tidak ditemukan di jaringan: cek kabel/Wi-Fi dan pastikan PC printer menyala.' }
        67      { 'PC printer tidak ditemukan di jaringan: cek kabel/Wi-Fi dan pastikan PC printer menyala.' }
        5       { 'Akses ditolak oleh PC printer: jalankan lagi menu 1 di PC printer.' }
        1272    { 'Windows ini memblokir login tamu: jalankan menu 1 versi TERBARU di PC printer.' }
        default { '' }
    }
}

# Jalur cadangan: pasang driver dari PC printer, lalu buat printer LOKAL yang port-nya \\PC\L3210.
# Dipakai bila sambungan printer biasa ditolak Windows (mis. kode 0x0000011B / 0x00000BCB / 0x00000709).
function Connect-ViaLocalPort($s, $target) {
    $unc = "\\$target\$ShareName"
    try {
        if (-not (Get-L3210Driver)) {
            Say 'Jalur cadangan: mengambil driver dari PC printer...'
            $tmp = Join-Path $env:TEMP 'l3210-driver'
            Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
            New-Item -ItemType Directory -Force -Path $tmp | Out-Null
            Copy-Item "\\$target\$DrvShare\*" $tmp -Recurse -Force
            foreach ($inf in Get-ChildItem $tmp -Recurse -Filter *.inf) { & pnputil.exe /add-driver $inf.FullName /install | Out-Null }
            $dn = Get-Content (Join-Path $tmp 'nama-driver.txt') -ErrorAction SilentlyContinue | Select-Object -First 1
            if (-not $dn) { $dn = 'EPSON L3210 Series' }
            Add-PrinterDriver -Name $dn
        }
        $drv = Get-L3210Driver
        if (-not $drv) { return $null }
        if (-not (Get-PrinterPort -Name $unc -ErrorAction SilentlyContinue)) { Add-PrinterPort -Name $unc }
        $label = if ($s.Lokasi) { $s.Lokasi } else { $s.Name }
        $pname = "L3210 $label"
        if (-not (Get-Printer -Name $pname -ErrorAction SilentlyContinue)) {
            Add-Printer -Name $pname -DriverName $drv.Name -PortName $unc
        }
        return $pname
    } catch {
        Warn "Jalur cadangan gagal: $($_.Exception.Message)"
        return $null
    }
}

# Sambungkan PC ini ke satu PC printer. Mengembalikan alamat printer (\\PC\L3210) atau $null.
function Connect-Server($s) {
    $target = $null
    foreach ($c in @($s.Name, $s.IP) | Where-Object { $_ } | Select-Object -Unique) {
        Say "Mencari PC printer: $c ..."
        if (Test-Port $c) { $target = $c; break }
    }
    if (-not $target) {
        Warn "PC printer $(Format-Server $s) tidak terjangkau. Pastikan menyala, satu jaringan, dan menu 1 sudah dijalankan di sana."
        return $null
    }

    # Login otomatis ke PC printer memakai akun cetak (dibuat oleh menu 1).
    foreach ($t in @($target, $s.Name, $s.IP) | Where-Object { $_ } | Select-Object -Unique) {
        & cmd.exe /c "net use \\$t\IPC$ /delete /y >nul 2>&1"
        & cmdkey.exe /add:$t /user:"$($s.Name)\$PrintUser" /pass:$PrintPass | Out-Null
    }
    $auth = Connect-Auth $target $s.Name
    if ($auth -eq 0) { Ok 'Login ke PC printer berhasil.' }
    else { Warn "Login ke PC printer gagal (kode $auth). $(Get-AuthHint $auth)" }

    $existing = Get-Printer -ErrorAction SilentlyContinue | Where-Object { $_.Type -eq 'Local' -and $_.PortName -eq "\\$target\$ShareName" } | Select-Object -First 1
    if ($existing) { Ok "Sudah tersambung: $($existing.Name)"; return $existing.Name }

    $unc = "\\$target\$ShareName"
    if (-not (Get-Conn $target)) {
        Say 'Menyambung dan mengambil driver dari PC printer (bisa 1-2 menit)...'
        $code = $null
        try { Add-Printer -ConnectionName $unc } catch { $code = Get-ErrCode $_ }
        if ($code) {
            # Jalur cadangan bawaan Windows.
            & rundll32.exe 'printui.dll,PrintUIEntry' /in /q /n"$unc"
            for ($i = 0; $i -lt 12 -and -not (Get-Conn $target); $i++) { Start-Sleep -Seconds 5 }
        }
        if (-not (Get-Conn $target)) {
            Warn "Sambungan biasa ke $unc ditolak (kode $code). $(Get-ErrHint $code)"
            $alt = @(Connect-ViaLocalPort $s $target)[-1]
            if ($alt) { Ok "Tersambung lewat jalur cadangan: $alt"; return $alt }
            Warn "Gagal tersambung ke $unc. Jalankan menu 0 (DIAGNOSA) di PC ini dan kirim hasilnya."
            return $null
        }
    }
    # Sambungkan untuk semua akun Windows di PC ini.
    & rundll32.exe 'printui.dll,PrintUIEntry' /ga /n"$unc"
    $name = (Get-Conn $target).Name
    Ok "Tersambung: $name  $($s.Lokasi)"
    return $name
}

# Cari otomatis PC printer di jaringan yang sama (subnet /24): PC yang membagikan printer "L3210".
function Find-Servers {
    $me = Get-MyIP
    if ("$me" -notmatch '^(\d+\.\d+\.\d+)\.\d+$') { return , @() }
    $prefix = $Matches[1]
    Say "Mencari PC printer di jaringan $prefix.x (sekitar 10 detik)..."
    $jobs = foreach ($i in 1..254) {
        $ip = "$prefix.$i"
        if ($ip -eq $me) { continue }
        $c = New-Object Net.Sockets.TcpClient
        try { [pscustomobject]@{ IP = $ip; Client = $c; Async = $c.BeginConnect($ip, 445, $null, $null) } } catch { }
    }
    Start-Sleep -Milliseconds 2500
    $open = @($jobs | Where-Object { $_.Async.IsCompleted -and $_.Client.Connected } | ForEach-Object { $_.IP })
    foreach ($j in $jobs) { try { $j.Client.Close() } catch { } }

    $found = @()
    foreach ($ip in $open) {
        # Login tersimpan milik pengguna untuk PC itu tidak disentuh.
        $had = ((& cmd.exe /c "cmdkey /list:$ip 2>nul") -join ' ') -match 'target='
        if (-not $had) { & cmdkey.exe /add:$ip /user:"$ip\$PrintUser" /pass:$PrintPass | Out-Null }
        $view = (& cmd.exe /c "net view \\$ip 2>nul") -join "`n"
        if ($view -match "(?m)^$ShareName\s") {
            $name = $ip
            $nb = (& cmd.exe /c "nbtstat -A $ip 2>nul") -join "`n"
            if ($nb -match '(?m)^\s*(\S+)\s+<00>\s+UNIQUE') { $name = $Matches[1] }
            $lok = ''
            try { $lok = "$((Get-Printer -ComputerName $name -ErrorAction Stop | Where-Object ShareName -eq $ShareName | Select-Object -First 1).Location)" } catch { }
            $found += [pscustomobject]@{ Name = $name; IP = $ip; Lokasi = $lok }
        } elseif (-not $had) {
            & cmd.exe /c "cmdkey /delete:$ip >nul 2>&1"
        }
    }
    return , $found
}

# Pilih satu atau beberapa PC printer: dari argumen, nomor di daftar, atau nama yang diketik.
function Select-Servers {
    $known = Read-Servers
    $ans = $Server
    if (-not $ans) {
        # Gabungkan daftar tersimpan dengan hasil pencarian otomatis di jaringan.
        foreach ($k in $known | Where-Object { -not $_.IP }) {
            try {
                $k.IP = ([Net.Dns]::GetHostAddresses($k.Name) | Where-Object { $_.AddressFamily -eq 'InterNetwork' } | Select-Object -First 1).ToString()
            } catch { }
        }
        foreach ($f in (Find-Servers)) {
            $hit = $known | Where-Object { $_.Name -eq $f.Name -or ($_.IP -and $_.IP -eq $f.IP) } | Select-Object -First 1
            if ($hit) { $hit.IP = $f.IP; if ($f.Lokasi) { $hit.Lokasi = $f.Lokasi } } else { $known += $f; try { Save-Server $f.Name $f.IP $f.Lokasi } catch { } }
        }
        if ($known.Count -gt 0) {
            Say 'Daftar PC printer klinik:'
            for ($i = 0; $i -lt $known.Count; $i++) { Say ("  {0}. {1}" -f ($i + 1), (Format-Server $known[$i])) }
            $ans = Ask 'Ketik NOMOR atau NAMA PC printer; pisahkan koma untuk beberapa [Enter = semua di daftar]' 'semua'
        } else {
            $ans = Ask 'Ketik NAMA PC PRINTER (tampil di akhir menu 1); pisahkan koma untuk beberapa'
        }
    }
    $picked = @()
    foreach ($tok in "$ans".Split(',') | ForEach-Object { $_.Trim() } | Where-Object { $_ }) {
        if ($tok -eq 'semua') { $picked += $known; continue }
        if ($tok -match '^\d+$' -and [int]$tok -ge 1 -and [int]$tok -le $known.Count) { $picked += $known[[int]$tok - 1]; continue }
        $hit = $known | Where-Object { $_.Name -eq $tok } | Select-Object -First 1
        if ($hit) { $picked += $hit } else { $picked += [pscustomobject]@{ Name = $tok; IP = ''; Lokasi = '' } }
    }
    return , @($picked | Sort-Object Name -Unique)
}

function Invoke-Lain {
    Say '=== 2. PC LAIN (mencetak lewat jaringan, bisa ke beberapa PC printer) ===' Cyan
    Assert-Components @('Spooler', 'LanmanWorkstation', 'PrintManagement')
    Enable-Svc Spooler
    Enable-Svc LanmanWorkstation

    $servers = Select-Servers
    if ($servers.Count -eq 0) { Fail 'PC printer belum dipilih. Jalankan dulu menu 1 di PC yang dicolok printer.' }

    $uncs = @()
    foreach ($s in $servers) {
        $u = @(Connect-Server $s)[-1]
        if ($u) { $uncs += $u }
    }
    if ($uncs.Count -eq 0) { Fail 'Tidak ada printer yang berhasil disambung.' }
    Restart-Service Spooler -Force
    Start-Sleep -Seconds 3

    if ($uncs.Count -eq 1) {
        if (Yes 'Jadikan printer default di PC ini? (y/N) [Enter = tidak, pilih printer saat Ctrl+P]' 'n') { Set-Default $uncs[0] }
    } else {
        Say 'Printer yang tersambung:'
        for ($i = 0; $i -lt $uncs.Count; $i++) { Say ("  {0}. {1}" -f ($i + 1), $uncs[$i]) }
        $n = Ask 'Nomor printer DEFAULT untuk PC ini [Enter = tidak ada, pilih printer saat Ctrl+P]' '0'
        if ($n -match '^\d+$' -and [int]$n -ge 1 -and [int]$n -le $uncs.Count) { Set-Default $uncs[[int]$n - 1] }
    }
    if (Yes 'Cetak halaman uji ke printer yang baru tersambung? (y/N)' 'n') { foreach ($u in $uncs) { Print-TestPage $u } }

    Say ''
    Say "SELESAI. PC ini bisa mencetak ke $($uncs.Count) printer: $($uncs -join ', ')" Green
    if ($uncs.Count -lt $servers.Count) { Warn 'Sebagian PC printer gagal disambung, lihat pesan [!] di atas.' }
}

# ---------------------------------------------------------------- 3. PERBAIKI
function Invoke-Perbaiki {
    Say '=== 3. PERBAIKI ANTREAN CETAK MACET ===' Cyan
    Assert-Components @('Spooler')
    Stop-Service Spooler -Force
    Remove-Item (Join-Path $env:SystemRoot 'System32\spool\PRINTERS\*') -Force -ErrorAction SilentlyContinue
    Enable-Svc Spooler
    Ok 'Antrean cetak dibersihkan dan Print Spooler dinyalakan ulang.'
    if (Get-Module -ListAvailable PrintManagement) {
        $list = Get-Printer -ErrorAction SilentlyContinue | Where-Object { $_.DriverName -like '*L3210*' -or $_.Name -like '*L3210*' }
        if ($list) { $list | Format-Table Name, PrinterStatus, JobCount -AutoSize | Out-String | Write-Host }
        else { Warn 'Printer L3210 belum terpasang di PC ini. Jalankan menu 1 atau 2.' }
    }
    Say 'Jika ini PC lain dan masih gagal: pastikan PC printer menyala dan tidak sedang sleep.' Cyan
}

# ---------------------------------------------------------------- 4. CEK
function Invoke-Cek {
    Say '=== 4. CEK KOMPONEN WINDOWS ===' Cyan
    Get-Components | Format-Table -AutoSize | Out-String | Write-Host
    [void](Show-UsbStatus)
    $drv = Get-L3210Driver
    if ($drv) { Say "Driver: $($drv.Name)" } else { Say 'Driver: belum terpasang' }
    $wu = Get-Service wuauserv -ErrorAction SilentlyContinue
    Say ("Windows Update: " + $(if ($wu) { "$($wu.Status) / $($wu.StartType)" } else { 'TIDAK ADA' }))
    Say ''
    Say 'Spooler wajib di semua PC. LanmanServer wajib di PC printer. LanmanWorkstation wajib di PC lain.'
    Say 'TIDAK ADA = komponen dibuang oleh Windows Lite. Stopped/Disabled tidak masalah, akan dinyalakan otomatis.'
}

# ---------------------------------------------------------------- 5. DRIVER SAJA
function Invoke-Driver {
    Say '=== 5. PASANG DRIVER SAJA (printer USB untuk PC ini, tanpa dibagikan) ===' Cyan
    Assert-Components @('Spooler', 'PrintManagement')
    Enable-Svc Spooler
    $printer = @(Install-LocalPrinter)[-1]
    Ok "Printer siap dipakai di PC ini: $($printer.Name) ($($printer.PortName))"
    if (Yes 'Jadikan printer default di PC ini? (y/N) [Enter = tidak, pilih printer saat Ctrl+P]' 'n') { Set-Default $printer.Name }
    if (Yes 'Cetak halaman uji sekarang? (y/N)' 'n') { Print-TestPage $printer.Name }
}

# Sambungan printer bersama L3210 yang ada di PC ini.
function Get-L3210Connections {
    Get-Printer -ErrorAction SilentlyContinue | Where-Object { $_.Type -eq 'Connection' -and ($_.ShareName -eq $ShareName -or $_.DriverName -like '*L3210*') }
}
function Remove-L3210Connections {
    $n = 0
    foreach ($c in @(Get-L3210Connections)) {
        & rundll32.exe 'printui.dll,PrintUIEntry' /gd /q /n"\\$($c.ComputerName)\$ShareName"
        try { Remove-Printer -Name $c.Name } catch { Warn "Tidak bisa melepas $($c.Name): $($_.Exception.Message)" }
        if ($c.ComputerName) { & cmd.exe /c "cmdkey /delete:$($c.ComputerName) >nul 2>&1" }
        Ok "Sambungan lama dilepas: $($c.Name)"
        $n++
    }
    foreach ($lp in @(Get-Printer -ErrorAction SilentlyContinue | Where-Object { $_.Type -eq 'Local' -and $_.PortName -like "\\*\$ShareName" })) {
        try {
            Remove-Printer -Name $lp.Name
            Remove-PrinterPort -Name $lp.PortName -ErrorAction SilentlyContinue
            Ok "Sambungan lama dilepas: $($lp.Name)"
            $n++
        } catch { Warn "Tidak bisa melepas $($lp.Name): $($_.Exception.Message)" }
    }
    return $n
}

# ---------------------------------------------------------------- 6. PINDAH PC PRINTER
function Invoke-Pindah {
    Say '=== 6. PINDAH PC PRINTER (PC ini pindah ke PC printer yang baru) ===' Cyan
    Say 'Urutan pindah: (a) colok USB printer ke PC baru, jalankan menu 1 di sana;'
    Say '               (b) jalankan menu 6 ini di setiap PC lain; (c) menu 8 di PC printer lama.'
    Assert-Components @('Spooler', 'LanmanWorkstation', 'PrintManagement')
    Enable-Svc Spooler
    [void](Remove-L3210Connections)
    Invoke-Lain
}

# ---------------------------------------------------------------- 7. STATUS + TES CETAK
function Invoke-Tes {
    Say '=== 7. STATUS PRINTER + TES CETAK ===' Cyan
    Assert-Components @('Spooler', 'PrintManagement')
    Enable-Svc Spooler
    $list = @(Get-Printer -ErrorAction SilentlyContinue | Where-Object { $_.DriverName -like '*L3210*' -or $_.Name -like '*L3210*' })
    if ($list.Count -eq 0) { Fail 'Printer L3210 belum terpasang di PC ini. Jalankan menu 1, 2, atau 5.' }
    for ($i = 0; $i -lt $list.Count; $i++) {
        $x = $list[$i]
        Say ("  {0}. {1}  [{2}]  lokasi: {3}  status: {4}  antre: {5}" -f ($i + 1), $x.Name, $x.Type, $x.Location, $x.PrinterStatus, $x.JobCount)
    }
    $p = $list[0]
    if ($list.Count -gt 1) {
        $n = Ask 'Nomor printer yang dites [Enter = 1]' '1'
        if ($n -match '^\d+$' -and [int]$n -ge 1 -and [int]$n -le $list.Count) { $p = $list[[int]$n - 1] }
    }
    if ($p.Type -eq 'Connection' -and $p.ComputerName -and -not (Test-Port $p.ComputerName)) {
        Warn "PC printer ($($p.ComputerName)) tidak terjangkau: pastikan menyala dan tidak sleep."
    }
    if (Yes "Jadikan '$($p.Name)' printer default? (y/N)" 'n') { Set-Default $p.Name }
    if (Yes 'Cetak halaman uji sekarang? (Y/n)' 'y') { Print-TestPage $p.Name }
}

# ---------------------------------------------------------------- 8. LEPAS
function Invoke-Lepas {
    Say '=== 8. LEPAS PRINTER BERSAMA DARI PC INI ===' Cyan
    Say 'PC lain   : sambungan ke printer bersama dihapus.'
    Say 'PC printer: berbagi printer dihentikan dan akun cetak dihapus (driver dan printer USB tetap ada).'
    Assert-Components @('Spooler', 'PrintManagement')
    if (-not (Yes 'Lanjutkan? (y/N)' $(if ($Silent) { 'y' } else { 'n' }))) { Say 'Dibatalkan.'; return }
    Enable-Svc Spooler

    $n = Remove-L3210Connections
    if ($n -gt 0) { Restart-Service Spooler -Force }

    $local  = Get-LocalL3210
    $shared = @(Get-Printer -ErrorAction SilentlyContinue | Where-Object { $_.Type -eq 'Local' -and $_.Shared -and $_.DriverName -like '*L3210*' -and $_.PortName -notlike '\\*' })
    if ($shared.Count -gt 0) {
        foreach ($sp in $shared) { Set-Printer -Name $sp.Name -Shared $false; Ok "Berbagi printer dihentikan: $($sp.Name)" }
        try {
            # Keluarkan PC ini dari daftar PC printer klinik.
            $all  = Read-Servers
            $rest = @($all | Where-Object { $_.Name -ne $env:COMPUTERNAME })
            if ($rest.Count -lt $all.Count) {
                Set-Content -Path $AddrFile -Value @($rest | ForEach-Object { "$($_.Name)|$($_.IP)|$($_.Lokasi)" })
            }
        } catch { }
    }
    if ((Test-LocalUser $PrintUser)) {
        & net.exe user $PrintUser /delete | Out-Null
        Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon\SpecialAccounts\UserList' -Name $PrintUser -ErrorAction SilentlyContinue
        Ok "Akun cetak '$PrintUser' dihapus."
    }
    if ($n -eq 0 -and -not $local) { Warn 'Tidak ada printer L3210 di PC ini.' }
    Say 'SELESAI.' Green
}

# ---------------------------------------------------------------- 9. GANTI NAMA
function Invoke-Rename {
    Say '=== 9. GANTI NAMA PRINTER ===' Cyan
    Assert-Components @('Spooler', 'PrintManagement')
    Enable-Svc Spooler
    $list = @(Get-Printer -ErrorAction SilentlyContinue | Where-Object { $_.DriverName -like '*L3210*' -and $_.Type -eq 'Local' })
    if ($list.Count -eq 0) {
        Fail 'Tidak ada printer L3210 yang bisa diganti namanya di PC ini. Ganti nama di PC PRINTER (yang dicolok USB); di PC lain namanya ikut berubah.'
    }
    $p = $list[0]
    if ($list.Count -gt 1) {
        for ($i = 0; $i -lt $list.Count; $i++) { Say ("  {0}. {1}  ({2})" -f ($i + 1), $list[$i].Name, $list[$i].PortName) }
        $n = Ask 'Nomor printer yang diganti namanya [Enter = 1]' '1'
        if ($n -match '^\d+$' -and [int]$n -ge 1 -and [int]$n -le $list.Count) { $p = $list[[int]$n - 1] }
    }
    Say "Nama sekarang: $($p.Name)"
    $new = if ($Silent) { $Server } else { Ask 'Nama BARU (contoh: Printer Apotek)' }
    if (-not $new) { Fail 'Nama baru belum diisi.' }
    if ($new -match '[\\,!\*\?\[\]]') { Fail 'Nama tidak boleh berisi tanda \ , ! * ? [ ]' }
    if (Get-Printer -Name $new -ErrorAction SilentlyContinue) { Fail "Sudah ada printer bernama '$new' di PC ini." }
    Rename-Printer -Name $p.Name -NewName $new
    Ok "Nama printer diganti: $($p.Name) -> $new"
    Say 'Di PC lain nama ikut berubah. Jika di sana printer jadi offline, jalankan menu 2 lagi.' Cyan
}

# ---------------------------------------------------------------- 0. DIAGNOSA
function Invoke-Diagnosa {
    Say '=== 0. DIAGNOSA (laporan lengkap, disimpan ke Desktop) ===' Cyan
    $script:Rep = @()
    function D($m) { Say $m; $script:Rep += "$m" }

    $cv = Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion' -ErrorAction SilentlyContinue
    D "Waktu      : $(Get-Date -Format 'yyyy-MM-dd HH:mm')"
    D "PC         : $env:COMPUTERNAME   akun: $env:USERNAME"
    D "Windows    : $($cv.ProductName) $($cv.DisplayVersion) build $($cv.CurrentBuild).$($cv.UBR)"
    D "IP         : $(Get-MyIP)"
    D ''
    D '-- Komponen Windows --'
    foreach ($c in Get-Components) { D ("{0,-18} {1}" -f $c.Komponen, $c.Status) }
    D ''
    D '-- Printer L3210 di PC ini --'
    $hasPM = [bool](Get-Module -ListAvailable PrintManagement)
    if ($hasPM) {
        $drv = Get-L3210Driver
        D ("Driver     : " + $(if ($drv) { $drv.Name } else { 'belum terpasang' }))
        $pr = @(Get-Printer -ErrorAction SilentlyContinue | Where-Object { $_.DriverName -like '*L3210*' -or $_.Name -like '*L3210*' })
        if ($pr.Count -eq 0) { D 'Printer    : tidak ada' }
        foreach ($x in $pr) { D ("Printer    : {0} | {1} | port {2} | share {3} | status {4} | antre {5}" -f $x.Name, $x.Type, $x.PortName, $x.ShareName, $x.PrinterStatus, $x.JobCount) }
    } else { D 'Modul PrintManagement TIDAK ADA' }
    foreach ($d in @(Get-EpsonUsb)) { D "USB        : $($d.Name) (kode $($d.ConfigManagerErrorCode))" }
    D ("Akun cetak : " + $(if (Test-LocalUser $PrintUser) { 'ada di PC ini' } else { 'tidak ada di PC ini (wajar untuk PC lain)' }))

    $targets = @()
    $targets += @(Read-Servers | ForEach-Object { $_ })
    if ($hasPM) {
        foreach ($c in @(Get-L3210Connections)) {
            if ($c.ComputerName -and -not ($targets | Where-Object { $_.Name -eq $c.ComputerName })) {
                $targets += [pscustomobject]@{ Name = $c.ComputerName; IP = ''; Lokasi = '' }
            }
        }
    }
    foreach ($s in $targets | Where-Object { $_.Name -ne $env:COMPUTERNAME }) {
        D ''
        D "-- Uji ke PC printer: $(Format-Server $s) --"
        $ipRes = ''
        try { $ipRes = ([Net.Dns]::GetHostAddresses($s.Name) | Where-Object { $_.AddressFamily -eq 'InterNetwork' } | Select-Object -First 1).ToString() } catch { }
        D ("Nama -> IP : " + $(if ($ipRes) { $ipRes } else { "GAGAL (nama tidak dikenali jaringan); IP tersimpan: $($s.IP)" }))
        $t = if ($ipRes) { $s.Name } elseif ($s.IP) { $s.IP } else { $null }
        if (-not $t) { continue }
        $p445 = Test-Port $t
        D ("Port 445   : " + $(if ($p445) { 'terbuka' } else { 'TERTUTUP (PC mati / firewall / beda jaringan)' }))
        if (-not $p445) { continue }
        & cmd.exe /c "net use \\$t\IPC$ /delete /y >nul 2>&1"
        $a = Connect-Auth $t $s.Name
        D ("Login cetak: " + $(if ($a -eq 0) { 'berhasil' } else { "GAGAL kode $a. $(Get-AuthHint $a)" }))
        $view = (& cmd.exe /c "net view \\$t 2>&1") -join ' '
        D ("Share L3210: " + $(if ($view -match "(^|\s)$ShareName\s") { 'terlihat' } else { 'TIDAK terlihat' }))
        D ("Share driver: " + $(if (Test-Path "\\$t\$DrvShare\nama-driver.txt") { 'ada' } else { 'tidak ada (jalankan menu 1 versi terbaru di PC printer)' }))
    }

    $file = Join-Path ([Environment]::GetFolderPath('Desktop')) "Diagnosa-Printer-$env:COMPUTERNAME.txt"
    try { Set-Content -Path $file -Value $script:Rep; Ok "Laporan disimpan: $file (kirim file/foto ini bila perlu bantuan)" }
    catch { Warn "Laporan tidak bisa disimpan: $($_.Exception.Message)" }
}

# ---------------------------------------------------------------- S. SCAN ULANG
function Invoke-Scan {
    Say '=== S. SCAN ULANG (hapus daftar tersimpan, cari PC printer yang sedang menyala) ===' Cyan
    if (Test-Path $AddrFile) {
        try { Remove-Item $AddrFile -Force; Ok 'Daftar PC printer yang tersimpan dihapus.' }
        catch { Warn "Daftar lama tidak bisa dihapus: $($_.Exception.Message)" }
    }
    $found = Find-Servers
    if ($found.Count -eq 0) {
        Warn 'Tidak ada PC printer yang sedang menyala di jaringan ini.'
        Say 'Pastikan PC printer menyala, satu jaringan dengan PC ini, dan menu 1 versi terbaru sudah dijalankan di sana.'
        return
    }
    Say ''
    Say "PC printer yang sedang menyala: $($found.Count)" Green
    for ($i = 0; $i -lt $found.Count; $i++) {
        Say ("  {0}. {1}   IP {2}" -f ($i + 1), (Format-Server $found[$i]), $found[$i].IP)
        try { Save-Server $found[$i].Name $found[$i].IP $found[$i].Lokasi } catch { }
    }
    Say ''
    Say 'Daftar baru disimpan. Jalankan menu 2 untuk menyambung, atau menu 6 untuk mengganti sambungan lama.' Cyan
}

# ---------------------------------------------------------------- MENU
if (-not $Mode) {
    Say ''
    Say '  ==================  EPSON L3210 - KLINIK  ==================' Cyan
    Say ''
    Say '  PASANG' Yellow
    Say '    1  PC PRINTER    PC yang dicolok kabel USB printer'
    Say '    2  PC LAIN       mencetak lewat jaringan (bisa beberapa printer)'
    Say '    5  DRIVER SAJA   printer USB untuk PC ini saja, tanpa dibagikan'
    Say ''
    Say '  KELOLA' Yellow
    Say '    S  SCAN ULANG    hapus daftar lama, cari PC printer yang menyala'
    Say '    6  PINDAH        lepas sambungan lama, pilih PC printer baru'
    Say '    9  GANTI NAMA    ganti nama printer'
    Say '    8  LEPAS         hapus sambungan / hentikan berbagi di PC ini'
    Say ''
    Say '  BANTUAN' Yellow
    Say '    7  TES CETAK     status printer + halaman uji'
    Say '    3  PERBAIKI      cetakan macet / antre terus'
    Say '    4  CEK           komponen Windows (Windows Lite)'
    Say '    0  DIAGNOSA      cek lengkap + laporan ke Desktop'
    Say ''
    $Mode = (Read-Host '  Ketik pilihan lalu Enter').Trim()
}
try {
    switch -Regex ($Mode) {
        '^(1|printer|host)$'  { Invoke-Printer; break }
        '^(2|lain|klien)$'    { Invoke-Lain; break }
        '^(3|perbaiki)$'      { Invoke-Perbaiki; break }
        '^(4|cek)$'           { Invoke-Cek; break }
        '^(5|driver)$'        { Invoke-Driver; break }
        '^(6|pindah)$'        { Invoke-Pindah; break }
        '^(7|tes)$'           { Invoke-Tes; break }
        '^(8|lepas)$'         { Invoke-Lepas; break }
        '^(9|rename|nama)$'   { Invoke-Rename; break }
        '^(0|diagnosa)$'      { Invoke-Diagnosa; break }
        '^(s|scan)$'          { Invoke-Scan; break }
        default               { Fail "Pilihan tidak dikenal: $Mode" }
    }
} catch {
    Fail $_.Exception.Message
}
Stop-Transcript | Out-Null
exit 0
