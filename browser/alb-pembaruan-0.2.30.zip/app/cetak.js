/* Surat PDF dari C-CARE digambar ke kanvas lalu dicetak (dialog Cetak Windows), tanpa disimpan ke folder Unduhan.
 * Dipanggil proses utama: window.__cetak(base64) → selesai bila semua halaman tergambar. */
pdfjsLib.GlobalWorkerOptions.workerSrc = 'pdf.worker.min.js';   // worker dimuat di halaman (file:// tidak bisa membuat Worker)
const PT_KE_PX = 96 / 72, MUTU = 2;   // kanvas 2× agar tulisan tajam di kertas
window.__cetak = async (b64) => {
  const data = Uint8Array.from(atob(b64), (c) => c.charCodeAt(0));
  const pdf = await pdfjsLib.getDocument({ data, isEvalSupported: false }).promise;
  let ukuran = null;
  for (let i = 1; i <= pdf.numPages; i++) {
    const hal = await pdf.getPage(i), vp1 = hal.getViewport({ scale: 1 });
    if (!ukuran) ukuran = vp1;
    const vp = hal.getViewport({ scale: PT_KE_PX * MUTU }), kv = document.createElement('canvas');
    kv.width = Math.ceil(vp.width); kv.height = Math.ceil(vp.height);
    kv.style.width = (vp1.width * PT_KE_PX) + 'px'; kv.style.height = (vp1.height * PT_KE_PX) + 'px';
    await hal.render({ canvasContext: kv.getContext('2d'), viewport: vp }).promise;
    document.body.appendChild(kv);
  }
  // ukuran kertas mengikuti halaman pertama surat (mis. A5/A4), tanpa margin tambahan
  document.getElementById('halaman').textContent = `@page{size:${ukuran.width}pt ${ukuran.height}pt;margin:0}`;
  document.getElementById('ket').textContent = `${pdf.numPages} halaman siap dicetak.`;
  return pdf.numPages;
};

// Pilihan tujuan cetak: printer Windows (dialog Cetak) atau printer di PC lain lewat internet.
// Mengembalikan indeks pilihan (-1 = dialog Windows).
window.__pilih = (label) => new Promise((selesai) => {
  const ket = document.getElementById('ket');
  ket.textContent = '';
  const tombol = (teks, nilai, kelas, judul) => {
    const b = document.createElement('button'); b.type = 'button'; b.textContent = teks; b.className = kelas; if (judul) b.title = judul;
    b.addEventListener('click', () => { ket.querySelectorAll('button').forEach((x) => { x.disabled = true; }); selesai(nilai); });
    ket.appendChild(b);
  };
  label.forEach((t, i) => { const [printer, pc] = t.split(' — '); tombol(`Cetak ke ${printer}`, i, 'utama', `${pc} · lewat internet`); });
  tombol('Printer lain…', -1, 'lain');
  ket.querySelector('button').focus();
});
window.__status = (teks) => { document.getElementById('ket').textContent = teks; };
// Halaman sebagai JPEG untuk dikirim: [{w, h (pt), b64}]; mutu diturunkan bila terlalu besar.
window.__jpeg = () => [...document.querySelectorAll('canvas')].map((kv) => {
  let mutu = 0.85, url = kv.toDataURL('image/jpeg', mutu);
  while (url.length > 1_250_000 && mutu > 0.4) { mutu -= 0.15; url = kv.toDataURL('image/jpeg', mutu); }
  return { w: parseFloat(kv.style.width) / PT_KE_PX, h: parseFloat(kv.style.height) / PT_KE_PX, b64: url.slice(url.indexOf(',') + 1) };
});
