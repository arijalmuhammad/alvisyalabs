// Pembaca ZIP kecil (stored + deflate) untuk paket pembaruan. Tanpa dependensi.
const zlib = require('zlib');

function bacaZip(buf) {
  let e = buf.length - 22;
  while (e >= 0 && buf.readUInt32LE(e) !== 0x06054b50) e--;           // akhir central directory
  if (e < 0) throw new Error('Bukan file ZIP.');
  const jumlah = buf.readUInt16LE(e + 10);
  let p = buf.readUInt32LE(e + 16);
  const isi = [];
  for (let i = 0; i < jumlah; i++) {
    if (buf.readUInt32LE(p) !== 0x02014b50) throw new Error('ZIP rusak.');
    const metode = buf.readUInt16LE(p + 10), ukuranZ = buf.readUInt32LE(p + 20);
    const pn = buf.readUInt16LE(p + 28), pe = buf.readUInt16LE(p + 30), pk = buf.readUInt16LE(p + 32);
    const lokal = buf.readUInt32LE(p + 42);
    const nama = buf.toString('utf8', p + 46, p + 46 + pn).replace(/\\/g, '/');
    p += 46 + pn + pe + pk;
    if (nama.endsWith('/')) continue;
    const mulai = lokal + 30 + buf.readUInt16LE(lokal + 26) + buf.readUInt16LE(lokal + 28);
    const mentah = buf.subarray(mulai, mulai + ukuranZ);
    let data;
    if (metode === 0) data = Buffer.from(mentah);
    else if (metode === 8) data = zlib.inflateRawSync(mentah);
    else throw new Error('Metode kompresi ZIP tidak didukung: ' + metode);
    isi.push({ nama, data });
  }
  return isi;
}

/** Petakan isi ZIP ke tujuan aman. Diterima: paket AlvisyaLabs Browser (app/…, ekstensi/…, package.json)
 *  atau ZIP CCare Dokter biasa (manifest.json di akar atau di satu folder teratas) → ekstensi/. */
function petakan(isi) {
  const aman = (n) => n && !n.split('/').some((s) => s === '..' || s === '') && !/^[a-zA-Z]:/.test(n) && !n.startsWith('/');
  const nama = isi.map((f) => f.nama);
  let awalan = null;
  if (nama.includes('manifest.json')) awalan = '';
  else {
    const atas = [...new Set(nama.map((n) => n.split('/')[0]))];
    if (atas.length === 1 && nama.includes(atas[0] + '/manifest.json')) awalan = atas[0] + '/';
  }
  const hasil = [];
  for (const f of isi) {
    let tujuan;
    if (awalan !== null) { if (!f.nama.startsWith(awalan)) continue; tujuan = 'ekstensi/' + f.nama.slice(awalan.length); }
    else if (f.nama === 'package.json' || f.nama.startsWith('app/') || f.nama.startsWith('ekstensi/')) tujuan = f.nama;
    else continue;
    if (!aman(tujuan)) throw new Error('Nama file tidak aman di ZIP: ' + f.nama);
    hasil.push({ tujuan, data: f.data });
  }
  if (!hasil.length) throw new Error('ZIP tidak berisi pembaruan AlvisyaLabs Browser atau CCare Dokter.');
  return hasil;
}

module.exports = { bacaZip, petakan };
