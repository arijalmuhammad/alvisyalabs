/* Alvisya Dokter — Auto Fill halaman MCU C-CARE (/Poli/Mcu/<id>). Struktur diukur dari halaman asli 11 Nov 2026:
 *   isian dokter: #AmnesaDokter #KepalaMuka #Thorax #Abdomen #Extremitas #Ekg #KodePenyakit(select2) #Diagnosa
 *                 #TataLaksana ("Rekomendasi Dokter") #StatusKunjunganID; isian perawat (read-only): #TinggiBadan #BeratBadan
 *                 #Imt #LingkarPerut #Sistole #Diastole #Respirasi #Nadi #Suhu #SaturasiO2 #SnallenChart #IsButaWarna #RiwayatPenyakit
 *   identitas: #IdentitasPasien_tab .form-group (.media-body = label, .col-md-8 = nilai)
 *   lab: baris "Rujukan Lab" → /Laboratorium/Detail/<id> (permintaan lab kunjungan ini; utama), cadangan Riwayat Lab →
 *        /Laboratorium/DetailRiwayat/<id> (tanggal "10 November 2026"). Tabel: Pemeriksaan | Hasil | Nilai Normal
 *        ("L: 14 - 16 ; P: 12 - 14 g/dl"). Menjawab 500 bila hasil belum diinput.
 *   tabel ISIAN DOKTER hanya ±655 px dari ±1390 px → panel Ringkasan MCU ditaruh di kolom kanan (lengket).
 * Aturan: hanya mengisi kotak yang masih KOSONG; tidak pernah menekan Simpan; Status Kunjungan tidak diubah.
 * Letak Interpretasi/Kesan/Saran (Pengaturan → Auto Fill → MCU):
 *   "rekomendasi" (bawaan, seperti isian MCU yang sudah ada): Diagnosa = daftar interpretasi + KESAN;
 *                 Rekomendasi Dokter = interpretasi + KESAN + SARAN.
 *   "template"  : di bawah Anamnesa; KESAN di bawah EKG. */
(async () => {
  if (!/\/Poli\/Mcu\/\d+/i.test(location.pathname)) return;
  const { isiCepat: ic = {} } = await chrome.storage.local.get('isiCepat');
  if (ic.mati || (ic.poliMati || {})['4mcu']) return;
  const N = nilaiAutofill(ic).mcu, M = window.MCU_SARAN, MODE = N.letakSaran === 'template' ? 'template' : 'rekomendasi';
  const $ = id => document.getElementById(id);
  const bersih = s => String(s == null ? '' : s).replace(/\s+/g, ' ').trim();
  /* kosong = belum diisi, termasuk penanda sementara "Menunggu hasil" yang biasa diketik pagi hari sebelum lab keluar */
  const kosong = v => !bersih(v) || /^[-–.]$/.test(bersih(v)) || /^menunggu(\s+hasil(\s+lab)?)?\.?$/i.test(bersih(v));
  const idKunjungan = (location.pathname.match(/\/Mcu\/(\d+)/) || [])[1];
  const TA = ['AmnesaDokter', 'KepalaMuka', 'Thorax', 'Abdomen', 'Extremitas', 'Ekg', 'Diagnosa', 'TataLaksana'];
  /* kotak teks tumbuh mengikuti isi (tidak ada gulir di dalam kotak) */
  const tinggi = el => { if (!el || el.tagName !== 'TEXTAREA') return; el.style.overflowY = 'hidden'; el.style.height = 'auto'; el.style.height = (el.scrollHeight + 2) + 'px'; };
  const setNilai = (el, v) => {
    const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto, 'value').set.call(el, v);
    ['input', 'change'].forEach(t => el.dispatchEvent(new Event(t, { bubbles: true })));
    tinggi(el);
  };
  const identitas = l => { const g = [...document.querySelectorAll('#IdentitasPasien_tab .form-group')].find(x => bersih((x.querySelector('.media-body') || {}).textContent) === l); return g ? bersih((g.querySelector('.col-md-8') || {}).textContent) : ''; };
  const pengkajian = l => { const r = [...document.querySelectorAll('#PengkajianAwal_tab tr')].find(x => bersih((x.cells[0] || {}).textContent) === l); return r ? bersih(r.cells[r.cells.length - 1].textContent).replace(/^:\s*/, '') : ''; };
  const nilai = id => { const el = $(id); return el ? bersih(el.value) : ''; };

  const nama = identitas('Nama Pasien'); if (nama) document.title = nama;   // sama seperti CPPT: nama pasien di judul tab

  /* ---------- data pasien untuk penyusun ---------- */
  function data(lab) {
    const bw = nilai('IsButaWarna').toLowerCase();
    return {
      jk: /perempuan|wanita/i.test(identitas('Jenis Kelamin')) ? 'P' : 'L', umur: parseInt(identitas('Umur'), 10) || null,
      tb: nilai('TinggiBadan'), bb: nilai('BeratBadan'), imt: nilai('Imt'), lp: nilai('LingkarPerut'),
      sis: nilai('Sistole'), dia: nilai('Diastole'), nadi: nilai('Nadi'), rr: nilai('Respirasi'), suhu: nilai('Suhu'), spo2: nilai('SaturasiO2'),
      visus: ($('SnallenChart') || {}).value || '', butaWarna: bw === 'true' ? true : bw === 'false' ? false : null,
      riwayat: [nilai('RiwayatPenyakit'), pengkajian('Riwayat Penyakit')].join(' '), lab: lab || {},
    };
  }

  /* ---------- hasil lab ---------- */
  const BULAN = { jan: 1, feb: 2, mar: 3, apr: 4, mei: 5, may: 5, jun: 6, jul: 7, agu: 8, agt: 8, aug: 8, sep: 9, okt: 10, oct: 10, nov: 11, des: 12, dec: 12 };
  function tanggalKe8(s) {                                                    // "10 November 2026" | "10-11-2026" | "2026-11-10" → "20261110"
    let m = s.match(/(\d{1,2})\s+([A-Za-z]{3,})\s+(\d{4})/);
    if (m && BULAN[m[2].slice(0, 3).toLowerCase()]) return m[3] + String(BULAN[m[2].slice(0, 3).toLowerCase()]).padStart(2, '0') + m[1].padStart(2, '0');
    m = s.match(/(\d{1,4})[-/](\d{1,2})[-/](\d{1,4})/); if (!m) return '';
    return m[1].length === 4 ? m[1] + m[2].padStart(2, '0') + m[3].padStart(2, '0') : m[3] + m[2].padStart(2, '0') + m[1].padStart(2, '0');
  }
  async function bacaHalamanLab(href) {
    const r = await fetch(href, { credentials: 'include', headers: { 'X-Requested-With': 'XMLHttpRequest' } });
    if (!r.ok) return null;
    const d = new DOMParser().parseFromString(await r.text(), 'text/html');
    const teks = [...d.querySelectorAll('tr')].map(tr => [...tr.cells].map(c => bersih(c.textContent)).join(' | ')).join('\n');
    return M.bacaLab(teks, data().jk);
  }
  async function ambilLabCcare() {
    let gagal = 0;
    /* 1. permintaan lab kunjungan ini (baris "Rujukan Lab" → Lihat Hasil Pemeriksaan) */
    const kini = document.querySelector('#IsianDokter_tab a[href*="/Laboratorium/Detail/"]');
    if (kini) { try { const lab = await bacaHalamanLab(kini.getAttribute('href')); if (lab && Object.keys(lab).length) return { status: 'ccare', lab }; if (!lab) gagal++; } catch (e) { gagal++; } }
    /* 2. cadangan: Riwayat Lab dengan tanggal terbaru */
    const baris = [...document.querySelectorAll('#RiwayatLab_tab tbody tr')].map(r => {
      const a = r.querySelector('a[href*="/Laboratorium/DetailRiwayat/"]'); return a ? { href: a.getAttribute('href'), t: tanggalKe8(bersih((r.cells[1] || {}).textContent)) } : null;
    }).filter(Boolean);
    if (!baris.length && !kini) return { status: 'tidak ada', lab: {} };
    const terbaru = baris.reduce((m, b) => (b.t > m ? b.t : m), '');
    const lab = {};
    for (const b of baris.filter(x => terbaru ? x.t === terbaru : x === baris[0])) {
      try { const l = await bacaHalamanLab(b.href); if (!l) { gagal++; continue; } Object.entries(l).forEach(([k, v]) => { if (!lab[k]) lab[k] = v; }); } catch (e) { gagal++; }
    }
    return { status: Object.keys(lab).length ? 'ccare' : gagal ? 'belum' : 'kosong', lab };
  }
  const kunciTempel = 'mcuLabTempel_' + idKunjungan;
  const labTempel = async () => { try { return (await chrome.storage.session.get(kunciTempel))[kunciTempel] || ''; } catch (e) { return ''; } };

  /* ---------- isi kerangka (hanya kotak kosong; paksa = Timpa ulang) ---------- */
  const isi = (id, v, paksa) => { const el = $(id); if (!el || el.readOnly || el.disabled || !v || (!paksa && !kosong(el.value))) return; setNilai(el, v); };
  const keluhan = pengkajian('Keluhan Utama'), alergi = identitas('Riwayat Alergi Obat');
  let pembuka = N.AmnesaDokter || '';
  if (keluhan && !/^(-|tidak ada|tidak ada keluhan|tak ada)$/i.test(keluhan)) pembuka = pembuka.split('\n')[0] + '\nKeluhan saat ini: ' + keluhan;
  if (alergi && !/^(-|tidak ada|tidak|disangkal)$/i.test(alergi)) pembuka += '\nRiwayat alergi obat : ' + alergi;
  function isiKerangka(paksa) {
    isi('AmnesaDokter', pembuka, paksa); isi('KepalaMuka', N.KepalaMuka, paksa); isi('Thorax', N.Thorax, paksa); isi('Abdomen', N.Abdomen, paksa);
    isi('Extremitas', N.Extremitas, paksa); isi('Ekg', N.Ekg, paksa); isi('TataLaksana', N.TataLaksana, paksa); isi('Diagnosa', 'Medical check up', paksa);
    const kp = $('KodePenyakit');                                          // ICD-10 template: ditambahkan bila belum ada (kode lain tidak dihapus)
    const teks = bersih(N.KodePenyakit), kode = teks.split('/')[0].trim().replace(/\./g, '');
    if (kp && kode && (paksa ? ![...kp.options].some(o => o.selected && o.value === kode) : ![...kp.options].some(o => o.selected && o.value))) {
      let o = [...kp.options].find(x => x.value === kode); if (!o) { o = new Option(teks, kode, true, true); kp.appendChild(o); }
      o.selected = true; kp.dispatchEvent(new Event('change', { bubbles: true }));
      if (window.jQuery) try { window.jQuery(kp).trigger('change'); } catch (e) {}
    }
  }
  isiKerangka(false);
  TA.forEach(id => { const el = $(id); if (el) { tinggi(el); el.addEventListener('input', () => tinggi(el)); } });

  /* ---------- menulis blok otomatis ---------- */
  const terakhir = {};                                       // teks otomatis terakhir per kotak — deteksi suntingan dokter
  const hilangkanTemplateTL = v => bersih(v) === bersih(N.TataLaksana) || bersih(v) === 'Medical check up' ? '' : v;
  /* ganti bagian "ekor" kotak mulai dari judul (re); bagian sebelumnya dipertahankan */
  function gantiEkor(id, re, ekor, nama, bersihkanKepala) {
    const el = $(id); if (!el) return false;
    const v = el.value, i = v.search(re);
    let kepala = (i >= 0 ? v.slice(0, i) : v).replace(/\s+$/, ''); if (bersihkanKepala) kepala = bersihkanKepala(kepala);
    const lama = i >= 0 ? v.slice(i).trim() : '';
    if (lama && lama !== (terakhir[id] || '').trim() && lama !== ekor.trim()
      && !confirm(`Bagian ${nama} di kotak ${({ Ekg: 'EKG', TataLaksana: 'Rekomendasi Dokter', AmnesaDokter: 'Anamnesa', Diagnosa: 'Diagnosa' })[id]} sudah berisi teks lain (mungkin suntingan Anda). Ganti dengan versi baru?`)) return false;
    setNilai(el, (kepala ? kepala + '\n\n' : '') + ekor); terakhir[id] = ekor; return true;
  }
  const kesanTeks = () => {                                  // Kesan yang sekarang tertulis (EKG pada mode template; Rekomendasi/Diagnosa pada mode rekomendasi)
    const v = (MODE === 'template' ? [$('Ekg')] : [$('TataLaksana'), $('Diagnosa')]).map(e => (e || {}).value || '').join('\n');
    const m = v.match(/KESAN\s*:\s*\n?\s*([^\n]+)/i); return m ? bersih(m[1]) : '';
  };
  let kesanPilihan = '';                                     // dipilih lewat panel / otomatis

  /* ---------- batas panjang: C-CARE Error 500 bila isian kepanjangan (Rekomendasi 1.712 karakter terbukti tersimpan) ---------- */
  const BATAS = Math.max(500, parseInt(N.batasKarakter, 10) || 1700);
  const tanda = x => x.startsWith('-') ? x : '- ' + x;
  const labAtauBelum = (h, singkat) => h.adaLab ? (singkat ? h.interpretasiLabSingkat : h.interpretasiLab) : '- Hasil laboratorium belum tersedia saat ringkasan ini disusun.';
  const TINGKAT = [                                                        // dari terlengkap ke teringkas
    { nama: 'lengkap', interp: h => [tanda(h.interpretasiFisik), labAtauBelum(h)].join('\n'), saran: h => h.saran },
    { nama: 'diet 1 baris', interp: h => [tanda(h.interpretasiFisik), labAtauBelum(h)].join('\n'), saran: h => h.saranDietSatuBaris },
    { nama: 'kalimat singkat', interp: h => [tanda(h.interpretasiFisikSingkat), labAtauBelum(h, true)].join('\n'), saran: h => h.saranDietSatuBaris },
    { nama: 'paling ringkas', interp: h => [tanda(h.interpretasiFisikSingkat), labAtauBelum(h, true)].join('\n'), saran: h => h.saranDietJudul },
  ];
  let tingkatTerpakai = '';
  function pilihTingkat(calon, tambahan = 0) {                            // tambahan = teks lain yang ikut di kotak yang sama
    const i = calon.findIndex(c => c.length + tambahan <= BATAS), k = i < 0 ? calon.length - 1 : i;
    tingkatTerpakai = k === 0 ? '' : TINGKAT[k].nama; return calon[k];
  }
  function blokRekomendasi(h, kesan) {
    const fisik = h.temuan.filter(t => t.kelompok === 'fisik'), labT = h.temuan.filter(t => t.kelompok === 'lab');
    /* Diagnosa: ringkas, gaya isian MCU klinik */
    const d = ['Interpretasi :'];
    if (!h.temuan.length && !(h.tipis || []).length) d.push(h.adaLab ? 'Pemeriksaan fisik dan laboratorium dalam batas normal' : 'Pemeriksaan fisik dalam batas normal');
    let n = 0; fisik.forEach(t => d.push(`${++n}. ${t.nama}`));
    if (labT.length || (h.tipis || []).length) {
      d.push(`${++n}. Laboratorium :`); labT.forEach(t => d.push(`- ${t.nama}${!t.ket ? '' : /\)$/.test(t.nama) ? `: ${t.ket}` : ` (${t.ket})`}`));
      if (!labT.length) d.push('- Tidak ada kelainan bermakna');
      if (h.tipis.length) d.push(`- Sedikit di luar rujukan, tidak bermakna secara klinis: ${h.tipis.join(', ')}`);
    }
    if (!h.adaLab) d.push(`${++n}. Laboratorium : hasil belum tersedia`);
    const diag = d.join('\n') + (kesan ? `\n\nKESAN :\n${kesan}` : '');
    /* Rekomendasi Dokter: interpretasi + KESAN + SARAN — versi terlengkap yang masih muat dalam batas karakter */
    const tl = pilihTingkat(TINGKAT.map(t => `Interpretasi :\n${t.interp(h)}` + (kesan ? `\n\nKESAN :\n${kesan}` : '') + `\n\nSARAN :\n${t.saran(h)}`));
    return { diag, tl };
  }
  /* timpa = true: interpretasi lama DIHAPUS dan diganti hasil baru tanpa bertanya (tombol "Timpa ulang"; ada Urungkan).
   * Kesan yang sudah dipilih dokter dipertahankan; pemeriksaan fisik & anamnesa pembuka tidak disentuh. */
  function tulisSaran(h, timpa) {
    const kesan = kesanPilihan || kesanTeks() || (h.kesan ? h.kesan.nilai : '');
    if (MODE === 'rekomendasi') {
      const b = blokRekomendasi(h, kesan);
      if (timpa) { setNilai($('TataLaksana'), b.tl); terakhir.TataLaksana = b.tl; setNilai($('Diagnosa'), b.diag); terakhir.Diagnosa = b.diag; }
      else {
        if (!gantiEkor('TataLaksana', /Interpretasi\s*:/i, b.tl, 'Interpretasi, Kesan & Saran', hilangkanTemplateTL)) return false;
        gantiEkor('Diagnosa', /Interpretasi\s*:/i, b.diag, 'Interpretasi & Kesan', v => bersih(v) === 'Medical check up' ? '' : v);
      }
    } else {
      const kepalaAnam = (($('AmnesaDokter').value.split(/\n*INTERPRETASI PEMERIKSAAN FISIK:|\n*INTERPRETASI LAB:|\n*SARAN\s*:/)[0]) || '').length + 2;
      const ekor = pilihTingkat(TINGKAT.map(t => {
        const fis = t.nama === 'lengkap' || t.nama === 'diet 1 baris' ? tanda(h.interpretasiFisik) : tanda(h.interpretasiFisikSingkat);
        return `INTERPRETASI PEMERIKSAAN FISIK:\n${fis}\n\nINTERPRETASI LAB:\n${labAtauBelum(h, !/lengkap|diet/.test(t.nama))}\n\nSARAN:\n${t.saran(h)}`;
      }), kepalaAnam);
      if (timpa) terakhir.AmnesaDokter = ($('AmnesaDokter').value.match(/(INTERPRETASI PEMERIKSAAN FISIK:|INTERPRETASI LAB:|SARAN\s*:)[\s\S]*$/) || [''])[0].trim();
      if (!gantiEkor('AmnesaDokter', /\n*INTERPRETASI PEMERIKSAAN FISIK:|\n*INTERPRETASI LAB:|\n*SARAN\s*:/, ekor, 'Interpretasi & Saran')) return false;
      const dg = $('Diagnosa');
      if (dg && (timpa || kosong(dg.value) || bersih(dg.value) === 'Medical check up' || bersih(dg.value) === bersih(terakhir.Diagnosa))) { setNilai(dg, h.diagnosa); terakhir.Diagnosa = h.diagnosa; }
      if (timpa) terakhir.Ekg = (($('Ekg').value.match(/KESAN\s*:[\s\S]*$/i)) || [''])[0].trim();
      if (kesan) tulisKesan(kesan, true);
    }
    if (kesan) kesanPilihan = kesan;
    return true;
  }
  /* KESAN: ganti/sisipkan tanpa menyentuh bagian lain */
  function tulisKesan(k, diam) {
    kesanPilihan = k;
    if (MODE === 'template') { gantiEkor('Ekg', /\n*KESAN\s*:/i, `KESAN : ${k}\n${M.KESAN[k]}`, 'Kesan'); }
    else ['Diagnosa', 'TataLaksana'].forEach(id => {
      const el = $(id); if (!el || !/Interpretasi\s*:/i.test(el.value)) return;
      let v = el.value;
      if (/KESAN\s*:\s*\n?[^\n]*/i.test(v)) v = v.replace(/KESAN\s*:\s*\n?[^\n]*/i, `KESAN :\n${k}`);
      else if (/\n*SARAN\s*:/i.test(v)) v = v.replace(/\n*SARAN\s*:/i, `\n\nKESAN :\n${k}\n\nSARAN :`);
      else v = v.replace(/\s+$/, '') + `\n\nKESAN :\n${k}`;
      setNilai(el, v); if (terakhir[id]) terakhir[id] = v.slice(v.search(/Interpretasi\s*:/i)).trim();
    });
    if (!diam) gambar();
  }

  /* ---------- tata letak: kolom kanan untuk panel (layar lebar), di atas tabel (layar sempit) ---------- */
  const tabelDokter = ($('AmnesaDokter') || {}).closest && $('AmnesaDokter').closest('table');
  if (!tabelDokter) return;
  const gaya = document.createElement('style');
  gaya.textContent = `
    .sjc-mcu{display:grid;grid-template-columns:minmax(0,1fr) 400px;gap:24px;align-items:start;clear:both}
    .sjc-mcu>.kiri{min-width:0}
    .sjc-mcu>.kiri>table{width:100%!important}
    .sjc-mcu>.kanan{position:sticky;top:16px}
    @media (max-width:1279px){.sjc-mcu{grid-template-columns:minmax(0,1fr)}.sjc-mcu>.kanan{position:static;order:-1}}`;
  document.head.appendChild(gaya);
  /* C-CARE asli: form-group > .col-md-6 (float, ±685 px) > .table-responsive > table — grid dipasang di luar kolom itu,
   * lebar kolom dilepas; tanpa kolom pembungkus (tiruan/versi lain) tabel sendiri yang dibungkus */
  const tab = document.getElementById('IsianDokter_tab');
  let kolom = tabelDokter.closest('[class*="col-md-"], [class*="col-sm-"], [class*="col-lg-"]');
  if (!kolom || (tab && !tab.contains(kolom))) kolom = tabelDokter;
  for (let x = tabelDokter; x && x !== kolom.parentElement; x = x.parentElement) { x.style.float = 'none'; x.style.width = '100%'; x.style.maxWidth = 'none'; x.style.flex = 'none'; }
  const bungkus = document.createElement('div'); bungkus.className = 'sjc-mcu';
  const kiri = document.createElement('div'); kiri.className = 'kiri';
  const kanan = document.createElement('div'); kanan.className = 'kanan';
  kolom.before(bungkus); kiri.appendChild(kolom); bungkus.append(kiri, kanan);
  TA.forEach(id => tinggi($(id)));                                           // lebar berubah → hitung ulang tinggi
  window.addEventListener('resize', () => TA.forEach(id => tinggi($(id))));

  const host = document.createElement('div'); kanan.appendChild(host);
  const R = host.attachShadow({ mode: 'open' });
  const IK = {
    awas: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M1 21h22L12 2 1 21zm12-3h-2v-2h2v2zm0-4h-2v-4h2v4z"/></svg>',
    galat: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/></svg>',
    ok: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm-2 15-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg>',
    centang: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 16.17 4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>',
    info: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/></svg>',
  };
  R.innerHTML = `<style>
    :host{all:initial;display:block}
    *{box-sizing:border-box}
    .p{--u:#263C92;--ut:#E8ECF7;--g:#D5E0E0;--pm:#E3EBEA;--is:#F2F6F6;--t:#0F2742;--t2:#4F6478;--m:#B91C1C;--k:#B45309;--h:#3B7A1E;
       font:14px/1.45 "Source Sans 3","Source Sans Pro",system-ui,"Segoe UI",sans-serif;color:var(--t);background:#fff;border:1px solid var(--g);border-radius:12px}
    svg{width:16px;height:16px;fill:currentColor;flex:none}
    .kp{display:flex;align-items:center;gap:8px;padding:10px 16px;border-bottom:1px solid var(--pm);white-space:nowrap}
    .kp b{font-size:15px}.kp .lab{margin-left:auto;display:inline-flex;align-items:center;gap:4px;font-size:13px;font-weight:600}
    .ciut{display:inline-flex;align-items:center;gap:2px;height:28px;padding:0 6px;border:1px solid var(--g);border-radius:8px;background:#fff;color:var(--t2);font-family:inherit;font-size:12px;font-weight:600;cursor:pointer}
    .ciut[aria-expanded=false] svg{transform:rotate(180deg)}
    .p.kecil .kp{border-bottom:0}.p.kecil .isi{display:none}
    .lab.ok{color:var(--h)}.lab.awas{color:var(--k)}
    .isi{padding:12px 16px;display:grid;gap:16px}
    .lbl{font-size:12px;font-weight:600;color:var(--t2);margin-bottom:6px}
    .chips{display:flex;flex-wrap:wrap;gap:8px}
    .c{display:inline-flex;align-items:center;gap:4px;min-height:28px;padding:2px 10px;border-radius:8px;font-size:13px;font-weight:600;border:1px solid}
    .c.r{color:var(--k);background:#FEF6E7;border-color:#F3D9A4}.c.b{color:var(--m);background:#FDECEC;border-color:#F3B9B9}.c.n{color:var(--h);background:#EEF6EA;border-color:#C9E1BD}
    .kesan{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px}
    .ks{position:relative;display:flex;align-items:center;gap:6px;min-height:36px;padding:6px 10px;border:1px solid var(--g);border-radius:8px;background:#fff;color:var(--t);font-family:inherit;font-size:13px;font-weight:600;line-height:1.2;cursor:pointer;text-align:left}
    .ks .ck{display:none;color:var(--u)}.ks[aria-pressed=true]{border-color:var(--u);background:var(--ut)}.ks[aria-pressed=true] .ck{display:inline}
    .ks.bahaya[aria-pressed=true]{border-color:var(--m);background:#FDECEC}.ks.bahaya[aria-pressed=true] .ck{color:var(--m)}
    .ks .tag{margin-left:auto;font-size:11px;font-weight:600;color:var(--u);border:1px solid var(--u);border-radius:6px;padding:0 5px;line-height:16px}
    .balon{grid-column:1/-1;position:relative;margin:4px 0 4px;padding:12px;border:1px solid var(--u);border-radius:12px;background:var(--ut)}
    .balon::before{content:"";position:absolute;top:-7px;left:var(--panah,24px);width:12px;height:12px;background:inherit;border-left:1px solid;border-top:1px solid;border-color:inherit;transform:rotate(45deg)}
    .balon.kuning{border-color:#E7B65C;background:#FEF6E7}.balon.merah{border-color:#E59A9A;background:#FDECEC}
    .balon .jd{display:flex;align-items:center;gap:6px;font-weight:600;margin-bottom:4px}
    .balon.kuning .jd{color:var(--k)}.balon.merah .jd{color:var(--m)}.balon .jd{color:var(--u)}
    .balon p{margin:0;font-size:13px;color:var(--t)}
    .balon .kaki{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-top:8px;font-size:12px;color:var(--t2)}
    .aksi{display:flex;gap:8px;flex-wrap:wrap;align-items:center}
    button.u,button.k{height:34px;padding:0 14px;border-radius:8px;font-family:inherit;font-size:13px;font-weight:600;line-height:1;cursor:pointer}
    button.u{background:var(--u);border:1px solid var(--u);color:#fff}button.k{background:#fff;border:1px solid var(--g);color:var(--u)}
    button.kc{height:28px;padding:0 10px}
    button:focus-visible{outline:2px solid var(--u);outline-offset:2px}
    textarea{width:100%;min-height:120px;padding:8px 10px;border:1px solid var(--g);border-radius:8px;background:var(--is);font:13px/1.4 ui-monospace,Consolas,monospace;color:var(--t);resize:vertical}
    .ket{font-size:12px;color:var(--t2)}
    .pesan{font-size:13px;color:var(--h);display:inline-flex;gap:4px;align-items:flex-start}
    .panjang{font-size:12px;color:var(--t2);display:inline-flex;gap:4px;align-items:flex-start;font-variant-numeric:tabular-nums}
    .panjang.lebih{color:var(--m);font-weight:600}
  </style>
  <div class="p">
    <div class="kp"><b>Ringkasan MCU</b><span class="lab" id="labStatus"></span>
      <button class="ciut" id="ciut" type="button" aria-expanded="true" title="Ciutkan panel"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7.41 15.41 12 10.83l4.59 4.58L18 14l-6-6-6 6z"/></svg><span>Ciutkan</span></button></div>
    <div class="isi" id="isiPanel">
      <div><div class="lbl">Temuan</div><div class="chips" id="temuan"></div></div>
      <div class="ket" id="tipis" hidden></div>
      <div><div class="lbl">Kesan (status kebugaran)</div><div class="kesan" id="kesan" role="group" aria-label="Kesan MCU"></div></div>
      <div class="aksi"><button class="u" id="susun" type="button">Susun interpretasi &amp; saran</button>
        <button class="k" id="timpa" type="button" title="Ganti semua isian dokter (anamnesa, pemeriksaan fisik, EKG, Diagnosa, Rekomendasi) dengan isi otomatis baru">Timpa ulang</button>
        <button class="k" id="urung" type="button" hidden>Urungkan</button>
        <button class="k" id="bukaTempel" type="button" aria-expanded="false">Tempel hasil lab</button>
        <button class="k" id="periksa" type="button">Periksa lab lagi</button></div>
      <span class="panjang" id="panjang" role="status"></span>
      <span class="pesan" id="pesan" role="status"></span>
      <div id="tempel" hidden><div class="lbl">Hasil lab (salin dari lembar hasil lab, satu pemeriksaan per baris)</div>
        <textarea id="teksLab" spellcheck="false" placeholder="Glukosa Puasa  112  mg/dL  70 - 99&#10;Kolesterol Total  236  mg/dL"></textarea>
        <div class="aksi" style="margin-top:8px"><button class="u" id="pakai" type="button">Pakai hasil ini</button><span class="ket">Hanya disimpan di memori browser sampai Chrome ditutup.</span></div></div>
    </div>
  </div>`;
  const q = s => R.querySelector(s);
  /* ciutkan/buka panel — diingat per komputer */
  const aturCiut = kecil => { q('.p').classList.toggle('kecil', kecil); const t = q('#ciut'); t.setAttribute('aria-expanded', !kecil); t.title = kecil ? 'Buka panel' : 'Ciutkan panel'; t.querySelector('span').textContent = kecil ? 'Buka' : 'Ciutkan'; };
  let awalKecil = false; try { awalKecil = localStorage.getItem('sjcMcuCiut') === '1'; } catch (e) {}
  aturCiut(awalKecil);
  q('#ciut').onclick = () => { const k = !q('.p').classList.contains('kecil'); aturCiut(k); try { localStorage.setItem('sjcMcuCiut', k ? '1' : '0'); } catch (e) {} };
  const KESAN_URUT = [['Fit to work', ''], ['Fit with restriction', ''], ['Temporary unfit', 'bahaya'], ['Permanent unfit', 'bahaya']];
  let labNow = {}, sumber = 'belum', hasil = null;

  let gambar = function () {
    hasil = M.susun(data(labNow));
    const st = q('#labStatus'), n = Object.keys(labNow).length;
    st.className = 'lab ' + (n ? 'ok' : 'awas');
    st.innerHTML = n ? `${IK.ok}<span>${n} lab ${sumber === 'tempel' ? 'ditempel' : 'terbaca'}</span>`
      : `${IK.awas}<span>${sumber === 'tidak ada' ? 'Tanpa lab' : 'Lab belum ada'}</span>`;
    q('#temuan').innerHTML = hasil.temuan.length ? hasil.temuan.map(t => `<span class="c ${t.berat === 'bermakna' ? 'b' : 'r'}">${t.berat === 'bermakna' ? IK.galat : IK.awas}${t.nama}</span>`).join('')
      : `<span class="c n">${IK.ok}Tidak ada temuan${n ? '' : ' (tanpa lab)'}</span>`;
    const tp = q('#tipis'); tp.hidden = !hasil.tipis.length;
    tp.textContent = hasil.tipis.length ? `Zona toleransi (tidak dijadikan temuan): ${hasil.tipis.join(' · ')}` : '';
    const pilih = (kesanTeks() || '').toLowerCase(), rk = hasil.rekom;
    /* balon (status kebugaran yang disarankan + alasannya) disisipkan tepat di bawah baris pilihan yang disarankan, panah menunjuk pilihan itu */
    const idx = KESAN_URUT.findIndex(([k]) => k === rk.nilai), kolom = idx % 2, baris = Math.floor(idx / 2);
    q('#kesan').innerHTML = KESAN_URUT.map(([k, c], i) => `<button type="button" class="ks ${c}" data-k="${k}" style="order:${Math.floor(i / 2) * 2}" aria-pressed="${pilih === k.toLowerCase()}"><span class="ck">${IK.centang}</span><span>${k}</span>${rk.nilai === k ? '<span class="tag">Saran</span>' : ''}</button>`).join('')
      + `<div class="balon" id="balon" role="note" style="order:${baris * 2 + 1}"></div>`;
    q('#kesan').querySelectorAll('.ks').forEach(b => b.onclick = () => tulisKesan(b.dataset.k));
    const b = q('#balon'), warna = rk.nilai === 'Fit to work' ? '' : rk.nilai === 'Fit with restriction' ? 'kuning' : 'merah';
    b.className = 'balon ' + warna;
    b.style.setProperty('--panah', kolom ? 'calc(50% + 28px)' : '28px');
    const sudah = pilih === rk.nilai.toLowerCase();
    b.innerHTML = `<div class="jd">${warna === 'merah' ? IK.galat : warna === 'kuning' ? IK.awas : IK.info}<span>Saran: ${rk.nilai}</span></div>
      <p>${rk.alasan}</p>
      <div class="kaki">${sudah ? `${IK.centang}<span>Sudah dipakai sebagai Kesan.</span>` : `<button class="u kc" type="button" id="pakaiKesan">Pakai saran ini</button>`}
        <span>${hasil.bermakna.length ? 'Ada temuan bermakna — Kesan tidak diisi otomatis. ' : ''}Keputusan akhir tetap dokter; sesuaikan dengan jenis pekerjaan peserta.</span></div>`;
    const tb = q('#pakaiKesan'); if (tb) tb.onclick = () => tulisKesan(rk.nilai);
  };
  const kabar = t => { const e = q('#pesan'); e.innerHTML = t ? IK.centang + '<span>' + t + '</span>' : ''; if (t) setTimeout(() => { e.innerHTML = ''; }, 6000); };

  async function muatLab() {
    const t = await labTempel();
    if (t) { labNow = M.bacaLab(t, data().jk); sumber = 'tempel'; q('#teksLab').value = t; }
    else { const r = await ambilLabCcare(); labNow = r.lab; sumber = r.status === 'ccare' ? 'ccare' : r.status; }
    gambar();
  }
  q('#susun').onclick = () => { if (tulisSaran(M.susun(data(labNow)))) { gambar(); kabar(MODE === 'rekomendasi' ? 'Ditulis di Diagnosa & Rekomendasi Dokter — periksa sebelum Simpan.' : 'Ditulis di Anamnesa & EKG — periksa sebelum Simpan.'); } };
  /* Timpa ulang: simpan salinan kotak dulu → bisa Urungkan selama halaman belum dimuat ulang */
  let salinan = null;
  /* Timpa ulang = SEMUA isian dokter diganti: anamnesa pembuka, pemeriksaan fisik (Kepala Muka, Thorax, Abdomen,
   * Ekstremitas), EKG, Rekomendasi, Diagnosa + interpretasi/saran baru. Kesan yang sudah dipilih tetap dipakai. */
  q('#timpa').onclick = () => {
    salinan = TA.map(id => [id, ($(id) || {}).value]);
    const kesanLama = kesanPilihan || kesanTeks();
    Object.keys(terakhir).forEach(k => delete terakhir[k]);
    isiKerangka(true); kesanPilihan = kesanLama;
    if (tulisSaran(M.susun(data(labNow)), true)) {
      gambar(); q('#urung').hidden = false;
      kabar('Ditimpa: anamnesa, pemeriksaan fisik, EKG, Diagnosa, Rekomendasi Dokter & interpretasi diganti isi baru. Salah? Tekan Urungkan.');
    }
  };
  q('#urung').onclick = () => {
    if (!salinan) return;
    salinan.forEach(([id, v]) => { const el = $(id); if (el && v != null) setNilai(el, v); });
    salinan = null; Object.keys(terakhir).forEach(k => delete terakhir[k]); kesanPilihan = '';
    q('#urung').hidden = true; gambar(); kabar('Dikembalikan ke isi sebelum ditimpa.');
  };
  q('#bukaTempel').onclick = () => { const b = q('#tempel'), on = b.hidden; b.hidden = !on; q('#bukaTempel').setAttribute('aria-expanded', on); if (on) q('#teksLab').focus(); };
  q('#periksa').onclick = async () => { await chrome.storage.session.remove(kunciTempel).catch(() => {}); q('#teksLab').value = ''; await muatLab(); kabar(Object.keys(labNow).length ? 'Hasil lab terbaca.' : 'Hasil lab belum tersedia.'); };
  q('#pakai').onclick = async () => {
    const t = q('#teksLab').value; const lab = M.bacaLab(t, data().jk);
    if (!Object.keys(lab).length) return kabar('Tidak ada pemeriksaan yang dikenali.');
    await chrome.storage.session.set({ [kunciTempel]: t }).catch(() => {});
    labNow = lab; sumber = 'tempel'; gambar(); q('#tempel').hidden = true; q('#bukaTempel').setAttribute('aria-expanded', false);
    kabar(`${Object.keys(lab).length} pemeriksaan dikenali. Tekan "Susun interpretasi & saran".`);
  };
  ['Ekg', 'Diagnosa', 'TataLaksana'].forEach(id => $(id) && $(id).addEventListener('input', () => { const p = kesanTeks().toLowerCase(); q('#kesan').querySelectorAll('.ks').forEach(b => b.setAttribute('aria-pressed', p === b.dataset.k.toLowerCase())); }));

  /* pengaman Simpan: kotak yang melebihi batas → konfirmasi dulu (Error 500 di C-CARE membuat isian hilang) */
  const formMcu = $('AmnesaDokter').form;
  if (formMcu) formMcu.addEventListener('submit', e => {
    const lebih = TA.map(id => [id, (($(id) || {}).value || '').length]).filter(([, n]) => n > BATAS);
    if (!lebih.length) return;
    const nama = { AmnesaDokter: 'Anamnesa', KepalaMuka: 'Kepala Muka', Thorax: 'Thorax', Abdomen: 'Abdomen', Extremitas: 'Ekstremitas', Ekg: 'EKG', Diagnosa: 'Diagnosa', TataLaksana: 'Rekomendasi Dokter' };
    const daftar = lebih.map(([id, n]) => `${nama[id]} ${n.toLocaleString('id-ID')} karakter`).join(', ');
    if (!confirm(`${daftar} — melebihi batas aman ${BATAS.toLocaleString('id-ID')} karakter.\n\nC-CARE bisa gagal menyimpan (Error 500) dan isian yang sudah diketik hilang. Tekan Batal lalu ringkas teksnya, atau OK untuk tetap menyimpan.`)) {
      e.preventDefault(); e.stopImmediatePropagation();
      const el = $(lebih[0][0]); if (el) { el.scrollIntoView({ block: 'center' }); el.focus(); }
    }
  }, true);
  function gambarPanjang() {                                                // penghitung karakter kotak terpanjang di panel
    const [id, n] = TA.map(i => [i, (($(i) || {}).value || '').length]).sort((a, b) => b[1] - a[1])[0];
    const e = q('#panjang'); if (!e) return;
    const lebih = n > BATAS, nama = id === 'TataLaksana' ? 'Rekomendasi' : id === 'AmnesaDokter' ? 'Anamnesa' : id;
    e.className = 'panjang ' + (lebih ? 'lebih' : '');
    e.innerHTML = `${lebih ? IK.awas : IK.info}<span>${nama}: ${n.toLocaleString('id-ID')} / ${BATAS.toLocaleString('id-ID')} karakter${tingkatTerpakai && !lebih ? ' · diringkas agar muat' : ''}${lebih ? ' — terlalu panjang, bisa gagal disimpan' : ''}</span>`;
  }
  TA.forEach(id => $(id) && $(id).addEventListener('input', gambarPanjang));
  const gambarAsli = gambar; gambar = function () { gambarAsli(); gambarPanjang(); };

  gambar();
  await muatLab();
  /* otomatis: begitu hasil lab terbaca dan interpretasi belum pernah ditulis */
  function otomatis() {
    if (N.saranOtomatis === '0' || !Object.keys(labNow).length) return;
    const nilaiDari = id => (($(id) || {}).value || '');
    const sudahAda = MODE === 'rekomendasi' ? /Interpretasi\s*:/i.test(nilaiDari('TataLaksana') + nilaiDari('Diagnosa')) : /INTERPRETASI|SARAN\s*:/.test(nilaiDari('AmnesaDokter'));
    if (!sudahAda) {
      if (tulisSaran(M.susun(data(labNow)))) { gambar(); kabar('Interpretasi & saran disusun otomatis — periksa sebelum Simpan.'); }
      return;
    }
    /* interpretasi lama disusun SEBELUM lab keluar ("hasil … belum tersedia") → sekarang lab ada: perbarui interpretasinya
     * (pemeriksaan fisik & anamnesa tidak disentuh; bisa Urungkan). Interpretasi tulisan dokter sendiri tidak disentuh. */
    const kotakLama = MODE === 'rekomendasi' ? ['TataLaksana', 'Diagnosa'] : ['AmnesaDokter', 'Diagnosa'];
    if (kotakLama.some(id => /hasil\s+(laboratorium\s+)?belum\s+tersedia/i.test(nilaiDari(id)))) {
      salinan = TA.map(id => [id, ($(id) || {}).value]);
      kesanPilihan = kesanTeks();
      if (tulisSaran(M.susun(data(labNow)), true)) { gambar(); q('#urung').hidden = false; kabar('Hasil lab sudah keluar — interpretasi & saran diperbarui otomatis. Salah? Tekan Urungkan.'); }
    }
  }
  otomatis();
  /* lab belum keluar saat halaman dibuka → cek ulang tiap 1 menit (maks. 20 menit, hanya saat tab terlihat) */
  if (!Object.keys(labNow).length && sumber !== 'tempel') {
    let kali = 0;
    const jam = setInterval(async () => {
      if (document.hidden) return;
      if (++kali > 20 || sumber === 'tempel' || Object.keys(labNow).length) return clearInterval(jam);
      await muatLab();
      if (Object.keys(labNow).length) { clearInterval(jam); otomatis(); }
    }, 60000);
  }
})();
