/* Alvisya Dokter v4.7.0 — Cek ICD-10 di CPPT: peringatan halus (tidak memblokir Simpan) bila
 *  1) kode yang dipilih tidak nyambung dengan kata kunci keluhan/anamnesa (kemungkinan salah klik), atau
 *  2) kode berformat ICD-10-CM Amerika (≥ 5 karakter) — PCare memakai ICD-10 WHO (maks. 4 karakter, mis. L03.1).
 * Hanya membaca isian di halaman; tidak mengirim apa pun. */
(() => {
  /* ---------- logika (murni, diuji di Node) ---------- */
  const KELUHAN = [   // kata kunci keluhan → sistem
    ['napas', /batuk|pilek|flu\b|tenggor|radang|sesak|dahak|amandel|bersin|hidung|ispa|nafas|napas/],
    ['demam', /demam|meriang|panas badan|febris/],
    ['kepala', /pusing|sakit kepala|nyeri kepala|migr[ae]n|vertigo|kleyengan|cenut|kepala/],
    ['cerna', /mual|muntah|diare|mencret|perut|lambung|ulu hati|ma+g+h?\b|bab\b|buang air besar|mulas|kembung|asam lambung|dispeps|wasir|ambeien/],
    ['hati', /kuning|ikter|urin (warna )?coklat|air kencing (seperti )?teh|hepatitis|hbsag|sgot|sgpt/],
    ['kemih', /kencing|\bbak\b|anyang|urin|berkemih/],
    ['kulit', /gatal|merah|ruam|bintik|biduran|luka|bisul|bernanah|nanah|kulit|jerawat|panu|kurap|eksim|alergi|lecet|bengkak/],
    ['otot', /sendi|pinggang|punggung|bahu|lutut|leher|pegal|linu|kram|kaku|belikat|tumit|jempol|jari|otot|keseleo|terkilir|tangan|kaki|lengan|paha|betis/],
    ['saraf', /kesemutan|kebas|baal|lemah sebelah|kejang|pingsan/],
    ['telinga', /telinga|kuping|dengar|denging/],
    ['mata', /\bmata\b|penglihatan|buram|kabur|belekan|kelilipan/],
    ['gigi', /gigi|gusi|sariawan|mulut|bibir|lidah/],
    ['td', /\bht\b|hipertensi|tensi|darah tinggi|jantung|dada|berdebar|nitro/],
    ['endokrin', /\bdm\b|gula|diabetes|kencing manis|tiroid|kolesterol|asam urat/],
    ['jiwa', /cemas|depresi|stres|tidak bisa tidur|insomnia|gelisah|panik/],
    ['cedera', /terkena|jatuh|pukul|air panas|luka bakar|tersiram|cedera|kecelakaan|terbentur|tergores|teriris|digigit|tertusuk/],
    ['genital', /testis|buah zakar|skrotum|kemaluan|penis|keputihan|haid|menstruasi|vagina/],
    ['umum', /lemas|lemah|tidak enak badan|kontrol|cek|konsul|surat|vaksin|imunisasi|rujuk|mcu|medical/],
  ];
  /* kode → sistem yang masuk akal; null = umum (tidak diperiksa) */
  function sistemKode(k) {
    const h = k[0], n = parseInt(k.slice(1, 3), 10);
    if (h === 'J') return ['napas', 'demam'];
    if (h === 'K') return n <= 14 ? ['gigi'] : n >= 70 && n <= 87 ? ['cerna', 'hati'] : ['cerna'];
    if (h === 'A') return n <= 9 ? ['cerna', 'demam'] : n >= 15 && n <= 19 ? ['napas', 'demam'] : n >= 90 && n <= 99 ? ['demam'] : null;
    if (h === 'B') return n <= 9 ? ['kulit', 'demam', 'gigi'] : n >= 15 && n <= 19 ? ['hati', 'cerna'] : n >= 35 && n <= 89 ? ['kulit', 'cerna'] : null;
    if (h === 'L') return ['kulit'];
    if (h === 'M') return ['otot', 'saraf'];
    if (h === 'G') return n >= 43 && n <= 44 ? ['kepala'] : n >= 50 && n <= 59 ? ['saraf', 'otot'] : ['saraf', 'kepala'];
    if (h === 'H') return n <= 59 ? ['mata'] : ['telinga', 'kepala'];
    if (h === 'I') return ['td', 'kepala', 'otot'];
    if (h === 'E') return ['endokrin'];
    if (h === 'F') return ['jiwa', 'kepala'];
    if (h === 'N') return n >= 30 && n <= 39 ? ['kemih', 'cerna'] : n >= 40 && n <= 53 ? ['genital'] : n >= 70 && n <= 98 ? ['genital', 'cerna'] : ['kemih'];
    if (h === 'S' || h === 'T') return ['cedera'];
    if (h === 'Q') return ['bawaan'];
    if (h === 'R') {
      if (n <= 9) return ['napas', 'td'];
      if (n <= 19) return ['cerna', 'hati'];
      if (n === 20) return ['saraf', 'otot'];
      if (n >= 21 && n <= 23) return ['kulit'];
      if (n >= 30 && n <= 39) return ['kemih'];
      if (n === 42 || n === 51) return ['kepala'];
      if (n === 50) return ['demam'];
      return null;                                                    // R52–R99: gejala umum
    }
    return null;                                                      // Z, O, P, C, D, U, W–Y: tidak diperiksa
  }
  /* kode yang butuh bukti khusus di teks */
  const KHUSUS = [
    [/^B17\.?1|^B18\.?2/, /hepatitis c|hcv/, 'butuh bukti hepatitis C (anti-HCV)'],
    [/^Q/, /bawaan|sejak lahir|kongenital/, 'kelainan bawaan — tidak ada keterangan "sejak lahir/bawaan"'],
    [/^G56\.?0/, /kesemutan|kebas|baal|pergelangan|malam/, 'sindrom terowongan karpal biasanya disertai kesemutan/kebas'],
  ];
  const NAMA = { napas: 'saluran napas', demam: 'demam', kepala: 'kepala', cerna: 'pencernaan', hati: 'hati', kemih: 'saluran kemih', kulit: 'kulit', otot: 'otot/sendi', saraf: 'saraf', telinga: 'telinga', mata: 'mata', gigi: 'gigi/mulut', td: 'jantung/tekanan darah', endokrin: 'endokrin', jiwa: 'kejiwaan', cedera: 'cedera', genital: 'genital/reproduksi', bawaan: 'kelainan bawaan' };
  const titik = k => k.length > 3 ? k.slice(0, 3) + '.' + k.slice(3) : k;

  function periksaIcd(teks, kodeList) {
    const t = String(teks || '').toLowerCase().replace(/riwayat alergi( obat)?\s*:[^.\n]*/g, ' ').replace(/\bao\s*:[^,.\n]*/g, ' '), hasil = [];   // alergi obat bukan keluhan kulit
    const sis = new Set(KELUHAN.filter(([, re]) => re.test(t)).map(([s]) => s));
    const umum = sis.has('umum'); sis.delete('umum');
    kodeList.forEach(raw => {
      const k = String(raw || '').toUpperCase().replace(/[^A-Z0-9]/g, ''); if (!/^[A-Z]\d{2}/.test(k)) return;
      if (k.length >= 5) hasil.push({ kode: titik(k), jenis: 'cm', pesan: `${titik(k)} berformat ICD-10-CM (Amerika); PCare memakai ICD-10 WHO, mis. ${titik(k.slice(0, 4))}` });
      const kh = KHUSUS.find(([re]) => re.test(k));
      if (kh && !kh[1].test(t)) { hasil.push({ kode: titik(k), jenis: 'cocok', pesan: `${titik(k)}: ${kh[2]}` }); return; }
      const ks = sistemKode(k);
      if (!ks || !sis.size || umum && !ks.includes('cedera') && !ks.includes('bawaan')) return;   // tidak bisa dinilai
      if (!ks.some(s => sis.has(s))) hasil.push({ kode: titik(k), jenis: 'cocok', pesan: `${titik(k)} (${NAMA[ks[0]]}) tidak nyambung dengan keluhan (${[...sis].map(s => NAMA[s]).join(', ')})` });
    });
    return hasil;
  }
  if (typeof module !== 'undefined') { module.exports = { periksaIcd }; return; }

  /* ---------- tampilan di CPPT ---------- */
  if (window.__sjcIcdCek) return; window.__sjcIcdCek = true;
  const kp = document.getElementById('KodePenyakit'); if (!kp) return;
  let aktif = true;
  chrome.storage.local.get(['isiCepat', 'cekIcd'], s => { aktif = !((s.isiCepat || {}).mati) && s.cekIcd !== false; cek(); });
  const kotak = document.createElement('div');
  kotak.setAttribute('role', 'status'); kotak.hidden = true;
  kotak.style.cssText = 'margin:6px 0 0;padding:8px 10px;border:1px solid #F3D19C;border-radius:8px;background:#FEF6E7;color:#7A3E06;font:13px/1.45 "Source Sans 3","Source Sans Pro",system-ui,sans-serif';
  const sesudah = (kp.nextElementSibling && /select2/.test(kp.nextElementSibling.className)) ? kp.nextElementSibling : kp;
  sesudah.after(kotak);
  const IK = '<svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true" style="flex:none;fill:#B45309;margin-top:1px"><path d="M1 21h22L12 2 1 21zm12-3h-2v-2h2v2zm0-4h-2v-4h2v4z"/></svg>';
  const esc = s => String(s).replace(/[&<>]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));
  function cek() {
    if (!aktif) { kotak.hidden = true; return; }
    const teks = ['Keluhan', 'AmnesaDokter'].map(id => (document.getElementById(id) || {}).value || '').join(' ');
    const kode = [...kp.options].filter(o => o.selected && o.value).map(o => o.value);
    const h = periksaIcd(teks, kode);
    kotak.hidden = !h.length;
    kotak.innerHTML = h.map(x => `<div style="display:flex;gap:6px;align-items:flex-start">${IK}<span><b>Periksa kode</b> · ${esc(x.pesan)}</span></div>`).join('');
  }
  let tunda = null; const nanti = () => { clearTimeout(tunda); tunda = setTimeout(cek, 300); };
  kp.addEventListener('change', nanti);
  document.addEventListener('isicepat-ubah', nanti);
  ['Keluhan', 'AmnesaDokter'].forEach(id => { const el = document.getElementById(id); if (el) el.addEventListener('input', nanti); });
  setInterval(cek, 3000);   // select2 kadang tidak memicu 'change' di dunia ekstensi
  chrome.storage.onChanged.addListener((c, a) => { if (a === 'local' && (c.isiCepat || c.cekIcd)) chrome.storage.local.get(['isiCepat', 'cekIcd'], s => { aktif = !((s.isiCepat || {}).mati) && s.cekIcd !== false; cek(); }); });
})();
