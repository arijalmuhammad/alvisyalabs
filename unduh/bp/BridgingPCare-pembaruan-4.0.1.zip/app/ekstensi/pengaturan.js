// Pengaturan Bridging PCare: login otomatis (password di aplikasi Windows, DPAPI), log, pembaruan
const $ = (s, r = document) => r.querySelector(s);
const HOST = "id.alvisya.bridging_pcare";
const VERSI = chrome.runtime.getManifest().version;

function host(pesan) {
  return new Promise((res) => {
    chrome.runtime.sendNativeMessage(HOST, pesan, (r) => {
      if (chrome.runtime.lastError) res({ ok: false, tanpaHost: true, pesan: chrome.runtime.lastError.message });
      else res(r || { ok: false, pesan: "tidak ada jawaban" });
    });
  });
}
const tulis = (el, teks, ok) => { el.textContent = teks; el.className = (el.className.replace(/\b(ok|salah)\b/g, "") + (ok === true ? " ok" : ok === false ? " salah" : "")).trim(); };
const duaKali = (btn, aksi) => {
  if (btn.dataset.yakin === "1") { btn.dataset.yakin = ""; btn.textContent = btn.dataset.asli; aksi(); return; }
  btn.dataset.asli = btn.textContent; btn.dataset.yakin = "1"; btn.textContent = "Klik lagi untuk yakin";
  setTimeout(() => { if (btn.dataset.yakin === "1") { btn.dataset.yakin = ""; btn.textContent = btn.dataset.asli; } }, 4000);
};

async function muat() {
  const info = await host({ cmd: "info" });
  if (!info.ok) {
    $("#peringatan-host").hidden = false;
    $("#pesan-host").textContent = info.pesan || "";
    $("#versi").textContent = `Bot v${VERSI} · aplikasi belum terhubung`;
  } else {
    $("#versi").textContent = `Aplikasi v${info.versi} · bot v${VERSI} · ${info.folder}`;
    $("#url-pembaruan").value = info.urlPembaruan || "";
  }
  for (const kotak of document.querySelectorAll(".akun")) {
    const situs = kotak.dataset.situs;
    // v3.4.1: tiga mode — Mati / Isi saja / Isi + Masuk
    const o = await chrome.storage.local.get(["autoLogin_" + situs, "loginKlik_" + situs]);
    const radio = [...kotak.querySelectorAll(".mode input")];
    radio.forEach((x) => (x.name = "mode-" + situs));
    const modeKini = !o["autoLogin_" + situs] ? "mati" : o["loginKlik_" + situs] === false ? "isi" : "masuk";
    const pasangMode = (m) => radio.forEach((x) => (x.checked = x.value === m));
    pasangMode(modeKini);
    const ada = info.ok && info.kred && info.kred[situs];
    tulis($(".status", kotak), ada ? "Password tersimpan (terenkripsi Windows). Isi ulang untuk mengganti." : "Belum ada password tersimpan.", ada ? true : undefined);
    radio.forEach((x) => (x.onchange = async () => {
      if (!x.checked) return;
      const m = x.value;
      if (m !== "mati" && !ada && !kotak.dataset.baruSimpan) { pasangMode("mati"); return tulis($(".status", kotak), "Simpan nama pengguna & password dulu.", false); }
      await chrome.storage.local.set({ ["autoLogin_" + situs]: m !== "mati", ["loginKlik_" + situs]: m === "masuk", ["loginDijeda_" + situs]: null, ["loginCoba_" + situs]: [] });
      tulis($(".status", kotak), m === "mati" ? "Login otomatis dimatikan." : m === "isi" ? "Nama pengguna & password diisi otomatis; Anda yang klik Masuk." : "Bot mengisi lalu klik Masuk.", true);
    }));
    $(".simpan", kotak).onclick = async () => {
      const user = $(".user", kotak).value.trim(), pass = $(".pass", kotak).value;
      if (!user || !pass) return tulis($(".status", kotak), "Isi nama pengguna dan password dulu.", false);
      const r = await host({ cmd: "kredSimpan", situs, user, pass });
      $(".pass", kotak).value = "";
      if (r.ok) { kotak.dataset.baruSimpan = "1";
        const tetap = radio.find((x) => x.checked && x.value !== "mati");
        const m = tetap ? tetap.value : "masuk";
        await chrome.storage.local.set({ ["autoLogin_" + situs]: true, ["loginKlik_" + situs]: m === "masuk", ["loginCoba_" + situs]: [], ["loginDijeda_" + situs]: null }); pasangMode(m);
        tulis($(".status", kotak), m === "isi" ? "Tersimpan terenkripsi. Mode: Isi saja." : "Tersimpan terenkripsi. Mode: Isi + Masuk.", true); }
      else tulis($(".status", kotak), r.pesan, false);
    };
    $(".hapus", kotak).onclick = () => duaKali($(".hapus", kotak), async () => {
      const r = await host({ cmd: "kredHapus", situs });
      await chrome.storage.local.set({ ["autoLogin_" + situs]: false }); pasangMode("mati"); delete kotak.dataset.baruSimpan;
      tulis($(".status", kotak), r.ok ? "Password dihapus. Login otomatis dimatikan." : r.pesan, r.ok);
    });
  }
}

// ---------- log ----------
$("#salin-log").onclick = async () => {
  const r = await host({ cmd: "logBaca", n: 800 });
  let teks = r.ok ? r.teks : "";
  if (!r.ok) {   // aplikasi belum terpasang: log cadangan di Chrome
    teks = ((await chrome.storage.local.get("logCadangan")).logCadangan || []).slice(-800).join("\n");
  }
  teks = `=== Log Bridging PCare (ekstensi v${VERSI}) · disalin ${new Date().toLocaleString("id-ID")} ===\n` + (teks || "(log kosong)");
  $("#isi-log").value = teks;
  try { await navigator.clipboard.writeText(teks); tulis($("#pesan-log"), "Tersalin. Tempel (Ctrl+V) di chat Claude.", true); }
  catch (e) { $("#isi-log").select(); tulis($("#pesan-log"), "Teks sudah dipilih: tekan Ctrl+C untuk menyalin.", undefined); }
};
$("#buka-log").onclick = async () => { const r = await host({ cmd: "bukaFolder", apa: "log" }); if (!r.ok) tulis($("#pesan-log"), r.pesan, false); };
$("#buka-ekstensi").onclick = async () => { const r = await host({ cmd: "bukaFolder", apa: "ekstensi" }); if (!r.ok) tulis($("#pesan-update"), r.pesan, false); };

// ---------- pembaruan ----------
async function selesaiPasang(r) {
  if (!r.ok) return tulis($("#pesan-update"), r.pesan, false);
  tulis($("#pesan-update"), `${r.pesan} Memulai ulang aplikasi…`, true);
  chrome.runtime.sendMessage({ type: "muatUlangEkstensi" });
}
$("#file-zip").onchange = async (e) => {
  const f = e.target.files[0]; if (!f) return;
  if (f.size > 40 * 1024 * 1024) return tulis($("#pesan-update"), "File terlalu besar.", false);
  tulis($("#pesan-update"), `Memasang ${f.name}…`);
  const b64 = await new Promise((res) => { const fr = new FileReader(); fr.onload = () => res(String(fr.result).split(",")[1] || ""); fr.readAsDataURL(f); });
  selesaiPasang(await host({ cmd: "pasangZip", b64 }));
  e.target.value = "";
};
$("#simpan-url").onclick = async () => {
  const url = $("#url-pembaruan").value.trim();
  if (url && !/^https:\/\//.test(url)) return tulis($("#pesan-update"), "Alamat harus diawali https://", false);
  const r = await host({ cmd: "aturUrl", url });
  tulis($("#pesan-update"), r.ok ? "Alamat pembaruan disimpan." : r.pesan, r.ok);
};
$("#cek").onclick = async () => {
  tulis($("#pesan-update"), "Mengecek…");
  const r = await host({ cmd: "cekPembaruan" });
  if (!r.ok) return tulis($("#pesan-update"), r.pesan, false);
  $("#pasang-online").hidden = !r.lebihBaru;
  tulis($("#pesan-update"), r.lebihBaru ? `Ada versi ${r.versiBaru}. ${r.catatan || ""}` : `Sudah versi terbaru (${VERSI}).`, r.lebihBaru ? undefined : true);
};
$("#pasang-online").onclick = async () => { tulis($("#pesan-update"), "Mengunduh & memasang…"); selesaiPasang(await host({ cmd: "pasangUrl" })); };
$("#kembalikan").onclick = () => duaKali($("#kembalikan"), async () => selesaiPasang(await host({ cmd: "kembalikan" })));

// v3.4.4: poli/kegiatan yang tidak diproses bot (bawaan: Konseling)
const BAWAAN_POLI = ["Konseling"];
async function muatPoli() {
  const o = await chrome.storage.local.get("poliDikecualikan");
  const d = Array.isArray(o.poliDikecualikan) ? o.poliDikecualikan : BAWAAN_POLI;
  $("#poli-kecuali").value = d.join(", ");
  tulis($("#pesan-poli"), d.length ? `Dilewati: ${d.join(", ")}.` : "Tidak ada poli yang dilewati; semua pasien Baru diproses.");
}
async function simpanPoli(d) {
  d = [...new Set(d.map((x) => x.replace(/\s+/g, " ").trim()).filter(Boolean))].slice(0, 20);
  await chrome.storage.local.set({ poliDikecualikan: d });
  await muatPoli(); tulis($("#pesan-poli"), d.length ? `Tersimpan. Dilewati: ${d.join(", ")}.` : "Tersimpan. Semua pasien Baru diproses.", true);
}
$("#simpan-poli").onclick = () => simpanPoli($("#poli-kecuali").value.split(/[,;\n]/));
$("#poli-kecuali").addEventListener("keydown", (e) => { if (e.key === "Enter") $("#simpan-poli").click(); });
$("#poli-bawaan").onclick = () => simpanPoli(BAWAAN_POLI);
muatPoli();

muat();
