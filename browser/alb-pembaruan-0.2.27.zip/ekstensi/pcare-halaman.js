/* Alvisya Dokter — PCare (eclaim BPJS), berjalan di semua halaman /eclaim/*.
 * Login      : isi ID & sandi tersimpan → tunggu verifikasi Cloudflare selesai SENDIRI → tekan Sign In.
 *              Tidak memalsukan/melewati verifikasi; bila Cloudflare meminta klik, pengguna yang mengklik.
 * Setelah masuk: catat keluar-sengaja, tawarkan simpan ID setelah masuk manual, tutup pemberitahuan satu-tombol,
 *              penjaga sesi (hanya saat jam aktif & komputer sedang dipakai).
 * Penyimpanan: pcareSetelan (ikut sinkron akun Chrome), pcareAkun {user,sandi} (HANYA komputer ini),
 *              pcareStatus {keluarSengaja, percobaanMasuk, masukGagal}, log (dipakai bersama tab Log Alvisya Dokter). */

const PCARE_BAWAAN = {
  aktif: true,
  otoMasuk: true,
  jamDari: '07:00', jamSampai: '21:00',
  tutupPeringatan: true,
  kecuali: ['gagal', 'error', 'galat', 'salah', 'tidak valid', 'tidak aktif', 'non aktif', 'nonaktif', 'tidak ditemukan',
    'tidak terdaftar', 'sudah terdaftar', 'sudah ada', 'ganda', 'duplikat', 'ditolak', 'wajib', 'harus', 'kuota', 'batas',
    'melebihi', 'kedaluwarsa', 'expired', 'tunggak', 'yakin', 'hapus', 'batal', 'rujuk', 'password', 'sandi'],
  jagaSesi: false, jagaMenit: 10, idleMenit: 15,
};
const pcareSetelan = async () => Object.assign({}, PCARE_BAWAAN, (await chrome.storage.local.get('pcareSetelan')).pcareSetelan || {});
const pcareStatus = async () => (await chrome.storage.local.get('pcareStatus')).pcareStatus || {};
async function aturStatus(ubah) { const s = await pcareStatus(); Object.keys(ubah).forEach(k => { if (ubah[k] === null) delete s[k]; else s[k] = ubah[k]; }); await chrome.storage.local.set({ pcareStatus: s }); return s; }

let antreLog = Promise.resolve();      // tulis berurutan agar catatan bersamaan tidak saling menimpa
function catat(level, sumber, teks) {
  const waktu = new Date(Date.now() + 7 * 36e5).toISOString().slice(0, 19).replace('T', ' ');
  antreLog = antreLog.then(async () => {
    const { log = [] } = await chrome.storage.local.get('log');
    log.push({ waktu, level, sumber: 'pcare-' + sumber, teks: String(teks).slice(0, 160), detail: '', versi: chrome.runtime.getManifest().version });
    await chrome.storage.local.set({ log: log.slice(-300) });
  }).catch(() => {});
  return antreLog;
}
const menitDari = s => { const [h, m] = String(s || '').split(':').map(Number); return (h || 0) * 60 + (m || 0); };
function dalamJam(s) {
  const d = new Date(Date.now() + 7 * 36e5), n = d.getUTCHours() * 60 + d.getUTCMinutes(), a = menitDari(s.jamDari), b = menitDari(s.jamSampai);
  return a <= b ? n >= a && n < b : n >= a || n < b;
}
const kataKecuali = (teks, s) => { const t = String(teks).toLowerCase(); return (s.kecuali || []).find(k => k && t.includes(k.toLowerCase())); };
const tunggu = ms => new Promise(r => setTimeout(r, ms));
/* tampil di layar — JANGAN pakai offsetParent: modal/notifikasi/SweetAlert PCare position:fixed → offsetParent selalu null */
const tampak = e => !!e && e.getClientRects().length > 0 && getComputedStyle(e).visibility !== 'hidden' && getComputedStyle(e).display !== 'none';
const bukaPengaturan = () => chrome.runtime.sendMessage({ aksi: 'pcareBukaPengaturan' });

(async () => {
  const s = await pcareSetelan();
  /* salinan kecil untuk pcare-utama.js (dunia halaman) — TANPA ID/sandi */
  try { localStorage.setItem('pcbSetelan', JSON.stringify({ tutup: s.aktif && s.tutupPeringatan, kecuali: s.kecuali })); } catch (e) {}
  if (!s.aktif) return;
  if (/\/eclaim\/Login/i.test(location.pathname) || document.getElementById('btnLogin')) return masuk(s);
  sudahMasuk();
  pantauKeluar();
  if (s.tutupPeringatan) pantauPemberitahuan(s);
  if (s.jagaSesi) jagaSesi(s);
})();

/* ===================== bilah kecil kanan bawah (shadow DOM) ===================== */
function bilah(teks, tombol = [], jenis = '') {
  let host = document.getElementById('pcb-bilah');
  if (!host) { host = document.createElement('div'); host.id = 'pcb-bilah'; host.attachShadow({ mode: 'open' }); document.documentElement.appendChild(host); }
  const r = host.shadowRoot;
  r.innerHTML = `<style>
    :host{all:initial}
    .b{position:fixed;right:16px;bottom:16px;z-index:2147483647;max-width:360px;display:flex;gap:8px;align-items:flex-start;padding:12px;border-radius:12px;
       background:#fff;color:#0F2742;border:1px solid #D5E0E0;box-shadow:0 8px 24px rgba(15,39,66,.16);font:14px/1.4 "Source Sans 3","Source Sans Pro",system-ui,"Segoe UI",sans-serif}
    .b.awas{border-color:#B45309}.b.galat{border-color:#B91C1C}
    .i{flex:none;width:22px;height:22px;border-radius:6px;background:#263C92;color:#fff;display:grid;place-items:center;font-weight:700;font-size:13px}
    .b.awas .i{background:#B45309}.b.galat .i{background:#B91C1C}
    .t{flex:1;min-width:0}.t b{display:block;font-size:13px;margin-bottom:2px}
    .a{display:flex;gap:8px;margin-top:8px;flex-wrap:wrap}
    button{font-family:inherit;font-size:13px;font-weight:600;line-height:1;height:32px;padding:0 12px;border-radius:8px;border:1px solid #D5E0E0;background:#fff;color:#0F2742;cursor:pointer}
    button.u{background:#263C92;border-color:#263C92;color:#fff}
    button:focus-visible{outline:2px solid #263C92;outline-offset:2px}
    .x{border:0;background:none;width:24px;height:24px;padding:0;color:#4F6478;font-size:18px;line-height:1}
  </style>
  <div class="b ${jenis}" role="status"><span class="i" aria-hidden="true">${jenis ? '!' : 'C'}</span>
    <div class="t"><b>Alvisya Dokter · PCare</b><span></span><div class="a"></div></div>
    <button class="x" title="Tutup" aria-label="Tutup">×</button></div>`;
  r.querySelector('.t span').textContent = teks;
  const a = r.querySelector('.a');
  tombol.forEach(([label, fn, utama]) => { const b = document.createElement('button'); b.textContent = label; if (utama) b.className = 'u'; b.onclick = fn; a.appendChild(b); });
  if (!tombol.length) a.remove();
  r.querySelector('.x').onclick = () => host.remove();
  return host;
}
const tutupBilah = () => { const h = document.getElementById('pcb-bilah'); if (h) h.remove(); };

/* ===================== halaman Login ===================== */
const isian = (ph, awal) => document.querySelector(`input[placeholder="${ph}" i]`) || document.querySelector(`input[name^="${awal}"]`);
function setNilai(el, v) {
  Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(el, v);
  ['input', 'change', 'keyup'].forEach(t => el.dispatchEvent(new Event(t, { bubbles: true })));
}

async function masuk(s) {
  const u = isian('Username', 'username_'), p = isian('Password', 'password_'), btn = document.getElementById('btnLogin');
  if (!u || !p || !btn) return;
  btn.addEventListener('click', () => {
    if (btn.dataset.pcbOto) return;
    if (u.value && p.value) chrome.storage.session.set({ pcareTawar: { user: u.value, sandi: p.value, t: Date.now() } }).catch(() => {});
  }, true);

  const akun = (await chrome.storage.local.get('pcareAkun')).pcareAkun || {}, st = await pcareStatus();
  if (!akun.user || !akun.sandi) return;
  setNilai(u, akun.user); setNilai(p, akun.sandi);

  const jalankan = async () => { tutupBilah(); await aturStatus({ keluarSengaja: null, masukGagal: null }); tekanMasuk(u, p, btn, akun); };
  if (st.percobaanMasuk && Date.now() - st.percobaanMasuk < 90e3 && !st.masukGagal) {
    await aturStatus({ masukGagal: true, percobaanMasuk: null }); st.masukGagal = true;
    catat('galat', 'masuk', 'Masuk otomatis kembali ke halaman Login — dihentikan.');
  }
  if (!s.otoMasuk) return bilah('ID & sandi sudah diisi. Masuk otomatis sedang mati.', [['Masuk', jalankan, true]]);
  if (st.masukGagal) return bilah('Masuk otomatis berhenti karena percobaan terakhir gagal. Periksa ID & sandi di Pengaturan.', [['Coba lagi', jalankan, true], ['Pengaturan', bukaPengaturan]], 'galat');
  if (st.keluarSengaja) return bilah('Anda keluar sendiri — masuk otomatis dijeda.', [['Masuk sekarang', jalankan, true]]);
  if (!dalamJam(s)) return bilah(`Di luar jam masuk otomatis (${s.jamDari}–${s.jamSampai}).`, [['Masuk sekarang', jalankan, true]]);
  if (st.percobaanMasuk && Date.now() - st.percobaanMasuk < 20e3) return bilah('Sedang masuk di tab lain…');
  tekanMasuk(u, p, btn, akun);
}

async function tekanMasuk(u, p, btn, akun) {
  setNilai(u, akun.user); setNilai(p, akun.sandi);
  const captcha = (document.getElementById('CaptchaMode') || {}).textContent === '1';
  const token = () => (document.querySelector('[name="cf-turnstile-response"]') || {}).value;
  if (captcha && !token()) {
    bilah('Menunggu verifikasi Cloudflare… Bila muncul kotak centang, klik sendiri.');
    for (let i = 0; i < 180 && !token(); i++) await tunggu(500);
    if (!token()) { bilah('Verifikasi Cloudflare belum selesai. Selesaikan, lalu tekan Sign In.', [], 'awas'); catat('awas', 'masuk', 'Token Cloudflare tidak muncul dalam 90 dtk.'); return; }
  }
  await aturStatus({ percobaanMasuk: Date.now() });
  bilah('Masuk ke PCare…');
  btn.dataset.pcbOto = '1'; btn.click(); delete btn.dataset.pcbOto;
  catat('info', 'masuk', 'Sign In ditekan otomatis.');
  for (let i = 0; i < 30; i++) {
    await tunggu(500);
    const m = [...document.querySelectorAll('.modal, .bootbox, .sweet-alert, [data-notify="container"], .alert-danger, .validation-summary-errors, .field-validation-error')].find(e => tampak(e) && e.innerText.trim());
    if (m) {
      await aturStatus({ masukGagal: true, percobaanMasuk: null });
      catat('galat', 'masuk', 'PCare menolak masuk otomatis: ' + m.innerText.trim().replace(/\s+/g, ' '));
      bilah('PCare menolak masuk otomatis — dihentikan agar akun tidak terkunci. Lihat pesan PCare.', [['Pengaturan', bukaPengaturan]], 'galat');
      return;
    }
  }
}

/* ===================== setelah masuk ===================== */
async function sudahMasuk() {
  const st = await pcareStatus(), akun = (await chrome.storage.local.get('pcareAkun')).pcareAkun || {};
  if (st.percobaanMasuk) catat('info', 'masuk', 'Masuk otomatis berhasil.');
  if (st.percobaanMasuk || st.keluarSengaja || st.masukGagal) await aturStatus({ percobaanMasuk: null, keluarSengaja: null, masukGagal: null });
  let tawar; try { ({ pcareTawar: tawar } = await chrome.storage.session.get('pcareTawar')); } catch (e) {}
  if (!tawar) return;
  chrome.storage.session.remove('pcareTawar').catch(() => {});
  if (Date.now() - tawar.t > 5 * 60e3 || (tawar.user === akun.user && tawar.sandi === akun.sandi)) return;
  bilah(`Simpan ID "${tawar.user}" & sandinya di komputer ini untuk masuk otomatis berikutnya?`, [
    ['Simpan', async () => { await chrome.storage.local.set({ pcareAkun: { user: tawar.user, sandi: tawar.sandi } }); catat('info', 'akun', 'ID & sandi disimpan dari masuk manual.'); bilah('Tersimpan. Masuk otomatis aktif saat sesi habis.'); setTimeout(tutupBilah, 4000); }, true],
    ['Jangan', tutupBilah],
  ]);
}

function pantauKeluar() {
  document.addEventListener('click', e => {
    const el = e.target.closest('a, button'); if (!el || el.closest('#idle-timeout-dialog')) return;   // "Batalkan Logout" ≠ keluar
    const teks = (el.innerText || el.title || '').trim(), href = el.getAttribute('href') || '';
    /* PCare: <a href=".../eclaim/Home/Logout">Sign out</a> */
    if (/^(sign\s?out|log\s?out|log\s?off|keluar)$/i.test(teks) || /\/Home\/Logout\b|\/log\s?off\b/i.test(href)) {
      aturStatus({ keluarSengaja: Date.now() });
      catat('info', 'keluar', 'Pengguna keluar sendiri — masuk otomatis dijeda.');
    }
  }, true);
}

/* Hanya kotak pesan: tampil, tanpa isian, tepat SATU tombol OK/Tutup, tanpa kata pengecualian. Konfirmasi tidak disentuh. */
function pantauPemberitahuan(s) {
  const sudah = new WeakSet(), labelAman = /^(ok|oke|okay|tutup|close|mengerti|baik|lanjut|lanjutkan|×|x)$/i;
  const periksa = () => {
    document.querySelectorAll('.modal, .bootbox').forEach(m => {
      if (sudah.has(m) || !tampak(m)) return;
      if (!/\b(in|show)\b/.test(m.className) && !m.classList.contains('bootbox')) return;
      sudah.add(m);
      const ringkas = (((m.querySelector('.modal-title') || {}).innerText || '') + ' ' + ((m.querySelector('.modal-body, .bootbox-body') || m).innerText || '')).trim().replace(/\s+/g, ' ');
      if (m.querySelector('.modal-body input:not([type=hidden]), .modal-body select, .modal-body textarea')) return;
      const kata = kataKecuali(ringkas, s);
      if (kata) return catat('info', 'pemberitahuan', `Dibiarkan (memuat "${kata}"): ${ringkas}`);
      const aksi = [...m.querySelectorAll('.modal-footer button, .modal-footer a.btn')].filter(tampak);
      if (aksi.length > 1) return catat('info', 'pemberitahuan', 'Dibiarkan (ada pilihan): ' + ringkas);
      const tbl = aksi.length === 1 ? aksi[0] : m.querySelector('.bootbox-close-button, button.close, [data-dismiss="modal"]');
      if (!tbl || (aksi.length === 1 && !labelAman.test(tbl.innerText.trim()))) return catat('info', 'pemberitahuan', 'Dibiarkan (tombol tak dikenal): ' + ringkas);
      setTimeout(() => { tbl.click(); catat('info', 'pemberitahuan', 'Ditutup: ' + ringkas); }, 250);
    });
    /* notifikasi bootstrap-notify PCare (showMessage): 428 = peringatan (mis. EWS "WARNING! … SIP habis",
     * "Pakta Integritas", "REMINDER!" — kelas alert-warning diganti WarningBoxKuningHitam), lainnya = galat/sukses.
     * Yang ditutup hanya PERINGATAN; galat (alert-error/danger) tidak pernah; sukses hilang sendiri. */
    document.querySelectorAll('[data-notify="container"]').forEach(n => {
      if (sudah.has(n) || !tampak(n)) return;
      const k = n.className;
      if (!/alert-warning|WarningBoxKuningHitam|fontBigger/.test(k) || /alert-(error|danger|success)/.test(k)) return;
      sudah.add(n);
      const ringkas = n.innerText.replace(/×/g, '').trim().replace(/\s+/g, ' ');
      const kata = kataKecuali(ringkas, s);
      if (kata) return catat('info', 'pemberitahuan', `Dibiarkan (memuat "${kata}"): ${ringkas}`);
      const x = n.querySelector('[data-notify="dismiss"], button.close'); if (!x) return;
      setTimeout(() => { x.click(); catat(/WARNING|REMINDER/i.test(ringkas) ? 'awas' : 'info', 'pemberitahuan', 'Ditutup: ' + ringkas); }, 250);
    });
    /* SweetAlert v1 (swal): hanya bila tombol Batal tersembunyi, tanpa isian, label OK/Tutup */
    document.querySelectorAll('.sweet-alert').forEach(a => {
      if (sudah.has(a) || !tampak(a) || !/\b(visible|showSweetAlert)\b/.test(a.className)) return;
      sudah.add(a);
      const ringkas = a.innerText.trim().replace(/\s+/g, ' '), ok = a.querySelector('button.confirm'), batal = a.querySelector('button.cancel');
      if (/show-input/.test(a.className) || tampak(batal)) return catat('info', 'pemberitahuan', 'Dibiarkan (ada pilihan): ' + ringkas);
      const kata = kataKecuali(ringkas, s);
      if (kata) return catat('info', 'pemberitahuan', `Dibiarkan (memuat "${kata}"): ${ringkas}`);
      if (!ok || !labelAman.test(ok.innerText.trim())) return catat('info', 'pemberitahuan', 'Dibiarkan (tombol tak dikenal): ' + ringkas);
      setTimeout(() => { ok.click(); catat('info', 'pemberitahuan', 'Ditutup: ' + ringkas); }, 250);
    });
    document.querySelectorAll('.alert-warning, .alert-info').forEach(a => {
      if (sudah.has(a) || !tampak(a) || a.matches('[data-notify="container"]')) return; sudah.add(a);
      const x = a.querySelector('button.close, [data-dismiss="alert"]'); if (!x) return;
      const ringkas = a.innerText.trim().replace(/\s+/g, ' ');
      if (kataKecuali(ringkas, s)) return;
      x.click(); catat('info', 'pemberitahuan', 'Ditutup: ' + ringkas);
    });
  };
  periksa();
  let t = null;
  new MutationObserver(() => { clearTimeout(t); t = setTimeout(periksa, 120); }).observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ['class', 'style'] });
}
window.addEventListener('message', e => { if (e.source === window && e.data && e.data.pcbLog) catat('info', 'pemberitahuan', e.data.pcbLog); });

/* ===================== penjaga sesi =====================
 * PCare (keepAlive.js, diukur 10 Nov 2026): logout setelah 10 menit tanpa aktivitas di halaman PCare
 * (Config.idleTimeLogout), 60 dtk sebelumnya tampil #idle-timeout-dialog "Sesi Anda Akan Segera Berakhir" dengan
 * tombol #idle-timeout-dialog-keepalive "Batalkan Logout" (→ POST /KeepAlive/perpanjang milik PCare).
 * Saat dialog itu tampil, tombol PCare tsb ditekan HANYA bila jam aktif DAN komputer dipakai dalam idleMenit terakhir
 * (mis. dokter sedang mengetik di tab C-CARE). Komputer ditinggal → sesi dibiarkan habis seperti biasa. */
function jagaSesi(s) {
  const dlg = document.getElementById('idle-timeout-dialog');
  if (!dlg) return;
  let sedang = false;
  const cek = async () => {
    const tampil = tampak(dlg) && /\b(in|show)\b/.test(dlg.className);
    if (!tampil || sedang) return;
    sedang = true;
    try {
      if (!dalamJam(s)) return catat('info', 'sesi', `Sesi dibiarkan habis (di luar jam ${s.jamDari}–${s.jamSampai}).`);
      let idle; try { idle = await chrome.runtime.sendMessage({ aksi: 'pcareIdle', detik: Math.max(1, s.idleMenit | 0) * 60 }); } catch (e) { return; }
      if (!idle || !idle.aktif) return catat('info', 'sesi', `Sesi dibiarkan habis (komputer diam ≥ ${s.idleMenit} menit).`);
      const b = document.getElementById('idle-timeout-dialog-keepalive') || [...dlg.querySelectorAll('button')].find(x => /batalkan logout|perpanjang/i.test(x.innerText));
      if (!b) return catat('awas', 'sesi', 'Dialog sesi PCare berubah — tombol "Batalkan Logout" tidak ditemukan.');
      b.click(); catat('info', 'sesi', 'Sesi PCare diperpanjang (komputer sedang dipakai).');
    } finally { setTimeout(() => { sedang = false; }, 5000); }
  };
  new MutationObserver(cek).observe(dlg, { attributes: true, attributeFilter: ['class', 'style'] });
}
