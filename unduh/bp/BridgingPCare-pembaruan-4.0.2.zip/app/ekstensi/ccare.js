// ===== Sisi C-CARE: ambil data kunjungan yang sedang dibuka =====
// v0.3: field tab "Pemeriksaan Perawat" dibaca langsung lewat ID asli C-CARE
// (/Poli/Ubah/<id>). Field yang ID-nya belum diketahui masih lewat label.

// key -> daftar ID C-CARE (dicoba berurutan; elemen tersembunyi di tab lain tetap terbaca)
const CC_IDS = {
  keluhan: ["Keluhan"],                    // isian perawat (tab Pemeriksaan Perawat)
  anamnesa: ["AmnesaDokter"],              // HANYA isian dokter (tab Pemeriksaan Dokter)
  diagnosaTeks: ["Diagnosa"],
  terapiObatTeks: ["Pengobatan"],
  terapiNonObat: ["TataLaksana"],           // Tata Laksana C-CARE -> Terapi Non Obat PCare
  alergi: ["RiwayatAlergi"],
  tb: ["TinggiBadan"],
  bb: ["BeratBadan"],
  imt: ["Imt"],
  lp: ["LingkarPerut"],
  sistole: ["Sistole"],
  diastole: ["Diastole"],
  rr: ["Respirasi"],
  hr: ["Nadi"],
  suhu: ["Suhu"],
  rujukan: ["StatusRujukanId"],
  tindakLanjut: ["TindakLanjutPengobatanId"],   // v3.1.0: Pulang / Rujuk / …
  rujukanPoli: ["RujukanPoliId"],               // tujuan rujukan internal
  ketRujukan: ["KeteranganRujukan"],            // teks bebas: spesialis, RS tujuan, cito
};

// Kode diagnosa dari select multi "KodePenyakit" (opsi terpilih, mis. "L080 / Pyoderma")
function readKodePenyakit() {
  const s = document.getElementById("KodePenyakit");
  if (!s) return "";
  return [...s.selectedOptions].map((o) => o.text || o.value).join("; ");
}

// Resep: ListResep[i] -> "Nama obat dosis (jumlah)"
// Kata kunci alat kesehatan / BMHP: bila nama item resep memuat salah satunya, item dianggap ALKES
const ALKES_RE = new RegExp("\\b(" + [
  "kasa", "kassa", "kain kasa", "perban", "verban", "elastic bandage", "bandage", "plester", "leukoplast", "hypafix",
  "softban", "underpad", "spuit", "syringe", "jarum", "needle", "abocath", "iv cath", "iv catheter", "infus set", "infusion set",
  "blood set", "transfusi set", "kateter", "catheter", "foley", "urine bag", "ngt", "nasogastric", "sarung tangan", "handscoon",
  "handscoen", "glove", "masker", "mask", "kapas", "alcohol swab", "alkohol swab", "swab", "lancet", "test strip", "strip",
  "benang", "catgut", "silk", "nylon", "blade", "pisau", "bisturi", "tongue spatel", "spatel", "nebu kit", "nebulizer kit",
  "nasal kanul", "nasal cannula", "kanul", "oxygen mask", "sungkup", "bidai", "spalk", "collar", "pembalut", "pot urin",
  "pot sputum", "tabung", "vacutainer", "wing needle", "three way", "3 way", "elektroda", "electrode", "ekg pad", "tensocrepe"
].join("|") + ")\\b", "i");
const isAlkes = (nama) => ALKES_RE.test(nama || "");

// Resep Alat Kesehatan: bagian terpisah di tab Pemeriksaan Dokter (dibaca generik dari kontainernya)
function readResepAlkes() {
  const head = [...document.querySelectorAll("a, h3, h4, h5, strong, b, label, legend, .card-title, .box-title, li")]
    .find((e) => BR.norm(e.textContent) === "resep alat kesehatan");
  if (!head) return [];
  let box = null;
  const href = head.getAttribute && head.getAttribute("href");
  if (href && href.startsWith("#") && href.length > 1) box = document.querySelector(href);
  if (!box) box = head.closest(".tab-pane, .card, .box, fieldset, .panel") || head.parentElement;
  if (!box) return [];
  const clean = (t) => (t || "").replace(/\s*\[.*$/, "").replace(/\(stok.*?\)/i, "").trim();
  const items = [];
  box.querySelectorAll("select").forEach((s) => {
    const t = clean(s.options[s.selectedIndex]?.text);
    if (!t || /pilih|^-+$/i.test(t) || /satuan|jenis/i.test(s.name || s.id || "")) return;
    const row = s.closest("tr, .row, .form-group") || s.parentElement;
    const jml = [...row.querySelectorAll("input[type=number], input[name*='Jumlah' i], input[id*='jumlah' i]")]
      .map((x) => x.value).find((v) => v && v.trim());
    items.push({ nama: t, line: t + (jml ? ` (${jml})` : "") });
  });
  // daftar yang hanya ditampilkan (tabel tanpa select)
  if (!items.length) box.querySelectorAll("tbody tr").forEach((tr) => {
    const t = clean(tr.cells[0]?.textContent === "" ? tr.cells[1]?.textContent : (tr.cells[1] || tr.cells[0])?.textContent);
    if (t && !/tidak ada|kosong/i.test(t)) items.push({ nama: t, line: t });
  });
  return items;
}

function readResep() {
  const clean = (t) => (t || "").replace(/\s*\[.*$/, "").replace(/\(stok.*?\)/i, "").trim();
  const isPlaceholder = (t) => !t || /pilih|^-+$/i.test(t);
  const items = [];
  for (let i = 0; i < 30; i++) {
    const sel = document.getElementById("obat_" + i);
    if (!sel) break;
    const racikan = document.getElementById("isRacikan_" + i)?.checked;
    let nama = racikan
      ? document.getElementById(`ListResep_${i}__NamaRacikan`)?.value?.trim()
      : clean(sel.options[sel.selectedIndex]?.text);
    if (racikan && nama) {
      const isi = [0, 1, 2, 3].map((j) => {
        const s2 = document.getElementById(`obatRacikan_${i}_${j}`);
        const t = clean(s2?.options[s2.selectedIndex]?.text);
        return isPlaceholder(t) ? "" : t;
      }).filter(Boolean);
      if (isi.length) nama += ` (racikan: ${isi.join(" + ")})`;
    }
    if (isPlaceholder(nama)) continue;
    const a = document.getElementById(`ListResep_${i}__IntensitasDosis`)?.value;
    const b = document.getElementById(`ListResep_${i}__JumlahDosis`)?.value;
    const satEl = document.getElementById(`ListResep_${i}__SatuanPembagiDosisId`);
    const sat = satEl ? satEl.options[satEl.selectedIndex]?.text : "";
    const jml = document.getElementById("jumlah_obat_" + i)?.value;
    let line = nama;
    if (a && b) line += ` ${a}x${b}${sat && !isPlaceholder(sat) ? " " + sat : ""}`;
    if (jml) line += ` (${jml})`;
    items.push({ nama, line });
  }
  return items;
}

// Dokter: cari nama dokter klinik yang muncul di halaman (mis. kolom PIC). Hanya diterima bila tepat satu.
function findDokterInPage() {
  const txt = BR.norm(document.body.innerText);
  const found = BR.DOKTER.filter((x) => txt.includes(BR.norm(x).replace(/^dr\.?\s*/, "")));
  return found.length === 1 ? found[0] : "";
}

// Belum ada ID asli -> cari lewat label (ada di tab Identitas / Pemeriksaan Dokter / Pemberian Obat)
// C-CARE tidak menampilkan No. BPJS; pasien dicocokkan ke antrean PCare lewat Nama + JK + Umur.
const CC_LABELS = {
  kartu: ["no. bpjs", "no bpjs", "no. kartu", "nomor bpjs", "no. jkn", "no. kartu bpjs", "nomor kartu"],
};

const ALL_KEYS = ["nama", "kelamin", "umur", "keluhan", "anamnesa", "alergi", "tb", "bb", "imt", "lp",
  "sistole", "diastole", "rr", "hr", "suhu", "diagnosa", "terapiObat", "terapiNonObat", "bmhp", "dokter"];

function readById(ids) {
  for (const id of ids) {
    const el = document.getElementById(id);
    if (!el) continue;
    const v = el.tagName === "SELECT" ? el.options[el.selectedIndex]?.text : el.value;
    if (v && v.trim() && !(el.tagName === "SELECT" && /^\s*-*\s*pilih/i.test(v))) return v.trim();
  }
  return "";
}

// Kotak Identitas Pasien C-CARE: <p class="media-body">Nama Pasien</p><p class="media-right">:</p>
// di kolom kiri, nilainya di kolom kanan <div class="col-md-8">. Ikut membaca bagian tertutup.
function readIdentitasCcare(label) {
  const want = BR.norm(label);
  const lab = [...document.querySelectorAll("p.media-body")].find((p) => BR.norm(p.textContent) === want);
  if (!lab) return "";
  const col = lab.closest("[class*='col-']");
  let valEl = col && col.nextElementSibling;
  if (!valEl || !valEl.textContent.trim()) {
    const row = lab.closest(".row, .media, li, tr") || lab.parentElement;
    valEl = row && row.querySelector(".col-md-8, [class*='col-md-8'], [class*='col-sm-8']");
  }
  const v = (valEl ? valEl.textContent : "").replace(/\s+/g, " ").trim();
  return v === "-" ? "" : v;
}

// Baca pasangan "Label : nilai" di seluruh halaman, TERMASUK bagian tersembunyi/tertutup.
// Dipakai untuk kotak Identitas Pasien (tidak berupa input).
function readIdentitas(labels) {
  const want = labels.map((l) => BR.norm(l).replace(/[:.]/g, "").trim());
  const els = [...document.querySelectorAll("td, th, dt, dd, label, span, b, strong, div, p, li")]
    .filter((el) => !el.closest("#br-panel") && el.children.length <= 1);
  for (const el of els) {
    const own = BR.norm(el.textContent).replace(/[:.]/g, "").trim();
    if (!want.includes(own)) continue;
    // nilai di elemen saudara berikutnya (lewati ":" yang berdiri sendiri)
    let sib = el.nextElementSibling;
    while (sib && /^[\s:]*$/.test(sib.textContent)) sib = sib.nextElementSibling;
    let v = sib ? sib.textContent.replace(/^[\s:]+/, "").trim() : "";
    // atau "Label : nilai" dalam satu induk
    if (!v && el.parentElement) {
      const t = el.parentElement.textContent.replace(/\s+/g, " ");
      const m = t.split(/:\s*/); if (m.length > 1) v = m.slice(1).join(":").trim();
    }
    if (v && v.length < 80) return v;
  }
  return "";
}

function readByLabel(labels) {
  for (const lab of labels) {
    const ctrl = BR.findControl(lab);
    if (ctrl) {
      const val = ctrl.tagName === "SELECT" ? ctrl.options[ctrl.selectedIndex]?.text : ctrl.value;
      if (val && val.trim()) return val.trim();
    }
    const el = BR.findLabelEl(lab);
    if (el) {
      const m = el.parentElement?.textContent.split(/:\s*/);
      const sib = el.nextElementSibling?.textContent?.replace(/^[:\s]+/, "").trim();
      const v = sib || (m && m.length > 1 ? m.slice(1).join(":").trim() : "");
      if (v) return v;
    }
  }
  return "";
}

function extract() {
  const d = {};
  for (const [k, ids] of Object.entries(CC_IDS)) d[k] = readById(ids);
  for (const [k, labels] of Object.entries(CC_LABELS)) d[k] = readIdentitas(labels);
  d.nama = readIdentitasCcare("Nama Pasien");
  d.rm = readIdentitasCcare("Nomor RM");
  d.tglLahir = readIdentitasCcare("Tanggal Lahir");
  const jk = BR.norm(readIdentitasCcare("Jenis Kelamin"));
  d.kelamin = /perempuan|wanita/.test(jk) ? "P" : /laki/.test(jk) ? "L" : "";
  const um = readIdentitasCcare("Umur").match(/(\d+)\s*tahun/i);
  d.umur = um ? parseInt(um[1], 10) : null;
  d.jenisPasien = readIdentitasCcare("Jenis Pasien");

  // angka: koma -> titik, ambil angkanya saja
  ["suhu", "tb", "bb", "lp", "sistole", "diastole", "rr", "hr", "imt"].forEach((k) => {
    const m = (d[k] || "").replace(",", ".").match(/\d+(\.\d+)?/);
    d[k] = m ? m[0] : "";
  });

  // No. Kartu: 13 digit; cadangan cari pola 000xxxxxxxxxx di seluruh halaman
  let km = (d.kartu || "").match(/\d{13}/);
  if (!km) {
    const uniq = [...new Set([...document.body.textContent.matchAll(/(?<!\d)(000\d{10})(?!\d)/g)].map((m) => m[1]))];
    if (uniq.length === 1) km = [uniq[0]];
    else if (uniq.length > 1) d._kartuGanda = uniq.join(", ");
  }
  d.kartu = km ? km[0] : "";

  // Diagnosa: ambil kode ICD-10 bila ada; teks panjang yang bukan diagnosa dibuang
  // Diagnosa: utamakan select KodePenyakit, cadangan textarea Diagnosa.
  // C-CARE menulis tanpa titik (l080, r509) -> format PCare (L08.0, R50.9)
  const icds = BR.icdList(readKodePenyakit() + " ; " + d.diagnosaTeks);
  d.diagnosa = icds.join(", ");

  // Terapi obat: utamakan daftar resep terstruktur, cadangan textarea Pengobatan
  // Terapi Obat vs BMHP: item Resep Alat Kesehatan + item resep yang tergolong alkes -> BMHP;
  // alkes TIDAK ikut ke Terapi Obat.
  const resep = readResep();
  const alkesResep = readResepAlkes();
  const alkesNama = new Set(alkesResep.map((x) => BR.norm(x.nama)));
  const obat = resep.filter((x) => !isAlkes(x.nama) && !alkesNama.has(BR.norm(x.nama)));
  const alkesDariResep = resep.filter((x) => isAlkes(x.nama) && !alkesNama.has(BR.norm(x.nama)));
  const bmhp = [...alkesResep, ...alkesDariResep];
  d.terapiObat = obat.map((x) => x.line).join(", ") || (resep.length ? "" : d.terapiObatTeks);
  d.bmhp = bmhp.map((x) => x.line).join(", ");
  d._alkesDipindah = alkesDariResep.map((x) => x.nama);

  d.dokter = findDokterInPage();
  delete d.diagnosaTeks; delete d.terapiObatTeks;

  d.ccareUrl = location.pathname;
  d.waktu = new Date().toLocaleString("id-ID");
  return d;
}

const LABEL_ID = {
  kartu: "No. Kartu", nama: "Nama", kelamin: "JK", umur: "Umur", keluhan: "Keluhan", anamnesa: "Anamnesa", alergi: "Alergi",
  tb: "TB", bb: "BB", imt: "IMT", lp: "LP", sistole: "Sistole", diastole: "Diastole", rr: "RR",
  hr: "Nadi", suhu: "Suhu", terapiNonObat: "Terapi non obat", bmhp: "BMHP", diagnosa: "Diagnosa",
  terapiObat: "Terapi obat", dokter: "Dokter",
};

// Simpan hasil ekstraksi ke antrian (per hari) untuk dipakai PCare
async function simpanKeAntrian(d) {
  const q = (await BR.store.get("ccareQueue")) || {};
  const today = BR.today();
  for (const k of Object.keys(q)) if (q[k].tgl !== today) delete q[k];
  d.tgl = today;
  d.v = 3;   // versi format data; PCare menolak data versi lama (mis. tanpa Tata Laksana/BMHP)
  // v1.9.0: kunci per KUNJUNGAN (alamat halaman), supaya 2 kunjungan pasien yang sama di hari yang sama tidak saling timpa
  const key = d.ccareUrl ? "url:" + BR.pathKunjungan(d.ccareUrl) : (d.kartu || `id:${BR.nameKey(d.nama)}|${d.kelamin}|${d.umur}`);
  q[key] = d;
  await BR.store.set("ccareQueue", q);
  return q;
}

function buildCcareButton() {
  if (document.getElementById("br-panel")) return;
  // Panel C-CARE disembunyikan; yang tampil hanya tombol bulat kecil "⇄" di pojok kiri bawah
  // (tidak menutupi tombol Simpan/Kembali C-CARE di kanan bawah).
  const fab = document.createElement("button");
  fab.id = "br-fab";
  fab.title = "Bridging C-CARE → PCare";
  fab.textContent = "⇄";
  document.body.appendChild(fab);

  const p = document.createElement("div");
  p.id = "br-panel";
  p.className = "br-small br-ccare br-hidden";
  p.innerHTML = `<div class="br-head"><div class="br-brand"><img class="br-logo" alt="IPB" src="${BR.urlLogo()}" onerror="this.style.visibility='hidden'"><div><div class="br-title">Alvisya Bridging PCare</div><div class="br-sub">di C-CARE</div></div></div><button id="br-tutup" class="br-ikon" title="Tutup">×</button></div>
    <div class="br-body">
      <div class="br-muted">Data diambil otomatis saat Anda klik ▶ di PCare. Tombol di bawah hanya cadangan.</div>
      <button id="br-kirim" class="br-primary">📤 Kirim kunjungan ini ke PCare</button>
      <div id="br-log"></div>
      <details><summary>⚙ Lanjutan</summary>
        <button id="br-struktur" style="margin-top:6px">🧩 Salin struktur halaman (tanpa data pasien)</button>
        <button id="br-identitas" style="margin-top:4px">🪪 Salin struktur Identitas (data disamarkan)</button>
      </details>
    </div>`;
  document.body.appendChild(p);
  fab.onclick = () => p.classList.toggle("br-hidden");
  p.querySelector("#br-tutup").onclick = () => p.classList.add("br-hidden");
  p.querySelector("#br-struktur").onclick = BR.copyStructure;
  p.querySelector("#br-identitas").onclick = copyIdentitas;
  p.querySelector("#br-kirim").onclick = async () => {
    const d = extract();
    // Peringatan bila halaman ini tampaknya bukan kunjungan hari ini
    const now = new Date();
    const bulan = ["januari","februari","maret","april","mei","juni","juli","agustus","september","oktober","november","desember"][now.getMonth()];
    const hariIni = new RegExp(`\\b0?${now.getDate()}\\s+(${bulan}|${bulan.slice(0,3)})\\w*\\s+${now.getFullYear()}\\b`, "i");
    d._bukanHariIni = !hariIni.test(document.body.textContent);
    await BR.store.set("ccareData", d);
    // antrian untuk Mode Otomatis PCare: disimpan per tanggal, dicari lewat No. Kartu / nama
    const q = await simpanKeAntrian(d);
    const filled = ALL_KEYS.filter((k) => d[k]).map((k) => LABEL_ID[k]);
    const empty = ALL_KEYS.filter((k) => !d[k]).map((k) => LABEL_ID[k]);
    if (d._alkesDipindah && d._alkesDipindah.length) filled.push(`(alkes dipindah dari resep ke BMHP: ${d._alkesDipindah.join(", ")})`);
    if (d._kartuGanda) empty.push(`(No. Kartu ganda di halaman: ${d._kartuGanda})`);
    document.getElementById("br-log").innerHTML =
      `<div class="br-ok">✓ Terbaca: ${filled.join(", ") || "-"}</div>` +
      (empty.length ? `<div class="br-err">✗ Kosong / belum terbaca: ${empty.join(", ")}</div>` : "") +
      `<div class="${d.nama && d.kelamin && d.umur !== null ? "br-ok" : "br-err"}">👤 ${d.nama || "(nama tidak terbaca)"} · ${d.kelamin || "JK ?"} · ${d.umur ?? "?"} th · RM ${d.rm || "?"}</div>` +
      (d._bukanHariIni ? `<div class="br-err">⚠️ Tanggal hari ini tidak ditemukan di halaman — mungkin ini KUNJUNGAN LAMA. Pastikan Anda membuka kunjungan hari ini.</div>` : "") +
      `<div class="br-ok">📥 Antrian hari ini: ${Object.keys(q).length} pasien siap untuk PCare.</div>` +
      `<div class="br-muted">Buka kunjungan pasien berikutnya dan klik Kirim lagi, atau buka PCare → ▶ Jalankan.</div>`;
  };
}

// Struktur kotak Identitas Pasien: kata label umum dibiarkan, data lain disamarkan
// (huruf -> x, angka -> 9), supaya pola "No. BPJS : 9999999999999" terlihat tanpa data asli.
const LABEL_WORDS = new Set(("no nomor bpjs kartu jkn nik nama pasien tanggal tgl lahir tempat alamat jenis kelamin " +
  "rm rekam medis umur usia tahun bulan hari telepon telp hp asuransi penjamin status pekerjaan agama golongan darah " +
  "identitas peserta kunjungan poli dokter laki perempuan l p").split(" "));
async function copyIdentitas() {
  const mask = (t) => t.split(/(\s+)/).map((w) => {
    const bare = w.toLowerCase().replace(/[^a-z]/g, "");
    if (!w.trim() || LABEL_WORDS.has(bare) || /^[:.\-\/()]+$/.test(w)) return w;
    return w.replace(/[A-Za-z]/g, "x").replace(/\d/g, "9");
  }).join("");
  const head = [...document.querySelectorAll("h1,h2,h3,h4,h5,.box-title,.panel-title,.card-title,legend,a,b,strong")]
    .find((e) => /identitas pasien/i.test(e.textContent));
  const box = head ? (head.closest(".box, .panel, .card, .tab-pane, section, fieldset") || head.parentElement) : null;
  const out = ["URL: " + location.pathname, head ? "Kotak ditemukan: <" + box.tagName.toLowerCase() + " class=" + box.className + ">" : "Judul 'Identitas Pasien' TIDAK ditemukan", ""];
  if (box) {
    [...box.querySelectorAll("*")].filter((e) => e.children.length === 0 && e.textContent.trim()).slice(0, 80)
      .forEach((e) => out.push(`<${e.tagName.toLowerCase()}${e.className ? " ." + String(e.className).split(" ")[0] : ""}> ${mask(e.textContent.trim().replace(/\s+/g, " ")).slice(0, 70)}`));
  }
  out.push("", "Angka 13 digit berawalan 000 di halaman: " +
    [...new Set([...document.body.textContent.matchAll(/(?<!\d)(000\d{10})(?!\d)/g)].map((m) => m[1]))].length + " buah");
  const text = out.join("\n");
  try { await navigator.clipboard.writeText(text); } catch (e) {
    const ta = document.createElement("textarea"); ta.value = text; document.body.appendChild(ta); ta.select(); document.execCommand("copy"); ta.remove();
  }
  document.getElementById("br-log").innerHTML = `<div class="br-ok">✓ Struktur Identitas disalin (disamarkan). Tempel ke chat Claude.</div>`;
}


// =====================================================================
// MODE PEKERJA: tab C-CARE yang dibuka ekstensi di latar belakang.
// =====================================================================
const BULAN = ["januari","februari","maret","april","mei","juni","juli","agustus","september","oktober","november","desember"];
// Pola tanggal yyyy-mm-dd dalam berbagai format tampilan C-CARE
function tglRegex(iso) {
  const [y, m, d] = iso.split("-").map((x) => parseInt(x, 10));
  const b = BULAN[m - 1], dd = String(d).padStart(2, "0"), mm = String(m).padStart(2, "0");
  return new RegExp(`(\\b0?${d}\\s+(${b}|${b.slice(0, 3)})\\w*\\s+${y}\\b)|(\\b${dd}[/-]${mm}[/-]${y}\\b)|(\\b${y}-${mm}-${dd}\\b)`, "i");
}

const isHalamanDaftar = () =>
  [...document.querySelectorAll("h1, h2, h3, h4, .card-title, .box-title, .content-header")]
    .some((h) => /data pasien/i.test(h.textContent));   // "Data Pasien Poli Umum", "Data Pasien Ruang Tindakan", …

function kirimPesan(msg) {
  return new Promise((res) => { try { chrome.runtime.sendMessage(msg, (r) => res(r || null)); } catch (e) { res(null); } });
}

async function selesaiPekerja(req, hasil) {
  if (hasil && hasil.nama) BR.ingatNama(hasil.nama);
  if (req && req.nama) BR.ingatNama(req.nama);
  BR.keFile("CCARE", hasil && hasil.ok ? "OK" : "PERINGATAN", `kunjungan ${req.poliTemu || ""}: ${hasil && hasil.ok ? "data diambil" : (hasil && hasil.pesan) || "gagal"}`);
  await BR.store.set("ccareRes_" + req.id, hasil);
}

// Setiap tab pekerja punya kunci sendiri: ccareReq_<tabId> (4 tab poli berjalan BERSAMAAN, tidak saling menimpa)
const kunciReq = (tabId) => "ccareReq_" + tabId;
// hasil pencarian satu poli → background (yang memutuskan setelah semua poli selesai)
async function laporCari(req, temuan) {
  await BR.store.set("ccareCari_" + req.id + "_" + req.poli, temuan);
  return true;
}

// v1.9.6: semua baris daftar poli pada tanggal req.tgl, lewat form halaman ini (POST + token anti-forgery bawaan form)
async function semuaBarisTabel(req, tgl) {
  try {
    const form = tgl.form; if (!form) return null;
    const fd = new FormData(form);
    fd.set(tgl.name || "Tanggal", req.tgl);
    const st = form.querySelector("select[name*='Status' i]");
    if (st && [...st.options].some((o) => o.value === "")) fd.set(st.name, "");          // semua status kunjungan
    const res = await fetch(form.getAttribute("action") || location.pathname, { method: "POST", body: fd, credentials: "include" });
    if (!res.ok) return null;
    const doc = new DOMParser().parseFromString(await res.text(), "text/html");
    if (doc.querySelector("input[type=password]")) return null;
    const tb = doc.querySelector("table#datatable-poli, table#datatable-kia") || doc.querySelector("table");
    if (!tb) return null;
    const ths = [...tb.querySelectorAll("thead th")].map((h) => BR.norm(h.textContent));
    const iNama = ths.findIndex((h) => h === "nama pasien" || h === "nama");
    const tglTabel = [...doc.querySelectorAll("input")].find((i) => i.name === tgl.name);
    if (tglTabel && tglTabel.value && tglTabel.value !== req.tgl) return null;            // server tidak memakai tanggal yang diminta
    return { rows: [...tb.querySelectorAll("tbody tr")].filter((tr) => tr.cells.length > 2), iNama };
  } catch (e) { return null; }
}
function cocokkanBaris(req, kodePoli, rows, iNama) {
  const key = BR.nameKey(req.nama), kataPcare = BR.kataNama(req.nama).join(" ");
  const sel = (tr) => (iNama >= 0 && tr.cells[iNama] ? [tr.cells[iNama]] : [...tr.cells]);
  const persisTd = (td) => { const k = BR.kataNama(td.textContent).join(" "); if (!k) return false;
    return k === kataPcare || (key.split(" ").length >= 2 && (k.includes(kataPcare) || (k.split(" ").length >= 2 && kataPcare.includes(k)))); };
  const skor = (tr) => Math.max(0, ...sel(tr).map((td) => BR.namaMirip(td.textContent, req.nama)));
  const nama = (tr) => (sel(tr).map((td) => [td.textContent.replace(/\s+/g, " ").trim(), BR.namaMirip(td.textContent, req.nama)]).sort((a, b) => b[1] - a[1])[0] || [""])[0];
  const tautan = (tr) => { const a = tr.querySelector("a[href*='/Poli/Ubah' i], a[href*='/Kia/Ubah' i]") || tr.querySelector("a[href*='/Poli/'], a[href*='/Kia/' i]");
    try { return a ? new URL(a.getAttribute("href"), location.href).href : ""; } catch (e) { return ""; } };
  const persis = rows.filter((tr) => sel(tr).some(persisTd));
  const mirip = rows.filter((tr) => !persis.includes(tr) && skor(tr) >= 0.75).sort((a, b) => skor(b) - skor(a));
  return { poli: kodePoli, cara: "semua baris",
    persis: persis.map((tr) => ({ nama: nama(tr), href: tautan(tr) })),
    mirip: mirip.map((tr) => ({ nama: nama(tr), href: tautan(tr), skor: Math.round(skor(tr) * 100) / 100 })) };
}

async function jalankanPekerja() {
  // Pelajari URL halaman "Data Pasien Poli Umum" setiap kali Anda membukanya
  const judulDaftar = [...document.querySelectorAll("h1, h2, h3, h4, .card-title, .box-title, .content-header")].map((h) => h.textContent).join(" ");
  // (alamat Poli Umum kini tetap: BR.CCARE_POLI.UMUM, tidak lagi dipelajari)

  const me = await kirimPesan({ type: "siapaSaya" });
  let req = null;
  for (let i = 0; i < 8 && !req; i++) {           // permintaan bisa tersimpan sesaat setelah tab terbuka
    const r = me ? await BR.store.get(kunciReq(me.tabId)) : null;
    if (r && r.tabId === me.tabId) req = r; else await BR.sleep(400);
  }
  if (!req) return false;                          // tab biasa, bukan pekerja

  document.getElementById("br-panel")?.classList.remove("br-hidden");
  const lapor = (pesan) => { const b = document.getElementById("br-log"); if (b) b.innerHTML = `<div class="br-ok">🤖 ${pesan}</div>`; };
  const key = BR.nameKey(req.nama);

  // ---- Tahap 1: cari pasien pada TANGGAL kunjungan di SATU poli (tab ini). Background membuka
  // Poli Umum, Ruang Tindakan, Prolanis, KIA BERSAMAAN lalu memutuskan (Poli Gigi & Kunjungan Sehat tidak dicari).
  if (req.stage === "cari") {
    const kodePoli = req.poli, namaPoli = BR.NAMA_POLI[kodePoli];
    if (document.querySelector("input[type=password]")) {
      // v2.0.0: login otomatis — hanya SATU tab latar yang login, tab lain menunggu lalu memuat ulang
      if (await BR.store.get("autoLogin_ccare")) {
        if (await BR.kunciLogin("ccare")) {
          const h = await BR.loginOtomatis("ccare", (t) => lapor(t));
          if (h === "dikirim") { await BR.sleep(8000); await BR.lepasKunciLogin("ccare"); return true; }   // halaman berpindah; skrip berjalan lagi
          await BR.lepasKunciLogin("ccare");
        } else {
          for (let i = 0; i < 50 && (await BR.loginSedang("ccare")); i++) await BR.sleep(500);
          location.reload(); return true;
        }
      }
      return laporCari(req, { poli: kodePoli, login: true, galat: "C-CARE belum login" });
    }
    const nav = req.nav || 0;
    if (BR.poliDariUrl(location.href) !== kodePoli || !isHalamanDaftar()) {
      if (nav < 2) { await BR.store.set(kunciReq(req.tabId), { ...req, nav: nav + 1 }); location.href = BR.CCARE_POLI[kodePoli]; return true; }
      return laporCari(req, { poli: kodePoli, galat: `halaman ${namaPoli} tidak bisa dibuka` });
    }
    lapor(`Mencari ${req.nama} pada ${req.tgl} di ${namaPoli}…`);
    const tgl = [BR.findControl("Tanggal Pemeriksaan", "input"), ...document.querySelectorAll("input[type=date]")]
      .find((el) => el && !el.closest(BR.UI_SENDIRI));          // jangan pernah kotak tanggal panel ekstensi lain
    if (!tgl) return laporCari(req, { poli: kodePoli, galat: `kotak Tanggal Pemeriksaan tidak ditemukan di ${namaPoli}` });
    // v1.9.6: ambil SEMUA baris tanggal itu lewat form halaman (POST, sama seperti tombol Tampilkan), lalu cocokkan di sini.
    // Tidak mengetik di kotak Search (dulu hanya kata pertama/terakhir nama yang dicari, dan isian Search tersimpan
    // oleh stateSave sehingga daftar poli Anda ikut tersaring), tidak terpengaruh jumlah baris per halaman.
    const barisFetch = await semuaBarisTabel(req, tgl);
    if (barisFetch) return laporCari(req, cocokkanBaris(req, kodePoli, barisFetch.rows, barisFetch.iNama));
    if (tgl.value !== req.tgl) {
      if (req.tglDicoba) return laporCari(req, { poli: kodePoli, galat: `tanggal ${namaPoli} tidak bisa diubah ke ${req.tgl}` });
      await BR.store.set(kunciReq(req.tabId), { ...req, tglDicoba: true });
      Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set.call(tgl, req.tgl);
      BR.fire(tgl);
      const form = tgl.form;
      const btn = (form || document).querySelector("button[type=submit], input[type=submit]") ||
        [...document.querySelectorAll("button, input[type=button], a.btn")].find((b) => /cari|tampil|filter|search|lihat/i.test(b.textContent || b.value || ""));
      if (btn) btn.click(); else if (form) form.submit();
      await BR.sleep(2500);                         // bila halaman dimuat ulang, skrip ini berjalan lagi
      if (tgl.isConnected && tgl.value !== req.tgl) return laporCari(req, { poli: kodePoli, galat: `tanggal ${namaPoli} tidak bisa diubah ke ${req.tgl}` });
    }
    // CADANGAN (fetch gagal): cari dengan KATA PERTAMA nama saja, supaya beda ejaan / nama dipendekkan tetap muncul
    const cari = document.querySelector("input[type=search]");
    const kata1 = key.split(" ").find((w) => w.length >= 3) || key;
    const sel = (tr) => [...tr.cells];
    const pas = (tr) => sel(tr).some((td) => { const k = BR.nameKey(td.textContent); return k && (k === key || (k.includes(key) && key.split(" ").length >= 2)); });
    const skorBaris = (tr) => Math.max(0, ...sel(tr).map((td) => BR.namaMirip(td.textContent, req.nama)));
    const namaBaris = (tr) => { const c = sel(tr).map((td) => [td.textContent.trim(), BR.namaMirip(td.textContent, req.nama)]).sort((a, b) => b[1] - a[1])[0]; return c ? c[0] : ""; };
    const jkCocok = (tr) => { const t = " " + BR.norm(tr.textContent) + " ";
      return !req.kelamin || !/ (l|p|laki-laki|perempuan) /.test(t) || (req.kelamin === "P" ? / (p|perempuan) /.test(t) : / (l|laki-laki) /.test(t)); };
    const tautan = (tr) => (tr.querySelector("a[href*='/Poli/'], a[href*='/Kia/' i]") || tr.querySelector("a[href]:not([href='#'])"))?.href || "";
    // CEPAT: cek tiap 250 ms; berhenti begitu ada yang cocok ATAU tabel menyatakan kosong (maks. ±2,5 dtk per kueri)
    const kosong = () => !!document.querySelector("td.dataTables_empty, .dataTables_empty") ||
      /tidak ada data|no matching|data tidak ditemukan|no data/i.test(document.querySelector("table tbody")?.textContent || "");
    const kataAkhir = key.split(" ").filter((w) => w.length >= 3).pop();
    const kueri = cari ? [kata1, ...(kataAkhir && kataAkhir !== kata1 ? [kataAkhir] : [])] : [null];   // 1) kata pertama 2) kata terakhir (ejaan depan beda)
    let rows = [], mirip = [];
    for (const q of kueri) {
      if (cari) { BR.setValue(cari, q); BR.pressEnter(cari); }
      for (let i = 0; i < 10; i++) {
        await BR.sleep(250);
        const semua = [...document.querySelectorAll("table tbody tr")];
        rows = semua.filter(pas);
        mirip = semua.filter((tr) => !pas(tr) && skorBaris(tr) >= 0.75);
        if (rows.length || mirip.length || (i >= 1 && kosong())) break;
      }
      if (rows.length || mirip.length) break;
    }
    if (cari) { BR.setValue(cari, ""); BR.pressEnter(cari); }   // v1.9.6: kosongkan Search agar daftar poli Anda tidak tersaring
    if (rows.length > 1) rows = rows.filter(jkCocok);
    const temuan = { poli: kodePoli,
      persis: rows.map((tr) => ({ nama: namaBaris(tr), href: tautan(tr) })),
      mirip: mirip.filter(jkCocok).map((tr) => ({ nama: namaBaris(tr), href: tautan(tr) })) };
    return laporCari(req, temuan);
  }
  if (req.stage === "visit") {
    for (let i = 0; i < 20 && !document.getElementById("Keluhan"); i++) await BR.sleep(500);
    if (!document.getElementById("Keluhan")) return selesaiPekerja(req, { ok: false, pesan: "Halaman kunjungan C-CARE tidak terbuka (field Keluhan tidak ada)." });
    const d = extract();
    const catatan = [];
    const nk = BR.nameKey(d.nama);
    const persis = nk === key || nk.includes(key) || key.includes(nk);
    // v1.9.0: No. Kartu di halaman C-CARE (bila sudah ditampilkan) mengalahkan pencocokan nama
    if (d.kartu && req.kartu && d.kartu !== req.kartu) return selesaiPekerja(req, { ok: false, pesan: `No. Kartu di C-CARE (${d.kartu}) berbeda dengan antrean PCare (${req.kartu}).` });
    const kartuCocok = !!(d.kartu && req.kartu && d.kartu === req.kartu);
    if (!persis && !kartuCocok && BR.namaMirip(d.nama, req.nama) < 0.75) return selesaiPekerja(req, { ok: false, pesan: `Nama di kunjungan (${d.nama}) tidak cocok dengan ${req.nama}.` });
    if (!persis && !kartuCocok) catatan.push(`nama C-CARE "${d.nama}" tidak persis sama dengan PCare "${req.nama}"`);
    if (d.kelamin && req.kelamin && d.kelamin !== req.kelamin) {
      // v3.2.9: petugas memilih "Tetap proses" → beda JK dicatat sebagai peringatan, bukan penolakan
      if (!req.abaikanJK) return selesaiPekerja(req, { ok: false, pesan: `Jenis kelamin C-CARE (${d.kelamin}) ≠ PCare (${req.kelamin}).` });
      catatan.push(`jenis kelamin C-CARE (${d.kelamin}) berbeda dengan PCare (${req.kelamin}); diproses atas pilihan petugas`);
    }
    if (d.umur != null && !isNaN(req.usia) && Math.abs(d.umur - req.usia) > 1) return selesaiPekerja(req, { ok: false, pesan: `Umur C-CARE (${d.umur}) ≠ PCare (${req.usia}).` });
    if (!tglRegex(req.tgl).test(document.body.textContent)) catatan.push(`tanggal ${req.tgl} tidak terlihat di halaman kunjungan`);
    d.tglKunjungan = req.tgl;
    await simpanKeAntrian(d);
    lapor(`Data ${d.nama} diambil.`);
    return selesaiPekerja(req, { ok: true, nama: d.nama, catatan, poli: req.poliTemu ? BR.NAMA_POLI[req.poliTemu] : "", url: d.ccareUrl || "" });
  }
  return false;
}

BR.pasangPencatatGalat("CCARE");
buildCcareButton();
jalankanPekerja().then(async (pekerja) => {
  if (pekerja) return;
  // tab C-CARE biasa: login otomatis bila halaman login & diaktifkan
  if (BR.diAplikasi && !BR.formLogin()) BR.store.set("kabarLogin_ccare", null);   // v3.2.0: sudah masuk → pita login di aplikasi hilang
  if (BR.formLogin() && (await BR.kunciLogin("ccare"))) {
    const h = await BR.loginOtomatis("ccare", null, { kotak: true });
    if (h === "mati") BR.kabarLogin("Login otomatis C-CARE belum aktif. Aktifkan di Pengaturan, atau login manual.");
    setTimeout(() => BR.lepasKunciLogin("ccare"), h === "dikirim" ? 8000 : 0);
  }
});
