/* Draf CPPT sementara (v4.7.7: localStorage browser ini, 24 jam — tidak terkirim ke mana pun):
 *  - Anamnesa, pemeriksaan fisik, diagnosa, tata laksana, dan resep yang sudah diketik disimpan otomatis tiap Anda mengetik.
 *  - Jika halaman ini tertutup/berganti TANPA SENGAJA (tombol Back/Forward browser, atau C-CARE menolak Simpan karena error
 *    lain) dan Anda membuka kunjungan yang SAMA lagi, isian itu dipulihkan otomatis (ditandai kuning — periksa sebelum Simpan).
 *  - Tidak ada lagi peringatan saat memuat ulang / menutup halaman (v4.7.7): isian sudah aman di draf.
 *  - Draf TIDAK dihapus saat Simpan ditekan (C-CARE bisa menolak, mis. "Formulir informasi rencana asuhan wajib diisi");
 *    dihapus saat kunjungan ini dibuka lagi dan isiannya sudah tersimpan di C-CARE, atau otomatis kedaluwarsa setelah 24 jam.
 * Tidak bisa dimatikan dari Pengaturan — ini jaring pengaman, tidak mengubah isian atau tampilan. */
(() => {
  const mUrl = location.pathname.match(/\/Ubah\/(\d+)/i); if (!mUrl || window.__sjcDraf) return; window.__sjcDraf = true;
  const KUNCI = 'sjcDraf_' + mUrl[1], UMUR = 24 * 3600 * 1000;
  try { Object.keys(localStorage).forEach(k => { if (k.startsWith('sjcDraf_')) { const d = JSON.parse(localStorage.getItem(k) || 'null'); if (!d || Date.now() - d.t > UMUR) localStorage.removeItem(k); } }); } catch (e) {}
  const bersih = s => String(s == null ? '' : s).replace(/\s+/g, ' ').trim();
  const FIELD_TEKS = ['AmnesaDokter', 'KepalaMuka', 'Thorax', 'Abdomen', 'Extremitas', 'Ekg', 'Diagnosa', 'TataLaksana', 'Pengobatan', 'KeteranganRujukan'];
  const FIELD_PILIH = ['TindakLanjutPengobatanId', 'StatusKunjunganID', 'StatusRujukanId', 'RujukanPoliId'];   // v4.8.3: ikut pulih setelah muat ulang
  const elTeks = n => document.getElementById(n);
  const bawaan = el => (([...el.options].find(o => o.defaultSelected) || el.options[0] || {}).value || '');
  const indeksResep = () => [...document.querySelectorAll('select[name^="ListResep["][name$="].ObatID"]')].map(s => +(s.name.match(/ListResep\[(\d+)\]/) || [])[1]).filter(n => !isNaN(n));
  const baris = i => ({
    obat: document.getElementById('obat_' + i), jumlah: document.getElementById('jumlah_obat_' + i),
    intensitas: document.getElementById(`ListResep_${i}__IntensitasDosis`), jumlahDosis: document.getElementById(`ListResep_${i}__JumlahDosis`),
    satuan: document.getElementById(`ListResep_${i}__SatuanPembagiDosisId`), ket: document.getElementById(`ListResep_${i}__Keterangan`),
    makan: [...document.querySelectorAll(`input[type=radio][name="ListResep[${i}].IsSebelumMakan"]`)], racikan: document.getElementById('isRacikan_' + i)
  });
  const terpilih = el => el && el.value && el.selectedIndex > 0 && !/^--|^pilih/i.test(el.value);

  function baca() {
    if (!document.getElementById('AmnesaDokter')) return null;
    const teks = {}; FIELD_TEKS.forEach(n => { const el = elTeks(n); if (el) teks[n] = el.value; });
    const resep = indeksResep().filter(i => { const x = baris(i); return terpilih(x.obat) && !(x.racikan && x.racikan.checked); }).map(i => {
      const x = baris(i);
      return { obat: x.obat.value, jumlah: x.jumlah.value, intensitas: x.intensitas.value, jumlahDosis: x.jumlahDosis.value, satuan: x.satuan ? x.satuan.value : '', makan: (x.makan.find(r => r.checked) || {}).value || '', ket: x.ket.value };
    });
    const pilih = {}; FIELD_PILIH.forEach(n => { const el = elTeks(n); if (el) pilih[n] = el.value; });
    const k = elTeks('KodePenyakit'), icd = k ? [...k.selectedOptions].map(o => ({ v: o.value, t: o.textContent })) : [];
    return { t: Date.now(), teks, resep, pilih, icd };
  }
  const adaIsi = d => !!(d && (Object.values(d.teks).some(v => bersih(v)) || d.resep.length));
  let tersimpanTerakhir = '';
  function simpanDraf() { const d = baca(); if (!d) return; const s = JSON.stringify(d); if (s === tersimpanTerakhir) return; tersimpanTerakhir = s; try { localStorage.setItem(KUNCI, s); } catch (e) {} }
  let tunda = 0; const jadwalSimpan = () => { clearTimeout(tunda); tunda = setTimeout(simpanDraf, 600); };
  function hapusDraf() { try { localStorage.removeItem(KUNCI); } catch (e) {} tersimpanTerakhir = ''; }

  const GAYA = document.createElement('style');
  GAYA.textContent = `.sjc-draf-info{display:flex;align-items:center;gap:10px;margin:0 0 10px;padding:8px 12px;background:#FFF5E6;border:1px solid #E9B872;border-radius:8px;font:13px/1.4 "Source Sans 3","Source Sans Pro","Segoe UI",system-ui,sans-serif;color:#B45309}
  .sjc-draf-info button{height:26px;padding:0 10px;border:1px solid #D5E0E0;border-radius:8px;background:#fff;color:#0F2742;font-size:12px;cursor:pointer;flex:none;margin-left:auto;font-family:inherit}`;
  document.head.appendChild(GAYA);

  function pulihkan() {
    /* dijalankan SEGERA (tidak menunggu), agar menang dari Auto Fill (isi-cepat.js) yang mengisi templat bawaan secara
       asinkron (chrome.storage.local.get) ke isian yang sama — Auto Fill sendiri tidak menimpa isian yang sudah terisi,
       jadi draf yang lebih dulu mengisi akan dipertahankan Auto Fill. */
    let d; try { d = JSON.parse(localStorage.getItem(KUNCI) || 'null'); } catch (e) { d = null; }
    if (!adaIsi(d) || Date.now() - d.t > UMUR) return;
    const resepKosong = !indeksResep().some(i => terpilih(baris(i).obat));
    /* per isian: pulihkan bila isian masih bawaan dari server (mis. anamnesa perawat yang tersalin) dan draf berbeda */
    const beda = FIELD_TEKS.filter(n => { const el = elTeks(n); return el && bersih(d.teks[n]) && bersih(d.teks[n]) !== bersih(el.value) && el.value === el.defaultValue; });
    const pilihBeda = FIELD_PILIH.filter(n => { const el = elTeks(n); return el && d.pilih && d.pilih[n] && d.pilih[n] !== el.value && el.value === bawaan(el) && [...el.options].some(o => o.value === d.pilih[n]); });
    const kp = elTeks('KodePenyakit'), icdPulih = kp && !kp.selectedOptions.length && d.icd && d.icd.length ? d.icd : [];
    if (!beda.length && !pilihBeda.length && !icdPulih.length && (!resepKosong || !d.resep.length)) { hapusDraf(); return; }   // sudah tersimpan di C-CARE → draf tidak perlu
    let dipulihkan = 0;
    pilihBeda.forEach(n => { const el = elTeks(n); el.value = d.pilih[n]; el.dispatchEvent(new Event('change', { bubbles: true })); dipulihkan++; });
    if (icdPulih.length) { icdPulih.forEach(x => kp.appendChild(new Option(x.t, x.v, true, true))); kp.dispatchEvent(new Event('change', { bubbles: true })); dipulihkan++; }
    beda.forEach(n => { const el = elTeks(n); el.value = d.teks[n]; el.dispatchEvent(new Event('input', { bubbles: true })); el.classList.add('sjc-draf-pulih'); dipulihkan++; });
    if (resepKosong && d.resep.length) { setTimeout(() => document.dispatchEvent(new CustomEvent('sjc-pulihkan-resep', { detail: JSON.stringify(d.resep) })), 400); dipulihkan += d.resep.length; }
    if (!dipulihkan) return;
    const p = document.getElementById('Pemeriksaan_tab'); if (!p) return;
    const b = document.createElement('div'); b.className = 'sjc-draf-info';
    b.innerHTML = '<span>Isian yang belum tersimpan dipulihkan (draf ' + new Date(d.t).toLocaleString('id-ID', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }) + ', disimpan 24 jam) — periksa sebelum Simpan.</span><button type="button">Hapus draf</button>';
    (p.querySelector('.box-body') || p).prepend(b);
    b.querySelector('button').onclick = () => {
      hapusDraf();
      FIELD_TEKS.forEach(n => { const el = elTeks(n); if (el && el.classList.contains('sjc-draf-pulih')) { el.value = el.defaultValue; el.classList.remove('sjc-draf-pulih'); } });
      b.remove();
    };
  }

  document.addEventListener('input', jadwalSimpan, true);
  document.addEventListener('change', jadwalSimpan, true);
  document.addEventListener('isicepat-ubah', jadwalSimpan);
  let sedangSimpan = false;
  document.addEventListener('submit', e => {
    if (!(e.target && e.target.querySelector && e.target.querySelector('#btn-simpan'))) return;
    if (e.defaultPrevented) return;                                           // dibatalkan skrip lain (mis. pengecekan stok) → draf & peringatan tetap aktif
    sedangSimpan = true; simpanDraf();                                         // draf tetap ada sampai terbukti tersimpan
  }, false);                                                                   // fase bubble: berjalan setelah pemeriksaan di fase capture
  window.addEventListener('pagehide', () => { if (!sedangSimpan) simpanDraf(); });   // tanpa peringatan "Reload site?": draf 24 jam sudah melindungi isian
  pulihkan();
})();
