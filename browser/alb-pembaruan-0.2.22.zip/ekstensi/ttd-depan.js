/* CCare Dokter v4.10.5 — tanda tangan Informasi Rencana Asuhan di halaman CPPT (/Poli/Ubah/{id}, /Kia/Ubah/{id}).
 * 1) Lencana status di kanan atas kartu CPPT: Belum TTD · Menunggu TTD · Sudah TTD · 10.42 · TTD gagal.
 *    Status dibaca dari C-CARE (form Informasi Rencana Asuhan kunjungan ini: kotak kosong = belum, gambar tanda tangan = sudah),
 *    bukan dari ingatan ekstensi → tetap benar setelah F5. Relay tablet hanya menambah "menunggu", "gagal", dan jam.
 * 2) Panel form asli C-CARE (iframe, origin sama). Dengan tablet: tersembunyi, dibuka dari balon "Tanda tangan di PC".
 *    Tanpa tablet: terbuka otomatis seperti sebelumnya.
 * Ekstensi tidak membuat, menyalin, atau mengisi tanda tangan; Simpan selalu tombol milik C-CARE. */
(() => {
  if (window.top !== window || window.__sjcTtdDepan) return; window.__sjcTtdDepan = true;
  const tautan = [...document.querySelectorAll('a[href*="/Poli/FormInformasiRencanaAsuhan/"]')];
  const asli = tautan.find(a => a.closest('#Pemeriksaan_tab')) || tautan.find(a => /btn/.test(a.className)); if (!asli) return;
  const url = new URL(asli.getAttribute('href'), location.origin).href;
  const idK = (url.match(/(\d+)\/?$/) || [])[1] || '';
  const POLA_URL = /^https:\/\/script\.google\.com\/macros\/s\/[\w-]+\/exec$/, POLA_T = /^[\w-]{20,64}$/;
  const ss = { get: k => { try { return sessionStorage.getItem(k) || ''; } catch (e) { return ''; } }, set: (k, v) => { try { sessionStorage.setItem(k, v); } catch (e) {} } };
  const jamDari = ms => { const d = new Date(+ms); return String(d.getHours()).padStart(2, '0') + '.' + String(d.getMinutes()).padStart(2, '0'); };

  const st = document.createElement('style');
  st.textContent = `.sjc-ttd{clear:both;margin:12px 0;border:1px solid #D5E0E0;border-radius:12px;background:#fff;font:14px/1.4 "Source Sans 3","Source Sans Pro",system-ui,sans-serif;color:#0F2742}
    .sjc-ttd-baris[hidden]{display:none}
    .sjc-ttd .isi{padding:12px 16px 16px}
    .sjc-ttd iframe{display:block;width:100%;max-width:560px;height:260px;border:1px solid #E3EBEA;border-radius:8px;background:#F5F8F8}
    .sjc-ttd .ket{display:flex;align-items:center;flex-wrap:wrap;gap:8px;margin:0 0 8px;font-size:13px;color:#4F6478}
    .sjc-ttd .ket.ok{color:#3B7A1E}.sjc-ttd .ket svg{width:16px;height:16px;fill:currentColor}
    .sjc-ttd a{color:#263C92}
    .sjc-ttd .ket button{min-height:32px;padding:0 12px;border:1px solid #263C92;border-radius:8px;background:#fff;color:#263C92;font-family:"Source Sans 3","Source Sans Pro",system-ui,sans-serif;font-weight:600;font-size:13px;white-space:nowrap;cursor:pointer}
    .sjc-lencana-wadah{position:relative}
    .sjc-lencana{position:absolute;right:8px;top:50%;transform:translateY(-50%);z-index:5;display:inline-flex;align-items:center;gap:4px;height:24px;padding:0 10px 0 8px;border:1px solid transparent;border-radius:12px;font-family:"Source Sans 3","Source Sans Pro",system-ui,sans-serif;font-size:13px;font-weight:600;line-height:1;white-space:nowrap;font-variant-numeric:tabular-nums;cursor:pointer;background:#EEF1F6;color:#4F6478}
    .sjc-lencana.sebaris{position:static;transform:none;margin-left:8px;vertical-align:middle}
    .sjc-lencana svg{width:16px;height:16px;fill:currentColor;flex:none}
    .sjc-lencana[data-st="menunggu"]{background:#FFF4E5;color:#B45309;border-color:#F3D3A6}
    .sjc-lencana[data-st="sudah"]{background:#E7F2E1;color:#3B7A1E;border-color:#C5DFB8}
    .sjc-lencana[data-st="gagal"]{background:#FBEAEA;color:#B91C1C;border-color:#EFC2C2}
    .sjc-lencana:focus-visible{outline:2px solid #263C92;outline-offset:2px}
    .sjc-balon{position:absolute;right:8px;top:calc(50% + 18px);z-index:30;width:264px;padding:12px;border:1px solid #D5E0E0;border-radius:12px;background:#fff;box-shadow:0 8px 24px rgba(15,39,66,.16);font-family:"Source Sans 3","Source Sans Pro",system-ui,sans-serif;font-size:13px;line-height:1.4;color:#0F2742;text-align:left;white-space:normal}
    .sjc-balon[hidden]{display:none}
    .sjc-balon dl{display:grid;grid-template-columns:auto 1fr;gap:4px 12px;margin:0 0 12px}.sjc-balon dt{color:#4F6478;font-weight:400}.sjc-balon dd{margin:0;font-weight:600;font-variant-numeric:tabular-nums}
    .sjc-balon button{display:block;width:100%;min-height:32px;margin-top:8px;border:1px solid #263C92;border-radius:8px;background:#fff;color:#263C92;font-family:inherit;font-size:13px;font-weight:600;cursor:pointer}
    .sjc-balon button.utama{background:#263C92;color:#fff}
    .sjc-balon button:focus-visible{outline:2px solid #263C92;outline-offset:2px}
    .sjc-balon p{margin:8px 0 0;color:#4F6478}`;
  document.head.appendChild(st);
  const IK = {
    pena: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM5.92 19H5v-.92l9.06-9.06.92.92L5.92 19zM20.71 5.63l-2.34-2.34a1 1 0 0 0-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83a1 1 0 0 0 0-1.41z"/></svg>',
    jam: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm0 18a8 8 0 1 1 0-16 8 8 0 0 1 0 16zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67V7z"/></svg>',
    cek: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 16.17 4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>',
    awas: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M1 21h22L12 2 1 21zm12-3h-2v-2h2v2zm0-4h-2v-4h2v4z"/></svg>',
  };

  /* ---------- panel form (dipakai saat tanda tangan di PC) ---------- */
  const panel = document.createElement('section'); panel.className = 'sjc-ttd'; panel.setAttribute('aria-label', 'Tanda tangan pasien atau keluarga');
  panel.innerHTML = `<div class="isi"><p class="ket">Tanda tangan pasien/keluarga di kotak, lalu tekan Simpan milik C-CARE.<button type="button" class="tb-lengkap" hidden>Form lengkap</button></p></div>`;
  const isi = panel.querySelector('.isi'), lengkap = panel.querySelector('.tb-lengkap');
  let barisPanel = null;
  const ttdDr = [...document.querySelectorAll('#Pemeriksaan_tab tr')].find(tr => tr.cells[0] && /^\s*(TTD|Tanda\s*tangan)\s*Dokter/i.test(tr.cells[0].textContent));
  /* letak panel: DI ATAS Anamnesa Dokter — tanda tangan dibutuhkan di awal, jadi tampil paling atas agar tidak terlupa.
     Cadangan: sesudah baris "TTD Dokter"; terakhir: paling atas tab Pemeriksaan. */
  const fAnam = document.querySelector('#Pemeriksaan_tab #AmnesaDokter, #Pemeriksaan_tab textarea[name*="mnesa" i]');
  const barisAnam = (fAnam && fAnam.closest('tr')) || [...document.querySelectorAll('#Pemeriksaan_tab tr')].find(tr => tr.cells[0] && /^\s*Anamnesa\s*Dokter/i.test(tr.cells[0].textContent));
  const barisBaru = ref => { const tr = document.createElement('tr'); tr.className = 'sjc-ttd-baris'; const td = document.createElement('td'); td.colSpan = Math.max(2, ref.cells.length); td.appendChild(panel); tr.appendChild(td); return tr; };
  if (barisAnam) { barisPanel = barisBaru(barisAnam); barisAnam.before(barisPanel); }
  else if (ttdDr) { barisPanel = barisBaru(ttdDr); ttdDr.after(barisPanel); }
  else { const tab = document.querySelector('#Pemeriksaan_tab'); const wadah = tab && (tab.querySelector('.box-body') || tab); barisPanel = panel; if (wadah) wadah.prepend(panel); else asli.insertAdjacentElement('afterend', panel); }
  let fr = null;
  function rapikan() {   // hanya kotak tanda tangan + Bersihkan + Simpan yang tampil; isi form C-CARE tidak diubah dan tetap terkirim utuh
    let d; try { d = fr.contentDocument; } catch (e) { return; } if (!d || !d.head) return;
    if (!/FormInformasiRencanaAsuhan/i.test(fr.contentWindow.location.pathname)) {    // C-CARE mengalihkan setelah Simpan = server menerima
      /* halaman ini dimuat SEBELUM tanda tangan ada → C-CARE menolak Simpan CPPT sampai disegarkan. Segarkan sendiri:
         draf (cppt-draf.js) memulihkan anamnesa, ICD-10, tindak lanjut, dan resep; posisi gulir dikembalikan. */
      fr.remove(); fr = null; tulis('sudah', Date.now(), 'PC');
      ss.set('sjcTtdSudah', idK); ss.set('sjcTtdJam', String(Date.now())); ss.set('sjcTtdGulir', String(scrollY));
      setTimeout(() => location.reload(), 400); return;
    }
    const tombol = [...d.querySelectorAll('button, input[type=submit], input[type=button]')].filter(b => !b.closest('.sjc-ttd-bar')), teks = b => (b.textContent || b.value || '').trim();
    const kv = d.querySelector('canvas'), simpan = tombol.find(b => /^simpan$/i.test(teks(b))), bersihkan = tombol.find(b => /^(bersihkan|hapus)$/i.test(teks(b)));
    const g = d.createElement('style');
    g.textContent = '.main-header,.main-sidebar,.main-footer,.content-header,.breadcrumb{display:none!important}.content-wrapper{margin-left:0!important;min-height:0!important;padding-top:0!important}body{background:#fff!important;padding-top:0!important}'
      /* kotak & gambar tanda tangan dibuat mini: lebar kotak dibatasi (skrip C-CARE tetap menghitung goresan dari ukuran tampil,
         sama seperti saat layar penuh), gambar tanda tangan tersimpan diperkecil — hanya tampilan, isi form tidak berubah */
      + '.ccare-canvas-stage:not(:fullscreen):not(.sjc-penuh){max-width:360px!important;margin-left:auto!important;margin-right:auto!important}'
      + 'form img{max-width:240px!important;max-height:110px!important;width:auto!important;height:auto!important}';
    if (kv && simpan) {   // tanpa keduanya form tampil utuh (lebih baik lengkap daripada tidak bisa menyimpan)
      [kv, simpan, bersihkan].filter(Boolean).forEach(el => { el.dataset.sjcJaga = 'daun'; for (let a = el.parentElement; a && a !== d.body; a = a.parentElement) if (!a.dataset.sjcJaga) a.dataset.sjcJaga = '1'; });
      g.textContent += 'body *:not([data-sjc-jaga]):not([data-sjc-jaga="daun"] *):not(.ccare-canvas-stage):not(.ccare-canvas-stage *){display:none!important}'
        + '[data-sjc-jaga="1"]:not(.ccare-canvas-stage){margin:0!important;padding:0!important;border:0!important;box-shadow:none!important;background:none!important;min-height:0!important;text-align:center!important}'
        + 'body{padding:12px!important}[data-sjc-jaga="daun"]:not(canvas){margin:8px 4px 0!important}';
      lengkap.hidden = false; lengkap.onclick = () => { g.remove(); lengkap.hidden = true; fr.style.height = '640px'; };   // mis. keluarga yang tanda tangan → ubah nama
      const ukur = () => { if (fr) fr.style.height = Math.max(180, d.documentElement.scrollHeight + 8) + 'px'; };
      setTimeout(ukur, 100); setTimeout(ukur, 1200);
    }
    d.head.appendChild(g);
  }
  function bukaPanel() {
    barisPanel.hidden = false;
    if (fr) return;
    fr = document.createElement('iframe'); fr.title = 'Form Informasi Rencana Asuhan'; fr.allow = 'fullscreen'; fr.src = url;
    fr.addEventListener('load', rapikan); isi.appendChild(fr);
  }
  function tutupPanel() { barisPanel.hidden = true; if (fr) { fr.remove(); fr = null; } }

  /* ---------- lencana + balon ---------- */
  const lencana = document.createElement('button'); lencana.type = 'button'; lencana.className = 'sjc-lencana';
  lencana.setAttribute('aria-haspopup', 'dialog'); lencana.setAttribute('aria-expanded', 'false');
  const balon = document.createElement('div'); balon.className = 'sjc-balon'; balon.hidden = true; balon.setAttribute('role', 'dialog'); balon.setAttribute('aria-label', 'Status tanda tangan');
  const kepala = document.querySelector('form[action*="/Ubah/"] .card-header') || document.querySelector('#Pemeriksaan_tab')?.closest('form')?.querySelector('.card-header');
  if (kepala) {
    kepala.classList.add('sjc-lencana-wadah'); kepala.append(lencana, balon);
    /* di kiri tombol "Formulir" (formulir-menu.js) yang juga menempel di kanan kepala kartu */
    const posisi = () => {                                                // sebaris dengan tombol Formulir (ikut turun bila kepala kartu terlipat di layar sempit)
      const fm = kepala.querySelector('.sjc-fm'), r = kepala.getBoundingClientRect(), f = fm && fm.offsetParent ? fm.getBoundingClientRect() : null;
      const kanan = f ? Math.round(r.right - f.left) + 8 : 8, tengah = f ? Math.round(f.top + f.height / 2 - r.top) : Math.round(r.height / 2);
      lencana.style.right = balon.style.right = kanan + 'px'; lencana.style.top = tengah + 'px'; balon.style.top = (tengah + 18) + 'px';
    };
    posisi(); new MutationObserver(posisi).observe(kepala, { childList: true, subtree: true }); addEventListener('resize', posisi);
  }
  else if (ttdDr) { lencana.classList.add('sebaris'); ttdDr.cells[1].classList.add('sjc-lencana-wadah'); ttdDr.cells[1].append(lencana, balon); }
  else { lencana.classList.add('sebaris'); asli.after(lencana, balon); }

  /* status: ccare = 'memeriksa' | 'belum' | 'sudah' | 'tidak' (form tak terbaca) ; relay hanya pelengkap */
  const S = { ccare: 'memeriksa', jam: 0, perangkat: '', relay: null, terkirim: null, tablet: false };
  function tulis(st, jam, perangkat) { if (st === 'sudah') { S.ccare = 'sudah'; if (jam) S.jam = jam; if (perangkat) S.perangkat = perangkat; } render(); }
  function status() {
    if (S.ccare === 'sudah') return 'sudah';
    if (S.ccare !== 'belum') return S.ccare;
    const r = S.relay;
    if (r && String(r.gagal) === idK && (r.gagalW || 0) > (String(r.signed) === idK ? r.signedW || 0 : 0)) return 'gagal';
    if (S.tablet && S.terkirim && tabletAktif()) return 'menunggu';
    return 'belum';
  }
  const tabletAktif = () => { const r = S.relay; return !r || r.tabletW === undefined || (r.kini && r.tabletW && r.kini - r.tabletW < 60000); };   // relay lama tanpa detak: anggap aktif
  function render() {
    const s = status();
    const isi = { memeriksa: [IK.jam, 'Memeriksa TTD'], belum: [IK.pena, 'Belum TTD'], menunggu: [IK.jam, 'Menunggu TTD'],
      sudah: [IK.cek, 'Sudah TTD' + (S.jam ? ' · ' + jamDari(S.jam) : '')], gagal: [IK.awas, 'TTD gagal'], tidak: [IK.awas, 'TTD tidak terbaca'] }[s];
    lencana.dataset.st = s === 'tidak' || s === 'memeriksa' ? 'belum' : s;
    lencana.innerHTML = isi[0] + '<span>' + isi[1] + '</span>';
    lencana.setAttribute('aria-label', 'Status tanda tangan: ' + isi[1] + '. Buka rincian.');
    if (!balon.hidden) isiBalon();
  }
  function isiBalon() {
    const s = status(), r = S.relay || {};
    const baris = [['Status', { memeriksa: 'Memeriksa…', belum: 'Belum ditandatangani', menunggu: 'Menunggu di tablet', sudah: 'Sudah ditandatangani', gagal: 'Simpan di tablet gagal', tidak: 'Form tidak terbaca' }[s]]];
    if (s === 'sudah') baris.push(['Jam', S.jam ? jamDari(S.jam) : '—'], ['Perangkat', S.perangkat || '—']);
    if (s === 'gagal' && r.gagalW) baris.push(['Jam', jamDari(r.gagalW)], ['Perangkat', 'Tablet']);
    if (S.tablet) baris.push(['Tablet', S.relay ? (tabletAktif() ? 'Aktif' : 'Tidak aktif') : 'Tidak terhubung']);
    balon.innerHTML = '<dl>' + baris.map(([a, b]) => `<dt>${a}</dt><dd>${b}</dd>`).join('') + '</dl>';
    if (S.tablet && s !== 'sudah') { const b = document.createElement('button'); b.type = 'button'; b.className = 'utama'; b.textContent = 'Kirim ulang ke tablet'; b.onclick = () => { kirim(true); b.textContent = 'Terkirim'; }; balon.appendChild(b); }
    if (s !== 'sudah') { const b = document.createElement('button'); b.type = 'button'; b.textContent = barisPanel.hidden ? 'Tanda tangan di PC' : 'Tutup tanda tangan di PC'; b.onclick = () => { barisPanel.hidden ? bukaPanel() : tutupPanel(); bukaBalon(false); }; balon.appendChild(b); }
    if (s === 'gagal') { const p = document.createElement('p'); p.textContent = 'Pasien bisa menekan Coba lagi di tablet.'; balon.appendChild(p); }
  }
  function bukaBalon(ya) { balon.hidden = !ya; lencana.setAttribute('aria-expanded', String(ya)); if (ya) { isiBalon(); (balon.querySelector('button') || lencana).focus(); } }
  lencana.addEventListener('click', e => { e.preventDefault(); e.stopPropagation(); bukaBalon(balon.hidden); });   // di dalam form: jangan kirim form
  document.addEventListener('click', e => { if (!balon.hidden && !balon.contains(e.target) && e.target !== lencana) bukaBalon(false); });
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && !balon.hidden) { bukaBalon(false); lencana.focus(); } });

  /* baca status dari C-CARE: halaman form yang sama dengan tombol "Formulir Informasi Rencana Asuhan" (GET, hanya membaca) */
  async function bacaCcare() {
    try {
      const res = await fetch(url, { credentials: 'same-origin', cache: 'no-store' });
      const d = new DOMParser().parseFromString(await res.text(), 'text/html');
      if (!res.ok || d.querySelector('input[type=password]')) S.ccare = 'tidak';
      else if (d.querySelector('canvas')) S.ccare = 'belum';
      else if ([...d.images].some(im => !im.closest('.main-header,.main-sidebar,.navbar,.logo,header,footer') && (/^data:image\//.test(im.getAttribute('src') || '') || +(im.getAttribute('width') || 0) >= 120 || /ttd|tanda|sign|paraf/i.test(im.getAttribute('src') || '')))) S.ccare = 'sudah';
      else S.ccare = 'tidak';
    } catch (e) { S.ccare = 'tidak'; }
    if (S.ccare === 'sudah' && !S.jam && ss.get('sjcTtdSudah') === idK) { S.jam = +ss.get('sjcTtdJam') || 0; S.perangkat = 'PC'; }   // jam saat ditandatangani di PC (tab ini)
    render();
    return S.ccare;
  }

  /* ---------- relay tablet (PC) ---------- */
  let cfg = null, pantau = null, awal;
  const relay = q => new Promise(ok => { try { chrome.runtime.sendMessage({ aksi: 'relayTtd', url: `${cfg.url}?t=${cfg.t}&${q}` }, r => ok(chrome.runtime.lastError ? null : r)); } catch (e) { ok(null); } });
  function kirim(ulang) {
    relay('set=' + idK).then(r => { S.terkirim = !!(r && r.ok); render(); });
    if (ulang || !pantau) mulaiPantau();
  }
  /* dokter meninggalkan CPPT ini (pindah halaman/tutup tab) → tablet tidak lagi meminta tanda tangan pasien ini (v4.10.8).
     Dikerjakan background (halaman sedang ditutup); hanya bila relay masih memegang kunjungan ini. */
  addEventListener('pagehide', () => { if (cfg && S.terkirim) try { chrome.runtime.sendMessage({ aksi: 'relayLepas', id: idK }); } catch (e) {} });
  /* v4.10.21: tiap 1 detik bila tablet aktif (detak < 60 dtk), tiap 5 detik bila tidak — beban relay Apps Script tetap rendah.
     Rantai setTimeout: permintaan berikutnya baru dikirim setelah yang sebelumnya selesai (relay lambat tidak menumpuk).
     Tablet melapor tersimpan (signedW berubah) → segarkan halaman agar C-CARE mengenali tanda tangan; draf menjaga ketikan.
     Setelah "gagal" tetap dipantau: pasien bisa Coba lagi. Relay gagal dicatat ke LOG paling sering sekali per menit. */
  let catatGagal = 0, genPantau = 0, cekCcare = Date.now();
  function mulaiPantau() {
    clearTimeout(pantau);
    const gen = ++genPantau;   // mulai ulang saat permintaan masih berjalan → rantai lama berhenti, tidak dobel
    const putaran = async () => {
      if (S.ccare === 'sudah') { pantau = null; return; }
      const r = await relay('get');
      if (gen !== genPantau) return;
      if (!r || !r.ok) {
        S.relay = null; render();
        if (Date.now() - catatGagal > 60000) { catatGagal = Date.now(); console.warn('[SJC] relay TTD gagal:', (r && (r.galat || r.error)) || 'tidak ada jawaban'); }
        pantau = setTimeout(putaran, 5000); return;
      }
      S.relay = r;
      /* v4.10.24: tablet bisa gagal melapor "tersimpan" → tiap ±8 dtk baca form C-CARE langsung; sudah bertanda tangan = segarkan */
      if (Date.now() - cekCcare > 8000) { cekCcare = Date.now(); if (await bacaCcare() === 'sudah') { pantau = null; console.warn('[SJC] TTD terbaca dari C-CARE (tablet tidak melapor)'); ss.set('sjcTtdGulir', String(scrollY)); location.reload(); return; } if (gen !== genPantau) return; }
      const sw = r.signedW || 0;
      if (awal === undefined) awal = sw;
      else if (String(r.signed) === idK && sw !== awal) { pantau = null; ss.set('sjcTtdGulir', String(scrollY)); location.reload(); return; }
      render();
      pantau = setTimeout(putaran, tabletAktif() ? 1000 : 5000);
    };
    pantau = setTimeout(putaran, 0);
  }

  render();
  const gulir = +ss.get('sjcTtdGulir'); if (gulir) { ss.set('sjcTtdGulir', ''); setTimeout(() => scrollTo(0, gulir), 900); }
  chrome.storage.local.get('ttdTablet', async s => {
    const c = s.ttdTablet || {};
    if (c.peran === 'pc' && POLA_URL.test(c.url || '') && POLA_T.test(c.t || '')) { cfg = c; S.tablet = true; }
    barisPanel.hidden = true;
    const hasil = await bacaCcare();
    if (cfg) {
      kirim(false);                                                   // tablet ikut membuka kunjungan ini (bila sudah ditandatangani: tablet menampilkan "Sudah ditandatangani")
      if (S.ccare === 'sudah') { const r = await relay('get'); if (r && r.ok) { S.relay = r; if (String(r.signed) === idK && r.signedW && !S.jam) { S.jam = r.signedW; S.perangkat = 'Tablet'; } render(); } }
    } else if (hasil !== 'sudah') bukaPanel();                         // tanpa tablet: form langsung siap di PC seperti sebelumnya
  });
})();
