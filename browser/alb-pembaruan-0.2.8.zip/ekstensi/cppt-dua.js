/* CPPT dokter "Dua kolom kerja" (arah B) — hanya susunan di layar Anda; data, nama isian, dan tombol C-CARE tidak berubah.
 *  - Kepala pasien lengket: nama, No. RM, usia, JK, jenis pasien, ALERGI (merah), jam daftar/perawat; identitas & riwayat dilipat (1 klik).
 *  - Strip TTV dari pengkajian perawat (abnormal = kuning/merah + teks).
 *  - Kiri: anamnesa, pemeriksaan fisik (2 kolom), diagnosa, tata laksana.  Kanan (lengket): resep (ringkas), alkes, lab,
 *    tindak lanjut, status kunjungan, surat istirahat, rujukan.  Bilah Simpan selalu terlihat di bawah.
 *  - Elemen C-CARE DIPINDAHKAN (bukan disalin) di dalam formulir yang sama → semua isian tetap terkirim saat Simpan.
 * Bisa dimatikan: tombol "Tampilan asli" di kepala pasien, atau Pengaturan → Tampilan → CPPT dua kolom. */
(() => {
  if (!/\/Ubah\/\d+/i.test(location.pathname) || window.__sjcDua) return; window.__sjcDua = true;
  const pane = document.getElementById('Pemeriksaan_tab'); if (!pane) return;
  const fh = pane.querySelector('.form-horizontal'), tabelDokter = pane.querySelector('table.table-bordered');
  if (!fh || !tabelDokter || !document.getElementById('AmnesaDokter')) return;
  const bersih = s => String(s == null ? '' : s).replace(/\s+/g, ' ').trim();
  const esc = t => String(t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const IK = {
    alergi: '<svg viewBox="0 0 24 24"><path d="M1 21h22L12 2 1 21zm12-3h-2v-2h2v2zm0-4h-2v-4h2v4z"/></svg>',
    bawah: '<svg viewBox="0 0 24 24"><path d="M7.4 8.6L12 13.2l4.6-4.6L18 10l-6 6-6-6z"/></svg>',
    atas: '<svg viewBox="0 0 24 24"><path d="M7.4 15.4L12 10.8l4.6 4.6L18 14l-6-6-6 6z"/></svg>',
    tukar: '<svg viewBox="0 0 24 24"><path d="M6.99 11L3 15l3.99 4v-3H14v-2H6.99v-3zM21 9l-3.99-4v3H10v2h7.01v3L21 9z"/></svg>'
  };
  /* ---------- baca dari halaman (hanya untuk ditampilkan di layar ini) ---------- */
  const nilaiIdentitas = label => {
    const p = [...document.querySelectorAll('#IdentitasPasien_tab p.media-body, #IdentitasPasien_tab .text-bold')].find(e => bersih(e.textContent).replace(/\s*:$/, '') === label);
    const kol = p && (p.closest('[class*="col-md-"]') || p.parentElement), v = kol && kol.nextElementSibling;
    return v ? bersih(v.textContent).replace(/^:\s*/, '') : '';
  };
  const nilaiTtv = label => {
    const td = [...document.querySelectorAll('#PengkajianAwal_tab td, #PengkajianUlang_tab td')].find(e => bersih(e.textContent) === label);
    const tr = td && td.closest('tr'); if (!tr) return '';
    const inp = tr.querySelector('input:not([type=hidden]), textarea'); if (inp) return bersih(inp.value);
    return bersih(tr.cells[tr.cells.length - 1].textContent).replace(/^:\s*/, '');
  };
  /* isian TTV dokter sendiri (Sistole, Nadi, dst) — lebih bisa diandalkan daripada tab Pengkajian di atas,
     yang kadang belum terisi walau TTV dokter sudah ada; dipakai duluan, tab Pengkajian jadi cadangan. */
  const nilaiAsli = id => { const el = document.getElementById(id); return el && bersih(el.value) ? bersih(el.value) : ''; };
  const vital = (id, label) => nilaiAsli(id) || nilaiTtv(label);
  const angka = s => { const m = String(s || '').replace(',', '.').match(/\d+(\.\d+)?/); return m ? +m[0] : NaN; };
  const riwayatWaktu = () => {                                                   // tabel Riwayat Status Kunjungan: baris Waktu
    const tr = [...document.querySelectorAll('section.content table tr')].find(r => /^waktu$/i.test(bersih((r.cells[0] || {}).textContent)));
    if (!tr) return [];
    return [...tr.cells].slice(1).map(c => (bersih(c.textContent).match(/(\d{1,2})[.:](\d{2})/) || []).slice(1, 3).join('.'));
  };
  /* ---------- gaya ---------- */
  const gaya = document.createElement('style'); gaya.id = 'sjc-dua-gaya';
  gaya.textContent = `
  html[data-sjc-dua] .sjc-dua-sembunyi{display:none!important}
  .sjc-kepala{position:sticky;top:50px;z-index:1020;display:flex;flex-wrap:wrap;align-items:center;gap:6px 16px;margin:0 0 12px;padding:10px 16px;background:#fff;border:1px solid #D5E0E0;border-radius:12px;font:14px/1.35 "Source Sans 3","Source Sans Pro","Segoe UI",system-ui,sans-serif;color:#0F2742;box-shadow:0 2px 8px rgba(15,39,66,.06)}
  .sjc-kepala .nm{font-size:18px;font-weight:700}.sjc-kepala .m{color:#4F6478;font-variant-numeric:tabular-nums}
  .sjc-kepala .alergi{display:inline-flex;align-items:center;gap:6px;padding:2px 10px;border-radius:999px;background:#FDECEC;color:#B91C1C;font-weight:700;font-size:13px}
  .sjc-kepala .alergi.tidak{background:#F2F6F6;color:#4F6478;font-weight:600}
  .sjc-kepala svg{width:16px;height:16px;fill:currentColor;flex:none}
  .sjc-kepala .alur{display:flex;font-size:12px;color:#4F6478}.sjc-kepala .alur span{padding:0 8px;border-left:1px solid #E3EBEA}.sjc-kepala .alur span:first-child{border:0;padding-left:0}.sjc-kepala .alur b{color:#0F2742}
  .sjc-kepala .kanan{margin-left:auto;display:flex;gap:8px}
  .sjc-kepala button{display:inline-flex;align-items:center;gap:4px;height:30px;padding:0 10px;border:1px solid #D5E0E0;border-radius:8px;background:#fff;color:#0F2742;font-size:13px;font-weight:600;line-height:1;font-family:inherit;cursor:pointer}
  .sjc-kepala button:focus-visible{outline:2px solid #263C92;outline-offset:2px}
  .sjc-ttv{display:flex;flex-wrap:wrap;margin:0 0 12px;border:1px solid #D5E0E0;border-radius:12px;background:#fff;overflow:hidden;font-family:"Source Sans 3","Source Sans Pro","Segoe UI",system-ui,sans-serif}
  .sjc-ttv div{flex:1 1 96px;padding:6px 12px;border-right:1px solid #E3EBEA;color:#0F2742}.sjc-ttv div:last-child{border-right:0}
  .sjc-ttv small{display:block;color:#4F6478;font-size:12px}.sjc-ttv b{font-size:15px;font-variant-numeric:tabular-nums}
  .sjc-ttv .kuning{background:#FFF5E6}.sjc-ttv .kuning b,.sjc-ttv .kuning em{color:#B45309}.sjc-ttv .merah{background:#FDECEC}.sjc-ttv .merah b,.sjc-ttv .merah em{color:#B91C1C}
  .sjc-ttv em{font-style:normal;font-weight:700;font-size:12px}
  html[data-sjc-dua] #Pemeriksaan_tab > .box-body{padding:0}
  .sjc-dua{display:grid;grid-template-columns:minmax(0,1.05fr) minmax(0,1fr);gap:16px;align-items:start}
  .sjc-dua > *{min-width:0}
  .sjc-dua-kanan{overflow-x:hidden}   /* resep memanjang ke bawah (tanpa gulir di dalam kolom) */
  .sjc-dua .form-group{margin-left:0!important;margin-right:0!important}
  .sjc-dua [class*="col-md-"]{width:100%!important;max-width:100%!important;flex:0 0 100%!important;float:none!important;padding-left:0!important;padding-right:0!important}
  .sjc-blok{background:#fff;border:1px solid #D5E0E0;border-radius:16px;padding:12px 16px;margin-bottom:12px}
  .sjc-blok > h3{margin:0 0 10px;font-size:13px;font-weight:700;line-height:1.2;font-family:"Source Sans 3","Source Sans Pro","Segoe UI",system-ui,sans-serif;letter-spacing:.04em;text-transform:uppercase;color:#4F6478}
  /* kiri: tabel isian dokter → kisi label-di-atas */
  .sjc-dua-kiri table.table-bordered{display:block;border:0;margin:0}
  .sjc-dua-kiri table.table-bordered > tbody{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px 16px}
  .sjc-dua-kiri table.table-bordered > tbody > tr{display:flex;flex-direction:column;gap:4px;grid-column:1/-1;min-width:0}
  .sjc-dua-kiri table.table-bordered > tbody > tr.sjc-setengah{grid-column:auto}
  .sjc-dua-kiri table.table-bordered > tbody > tr > td,.sjc-dua-kiri table.table-bordered > tbody > tr > th{display:block;width:auto!important;border:0!important;padding:0!important;background:none!important}
  .sjc-dua-kiri table.table-bordered > tbody > tr > td.text-bold{font-size:13px;color:#0F2742}
  .sjc-dua-kiri table.table-bordered > thead,.sjc-dua-kiri table.table-bordered > tbody > tr:has(> th){display:none}   /* judul "ISIAN DOKTER" saja; baris isian tidak pernah disembunyikan */
  .sjc-dua-kiri textarea.form-control{border-radius:8px;border-color:#D5E0E0;background:#F2F6F6}
  .sjc-dua-kiri textarea.form-control:focus{background:#fff;border-color:#263C92}
  /* kanan: resep ringkas (baris label → kisi 2 kolom) */
  .sjc-dua-kanan #GrupResep > tr > td{padding:6px!important}
  .sjc-dua-kanan #GrupResep table.no-border{margin:0}
  .sjc-dua-kanan #GrupResep table.no-border > tbody{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:6px 12px}
  .sjc-dua-kanan #GrupResep table.no-border > tbody > tr{display:flex;align-items:center;gap:6px;min-width:0}
  .sjc-dua-kanan #GrupResep table.no-border > tbody > tr > td{padding:0!important;border:0!important;width:auto!important}
  .sjc-dua-kanan #GrupResep table.no-border > tbody > tr > td:first-child{flex:none;width:76px!important;font-size:12px;color:#4F6478;white-space:nowrap}
  .sjc-dua-kanan #GrupResep table.no-border > tbody > tr > td:not(:first-child){flex:1;min-width:0}
  .sjc-dua-kanan #GrupResep table.no-border > tbody > tr{grid-column:1/-1;order:9}
  .sjc-dua-kanan #GrupResep table.no-border > tbody > tr:nth-child(1){order:1}.sjc-dua-kanan #GrupResep table.no-border > tbody > tr:nth-child(2){order:2}
  .sjc-dua-kanan #GrupResep table.no-border > tbody > tr:has([id^="jumlah_obat_"]){order:3;grid-column:auto}
  .sjc-dua-kanan #GrupResep table.no-border > tbody > tr:has([name$="IsSebelumMakan"]){order:4;grid-column:auto}
  .sjc-dua-kanan #GrupResep table.no-border > tbody > tr:has([id*="__IntensitasDosis"]){order:5}
  .sjc-dua-kanan #GrupResep table.no-border > tbody > tr:has([id*="__Keterangan"]){order:6;flex-wrap:wrap}
  .sjc-dua-kanan #GrupResep table.no-border > tbody > tr:has([name$="IsSebelumMakan"]) > td:first-child::before{content:"Waktu"}
  .sjc-dua-kanan #GrupResep table.no-border > tbody > tr:has([name$="IsSebelumMakan"]) > td:last-child{display:flex;flex-wrap:wrap;align-items:center;gap:4px 14px;font-size:13px;line-height:1.3}
  .sjc-dua-kanan #GrupResep table.no-border > tbody > tr:has([name$="IsSebelumMakan"]) > td:last-child label,
  .sjc-dua-kanan #GrupResep table.no-border > tbody > tr:has([name$="IsSebelumMakan"]) > td:last-child .sjc-waktu-opsi{display:inline-flex;align-items:center;gap:4px;white-space:nowrap;margin:0}
  .sjc-dua-kanan #GrupResep .sjc-memori-ket{flex-basis:100%;margin-top:2px}
  .sjc-dua-kanan #GrupResep > tr > td.text-center{width:28px!important;padding:6px 2px!important;color:#4F6478}
  .sjc-dua-kanan #GrupResep > tr + tr > td{border-top:1px solid #E3EBEA!important}
  .sjc-dua-kanan #GrupResep table.no-border > tbody > tr:has(input[type=radio][name$="IsRacikan"]) td:first-child{width:76px!important}
  .sjc-dua-kanan #GrupResep table.no-border > tbody > tr:has([id*="__IntensitasDosis"]) td:nth-child(2),.sjc-dua-kanan #GrupResep table.no-border > tbody > tr:has([id*="__IntensitasDosis"]) td:nth-child(4){flex:0 0 56px}
  .sjc-dua-kanan #GrupResep table.no-border > tbody > tr:has([id*="__IntensitasDosis"]) td:nth-child(3){flex:none;color:#4F6478}
  .sjc-dua-kanan #GrupResep table.no-border > tbody > tr:has([id*="__IntensitasDosis"]) td:nth-child(5){flex:0 0 128px;min-width:0}
  .sjc-dua-kanan #GrupResep table.no-border > tbody > tr:has([id*="__IntensitasDosis"]) td:nth-child(5) select,.sjc-dua-kanan #GrupResep table.no-border > tbody > tr:has([id*="__IntensitasDosis"]) td:nth-child(5) .select2-selection{font-size:12px;padding-left:6px!important;padding-right:20px!important}
  .sjc-dua-kanan #GrupResep table.no-border > tbody > tr:has([id*="__IntensitasDosis"]) td:nth-child(5) .select2-selection__rendered{overflow:hidden;text-overflow:ellipsis}
  .sjc-dua-kanan #GrupResep table.no-border > tbody > tr:has([id*="__IntensitasDosis"]){grid-column:1/-1}
  .sjc-dua-kanan #GrupResep .form-control{height:32px;padding:4px 8px}
  .sjc-dua-kanan table.table-bordered > thead th{padding:6px 8px!important}
  /* bilah Simpan selalu terlihat */
  html[data-sjc-dua] form .box-footer:has(#btn-simpan){display:none}
  .sjc-bilah{position:sticky;bottom:0;z-index:1010;display:flex;flex-wrap:wrap;align-items:center;gap:8px 12px;padding:10px 16px;background:#fff;border-top:1px solid #D5E0E0;box-shadow:0 -4px 16px rgba(15,39,66,.06);font-family:"Source Sans 3","Source Sans Pro","Segoe UI",system-ui,sans-serif;color:#0F2742}
  .sjc-bilah svg{width:18px;height:18px;fill:currentColor;flex:none}
  .sjc-bilah button,.sjc-bilah a.kembali{display:inline-flex;align-items:center;gap:6px;height:40px;padding:0 14px;border:1px solid #263C92;border-radius:8px;background:#fff;color:#263C92;font-size:15px;font-weight:700;font-family:inherit;cursor:pointer;white-space:nowrap;text-decoration:none}
  .sjc-bilah button small{font-weight:400;font-size:14px;opacity:.85}
  .sjc-bilah button.utama{background:#263C92;color:#fff}
  .sjc-bilah button:focus-visible,.sjc-bilah a:focus-visible{outline:2px solid #263C92;outline-offset:2px}
  .sjc-bilah .wajib{height:32px;padding:0 12px;border-radius:999px;border-color:#E9B872;background:#FFF5E6;color:#0F2742;font-size:14px}
  .sjc-bilah .wajib i{display:inline-block;width:10px;height:10px;border-radius:50%;background:#B45309}
  .sjc-bilah .wajib.lengkap{border-color:#B9D7B0;background:#F0F7EC}.sjc-bilah .wajib.lengkap i{background:#3B7A1E}
  .sjc-bilah .info{display:inline-flex;align-items:center;gap:6px;margin-left:auto;color:#4F6478;font-size:14px}
  .sjc-bilah a.kembali{border-color:#D5E0E0;color:#4F6478;font-weight:600}
  .sjc-bilah button.kecil{height:32px;padding:0 10px;border-color:#D5E0E0;color:#0F2742;font-size:13px;font-weight:600}
  .sjc-bilah button.pilih{background:#263C92;color:#fff}.sjc-bilah button.pilih small{opacity:.9}
  .sjc-bilah button.utama{margin-left:8px}
  .sjc-bilah .spasi{flex:1}.sjc-bilah a.kembali{height:32px;padding:0 10px;font-size:13px}
  .sjc-bilah .tanpa-obat{color:#B45309;font-size:13px;font-weight:600}
  .sjc-pop-wadah{position:relative;display:inline-flex}
  .sjc-pop{position:absolute;right:0;bottom:calc(100% + 10px);z-index:1030;width:min(560px,90vw);max-height:70vh;overflow:auto;padding:14px 16px;background:#fff;border:1px solid #D5E0E0;border-radius:12px;box-shadow:0 12px 32px rgba(15,39,66,.2);text-align:left}
  .sjc-pop h4{margin:0 0 10px;font-size:15px;font-weight:700}
  .sjc-pop .sp{display:grid;grid-template-columns:repeat(auto-fill,minmax(128px,1fr));gap:6px 8px;margin:0 0 12px}
  .sjc-pop .sp button{height:30px;padding:0 10px;border:1px solid #D5E0E0;border-radius:8px;background:#fff;color:#0F2742;font-size:13px;font-weight:600;line-height:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-family:inherit}
  .sjc-pop .sp button[aria-pressed=true]{border-color:#263C92;background:#E8ECF7;color:#263C92}
  .sjc-pop .isi{border-top:1px solid #E3EBEA;padding-top:10px}
  .sjc-pop .isi .form-group{margin:0 0 8px!important;display:block}.sjc-pop .isi [class*="col-md-"]{width:100%!important;padding:0!important;float:none!important}
  .sjc-pop .kaki{display:flex;justify-content:flex-end}.sjc-pop .kaki button{height:32px;border-color:#D5E0E0;color:#0F2742;font-size:13px}
  .sjc-sorot{outline:3px solid #E9B872!important;outline-offset:2px;transition:outline-color .2s}
  @media (max-width:1300px){.sjc-bilah .info,.sjc-bilah a.kembali,.sjc-bilah [data-a=autofill]{display:none}.sjc-bilah button small{display:none}.sjc-bilah .wajib{margin-right:auto}.sjc-bilah button,.sjc-bilah a.kembali{height:36px;padding:0 10px;font-size:14px}}
  @media (max-width:1199px){.sjc-dua{grid-template-columns:1fr}.sjc-dua-kanan{position:static;max-height:none;overflow:visible}}
  @media (max-width:640px){.sjc-dua-kiri table.table-bordered > tbody{grid-template-columns:1fr}.sjc-dua-kiri table.table-bordered > tbody > tr.sjc-setengah{grid-column:1/-1}.sjc-dua-kanan #GrupResep table.no-border > tbody{grid-template-columns:1fr}.sjc-kepala .kanan{margin-left:0}}`;
  /* ---------- susun ---------- */
  let kepala = null, ttv = null, kotak = null, asal = [], terbuka = false, aktif = false, klip = [];
  const pindah = (el, ke) => { if (!el) return; asal.push([el, el.parentNode, el.nextSibling]); ke.appendChild(el); };
  const barisDengan = sel => { const e = tabelDokter.querySelector(sel); return e && e.closest('tr'); };
  function bangunKepala() {
    const nama = nilaiIdentitas('Nama Pasien'), rm = nilaiIdentitas('Nomor RM'), umur = nilaiIdentitas('Umur').replace(/(\d+)\s*Tahun\s*(\d+)\s*Bulan.*/i, '$1 th $2 bln'),
      jk = nilaiIdentitas('Jenis Kelamin'), jp = nilaiIdentitas('Jenis Pasien'), al = nilaiIdentitas('Riwayat Alergi Obat') || nilaiTtv('Riwayat Alergi Obat'),
      /* "11 Juli 2007" → "11 Jul 2007", seirama dengan pemendekan umur di atas */
      tgl = nilaiIdentitas('Tanggal Lahir').replace(/\b(Jan|Feb|Mar|Apr|Mei|Jun|Jul|Agu|Sep|Okt|Nov|Des)\w*/i, '$1');
    const adaAlergi = al && !/^(-|tidak( ada)?|tdk|disangkal|negatif|nihil|\(-\))$/i.test(al);
    const w = riwayatWaktu();
    kepala = document.createElement('div'); kepala.className = 'sjc-kepala'; kepala.setAttribute('role', 'region'); kepala.setAttribute('aria-label', 'Pasien');
    kepala.innerHTML = `<span class="nm"></span><span class="m"></span><span class="alergi${adaAlergi ? '' : ' tidak'}">${adaAlergi ? IK.alergi : ''}<span></span></span>
      <span class="alur"><span>Daftar <b>${esc(w[0] || '—')}</b></span><span>Perawat <b>${esc(w[1] || '—')}</b></span></span>
      <span class="kanan"><button type="button" data-a="identitas" aria-expanded="false" title="Identitas lengkap &amp; riwayat status kunjungan (waktu &amp; PIC tiap tahap)">Detail pasien ${IK.bawah}</button><button type="button" data-a="asli" title="Kembali ke tampilan C-CARE asli">${IK.tukar}Tampilan asli</button></span>`;
    kepala.querySelector('.nm').textContent = nama || 'Pasien';
    if (nama) document.title = nama;          // nama pasien di judul tab — mudah dibedakan saat banyak tab CPPT terbuka
    kepala.querySelector('.m').textContent = [rm && 'RM ' + rm, umur, tgl, jk, jp].filter(Boolean).join(' · ');
    kepala.querySelector('.alergi span').textContent = adaAlergi ? 'Alergi: ' + al : 'Tidak ada alergi tercatat';
    kepala.addEventListener('click', e => {
      const b = e.target.closest('button[data-a]'); if (!b) return;
      if (b.dataset.a === 'asli') { chrome.storage.local.get('isiCepat', s => { const ic = s.isiCepat || {}; ic.duaMati = true; chrome.storage.local.set({ isiCepat: ic }); }); return; }
      terbuka = !terbuka; kartuLipat().forEach(k => k.classList.toggle('sjc-dua-sembunyi', !terbuka));
      b.setAttribute('aria-expanded', String(terbuka)); b.innerHTML = 'Detail pasien ' + (terbuka ? IK.atas : IK.bawah);
    });
    const ttvData = [
      ['TD', (() => { const s = angka(vital('Sistole', 'Sistole')), d = angka(vital('Diastole', 'Diastole')); return isNaN(s) ? null : { v: `${s}/${isNaN(d) ? '–' : d}`, k: s >= 180 || d >= 110 ? 'merah' : s >= 140 || d >= 90 ? 'kuning' : '', t: s >= 180 || d >= 110 ? 'krisis' : 'tinggi' }; })()],
      ['Nadi', (() => { const n = angka(vital('Nadi', 'Nadi')); return isNaN(n) ? null : { v: n, k: n > 130 || n < 50 ? 'merah' : n > 100 || n < 60 ? 'kuning' : '', t: n > 100 ? 'cepat' : 'lambat' }; })()],
      ['RR', (() => { const n = angka(vital('Respirasi', 'Respirasi')); return isNaN(n) ? null : { v: n, k: n > 30 || n < 10 ? 'merah' : n > 24 || n < 12 ? 'kuning' : '', t: n > 24 ? 'cepat' : 'lambat' }; })()],
      ['Suhu', (() => { const n = angka(vital('Suhu', 'Suhu')); return isNaN(n) ? null : { v: String(n).replace('.', ',') + ' °C', k: n >= 39.5 || n < 35 ? 'merah' : n >= 37.5 ? 'kuning' : '', t: n < 35 ? 'rendah' : 'demam' }; })()],
      ['SpO₂', (() => { const n = angka(vital('SaturasiO2', 'Saturasi O2')); return isNaN(n) ? null : { v: n + '%', k: n < 90 ? 'merah' : n < 95 ? 'kuning' : '', t: 'rendah' }; })()],
      ['BB / TB', (() => { const b = angka(vital('BeratBadan', 'Berat Badan')), t = angka(vital('TinggiBadan', 'Tinggi Badan')); return isNaN(b) && isNaN(t) ? null : { v: `${isNaN(b) ? '–' : b} / ${isNaN(t) ? '–' : t}`, k: '' }; })()],
      ['IMT', (() => { const n = angka(vital('Imt', 'IMT')); return isNaN(n) ? null : { v: String(n).replace('.', ','), k: n >= 30 || n < 17 ? 'kuning' : '', t: n < 17 ? 'kurang' : 'obesitas' }; })()],
      ['Nyeri', (() => { const n = angka(vital('SkalaNyeri', 'Skala Nyeri')); return isNaN(n) ? null : { v: n + '/10', k: n >= 7 ? 'merah' : n >= 4 ? 'kuning' : '', t: n >= 7 ? 'berat' : 'sedang' }; })()]
    ].filter(x => x[1]);
    if (ttvData.length) {
      ttv = document.createElement('div'); ttv.className = 'sjc-ttv'; ttv.setAttribute('aria-label', 'Tanda vital dari perawat');
      ttv.innerHTML = ttvData.map(([l, x]) => `<div class="${x.k}"><small>${l}${x.k ? ' · <em>' + x.t + '</em>' : ''}</small><b>${esc(x.v)}</b></div>`).join('');
    }
  }
  /* kartu Identitas Pasien & Riwayat Status Kunjungan dilipat bersama (jam & data penting sudah ada di kepala); awalnya terlipat */
  const kartuLipat = () => kartuAtas();
  const kartuAtas = () => { const f = pane.closest('form'), s = document.querySelector('section.content'); return s ? [...s.querySelectorAll(':scope > .box')].filter(b => !b.contains(f) && !b.classList.contains('modal')) : []; };
  function pasang() {
    if (aktif) return; aktif = true; asal = [];
    if (!gaya.isConnected) document.head.appendChild(gaya);
    document.documentElement.setAttribute('data-sjc-dua', '');
    /* AdminLTE: .wrapper{overflow:hidden} membuat posisi lengket (kepala & bilah) tidak jalan → ganti 'clip' (tetap memotong, tanpa wadah gulir) */
    for (let x = pane.closest('form'); x && x !== document.body; x = x.parentElement) { const c = getComputedStyle(x); if (c.overflowX !== 'visible' || c.overflowY !== 'visible') { klip.push([x, x.style.overflow]); x.style.overflow = 'clip'; } }
    bangunKepala();
    const kartuForm = pane.closest('form') && pane.closest('form').closest('.box') || pane.closest('.card');
    kartuForm.before(kepala); if (ttv) kartuForm.before(ttv);
    kartuLipat().forEach(k => k.classList.add('sjc-dua-sembunyi'));
    kotak = document.createElement('div'); kotak.className = 'sjc-dua';
    kotak.innerHTML = '<div class="sjc-dua-kiri"><div class="sjc-blok" data-b="soa"><h3>Anamnesa, pemeriksaan &amp; diagnosa</h3></div></div><div class="sjc-dua-kanan"><div class="sjc-blok" data-b="resep"><h3>Resep</h3></div><div class="sjc-blok" data-b="lain"><h3>Surat istirahat &amp; lab</h3></div><div class="sjc-blok sjc-dua-sembunyi" data-b="tl"><h3>Tindak lanjut lengkap</h3><table class="table sjc-tl-tabel"><tbody></tbody></table></div></div>';
    fh.prepend(kotak);
    const kiri = kotak.querySelector('[data-b=soa]'), resep = kotak.querySelector('[data-b=resep]'), tl = kotak.querySelector('[data-b=tl]'), lain = kotak.querySelector('[data-b=lain]');
    /* kiri: tabel isian dokter (pemeriksaan fisik & tata laksana jadi setengah lebar) */
    const fgDokter = tabelDokter.closest('.form-group') || tabelDokter;
    pindah(fgDokter, kiri);
    ['#KepalaMuka', '#Thorax', '#Abdomen', '#Extremitas', '#TataLaksana', '#Pengobatan'].forEach(s => { const r = barisDengan(s); if (r) r.classList.add('sjc-setengah'); });
    /* kanan: resep obat, alkes, lab, lalu tindak lanjut + kotak status kunjungan (dari luar tab) */
    const resepObat = document.getElementById('GrupResep'), alkes = document.getElementById('GrupResepAlkes') || (document.getElementById('TambahResepAlkes') || {}).closest?.call(document.getElementById('TambahResepAlkes'), 'table');
    const bungkus = el => el && (el.closest('span') && el.closest('span').parentElement === fh ? el.closest('span') : el.closest('.form-group'));
    const wResep = bungkus(resepObat); if (wResep) pindah(wResep, resep);
    const wAlkes = alkes && bungkus(alkes); if (wAlkes && wAlkes !== wResep) pindah(wAlkes, resep);
    const lab = [...fh.children].find(c => c !== kotak && /Pemeriksaan Lab/i.test(bersih(c.textContent).slice(0, 40)));
    const trTl = barisDengan('#TindakLanjutPengobatanId'); if (trTl) pindah(trTl, tl.querySelector('tbody'));
    const st = document.getElementById('boxFormStatusKunjungan'); if (st) pindah(st, tl);
    /* Tindak lanjut diganti bilah bawah (kotaknya disembunyikan, isiannya tetap di formulir); surat istirahat & lab tetap terlihat */
    const pindahSurat = () => { const sf = document.querySelector('.sjc-surat-fg') || (document.getElementById('sjcSurat') || {}).parentElement; if (sf && !lain.contains(sf)) pindah(sf, lain); };
    pindahSurat(); setTimeout(pindahSurat, 1500);
    if (lab) pindah(lab, lain);
    pasangBilah();
    setTimeout(() => window.dispatchEvent(new Event('resize')), 50);              // select2 & kotak teks menyesuaikan lebar baru
  }
  /* ---------- bilah bawah (ikut bergulir): isian wajib · Ctrl+S · aksi Simpan di kanan ---------- */
  let bilah = null, jamWajib = 0;
  const IKB = {
    turun: '<svg viewBox="0 0 24 24"><path d="M20 12l-1.4-1.4-5.6 5.6V4h-2v12.2l-5.6-5.6L4 12l8 8z"/></svg>',
    cek: '<svg viewBox="0 0 24 24"><path d="M9 16.2L4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4z"/></svg>',
    obat: '<svg viewBox="0 0 24 24"><path d="M4.2 11.3l7.1-7.1a5 5 0 017.1 7.1l-7.1 7.1a5 5 0 01-7.1-7.1zm1.4 1.4a3 3 0 004.3 4.3l3-3-4.3-4.3-3 3zm8.7 0l3-3a3 3 0 00-4.3-4.3l-3 3 4.3 4.3z"/></svg>',
    rujuk: '<svg viewBox="0 0 24 24"><path d="M19 3H5a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2V5a2 2 0 00-2-2zm-2 10h-4v4h-2v-4H7v-2h4V7h2v4h4v2z"/></svg>',
    selesai: '<svg viewBox="0 0 24 24"><path d="M12 2a10 10 0 100 20 10 10 0 000-20zm0 18a8 8 0 110-16 8 8 0 010 16zm-1.5-5.6L7 10.9l-1.4 1.4 4.9 4.9 8-8L17 7.8z"/></svg>',
    simpan: '<svg viewBox="0 0 24 24"><path d="M17 3H5a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2V7l-4-4zm-5 16a3 3 0 110-6 3 3 0 010 6zm3-10H5V5h10v4z"/></svg>'
  };
  /* isian bertanda * yang masih kosong (label C-CARE), plus Status Kunjungan */
  function isianWajibKosong() {
    const hasil = [];
    tabelDokter.querySelectorAll('tr').forEach(tr => {
      const lbl = tr.cells[0]; if (!lbl || !/\*/.test(lbl.textContent)) return;
      const el = tr.querySelector('textarea, select, input:not([type=hidden])'); if (!el || el.disabled) return;
      const kosong = el.tagName === 'SELECT' ? (el.multiple ? !el.selectedOptions.length : !el.value) : !bersih(el.value);
      if (kosong) hasil.push(el);
    });
    const tl = document.getElementById('TindakLanjutPengobatanId'); if (tl && !tl.value && !hasil.includes(tl)) hasil.push(tl);
    const st = document.getElementById('StatusKunjunganID'); if (st && !st.value) hasil.push(st);
    return hasil;
  }
  function perbaruiWajib() {
    if (!bilah) return;
    const k = isianWajibKosong(), b = bilah.querySelector('.wajib');
    b.classList.toggle('lengkap', !k.length);
    b.innerHTML = k.length ? `<i></i>${k.length} isian wajib belum diisi ${IKB.turun}` : `<i></i>Isian wajib lengkap`;
    b.disabled = !k.length;
  }
  function tuju(el) {
    const t = el.nextElementSibling && /select2/.test(el.nextElementSibling.className) ? el.nextElementSibling : el;
    t.scrollIntoView({ block: 'center', behavior: 'smooth' });
    t.classList.add('sjc-sorot'); setTimeout(() => t.classList.remove('sjc-sorot'), 1600);
    setTimeout(() => { try { if (t === el) el.focus({ preventScroll: true }); else (t.querySelector('.select2-selection') || t).focus(); } catch (e) {} }, 350);
  }
  const ubahSelect = (el, v) => { if (!el || el.value === v) return; el.value = v; el.dispatchEvent(new Event('change', { bubbles: true })); document.dispatchEvent(new CustomEvent('sjc-satuan', { detail: JSON.stringify({ id: el.id, val: v }) })); };
  const adaObat = () => [...document.querySelectorAll('#GrupResep select[name$=".ObatID"]')].some(s => s.value && s.selectedIndex > 0 && !/^--|^pilih/i.test(s.value));
  function simpan() { const k = isianWajibKosong(); if (k.length) { tuju(k[0]); return; } const b = document.getElementById('btn-simpan'); if (b) b.click(); }
  const SPESIALIS = ['Penyakit Dalam', 'Bedah', 'Mata', 'Kulit dan Kelamin', 'Jiwa', 'Anak', 'Saraf', 'THT', 'Obstetri dan Ginekologi', 'Paru', 'Jantung', 'Orthopedi'];
  function keadaanTl() {                                       // tombol mana yang sedang berlaku (dari isian C-CARE)
    const tl = (document.getElementById('TindakLanjutPengobatanId') || {}).value, st = (document.getElementById('StatusKunjunganID') || {}).value;
    return tl === '4' ? 'rujuk' : tl === '1' && st === '4' ? 'obat' : tl === '1' && st === '5' ? 'selesai' : tl && !['1', '4'].includes(tl) ? 'lain' : '';
  }
  function tandaiTombol() {
    if (!bilah) return; const k = keadaanTl();
    bilah.querySelectorAll('[data-pilih]').forEach(b => { const on = b.dataset.pilih === k; b.setAttribute('aria-pressed', String(on)); b.classList.toggle('pilih', on); });
    const peringatan = bilah.querySelector('.tanpa-obat'); if (peringatan) peringatan.hidden = !(k === 'obat' && !adaObat());
  }
  function pasangBilah() {
    const form = pane.closest('form'); if (!form || bilah) return;
    bilah = document.createElement('div'); bilah.className = 'sjc-bilah'; bilah.setAttribute('role', 'toolbar'); bilah.setAttribute('aria-label', 'Tindak lanjut & simpan');
    const kembali = [...(form.querySelector('.box-footer') || form).querySelectorAll('a[href]')].find(a => /kembali/i.test(a.textContent));
    bilah.innerHTML = `<button type="button" class="wajib" data-a="wajib"></button>
      <button type="button" class="kecil" data-a="autofill" title="Buka ringkasan Auto Fill">${IKB.cek}Auto Fill</button>
      <span class="spasi"></span>${kembali ? `<a class="kembali" href="${esc(kembali.getAttribute('href'))}">Kembali</a>` : ''}
      <span class="tanpa-obat" hidden>Resep masih kosong</span>
      <button type="button" data-a="obat" data-pilih="obat" title="Tindak lanjut Pulang + status Menunggu Obat (belum disimpan)">${IKB.obat}Menunggu obat <small>ke farmasi</small></button>
      <span class="sjc-pop-wadah"><button type="button" data-a="rujuk" data-pilih="rujuk" aria-haspopup="dialog" title="Tindak lanjut Rujuk eksternal">${IKB.rujuk}Rujuk eksternal ${IK.atas}</button>
        <div class="sjc-pop" role="dialog" aria-label="Rujuk eksternal" hidden><h4>Rujuk eksternal</h4><div class="sp">${SPESIALIS.map(n => `<button type="button" data-sp="${n}">${n}</button>`).join('')}</div><div class="isi"></div><div class="kaki"><button type="button" data-a="tutup">Tutup</button></div></div></span>
      <button type="button" data-a="selesai" data-pilih="selesai" title="Tindak lanjut Pulang + status Selesai (belum disimpan)">${IKB.selesai}Selesai <small>tanpa obat</small></button>
      <button type="button" class="kecil" data-a="lain" data-pilih="lain" title="Rujuk internal, rawat, pulang paksa, dll.">Lainnya ${IK.bawah}</button>
      <button type="button" class="utama" data-a="simpan" title="Simpan (Ctrl+S)">${IKB.simpan}Simpan <small>Ctrl+S</small></button>`;
    form.appendChild(bilah);
    /* isian rujukan eksternal C-CARE (BPJS/Umum, formulir, keterangan) dipindah ke panel — tetap di dalam formulir */
    const pop = bilah.querySelector('.sjc-pop'), isiPop = pop.querySelector('.isi');
    ['rujukanEksternal', 'keteranganRujukan'].forEach(id => { const el = document.getElementById(id); if (el) pindah(el, isiPop); });
    const tutupPop = () => { pop.hidden = true; };
    document.addEventListener('mousedown', e => { if (!pop.hidden && !e.target.closest('.sjc-pop-wadah')) tutupPop(); });
    document.addEventListener('keydown', e => { if (e.key === 'Escape') tutupPop(); });
    bilah.addEventListener('click', e => {
      const sp = e.target.closest('[data-sp]');
      if (sp) {                                                        // poli spesialis → tombol Auto Fill di bawah Tata Laksana (atau langsung)
        const asli = document.querySelector(`.isi-sp button[data-sp="${sp.dataset.sp}"]`);
        if (asli) asli.click(); else { const t = document.getElementById('TataLaksana'); if (t) { t.value = 'Rencana merujuk ke FKRTL ke Poli Spesialis ' + sp.dataset.sp; t.dispatchEvent(new Event('input', { bubbles: true })); } }
        pop.querySelectorAll('[data-sp]').forEach(x => x.setAttribute('aria-pressed', String(x === sp))); return;
      }
      const b = e.target.closest('button[data-a]'); if (!b) return;
      const tl = document.getElementById('TindakLanjutPengobatanId'), st = document.getElementById('StatusKunjunganID');
      const a = b.dataset.a;
      if (a === 'wajib') { const k = isianWajibKosong(); if (k.length) tuju(k[0]); }
      else if (a === 'simpan') simpan();
      else if (a === 'autofill') document.dispatchEvent(new CustomEvent('sjc-buka-autofill'));
      else if (a === 'tutup') tutupPop();
      else if (a === 'lain') { const k = kotak && kotak.querySelector('[data-b=tl]'); if (k) { k.classList.remove('sjc-dua-sembunyi'); tuju(document.getElementById('TindakLanjutPengobatanId') || k); } }
      else if (a === 'obat' || a === 'selesai') {                       // memilih tindak lanjut (TIDAK menyimpan)
        ubahSelect(tl, '1'); setTimeout(() => { ubahSelect(st, a === 'obat' ? '4' : '5'); perbaruiWajib(); tandaiTombol(); }, 250);
      } else if (a === 'rujuk') {
        if (tl && tl.value !== '4') ubahSelect(tl, '4');
        pop.hidden = !pop.hidden; setTimeout(() => { ['rujukanEksternal', 'keteranganRujukan'].forEach(id => { const el = document.getElementById(id); if (el) el.style.display = ''; }); tandaiTombol(); perbaruiWajib(); }, 300);
      }
    });
    tandaiTombol(); setInterval(tandaiTombol, 1000);
    perbaruiWajib();
    document.addEventListener('input', perbaruiWajib, true); document.addEventListener('change', perbaruiWajib, true);
    document.addEventListener('isicepat-ubah', perbaruiWajib);
    jamWajib = setInterval(perbaruiWajib, 1500);
  }
  function lepas() {
    if (!aktif) return; aktif = false;
    for (let i = asal.length - 1; i >= 0; i--) { const [el, induk, berikut] = asal[i]; if (induk) induk.insertBefore(el, berikut && berikut.parentNode === induk ? berikut : null); }
    asal = [];
    document.querySelectorAll('.sjc-setengah').forEach(r => r.classList.remove('sjc-setengah'));
    kartuAtas().forEach(k => k.classList.remove('sjc-dua-sembunyi'));
    [kotak, kepala, ttv, bilah].forEach(e => e && e.remove()); kotak = kepala = ttv = bilah = null; clearInterval(jamWajib);
    klip.forEach(([x, o]) => { x.style.overflow = o; }); klip = [];
    document.documentElement.removeAttribute('data-sjc-dua'); gaya.remove();
    setTimeout(() => window.dispatchEvent(new Event('resize')), 50);
  }
  const aktifDari = ic => !(ic || {}).mati && !(ic || {}).duaMati;
  /* setelah "Tampilan asli": tombol kecil mengambang untuk kembali ke dua kolom (tanpa membuka Pengaturan) */
  let tbBalik = null;
  function tombolBalik(ic) {
    const perlu = !(ic || {}).mati && !!(ic || {}).duaMati;
    if (!perlu) { if (tbBalik) { tbBalik.remove(); tbBalik = null; } return; }
    if (tbBalik) return;
    tbBalik = document.createElement('button'); tbBalik.type = 'button'; tbBalik.className = 'sjc-balik-dua';
    tbBalik.innerHTML = IK.tukar + 'Tampilan dua kolom';
    tbBalik.title = 'Kembali ke tampilan CPPT dua kolom';
    tbBalik.style.cssText = 'position:fixed;right:16px;top:64px;z-index:2147482000;display:inline-flex;align-items:center;gap:6px;min-height:40px;padding:0 14px;border:1px solid #263C92;border-radius:8px;background:#fff;color:#263C92;font:700 15px/1 "Source Sans 3","Source Sans Pro",system-ui,sans-serif;cursor:pointer;box-shadow:0 4px 12px rgba(15,39,66,.16)';
    const svg = tbBalik.querySelector('svg'); if (svg) svg.style.cssText = 'width:18px;height:18px;fill:currentColor';
    tbBalik.addEventListener('click', () => chrome.storage.local.get('isiCepat', s => { const c = s.isiCepat || {}; c.duaMati = false; chrome.storage.local.set({ isiCepat: c }); }));
    document.body.appendChild(tbBalik);
  }
  /* tunggu skrip lain (Auto Fill, surat istirahat, resep) selesai memasang elemennya */
  chrome.storage.local.get('isiCepat', s => { if (aktifDari(s.isiCepat)) setTimeout(pasang, 600); tombolBalik(s.isiCepat); });
  chrome.storage.onChanged.addListener((u, a) => { if (a === 'local' && u.isiCepat) { (aktifDari(u.isiCepat.newValue) ? pasang : lepas)(); tombolBalik(u.isiCepat.newValue); } });
})();
