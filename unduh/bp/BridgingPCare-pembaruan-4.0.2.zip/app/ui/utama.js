"use strict";
// ===== Alvisya Bridging PCare 3.3 · arah D "Kendali di Atas" =====
// Bilah atas: merek · PCare/C-CARE · status + kendali bot · Menu.  Bilah halaman: navigasi + zoom.
// Kiri: Perlu tindakan → Antrean → Selesai (dilipat).  Kanan: data pasien / pratinjau / menu (tidak pernah menutupi PCare).
const $ = (s, r = document) => r.querySelector(s);
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
const TAMPIL_RUJUKAN = false;   // rujukan disembunyikan dulu (keputusan petugas, 27 Okt 2026)

// ---------- ikon (satu set garis, Material-like) ----------
const svg = (d) => `<svg viewBox="0 0 24 24" aria-hidden="true">${d}</svg>`;
const IKON = {
  tersimpan: svg('<path d="M5 12.5l4.2 4.2L19 7"/>'),
  cek: svg('<path d="M12 4l9 16H3z"/><path d="M12 10v4M12 17v.5"/>'),
  belum: svg('<circle cx="12" cy="12" r="7"/>'),
  dikecualikan: svg('<circle cx="12" cy="12" r="7"/><path d="M7 17L17 7"/>'),
  jalan: svg('<path d="M8 5l11 7-11 7z"/>'),
  dilewati: svg('<path d="M6 6l7 6-7 6M16 6v12"/>'),
  dilayani: svg('<circle cx="12" cy="12" r="7"/><path d="M8.5 12.5l2.3 2.3 4.7-5"/>'),
  rujuk: svg('<path d="M5 12h12M13 7l5 5-5 5"/>'),
  alergi: svg('<path d="M12 4l9 16H3z"/><path d="M12 10v4M12 17v.5"/>'),
  info: svg('<circle cx="12" cy="12" r="8"/><path d="M12 11v5M12 8v.5"/>'),
  tutup: svg('<path d="M6 6l12 12M18 6L6 18"/>'),
  bawah: svg('<path d="M6 9l6 6 6-6"/>'),
};
const LABEL_ST = { dikecualikan: "Dikecualikan", tersimpan: "Tersimpan", cek: "Perlu dicek", belum: "Belum", jalan: "Diproses", dilewati: "Dilewati", dilayani: "Dilayani" };
const lencana = (st, teks, judul) => `<span class="st ${st}"${judul ? ` title="${esc(judul)}"` : ""}>${IKON[st] || ""}${esc(teks || LABEL_ST[st] || st)}</span>`;
const bersihTeks = (t) => String(t || "").replace(/[⌀-⯿\u{1F300}-\u{1FAFF}️]/gu, "").replace(/\s+/g, " ").trim();

// ---------- pesan bot → judul singkat + alasan satu kalimat ----------
const POLA_ALASAN = [
  [/tercatat tersimpan pukul ([\d.:]+), tetapi di PCare masih Baru/i, "Belum tersimpan di PCare", (m) => `Bot sempat mencatat tersimpan (${m[1]}). Status PCare: Baru.`],
  [/anamnesa.*kosong/i, "Anamnesa kosong", () => "Dokter belum mengisi anamnesa di C-CARE."],
  [/jenis kelamin c-care \((\w)\)\s*≠?\s*pcare \((\w)\)/i, "Jenis kelamin beda", (m) => `C-CARE: ${m[1]} · PCare: ${m[2]}.`],
  [/umur c-care \((\d+)\)\s*≠?\s*pcare \((\d+)\)/i, "Umur beda", (m) => `C-CARE: ${m[1]} th · PCare: ${m[2]} th.`],
  [/no\.?\s?kartu yang tampil/i, "Kartu tidak cocok", () => "Pasien di form PCare bukan pasien antrean ini."],
  [/tanggal kunjungan c-care/i, "Tanggal beda", () => "Tanggal kunjungan C-CARE tidak sama dengan PCare."],
  [/tidak terkonfirmasi|simpan belum berhasil/i, "Simpan belum pasti", () => "Periksa di PCare apakah kunjungan sudah tersimpan."],
  [/cloudflare/i, "Verifikasi Cloudflare", () => "Centang kotak Cloudflare di halaman PCare."],
  [/belum login|minta login/i, "Perlu login", () => "Login dulu di halaman yang diminta."],
  [/c-care:.*(tidak ditemukan|belum lengkap|tidak terbuka|tidak ada|tidak cocok)/i, "Data C-CARE belum didapat", (m, t) => kalimat(t.replace(/^.*?c-care:\s*/i, ""))],
  [/dialog|ya\/tidak/i, "Keputusan di PCare", () => "Pilih Ya atau Tidak pada dialog PCare."],
  [/perbaiki form|pratinjau|periksa manual/i, "Periksa form", () => "Periksa isian di form PCare, lalu simpan."],
];
function kalimat(t) {
  t = bersihTeks(t).replace(/^(menunggu anda|berhenti)\s*[:—-]\s*/i, "").replace(/\s*\((lewati|atau|pasien)[^)]*\)/gi, "")
    .replace(/\s*(setelah|sesudah) (selesai|dokter)[^.]*\.?/gi, "").replace(/\s*klik\s+(lanjut|⏭)[^.]*\.?/gi, "").trim();
  const m = t.match(/^[^.]*\.?/); t = (m ? m[0] : t).trim();
  return t.length > 110 ? t.slice(0, 107) + "…" : t;
}
function uraiAlasan(teks) {
  const t = bersihTeks(teks);
  for (const [re, judul, ket] of POLA_ALASAN) { const m = t.match(re); if (m) return { judul, ket: ket(m, t) }; }
  return { judul: "Perlu dicek", ket: kalimat(t) };
}

// ---------- bilah atas: situs ----------
const TEKS_SITUS = { belum: "belum login", memuat: "memuat…" };
function tampilkanStatus(s) {
  for (const k of ["pcare", "ccare"]) {
    $("#tab-" + k).classList.toggle("aktif", s.tampil === k);
    $("#tab-" + k).setAttribute("aria-selected", s.tampil === k);
    $("#st-" + k).className = "titik " + (s[k] || "memuat");
    $("#tx-" + k).textContent = TEKS_SITUS[s[k]] ? " " + TEKS_SITUS[s[k]] : "";
    $("#tab-" + k).title = s[k] === "masuk" ? "Sudah masuk" : s[k] === "—" ? "Belum dibuka. Klik untuk membuka." : TEKS_SITUS[s[k]] || "";
  }
  $("#btn-kembali").disabled = !s.bisaKembali;
  if (s.zoom) $("#btn-zoom").textContent = s.zoom + "%";
  if (s.url !== undefined) tulisUrl(s.url);
  S.situs = s; renderPita();
}
const NAMA_HAL = [[/EntriKunjunganDokkel/i, "Pelayanan Pasien"], [/EntriDaftarDokkel/i, "Pendaftaran Pasien"], [/eclaim\/login/i, "Login"], [/\/Poli\/Ubah/i, "Kunjungan Poli"], [/Account\/Login/i, "Login"]];
function tulisUrl(u) {
  let host = "", hal = "";
  try { const x = new URL(u); host = x.hostname; hal = (NAMA_HAL.find(([re]) => re.test(x.pathname)) || [, ""])[1]; } catch (e) {}
  $("#url-teks").innerHTML = host ? `${esc(host)}${hal ? ` <span>›</span> <b>${esc(hal)}</b>` : ""}` : "memuat…";
}
let tKabar = null;
const kabar = (t) => { const k = $("#kabar"); k.textContent = t; k.hidden = false; clearTimeout(tKabar); tKabar = setTimeout(() => { k.hidden = true; }, 2600); };
$("#tab-pcare").onclick = () => app.tampil("pcare");
$("#tab-ccare").onclick = () => app.tampil("ccare");
$("#btn-muat").onclick = () => app.muatUlang();
$("#btn-kembali").onclick = () => app.kembali();
$("#btn-beranda").onclick = () => app.beranda();
$("#btn-kecil").onclick = () => app.zoom(-1);
$("#btn-besar").onclick = () => app.zoom(+1);
$("#btn-zoom").onclick = () => app.zoom(0);
$("#btn-atur").onclick = () => app.pengaturan();
$("#btn-log").onclick = async () => { await app.salinLog(); kabar("Log tersalin. Tempel (Ctrl+V) di chat Claude."); };
app.onStatus((s) => tampilkanStatus(s));
app.info().then((i) => { $("#versi").textContent = `Klinik IPB Dramaga · v${i.versi}`; $("#awan").hidden = !i.diAwan; });

// ---------- area tengah dilaporkan ke aplikasi (tempat halaman PCare/C-CARE) ----------
// #tengah = area di bawah bilah halaman dan pita login
const laporArea = () => { const r = $("#tengah").getBoundingClientRect(); app.area({ x: r.left, y: r.top, width: r.width, height: r.height }); };
new ResizeObserver(laporArea).observe($("#tengah"));
window.addEventListener("resize", laporArea);

// ---------- data ----------
const S = { situs: {}, kabarLogin: {}, pv: null, menu: false, mentah: null, processed: {}, antrean: null, queue: {}, status: null, run: {}, aktivitas: [], cari: "", pilih: null, sibuk: null, hasil: null, kiri: true, selesaiBuka: false };
const hariIni = () => { const d = new Date(), p = (x) => String(x).padStart(2, "0"); return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`; };
// nama tanpa gelar ("DR. ", ", S.KOM", "S.E.", "SP.PD") — hanya gelar bertitik/berkoma yang dibuang, nama biasa (mis. SITI) tetap
const kunciNama = (s) => String(s || "").toUpperCase().split(",")[0]
  .replace(/\b(DR|DRG|DRS|DRA|IR|HJ|H|PROF|NY|TN|AN|SDR|SDRI)\.(?=\s|$)/g, " ")
  .replace(/\b[A-Z]{1,3}\.\s?[A-Z]{1,5}\.?(?=\s|$)/g, " ")
  .replace(/[^A-Z]/g, "");
const kartuSamar = (k) => (k && k.length > 4 ? "****" + k.slice(-4) : k || "");

const menit = (j) => { const m = String(j || "").match(/(\d{1,2})[.:](\d{2})/); return m ? +m[1] * 60 + +m[2] : -1e9; };
// status "Tersimpan" dihitung juga dari catatan bot (processed), supaya langsung berubah tanpa Muat antrean
function terapkanProses() {
  const a = S.mentah;
  if (!a || !a.rows) { S.antrean = a; return; }
  const p = S.processed || {}, hari = hariIni();
  S.antrean = { ...a, rows: a.rows.map((r) => {
    const x = p[`${r.kartu}|${r.antrean || ""}`];
    if (r.status === "cek" && /di PCare masih Baru/.test(r.ket || "")) return r;   // v3.4.3: ditandai bot dari daftar PCare
    if (x && x.tgl === hari && /otomatis|manual/.test(x.hasil)) {
      // v3.4.3: PCare adalah sumber kebenaran. Bot mencatat tersimpan, tetapi antrean yang dibaca ≥ 2 menit sesudahnya
      // masih "Baru" → jangan tampil Tersimpan; pindahkan ke Perlu tindakan.
      if (r.status === "belum" && menit(a.jam) - menit(x.jam) >= 2)
        return { ...r, status: "cek", ket: `Bot tercatat tersimpan pukul ${String(x.jam).replace(":", ".")}, tetapi di PCare masih Baru.`, belumDiPcare: true };
      return { ...r, status: "tersimpan", ket: x.jam ? "pukul " + String(x.jam).replace(":", ".") : r.ket };
    }
    if (x && x.tgl === hari && x.hasil === "dilewati" && r.status === "belum") return { ...r, status: "dilewati" };
    return r;
  }) };
  if (S.pilih) S.pilih = S.antrean.rows.find((x) => x.antrean === S.pilih.antrean && x.kartu === S.pilih.kartu) || S.pilih;
}
async function muatAwal() {
  const o = await app.ambil(["run", "autoSave", "lanjutOtomatis", "modeBot", "mejaAntrean", "processed", "ccareQueue", "statusBot", "aktivitasBot", "panelBotTampil", "mejaKiri", "kabarLogin_pcare", "kabarLogin_ccare", "pratinjauAktif", "selesaiBuka"]);
  S.kabarLogin = { pcare: o.kabarLogin_pcare || null, ccare: o.kabarLogin_ccare || null };
  S.pv = o.pratinjauAktif && Date.now() - (o.pratinjauAktif.at || 0) < 600e3 ? o.pratinjauAktif : null;
  S.mentah = o.mejaAntrean || null; S.processed = o.processed || {}; terapkanProses(); S.queue = o.ccareQueue || {}; S.status = o.statusBot || null; S.aktivitas = o.aktivitasBot || [];
  S.kiri = o.mejaKiri !== false; S.run = o.run || {}; S.selesaiBuka = !!o.selesaiBuka;
  S.mode = ["periksa", "otomatis", "nonstop"].includes(o.modeBot) ? o.modeBot : o.autoSave ? "otomatis" : "periksa";
  if (o.lanjutOtomatis !== true) app.simpan({ lanjutOtomatis: true });   // v3.4.2: selalu lanjut ke pasien berikutnya (sakelar dihapus)
  renderMode();
  if (o.panelBotTampil !== false) app.simpan({ panelBotTampil: false });   // panel lama di halaman PCare tidak dipakai lagi
  aturKiri(); renderDaftar(); renderStatus(); renderAktivitas(); renderPita(); renderPv(); aturKanan();
}
app.onBerubah((ch) => {
  if (ch.mejaAntrean || ch.processed) {
    if (ch.mejaAntrean) S.mentah = ch.mejaAntrean.newValue || null;
    if (ch.processed) S.processed = ch.processed.newValue || {};
    terapkanProses(); renderDaftar(); if (S.pilih) renderPasien();
  }
  if (ch.ccareQueue) { S.queue = ch.ccareQueue.newValue || {}; if (S.pilih) renderPasien(); }
  if (ch.statusBot) { S.status = ch.statusBot.newValue; renderStatus(); renderDaftar(); }
  if (ch.run) { S.run = ch.run.newValue || {}; renderStatus(); renderDaftar(); }
  if (ch.aktivitasBot) { S.aktivitas = ch.aktivitasBot.newValue || []; renderAktivitas(); }
  if (ch.modeBot && ch.modeBot.newValue) { S.mode = ch.modeBot.newValue; renderMode(); }
  for (const k of ["pcare", "ccare"]) if (ch["kabarLogin_" + k]) { S.kabarLogin[k] = ch["kabarLogin_" + k].newValue || null; renderPita(); }
  if (ch.pratinjauAktif) { S.pv = ch.pratinjauAktif.newValue || null; if (S.pv) S.menu = false; renderPv(); }
  if (ch.hasilPerintah && ch.hasilPerintah.newValue) {
    const h = ch.hasilPerintah.newValue;
    if (S.tungguPerintah && S.tungguPerintah === h.id) {
      S.tungguPerintah = null;
      if (h.pesan) kabar(h.pesan);
      if (S.tungguPv === h.id) { S.tungguPv = null; return; }
      S.hasil = h; if (S.pilih) renderPasien();
    }
  }
});

// ---------- perintah ke bot di halaman PCare ----------
let nomorPerintah = 0;
function perintah(cmd, extra = {}) {
  const id = `${Date.now()}-${++nomorPerintah}`;
  S.tungguPerintah = id;
  app.simpan({ perintahBot: { id, cmd, at: Date.now(), ...extra } });
  setTimeout(() => { if (S.tungguPerintah === id) { S.tungguPerintah = null; kabar("Halaman PCare tidak menjawab. Pastikan PCare sudah login."); } }, 8000);
  return id;
}
$("#btn-refresh").onclick = () => { app.tampil("pcare"); perintah("refresh"); };
$("#btn-jalan").onclick = () => { app.tampil("pcare"); perintah(S.mode === "nonstop" ? "nonstop" : "jalankan"); };
$("#btn-henti").onclick = () => perintah("berhenti");
$("#btn-lanjut").onclick = () => { app.tampil("pcare"); perintah("lanjut"); };
$("#btn-lewati").onclick = () => perintah("lewati");

// ---------- v3.4.2: satu pilihan Mode menggantikan Simpan otomatis · Lanjut otomatis · Jalankan nonstop ----------
const NAMA_MODE = { periksa: "Periksa dulu", otomatis: "Simpan otomatis", nonstop: "Nonstop" };
const KET_MODE = { periksa: "Anda klik Simpan di pratinjau setiap pasien.", otomatis: "Tersimpan 5 detik sesudah pratinjau bila tanpa peringatan.", nonstop: "Tanpa menunggu Anda; pasien bermasalah dilewati dan dicatat." };
// <select> bawaan dipakai karena daftar pilihannya tampil DI ATAS halaman PCare (popup HTML biasa tertutup halaman PCare)
function renderMode() {
  const m = S.mode || "periksa";
  $("#mode-pilih").value = m; $("#btn-mode").dataset.mode = m;
}
$("#mode-pilih").onchange = (e) => {
  const m = e.target.value; S.mode = m; renderMode();
  app.simpan({ modeBot: m, autoSave: m === "otomatis" });
  kabar(`Mode: ${NAMA_MODE[m]}`);
};

// tombol berisiko: klik pertama menjelaskan akibatnya, klik kedua menjalankan (5–6 detik)
function duaLangkah(b, teksYakin, ket, aksi) {
  if (!b.classList.contains("yakin")) {
    document.querySelectorAll(".yakin").forEach((x) => { if (x !== b) { x.classList.remove("yakin"); x.textContent = x.dataset.asli; } });
    b.dataset.asli = b.dataset.asli || b.textContent; b.classList.add("yakin"); b.textContent = teksYakin;
    if (ket) ket(true);
    clearTimeout(b._t); b._t = setTimeout(() => { b.classList.remove("yakin"); b.textContent = b.dataset.asli; if (ket) ket(false); }, 6000);
    return;
  }
  clearTimeout(b._t); b.classList.remove("yakin"); b.textContent = b.dataset.asli; if (ket) ket(false);
  aksi();
}

// ---------- Menu (kolom kanan) ----------
$("#btn-menu").onclick = () => { S.menu = !S.menu; aturKanan(); };
$("#menu-tutup").onclick = () => { S.menu = false; aturKanan(); };
const AKIBAT = {
  browser: "Cache halaman PCare/C-CARE dihapus. Login tetap; halaman dimuat ulang.",
  reset: "Bot berhenti dan melupakan semua hasil scan: tanda Tersimpan/Dilewati, data C-CARE, aktivitas. Status dibaca ulang dari PCare.",
};
const KET_BERSIH = "Data di PCare dan C-CARE tidak ikut terhapus.";
document.querySelectorAll("[data-bersih]").forEach((b) => (b.onclick = () => {
  const k = b.dataset.bersih;
  duaLangkah(b, "Klik lagi", (on) => ($("#bersih-ket").textContent = on ? AKIBAT[k] : KET_BERSIH), async () => {
    if (k === "browser") { const h = await app.bersihCache(); kabar(h.ok ? `Cache browser dibersihkan (${h.mb} MB)` : "Gagal: " + h.pesan); if (h.ok) app.muatUlang(); }
    if (k === "reset") {
      if (S.run && S.run.active) perintah("berhenti");
      // v3.4.3 "Reset memori bot": lupakan SEMUA yang pernah dipindai; login, password & pengaturan tetap
      await app.simpan({ processed: {}, ccareQueue: {}, ccareDipakai: {}, ccareData: null, lewatHariIni: { tgl: hariIni(), item: {} },
        aktivitasBot: [], pratinjauAktif: null, mejaAntrean: null, statusBot: { teks: "", at: Date.now() } });
      S.pilih = null; S.hasil = null; aturKanan();
      kabar("Memori bot dikosongkan. Antrean dibaca ulang dari PCare…");
      setTimeout(() => { app.tampil("pcare"); perintah("refresh"); }, 800);
    }
  });
}));
const IKON_AKT = { ok: IKON.tersimpan, cek: IKON.cek, info: IKON.info };
function renderAktivitas() {
  const a = (S.aktivitas || []).slice(0, 40);
  $("#aktivitas").innerHTML = a.length ? a.map((x) => `<li class="${esc(x.jenis)}"><span class="jam">${esc(x.jam)}</span>${IKON_AKT[x.jenis] || IKON.info}<span class="teks-a">${esc(bersihTeks(x.teks))}</span></li>`).join("")
    : `<li><span class="kosong-a">Belum ada aktivitas.</span></li>`;
}

// ---------- kolom kanan: satu isi pada satu waktu (menu > pratinjau > data pasien) ----------
function aturKanan() {
  const isi = S.menu ? "menu" : S.pv ? "pv" : S.pilih ? "pasien" : "";
  $("#menu").hidden = isi !== "menu"; $("#pv").hidden = isi !== "pv"; $("#pasien").hidden = isi !== "pasien";
  $("#kanan").hidden = !isi;
  $("#btn-menu").setAttribute("aria-expanded", S.menu);
  aturKiri();
}

// layar sempit (< 1280 px): saat kolom kanan terbuka, kolom Antrean diciutkan sementara agar PCare tetap cukup lebar
const sempit = () => window.innerWidth < 1280;
function aturKiri() {
  const tampil = S.kiri && !(sempit() && (S.pilih || S.pv || S.menu));
  $("#kiri").hidden = !tampil; $("#btn-antrean").setAttribute("aria-pressed", tampil); requestAnimationFrame(laporArea);
}
window.addEventListener("resize", () => aturKiri());
$("#btn-antrean").onclick = () => {
  if (sempit() && (S.pilih || S.pv || S.menu) && S.kiri) {
    if (S.pv) { kabar("Selesaikan pratinjau dulu: Batal atau Simpan ke PCare"); return; }
    S.menu = false; S.pilih = null; renderPasien(); renderDaftar(); aturKanan(); return;
  }
  S.kiri = !S.kiri; app.simpan({ mejaKiri: S.kiri }); aturKiri();
};

// ---------- status bot di bilah atas ----------
const LANGKAH = { pick: "Memilih pasien", ccare: "Ambil data C-CARE", load: "Muat pasien", verify: "Cocokkan kartu", fill: "Isi form", cekSimpan: "Cek hasil simpan" };
const keadaanBot = () => { const r = S.run || {}; return r.active ? (r.paused ? "jeda" : "jalan") : "henti"; };
function renderStatus() {
  const r = S.run || {}, k = keadaanBot(), el = $("#botst");
  el.dataset.st = k;
  $("#bot-lbl").textContent = k === "jalan" ? "Berjalan" : k === "jeda" ? "Menunggu Anda" : "Bot siap";
  const det = [r.current && k !== "henti" ? r.current.antrean : "", k === "jalan" ? LANGKAH[r.step] || "" : ""].filter(Boolean).join(" · ");
  $("#bot-det").textContent = det;
  el.title = S.status && S.status.teks ? bersihTeks(S.status.teks) : "";
  el.querySelector(".bilah-jalan")?.remove();
  if (k === "jalan") el.insertAdjacentHTML("beforeend", '<span class="bilah-jalan" aria-hidden="true"></span>');
  $("#btn-jalan").hidden = k !== "henti";
  $("#btn-lanjut").hidden = k !== "jeda";
  $("#btn-lewati").hidden = k === "henti" || !r.current;
  $("#btn-henti").hidden = k === "henti";
  // mode dikunci selama bot berjalan agar perilaku simpan tidak berubah di tengah pasien
  $("#mode-pilih").disabled = k !== "henti"; $("#btn-mode").classList.toggle("mati", k !== "henti");
  $("#btn-mode").title = k === "henti" ? `Mode ${NAMA_MODE[S.mode || "periksa"]}: ${KET_MODE[S.mode || "periksa"]}` : "Klik Berhenti dulu untuk mengganti mode";
}

// ---------- kolom kiri: Perlu tindakan → Antrean → Selesai ----------
function dataPasien(row) {   // data C-CARE yang cocok untuk baris antrean (hari ini)
  const q = Object.values(S.queue || {}).filter((d) => d && d.tgl === hariIni());
  return q.find((d) => d.dipakai && d.dipakai === row.antrean) ||
    q.find((d) => d.kartu && d.kartu === row.kartu) ||
    q.find((d) => kunciNama(d.nama) === kunciNama(row.nama) && (!row.kelamin || !d.kelamin || d.kelamin === row.kelamin)) || null;
}
const subBaris = (r) => [r.usia != null ? r.usia + " th" : "", r.kelamin, r.poli].filter(Boolean).join(" · ");
function kartuTugas(r, alasan, bot) {
  const jk = bot && /jenis kelamin/i.test(alasan.judul) && !(S.run.current && S.run.current.abaikanJK);
  return `<div class="tugas${bot ? " bot" : ""}" data-a="${esc(r.antrean)}" data-k="${esc(r.kartu)}">${IKON.cek}
    <b>${esc(alasan.judul)}</b><span class="nm num" data-buka title="Lihat data pasien">${esc(r.antrean)} · ${esc(r.nama)}</span><span class="al">${esc(alasan.ket)}</span>
    ${bot ? (jk ? `<span class="ak"><button class="tombol kecil" data-aksi="jk">Tetap proses</button></span>` : "")
      : `<span class="ak"><button class="tombol kecil" data-aksi="proses">Proses ulang</button><button class="tombol kecil" data-aksi="buka">Lihat</button></span>`}</div>`;
}
function renderDaftar() {
  const a = S.antrean, box = $("#daftar");
  const rows = a && a.rows ? a.rows : [];
  const n = (st) => rows.filter((r) => r.status === st).length;
  $("#ringkas").textContent = rows.length ? `${rows.length} pasien · ${n("tersimpan")} tersimpan${a.jam ? " · dibaca " + a.jam : ""}` : "Belum dimuat";
  if (!rows.length) { box.innerHTML = `<div class="kosong"><b>Antrean belum dimuat</b>Login PCare, lalu klik Muat antrean.</div>`; return; }
  const q = S.cari.trim(), cari = kunciNama(q), cariNo = q.toUpperCase();
  const cocok = (r) => !q || kunciNama(r.nama).includes(cari) || String(r.antrean).toUpperCase().includes(cariNo);
  const run = S.run || {}, k = keadaanBot(), cur = run.current;
  const sedang = (r) => cur && k !== "henti" && cur.antrean === r.antrean && cur.kartu === r.kartu;
  // 1) Perlu tindakan: pasien yang sedang ditunggu bot + pasien berstatus "Perlu dicek"
  let tugas = "", nTugas = 0;
  const rBot = k === "jeda" && rows.find(sedang);
  if (rBot && cocok(rBot)) { tugas += kartuTugas(rBot, uraiAlasan(S.status && S.status.teks), true); nTugas++; }
  for (const r of rows.filter((r) => r.status === "cek" && !(rBot && r === rBot) && cocok(r))) { tugas += kartuTugas(r, uraiAlasan(r.ket || "Perlu dicek")); nTugas++; }
  // 2) Antrean: belum diproses (yang sedang diproses ditandai)
  const antre = rows.filter((r) => r.status === "belum" && !(rBot && r === rBot) && cocok(r));
  // 3) Selesai: tersimpan, sudah dilayani, dilewati
  const selesai = rows.filter((r) => /tersimpan|dilayani|dilewati/.test(r.status) && cocok(r));
  // 4) v3.4.4: poli yang dikecualikan di Pengaturan (mis. Konseling) — tampil, tetapi tidak diproses bot
  const kecuali = rows.filter((r) => r.status === "dikecualikan" && cocok(r));
  const baris = (r) => { const j = sedang(r) && k === "jalan";
    return `<button class="baris${j ? " jalan" : ""}" role="option" data-a="${esc(r.antrean)}" data-k="${esc(r.kartu)}" aria-selected="${!!(S.pilih && S.pilih.antrean === r.antrean && S.pilih.kartu === r.kartu)}">
      <span class="no">${esc(r.antrean)}</span><span class="nm">${esc(r.nama)}</span>${lencana(j ? "jalan" : r.status, null, r.status === "tersimpan" && r.ket ? "Tersimpan " + r.ket : "")}<span class="sub">${esc(subBaris(r))}</span></button>`; };
  box.innerHTML =
    (nTugas ? `<div class="grup"><h3>Perlu tindakan</h3><span class="n kuning num">${nTugas}</span></div>${tugas}` : "") +
    `<div class="grup"><h3>Antrean</h3><span class="n num">${antre.length}</span></div>` +
    (antre.length ? antre.map(baris).join("") : `<div class="kosong">${q ? "Tidak ada yang cocok." : "Semua pasien Baru sudah diproses."}</div>`) +
    (kecuali.length ? `<div class="grup"><h3>Tidak diproses bot</h3><span class="n num">${kecuali.length}</span></div>${kecuali.map(baris).join("")}` : "") +
    `<button class="grup" id="btn-selesai" aria-expanded="${S.selesaiBuka}"><h3>Selesai hari ini</h3><span class="n num">${selesai.length}</span>${IKON.bawah}</button>` +
    (S.selesaiBuka ? selesai.map(baris).join("") : "");
  box.querySelectorAll(".baris").forEach((b) => (b.onclick = () => pilihPasien(b.dataset.a, b.dataset.k)));
  $("#btn-selesai").onclick = () => { S.selesaiBuka = !S.selesaiBuka; app.simpan({ selesaiBuka: S.selesaiBuka }); renderDaftar(); };
  box.querySelectorAll(".tugas").forEach((t) => {
    const a = t.dataset.a, kt = t.dataset.k;
    t.querySelector("[data-buka]").onclick = () => pilihPasien(a, kt);
    t.querySelectorAll("[data-aksi]").forEach((b) => (b.onclick = () => {
      const x = b.dataset.aksi;
      if (x === "buka") pilihPasien(a, kt);
      if (x === "proses") { app.tampil("pcare"); perintah("proses", { antrean: a, kartu: kt }); }
      if (x === "jk") duaLangkah(b, "Yakin? Klik lagi", null, () => { app.tampil("pcare"); perintah("abaikanJK"); });
    }));
  });
}
$("#cari").addEventListener("input", (e) => { S.cari = e.target.value; renderDaftar(); });

function pilihPasien(antrean, kartu) {
  const r = (S.antrean?.rows || []).find((x) => x.antrean === antrean && x.kartu === kartu);
  if (!r) return;
  S.pilih = r; S.hasil = null; S.sibuk = null; S.menu = false;
  renderDaftar(); renderPasien();
}

// ---------- rujukan: urai teks bebas Keterangan Rujukan C-CARE ----------
// kamus singkatan spesialis (ejaan beragam: "SpPD", "sp.pd", "sppd", "dr. Sp. PD") → nama di PCare
const KAMUS_SP = [
  ["THT", "THT-KL", ["tht"]], ["JP", "Jantung dan Pembuluh Darah", ["jantung"]], ["KK", "Kulit dan Kelamin", ["kulit"]], ["DVE", "Kulit dan Kelamin", ["kulit"]],
  ["KJ", "Kedokteran Jiwa", ["jiwa", "psikiatri"]], ["OG", "Obstetri dan Ginekologi", ["obstetri", "kebidanan", "obgyn"]], ["OT", "Orthopedi dan Traumatologi", ["orthopedi", "ortopedi"]],
  ["BS", "Bedah Saraf", ["bedah saraf"]], ["RM", "Rehabilitasi Medik", ["rehabilitasi"]], ["GK", "Gizi Klinik", ["gizi"]], ["PD", "Penyakit Dalam", ["penyakit dalam"]],
  ["PK", "Patologi Klinik", ["patologi klinik"]], ["RAD", "Radiologi", ["radiologi"]], ["AN", "Anestesi", ["anestesi"]], ["BP", "Bedah Plastik", ["bedah plastik"]],
  ["U", "Urologi", ["urologi"]], ["M", "Mata", ["mata"]], ["P", "Paru", ["paru", "pulmonologi"]], ["N", "Saraf", ["saraf", "neurologi"]], ["S", "Saraf", ["saraf", "neurologi"]],
  ["A", "Anak", ["anak"]], ["B", "Bedah", ["bedah umum", "bedah"]],
];
function uraiKeterangan(teks) {
  const t = " " + String(teks || "").toLowerCase().replace(/[()]/g, " ") + " ";
  const sp = [];
  // "sp.pd", "sp pd", "sppd", "sp. m", "dr. sp. kk", "sp tht-kl"
  for (const m of t.matchAll(/\bsp\s*\.?\s*([a-z]{1,4})(?:[\s.-]*kl)?\b/g)) {
    let kode = m[1].toUpperCase();
    let hit = KAMUS_SP.find(([k]) => k === kode);
    if (!hit && kode.length > 2) hit = KAMUS_SP.find(([k]) => kode.startsWith(k) && k.length >= 2);
    if (hit && !sp.some((x) => x.nama === hit[1])) sp.push({ kode: hit[0], nama: hit[1], cari: hit[2] });
  }
  for (const [k, nama, cari] of KAMUS_SP) if (cari.some((c) => c.length > 4 && t.includes(" " + c)) && !sp.some((x) => x.nama === nama)) sp.push({ kode: k, nama, cari });
  const rs = (t.match(/\b(rsu?d?\s*[a-z][a-z .]{1,40}?|rsmd|rs\s?md|klinik\s+[a-z][a-z .]{2,40}?)(?=\s*(?:$|,|;|\.|\bcito\b|\bsegera\b|\bwl\b))/) || [])[1];
  const cito = /\bcito\b|\bsegera\b|\bdarurat\b|\bemergen/.test(t);
  return { spesialis: sp, rs: rs ? rs.replace(/\s+/g, " ").trim().toUpperCase() : "", cito };
}
function rujukanDari(d) {
  if (!d) return { ada: false };
  const tl = String(d.tindakLanjut || ""), st = String(d.rujukan || ""), ket = String(d.ketRujukan || "").trim();
  const eks = /eksternal/i.test(st), intr = /internal/i.test(st), rujukTL = /rujuk/i.test(tl);
  const ada = rujukTL || eks || intr || !!ket;
  if (!ada) return { ada: false };
  const u = uraiKeterangan(ket);
  const catatan = [];
  if (eks && tl && !rujukTL) catatan.push(`Tindak lanjut di C-CARE "${tl}", tetapi status rujukan Eksternal.`);
  if (rujukTL && !st) catatan.push("Tindak lanjut Rujuk, tetapi status rujukan belum dipilih di C-CARE.");
  if ((rujukTL || eks) && !ket) catatan.push("Keterangan rujukan kosong: spesialis tujuan tidak diketahui.");
  if (ket && !u.spesialis.length && !intr) catatan.push("Spesialis tidak terbaca dari keterangan. Pilih manual.");
  return { ada, jenis: intr ? "Internal" : "Eksternal", poliInternal: intr ? d.rujukanPoli || "" : "", ket, ...u, catatan };
}

// ---------- kolom kanan: data pasien ----------
const ABNORMAL = { sistole: (v) => v >= 140 || v < 90, diastole: (v) => v >= 90, hr: (v) => v > 100 || v < 50, rr: (v) => v > 24, suhu: (v) => v >= 37.5 || v < 35 };
const sel = (k, lab, v, sat = "") => `<div class="${ABNORMAL[k] && v !== "" && v != null && ABNORMAL[k](parseFloat(v)) ? "ab" : ""}"><small>${lab}</small>${v === "" || v == null ? "—" : esc(v) + sat}</div>`;
const barisKV = (k, v, salin = true) => v ? `<span class="k">${esc(k)}</span><span class="v">${esc(v)}</span>${salin ? `<button class="salin" data-salin="${esc(v)}">Salin</button>` : "<span></span>"}` : "";
function renderPasien() {
  const r = S.pilih, box = $("#pasien");
  aturKanan();
  if (!r) { box.innerHTML = ""; return; }
  const d = dataPasien(r), rj = rujukanDari(d);
  const sub = [r.antrean, r.usia != null ? r.usia + " th" : "", r.kelamin, r.kartu ? "BPJS " + kartuSamar(r.kartu) : ""].filter(Boolean).join(" · ");
  let isi = "", kaki = "";
  const alergi = d && d.alergi && !/^(-|tidak( ada)?|tdk|negatif|disangkal|0)$/i.test(d.alergi.trim()) ? d.alergi : "";
  const kepala = `<div class="p-kepala"><h2>${esc(r.nama)}</h2><button class="tutup" id="p-tutup" title="Tutup" aria-label="Tutup">${IKON.tutup}</button>
    <p class="redup">${esc(sub)}</p>
    ${d ? `<p class="redup">C-CARE${d.poli ? " " + esc(d.poli) : ""}${d.waktu ? " · dibaca " + esc(d.waktu) : ""}${d.dokter ? " · " + esc(d.dokter) : ""}${d.rm ? " · RM " + esc(d.rm) : ""}</p>
      <div class="alergi ${alergi ? "ada" : "tidak"}">${alergi ? IKON.alergi + "Alergi: " + esc(alergi) : "Alergi: tidak ada catatan"}</div>` : ""}
    <div class="p-status">${lencana(r.status, r.status === "cek" && r.ket ? "Perlu dicek" : null)}${r.ket && r.status !== "tersimpan" ? `<div class="redup">${esc(r.ket)}</div>` : ""}</div></div>`;
  if (!d) {
    isi = `<div class="kosong"><b>Data C-CARE belum diambil</b>Bot mencari kunjungan pasien ini di C-CARE (dibaca saja, tidak mengubah apa pun).</div>
      ${S.sibuk ? `<p class="hasil sisi">${esc(S.sibuk)}</p>` : ""}${S.hasil && S.hasil.gagal ? `<p class="hasil gagal sisi">${esc(S.hasil.pesan)}</p>` : ""}`;
    kaki = `<button class="tombol utama lebar" id="p-ambil" ${S.sibuk ? "disabled" : ""}>Ambil dari C-CARE</button>`;
  } else {
    if (rj.ada && TAMPIL_RUJUKAN) {
      isi += `<section class="bag rujukan"><h3>Catatan rujukan ${esc(rj.jenis)} · opsional</h3>
        ${rj.cito ? `<div class="peringatan merah">${IKON.alergi}Cito / segera</div>` : ""}
        ${rj.catatan.map((c) => `<div class="peringatan">${IKON.cek}${esc(c)}</div>`).join("")}
        <div class="kv">${rj.spesialis.map((s, i) => barisKV(i ? `Spesialis ${i + 1}` : "Spesialis", s.nama)).join("")}${barisKV("Poli tujuan", rj.poliInternal)}${barisKV("RS tujuan", rj.rs)}</div>
        ${rj.ket ? `<div class="asli">Keterangan C-CARE: “${esc(rj.ket)}”</div>` : ""}
        ${rj.spesialis.length && rj.jenis === "Eksternal" ? `<button class="tombol" id="p-isi-rujukan">Isi spesialis di PCare (opsional)</button>` : ""}
        ${S.hasil && !S.hasil.gagal && S.hasil.id ? `<p class="hasil ${S.hasil.ok ? "ok" : "gagal"}">${esc(S.hasil.pesan)}</p>` : ""}
      </section>`;
    }
    const dx = String(d.diagnosa || "").split(/\s*,\s*/).filter(Boolean);
    isi += `<section class="bag"><h3>Diagnosa</h3><div class="kv">${dx.map((k, i) => barisKV(i ? "#" + (i + 1) : "Utama", k)).join("") || '<span class="k">—</span><span class="v">tidak ada kode ICD-10</span><span></span>'}</div></section>`;
    isi += `<section class="bag"><h3>Tanda vital</h3><div class="strip">${sel("sistole", "TD", d.sistole && d.diastole ? d.sistole + "/" + d.diastole : "")}${sel("hr", "Nadi", d.hr)}${sel("rr", "RR", d.rr)}${sel("suhu", "Suhu", d.suhu)}</div>
      <div class="strip">${sel("tb", "TB", d.tb)}${sel("bb", "BB", d.bb)}${sel("lp", "LP", d.lp)}${sel("imt", "IMT", d.imt)}</div>
      ${["sistole", "diastole", "hr", "rr", "suhu"].some((k) => d[k] && ABNORMAL[k](parseFloat(d[k]))) ? `<div class="peringatan">${IKON.cek}Ada tanda vital di luar batas normal (kuning).</div>` : ""}</section>`;
    for (const [k, lab] of [["keluhan", "Keluhan"], ["anamnesa", "Anamnesa"], ["terapiObat", "Terapi obat"], ["terapiNonObat", "Terapi non obat"], ["bmhp", "BMHP"]])
      if (d[k]) isi += `<section class="bag"><div class="bag-kepala"><h3>${lab}</h3><button class="salin" data-salin="${esc(d[k])}" aria-label="Salin ${lab.toLowerCase()}">Salin</button></div><div class="teks">${esc(d[k])}</div></section>`;
    kaki = `${d.ccareUrl ? `<button class="tombol" id="p-buka">Buka lengkap di C-CARE</button>` : ""}<button class="tombol" id="p-ambil" ${S.sibuk ? "disabled" : ""}>${S.sibuk ? "Mengambil…" : "Ambil ulang"}</button>`;
  }
  // satu aksi utama: bila ada rujukan eksternal, "Isi spesialis di PCare" yang utama; selain itu "Proses dengan bot"
  if (r.status === "belum" || r.status === "cek" || r.status === "dikecualikan") kaki += `<button class="tombol utama" id="p-proses">Proses dengan bot</button>
    <button class="tautan-pv lebar-penuh" id="p-tandai" title="Pakai bila kunjungan ini sudah Anda simpan sendiri di PCare. Bot tidak memprosesnya lagi hari ini.">Sudah disimpan manual di PCare</button>`;
  box.innerHTML = kepala + `<div class="p-isi">${isi}</div><div class="p-kaki">${kaki}</div>`;
  $("#p-tutup").onclick = () => { S.pilih = null; renderDaftar(); renderPasien(); };
  box.querySelectorAll("[data-salin]").forEach((b) => (b.onclick = async () => { await app.salin(b.dataset.salin); kabar("Tersalin"); }));
  if ($("#p-ambil")) $("#p-ambil").onclick = () => ambilCcare(r);
  if ($("#p-buka")) $("#p-buka").onclick = () => app.bukaCcare(d.ccareUrl);
  if ($("#p-proses")) $("#p-proses").onclick = () => { app.tampil("pcare"); perintah("proses", { antrean: r.antrean, kartu: r.kartu }); };
  if ($("#p-tandai")) $("#p-tandai").onclick = () => perintah("tandai", { antrean: r.antrean, kartu: r.kartu, nama: r.nama });
  if ($("#p-isi-rujukan")) $("#p-isi-rujukan").onclick = () => { app.tampil("pcare"); perintah("isiRujukan", { spesialis: rj.spesialis.slice(0, 3) }); };
}
async function ambilCcare(r) {
  S.sibuk = "Mencari kunjungan di C-CARE… (biasanya 10–30 detik)"; S.hasil = null; renderPasien();
  const tgl = S.antrean && /^\d{4}-\d{2}-\d{2}$/.test(S.antrean.tgl) ? S.antrean.tgl : hariIni();
  const h = await app.kirimBot({ type: "ambilCcare", req: { nama: r.nama, kelamin: r.kelamin, usia: r.usia, tgl, kartu: r.kartu, antrean: r.antrean, poliPcare: r.poli || "" } });
  S.sibuk = null;
  if (!h || !h.ok) S.hasil = { gagal: true, pesan: (h && h.pesan) || "C-CARE tidak menjawab." };
  else { S.hasil = null; kabar(`Data C-CARE ${r.nama} diambil`); }
  if (S.pilih === r) renderPasien();
}

// ---------- v3.2.0: pita login (di atas halaman, tidak menutupinya) ----------
const NAMA_SITUS = { pcare: "PCare", ccare: "C-CARE" };
function renderPita() {
  const el = $("#pita");
  // hanya kabar situs yang sedang dilihat; kabar lama (> 10 menit) atau situs yang sudah masuk diabaikan
  const k = S.situs.tampil === "ccare" ? "ccare" : "pcare", kb = S.kabarLogin[k];
  const situs = kb && kb.teks && Date.now() - (kb.at || 0) < 600e3 && S.situs[k] !== "masuk" ? k : null;
  const sebelum = el.hidden;
  if (!situs) { el.hidden = true; el.innerHTML = ""; }
  else {
    const v = S.kabarLogin[situs];
    const cek = /gagal|ditolak|dihentikan|dibatalkan|belum aktif|batas/i.test(v.teks);
    el.className = "pita" + (cek ? " cek" : "");
    el.innerHTML = `${cek ? IKON.cek : IKON.info}<span class="pt-teks"><b>${NAMA_SITUS[situs]}:</b> ${esc(v.teks)}</span>` +
      (v.tombol || []).map((t) => `<button class="tombol" data-kl="${esc(t)}">${esc(t)}</button>`).join("") +
      (/Pengaturan/.test(v.teks) ? `<button class="tombol" id="pt-atur">Buka Pengaturan</button>` : "") +
      `<button class="tutup" data-kl="×" title="Tutup / batalkan login otomatis" aria-label="Tutup">${IKON.tutup}</button>`;
    if ($("#pt-atur")) $("#pt-atur").onclick = () => app.pengaturan();
    el.querySelectorAll("[data-kl]").forEach((b) => (b.onclick = () => {
      app.simpan({ klikKabar: { situs, tombol: b.dataset.kl, at: Date.now() } });
      if (b.dataset.kl === "×") { S.kabarLogin[situs] = null; renderPita(); }
      else app.tampil(situs);
    }));
    el.hidden = false;
  }
  if (sebelum !== el.hidden) requestAnimationFrame(laporArea);
}

// ---------- v3.2.0: pratinjau sebelum simpan di kolom kanan (tidak menutupi PCare) ----------
// Isinya dikirim halaman PCare lewat "pratinjauAktif"; klik dikirim balik sebagai perintah "pv".
const PV = { id: null, gen: null, cache: {} };
const LABEL_PV = { diagnosa: "Utama", diagnosa2: "#2", diagnosa3: "#3", diagnosa4: "#4", terapiObat: "Terapi obat", terapiNonObat: "Terapi non obat",
  sistole: "Sistole", diastole: "Diastole", hr: "Nadi", rr: "Napas", suhu: "Suhu", tb: "Tinggi", bb: "Berat", lp: "Lingkar perut" };
const SATUAN_PV = { sistole: "mmHg", diastole: "mmHg", hr: "x/mnt", rr: "x/mnt", suhu: "°C", tb: "cm", bb: "kg", lp: "cm" };
const GRUP_PV = [["Keluhan & anamnesa", ["keluhan", "anamnesa"], ""], ["Diagnosa ICD-10", ["diagnosa", "diagnosa2", "diagnosa3", "diagnosa4"], "dua"],
  ["Terapi", ["terapiObat", "terapiNonObat", "bmhp"], ""], ["Tanda vital", ["sistole", "diastole", "hr", "rr", "suhu"], "tiga"], ["Antropometri", ["tb", "bb", "lp"], "tiga"]];
function barisPasienPv(v) {
  const rows = (S.antrean && S.antrean.rows) || [];
  return rows.find((x) => x.antrean === v.antrean && (!v.kartu || x.kartu === v.kartu)) || rows.find((x) => x.antrean === v.antrean) || null;
}
function htmlKepalaPv(v) {
  const r = barisPasienPv(v), d = r ? dataPasien(r) : null;
  const alergi = d && d.alergi && !/^(-|tidak( ada)?|tdk|negatif|disangkal|0)$/i.test(d.alergi.trim()) ? d.alergi : "";
  const sub = [v.antrean, r && r.usia != null ? r.usia + " th" : "", r ? r.kelamin : "", v.kartu ? "BPJS " + kartuSamar(v.kartu) : ""].filter(Boolean).join(" · ");
  return `<div class="label-atas">${esc(v.judul || "Pratinjau sebelum simpan")}</div>
    <h2>${esc(r ? r.nama : "Pasien " + (v.antrean || ""))}</h2><button class="tutup" data-pv="br-pv-x" title="Batal (Esc): tidak disimpan" aria-label="Batal">${IKON.tutup}</button>
    <p class="redup">${esc(sub)}</p>
    ${alergi ? `<div class="alergi ada">${IKON.alergi}Alergi: ${esc(alergi)}</div>` : ""}`;
}
function htmlPesanPv(v) {
  const p = v.pesan; if (!p) return "";
  if (p.jenis === "ok") return `<div class="pv-pesan ok">${IKON.tersimpan}<span>${esc(p.judul)}</span></div>`;
  return `<div class="pv-pesan cek">${IKON.cek}<div><b>${esc(p.judul)}</b><ul>${p.item.map((x) => `<li>${esc(x)}</li>`).join("")}</ul></div></div>`;
}
function htmlLihatPv(v) {
  return `<dl class="pv-daftar">${v.baris.filter((b) => !b.k && !b.catatan).map((b) =>
    `<div class="pv-baris"><dt>${esc(b.th)}</dt><dd class="${b.kosong ? "nihil" : ""}">${b.kosong ? "Kosong" : esc(b.td)}</dd></div>`).join("")}</dl>`;
}
function htmlEditPv(v) {
  const per = Object.fromEntries(v.baris.filter((b) => b.k).map((b) => [b.k, b]));
  const pakai = new Set();
  const isian = (b) => {
    pakai.add(b.k);
    const lab = LABEL_PV[b.k] || b.th, sat = SATUAN_PV[b.k], kode = /^diagnosa\d?$/.test(b.k);
    const contoh = b.mati ? "Tidak ada di form" : kode ? "mis. J06.9" : "";
    const attr = `data-k="${esc(b.k)}" id="pv-${esc(b.k)}" ${b.mati ? "disabled" : ""} placeholder="${esc(contoh)}"`;
    return `<label class="isian" for="pv-${esc(b.k)}"><span>${esc(lab)}${sat ? ` <small>${esc(sat)}</small>` : ""}</span>${b.tipe === "area"
      ? `<textarea ${attr} rows="${Math.max(2, b.baris || 2)}"></textarea>`
      : `<input ${attr} ${b.tipe === "num" ? 'inputmode="decimal"' : ""} ${kode ? 'class="kode" autocomplete="off" spellcheck="false"' : ""}>`}</label>`;
  };
  let h = GRUP_PV.map(([judul, kunci, kelas]) => { const ada = kunci.filter((k) => per[k]); if (!ada.length) return "";
    return `<section class="pv-grup"><h3>${judul}</h3><div class="isi ${kelas}">${ada.map((k) => isian(per[k])).join("")}</div></section>`; }).join("");
  const sisa = v.baris.filter((b) => b.k && !pakai.has(b.k));
  if (sisa.length) h += `<section class="pv-grup"><h3>Lainnya</h3><div class="isi">${sisa.map(isian).join("")}</div></section>`;
  const cat = v.baris.find((b) => b.catatan);
  if (cat) h += `<p class="pv-catatan">${esc(cat.td)}</p>`;
  return h;
}
function htmlTombolPv(v) {
  return v.tombol.map((b) => `<button type="button" class="${b.primer ? "tombol utama" : b.tautan ? "tautan-pv" : "tombol"}" data-pv="${esc(b.id)}" ${b.mati ? "disabled" : ""}>${esc(b.teks)}</button>`).join("");
}
function bagianPv(id, html) { if (PV.cache[id] === html) return false; PV.cache[id] = html; $("#" + id).innerHTML = html; return true; }
function renderPv() {
  const v = S.pv, box = $("#pv");
  aturKanan();
  if (!v) { PV.id = null; PV.cache = {}; box.innerHTML = ""; return; }
  if (PV.id !== v.id) {
    PV.id = v.id; PV.gen = null; PV.cache = {};
    box.innerHTML = `<div class="p-kepala" id="pv-kepala"></div><div class="p-isi"><div id="pv-pesan"></div><div id="pv-badan"></div></div>
      <div class="p-kaki pv-kaki"><p class="hitung" id="pv-hitung" aria-live="polite"></p><div class="pv-tombol" id="pv-tombol"></div></div>`;
    app.tampil("pcare");
  }
  bagianPv("pv-kepala", htmlKepalaPv(v));
  bagianPv("pv-pesan", htmlPesanPv(v));
  const baru = bagianPv("pv-badan", v.edit ? htmlEditPv(v) : htmlLihatPv(v));
  if (v.edit && (baru || PV.gen !== v.gen)) {   // nilai isian hanya ditimpa saat form baru dibuka / "Muat ulang dari form"
    PV.gen = v.gen;
    for (const b of v.baris) if (b.k) { const f = box.querySelector(`[data-k="${b.k}"]`); if (f) f.value = b.nilai || ""; }
    if (baru) { const f = box.querySelector("[data-k]:not(:disabled)"); if (f) f.focus(); }
  }
  $("#pv-hitung").textContent = v.hitung || "";
  bagianPv("pv-tombol", htmlTombolPv(v));
}
function kirimPv(tombol) {
  if (!S.pv) return;
  const extra = { pvId: S.pv.id, tombol };
  if (S.pv.edit && tombol === "br-pv-tulis") extra.nilai = Object.fromEntries([...document.querySelectorAll("#pv [data-k]")].map((f) => [f.dataset.k, /^diagnosa/.test(f.dataset.k) ? f.value.trim().toUpperCase() : f.value]));
  S.tungguPv = perintah("pv", extra);
}
$("#pv").addEventListener("click", (e) => { const b = e.target.closest("[data-pv]"); if (b && !b.disabled) kirimPv(b.dataset.pv); });
document.addEventListener("keydown", (e) => {
  if (e.key !== "Escape" || !S.pv) return;
  if (S.pv.edit && /^(INPUT|TEXTAREA)$/.test((document.activeElement || {}).tagName || "")) { document.activeElement.blur(); return; }   // Esc pertama: keluar dari isian
  kirimPv(S.pv.edit ? "br-pv-tutup" : "br-pv-batal");
});

muatAwal();
