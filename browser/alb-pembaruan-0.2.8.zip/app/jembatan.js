/* Halaman jembatan tersembunyi AlvisyaLabs Browser: meneruskan panggilan shim dari service worker ke proses utama. */
chrome.runtime.onMessage.addListener((m, _s, balas) => {
  if (!m || !m.__aldesk) return;
  fetch('aldesk://x/' + m.__aldesk, { method: 'POST', body: JSON.stringify(m.data ?? null) })
    .then((r) => r.json()).then((j) => balas(j && j.galat ? { galat: j.galat } : { hasil: j }), (e) => balas({ galat: String(e && e.message || e) }));
  return true;
});
