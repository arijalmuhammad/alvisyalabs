/* Salin resep dari Riwayat Kunjungan (tab Identitas Pasien → Riwayat Kunjungan) ke resep kunjungan saat ini.
 *  - Tombol salin muncul di kolom Resep setiap baris riwayat yang isinya bisa dibaca.
 *  - Obat dicocokkan dengan NAMA ke daftar obat C-CARE saat ini (stok bisa sudah berubah); yang cocok ditambahkan sebagai
 *    baris resep baru, YANG TIDAK COCOK dilewati dan dilaporkan — semua tetap harus Anda periksa sebelum Simpan.
 * Catatan: kolom resep dicari lewat judul kolom "Resep" (toleran terhadap th/td, spasi, atau tambahan ikon urutan);
 * bila judul tidak ketemu, dicoba cadangan: kolom yang ISINYA cocok pola "Nama (Jumlah Satuan) x Intensitas" di
 * sebagian besar baris. Bila keduanya gagal (struktur tabel berubah total), tombol salin tidak akan muncul sama
 * sekali (aman — tidak mengubah apa pun) daripada salah membaca. */
(() => {
  if (!/\/Ubah\/\d+/i.test(location.pathname) || window.__sjcRiwayat) return; window.__sjcRiwayat = true;
  const bersih = s => String(s == null ? '' : s).replace(/\s+/g, ' ').trim();
  const esc = t => String(t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const SATUAN_ID = { tablet: '1', ml: '3', 'sendok makan': '5', oles: '6', tetes: '7', bungkus: '8', kapsul: '9', suppos: '10', 'sendok obat': '1008', pen: '2008' };
  const IK_SALIN = '<svg viewBox="0 0 24 24"><path d="M16 1H4a2 2 0 00-2 2v14h2V3h12V1zm3 4H8a2 2 0 00-2 2v14a2 2 0 002 2h11a2 2 0 002-2V7a2 2 0 00-2-2zm0 16H8V7h11v14z"/></svg>';

  /* ---------- cari tab "Riwayat Kunjungan" & kolom "Resep" di dalamnya ---------- */
  function panelRiwayat() {
    const tautan = [...document.querySelectorAll('a[href^="#"]')].find(a => /riwayat\s*kunjungan/i.test(bersih(a.textContent)));
    const sel = tautan && (tautan.getAttribute('href') || '');
    return sel ? document.querySelector(sel) : null;
  }
  const POLA_RESEP = /\(\s*\d+[^)]*\)\s*x\s*\d+/i;                              // ciri khas satu baris resep, mis. "(10 Tablet) x 3"
  function baris(panel) {
    const hasil = [];
    panel.querySelectorAll('table').forEach(tbl => {
      const barisData = tbl.tBodies[0] ? [...tbl.tBodies[0].rows] : [...tbl.rows].slice(1);
      const head = [...tbl.querySelectorAll('thead th, thead td, tr:first-child th, tr:first-child td')].map(th => bersih(th.textContent));
      let kolomResep = head.findIndex(h => /resep/i.test(h));
      if (kolomResep < 0) {                                                     // cadangan: judul kolom tidak ketemu → cari lewat ISI kolom
        const jmlKolom = barisData.reduce((m, tr) => Math.max(m, tr.cells.length), 0);
        for (let k = 0; k < jmlKolom; k++) {
          if (barisData.some(tr => tr.cells[k] && POLA_RESEP.test(tr.cells[k].textContent))) { kolomResep = k; break; }
        }
      }
      if (kolomResep < 0) return;
      barisData.forEach(tr => { const sel = tr.cells[kolomResep]; if (sel && bersih(sel.textContent)) hasil.push(sel); });
    });
    return hasil;
  }
  /* "Farsifen 400 mg (10 Tablet) x 3" → {nama,jumlah,satuan,intensitas}; baris yang tidak cocok pola dilewati.
   * DIBACA HANYA dari .sjc-salin-asli (teks riwayat asli yang sudah dipisah dari tombol & pesan kita sendiri) —
   * membaca langsung dari sel akan ikut membaca label tombol/pesan begitu keduanya ditambahkan. */
  function pecahResep(asli) {
    const teks = asli.innerHTML.replace(/<br\s*\/?>/gi, '\n');
    const d = document.createElement('div'); d.innerHTML = teks;
    return d.textContent.split(/\n|<br\s*\/?>/i).map(bersih).filter(Boolean).map(baris => {
      const m = baris.match(/^(.*?)\s*\((\d+)\s*([^)]*)\)\s*x\s*(\d+)\s*$/i);
      if (!m) return { teks: baris, cocok: false };
      return { teks: baris, cocok: true, nama: bersih(m[1]), jumlah: m[2], satuanTeks: bersih(m[3]), satuan: SATUAN_ID[bersih(m[3]).toLowerCase()] || '', intensitas: m[4] };
    });
  }

  const GAYA = document.createElement('style');
  GAYA.textContent = `.sjc-salin-resep{display:inline-flex;align-items:center;gap:5px;height:26px;padding:0 10px;margin-bottom:6px;border:1px solid #263C92;border-radius:8px;background:#fff;color:#263C92;font:12px/1 "Source Sans 3","Source Sans Pro","Segoe UI",system-ui,sans-serif;font-weight:700;cursor:pointer}
  .sjc-salin-resep svg{width:14px;height:14px;fill:currentColor}.sjc-salin-resep:disabled{opacity:.5;cursor:default}
  .sjc-salin-pesan{margin-top:4px;font:12px/1.4 "Source Sans 3","Source Sans Pro","Segoe UI",system-ui,sans-serif;color:#4F6478}`;

  function pasangTombol(sel) {
    if (sel.dataset.sjcSalin) return;                                          // sudah ditangani (tombol dipasang / sudah disalin) — tidak diulang
    let asli = sel.querySelector('.sjc-salin-asli');
    if (!asli) { asli = document.createElement('span'); asli.className = 'sjc-salin-asli'; while (sel.firstChild) asli.appendChild(sel.firstChild); sel.appendChild(asli); }
    if (!pecahResep(asli).some(x => x.cocok)) return;
    if (!GAYA.isConnected) document.head.appendChild(GAYA);
    sel.dataset.sjcSalin = '1';
    const tombol = document.createElement('button'); tombol.type = 'button'; tombol.className = 'sjc-salin-resep';
    tombol.innerHTML = IK_SALIN + 'Salin ke resep';
    sel.insertBefore(tombol, asli);                                           // selalu DI LUAR teks asli → tidak pernah tercampur saat dibaca ulang
    tombol.addEventListener('click', () => salin(sel, asli, tombol));
  }
  function pesan(sel, teks) {
    let p = sel.querySelector('.sjc-salin-pesan'); if (!p) { p = document.createElement('div'); p.className = 'sjc-salin-pesan'; sel.appendChild(p); }
    p.textContent = teks;
  }
  async function salin(sel, asli, tombol) {
    const baris = pecahResep(asli).filter(x => x.cocok);
    tombol.disabled = true; tombol.textContent = 'Menyalin…';
    let ok = 0; const lewat = [], duplikat = [];
    for (const b of baris) {
      const hasil = document.__sjcSalinSatuResep ? await document.__sjcSalinSatuResep(b) : false;
      if (hasil === 'duplikat') duplikat.push(b.nama);
      else if (hasil) ok++;
      else lewat.push(b.nama);
    }
    tombol.remove();
    const ket = [lewat.length ? 'tidak ditemukan: ' + lewat.join(', ') : '', duplikat.length ? 'sudah ada di resep: ' + duplikat.join(', ') : ''].filter(Boolean).join(' · ');
    pesan(sel, ok ? `${ok} dari ${baris.length} obat disalin ke resep${ket ? ' — ' + ket : ''}. Periksa dosis & aturan pakai sebelum Simpan.`
      : duplikat.length && !lewat.length ? `Semua obat (${duplikat.length}) sudah ada di resep — tidak disalin ulang.`
      : 'Tidak ada obat yang cocok dengan daftar obat saat ini — salin manual.');
  }
  function telusuri() { const panel = panelRiwayat(); if (panel) baris(panel).forEach(pasangTombol); }
  new MutationObserver(telusuri).observe(document.body, { childList: true, subtree: true });
  setTimeout(telusuri, 1200);
})();
