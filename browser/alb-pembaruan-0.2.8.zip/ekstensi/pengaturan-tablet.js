/* Pengaturan → Tampilan → Tablet tanda tangan (v4.8.0). Disimpan di chrome.storage.local "ttdTablet" {peran, url, t}. */
(() => {
  const $ = id => document.getElementById(id); if (!$('kartuTablet')) return;
  const POLA_URL = /^https:\/\/script\.google\.com\/macros\/s\/[\w-]+\/exec$/;
  const tokenBaru = () => { const a = new Uint8Array(18); crypto.getRandomValues(a); return btoa(String.fromCharCode(...a)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); };
  let cfg = {};
  const pesan = (t, k) => { $('tbPesan').textContent = t; $('tbPesan').className = 'pesan' + (k ? ' ' + k : ''); };
  function tautan() {
    if ([...document.getElementsByName('tbJenis')].find(r => r.checked).value === 'web') return `${cfg.url}?t=${cfg.t}`;
    const b = btoa(JSON.stringify({ u: cfg.url, t: cfg.t })).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
    return 'https://c-care.ipb.ac.id/#sjcTablet=' + b;
  }
  function gambar() {
    const siap = cfg.peran === 'pc' && POLA_URL.test(cfg.url || '') && cfg.t;
    $('tbPasang').hidden = !siap; if (!siap) return;
    const q = qrcode(0, 'M'); q.addData(tautan()); q.make();
    $('tbQr').innerHTML = q.createImgTag(4, 0, 'Kode QR pemasangan tablet');
    const img = $('tbQr').querySelector('img'); img.style.cssText = 'width:100%;height:100%;image-rendering:pixelated';
  }
  chrome.storage.local.get('ttdTablet', s => { cfg = s.ttdTablet || {}; $('tbPeran').value = cfg.peran || ''; $('tbUrl').value = cfg.url || ''; gambar(); });
  $('tbSimpan').addEventListener('click', () => {
    const peran = $('tbPeran').value, url = $('tbUrl').value.trim();
    if (peran && !POLA_URL.test(url)) { pesan('URL harus berbentuk https://script.google.com/macros/s/…/exec', 'galat'); $('tbUrl').focus(); return; }
    if (peran === 'tablet' && !cfg.t) { pesan('Untuk tablet, pindai kode QR dari Pengaturan di PC dokter.', 'awas'); return; }
    cfg = { peran, url, t: cfg.t || tokenBaru() };
    chrome.storage.local.set({ ttdTablet: cfg }, () => { pesan(peran ? 'Tersimpan.' : 'Tablet tanda tangan tidak dipakai di perangkat ini.', 'ok'); gambar(); });
  });
  document.getElementsByName('tbJenis').forEach(r => r.addEventListener('change', gambar));
  $('tbSalin').addEventListener('click', () => navigator.clipboard.writeText(tautan()).then(() => pesan('Tautan tersalin.', 'ok')));
  $('tbTokenBaru').addEventListener('click', () => { cfg.t = tokenBaru(); chrome.storage.local.set({ ttdTablet: cfg }, () => { pesan('Token baru dibuat. Pasang ulang tablet dengan kode QR ini.', 'awas'); gambar(); }); });
})();
