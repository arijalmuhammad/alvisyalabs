(() => {
  const $ = id => document.getElementById(id);
  const tokenBaru = () => { const a = new Uint8Array(18); crypto.getRandomValues(a); return btoa(String.fromCharCode(...a)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); };
  let cfg = {};
  const pesan = (t, k) => { $('pesan').textContent = t; $('pesan').className = 'pesan' + (k ? ' ' + k : ''); };
  const tautan = () => `${cfg.url}?t=${cfg.t}`;   // format yang dibaca aplikasi tablet (TtdSetupActivity)
  function gambar() {
    if (!cfg.url || !cfg.t) { pesan('Setelan belum siap. Tutup lalu buka lagi halaman ini.', 'galat'); return; }
    const q = qrcode(0, 'M'); q.addData(tautan()); q.make();
    $('qr').innerHTML = q.createImgTag(4, 0, 'Kode QR pemasangan tablet');
    $('qr').querySelector('img').style.cssText = 'width:100%;height:100%;image-rendering:pixelated';
  }
  function muat() { chrome.storage.local.get('ttdTablet', s => { cfg = s.ttdTablet || {}; gambar(); }); }
  // shortcut: kata sandi tetap sesuai permintaan pemilik, hanya penghalang ringan (bisa dibaca dari berkas ekstensi)
  $('gerbang').addEventListener('submit', e => {
    e.preventDefault();
    if ($('sandi').value.trim() !== 'IPB123') { $('sandiPesan').textContent = 'Kata sandi salah. Coba lagi.'; $('sandi').select(); return; }
    $('gerbang').hidden = true; $('isi').hidden = false; muat();
  });
  $('salin').addEventListener('click', () => navigator.clipboard.writeText(tautan()).then(() => pesan('Tautan tersalin.', 'ok'), () => pesan('Gagal menyalin. Pindai kode QR saja.', 'galat')));
  $('tokenBaru').addEventListener('click', () => {
    cfg = { peran: 'pc', url: cfg.url, t: tokenBaru() };
    chrome.storage.local.set({ ttdTablet: cfg }, () => { pesan('Kode baru dibuat. Tablet lama tidak tersambung lagi; pindai ulang kode ini di tablet.', 'galat'); gambar(); });
  });
  cekPembaruan().then(p => { if (p) { $('baruUrl').href = p.url; $('baruUrl').textContent = 'Unduh versi ' + p.versi; $('baru').hidden = false; } });
  $('sandi').focus();
})();
