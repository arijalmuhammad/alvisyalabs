/* Shim CCare Desktop: melengkapi API chrome.* yang belum ada di Electron. Disisipkan sebelum skrip ekstensi
   (service worker & halaman ekstensi). Jalur ke proses utama: fetch ke skema aldesk:// (lihat main.js). */
(() => {
  if (globalThis.__aldesk) return; globalThis.__aldesk = true;
  const panggil = (aksi, data) => fetch('aldesk://x/' + aksi, { method: 'POST', body: JSON.stringify(data ?? null) })
    .then((r) => r.json()).then((j) => { if (j && j.galat) throw new Error(j.galat); return j; });
  const cbAtauJanji = (p, cb) => { if (typeof cb === 'function') { p.then(cb, () => cb()); return; } return p; };
  const c = globalThis.chrome;

  // Electron belum mengisi status/windowId tab dan tidak memancarkan onUpdated → tab dikelola proses utama.
  c.tabs.create = (opsi, cb) => cbAtauJanji(panggil('tabsCreate', opsi || {}), cb);
  c.tabs.query = (q, cb) => cbAtauJanji(panggil('tabsQuery', q || {}), cb);
  c.tabs.get = (id, cb) => cbAtauJanji(panggil('tabsGet', { id }), cb);
  c.tabs.update = (id, o, cb) => { if (typeof id === 'object') { cb = o; o = id; id = null; } return cbAtauJanji(panggil('tabsUpdate', { id, o: o || {} }), cb); };
  c.tabs.reload = (id, o, cb) => { if (typeof id !== 'number') { cb = typeof o === 'function' ? o : id; id = null; } return cbAtauJanji(panggil('tabsReload', { id }), cb); };
  const acara = () => { const l = []; return { l, addListener: (f) => l.push(f), removeListener: (f) => { const i = l.indexOf(f); if (i >= 0) l.splice(i, 1); }, hasListener: (f) => l.includes(f) }; };
  const onUpdated = acara(), onRemoved = acara(), onKlikNotif = acara();
  c.tabs.onUpdated = onUpdated; c.tabs.onRemoved = onRemoved;
  c.tabs.remove = (ids, cb) => cbAtauJanji(panggil('tabsRemove', [].concat(ids)), cb);
  c.runtime.openOptionsPage = (cb) => cbAtauJanji(panggil('tabsCreate', { url: c.runtime.getURL('pengaturan.html') }), cb);
  c.runtime.reload = () => { panggil('muatUlangEkstensi'); };
  if (!c.windows) c.windows = { update: (id, o, cb) => cbAtauJanji(panggil('fokus', {}), cb), WINDOW_ID_CURRENT: -2 };

  if (!c.notifications) {
    let seri = 0;
    c.notifications = {
      create(id, opsi, cb) {
        if (typeof id === 'object') { cb = opsi; opsi = id; id = 'n' + (++seri) + '-' + Date.now(); }
        if (opsi && opsi.iconUrl && !/^[a-z-]+:/.test(opsi.iconUrl)) opsi = { ...opsi, iconUrl: c.runtime.getURL(opsi.iconUrl) };
        return cbAtauJanji(panggil('notifBuat', { id, opsi }).then(() => id), cb);
      },
      update(id, opsi, cb) { return cbAtauJanji(panggil('notifUbah', { id, opsi }).then((r) => !!r.ada), cb); },
      clear(id, cb) { return cbAtauJanji(panggil('notifHapus', { id }).then((r) => !!r.ada), cb); },
      onClicked: onKlikNotif,
    };
  }
  // Satu antrean kejadian per konteks (service worker / halaman): klik notifikasi, perubahan & penutupan tab.
  const klien = Math.random().toString(36).slice(2);
  const jalankan = (l, ...a) => l.slice().forEach((f) => { try { f(...a); } catch (x) { console.error(x); } });
  const tunggu = () => panggil('kejadian', { klien }).then((ev) => {
    for (const e of ev || []) {
      if (e.jenis === 'notifKlik') jalankan(onKlikNotif.l, e.id);
      else if (e.jenis === 'tabUbah') jalankan(onUpdated.l, e.id, e.info, e.tab);
      else if (e.jenis === 'tabTutup') jalankan(onRemoved.l, e.id, { windowId: 1, isWindowClosing: false });
    }
  }).catch(() => new Promise((r) => setTimeout(r, 3000))).finally(tunggu);
  tunggu();
})();
