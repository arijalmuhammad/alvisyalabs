// ===== Utilitas bersama =====
// Field dicari berdasarkan TEKS LABEL. Jika nanti ID asli sudah diketahui,
// isi SELECTOR_OVERRIDE di pcare.js agar lebih presisi.

const BR = {};

BR.sleep = (ms) => new Promise((r) => setTimeout(r, ms));

BR.norm = (s) =>
  (s || "").replace(/\*/g, "").replace(/\s+/g, " ").trim().toLowerCase();

BR.visible = (el) =>
  !!el && !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length);

// Alamat halaman daftar pasien C-CARE (dari dr. Arijal, 14-10-2026).
// TIDAK direkap (bukan pelayanan dokter umum / bukan penyakit): Poli Gigi /Poli/Index/2, Kunjungan Sehat /Poli/Index/4.
BR.CCARE_POLI = {
  UMUM: "https://c-care.ipb.ac.id/Poli/Index/1",
  KIA: "https://c-care.ipb.ac.id/Kia",
  TINDAKAN: "https://c-care.ipb.ac.id/Poli/Index/5",
  PROLANIS: "https://c-care.ipb.ac.id/Poli/Index/8",
  GIZI: "https://c-care.ipb.ac.id/Poli/Index/7",   // v1.9.1: Poli Gizi dikirim ke PCare sebagai Poli Umum
  GIGI: "https://c-care.ipb.ac.id/Poli/Index/2",   // v1.9.6: hanya dicari untuk pesan "ditemukan di Poli Gigi" (tidak dikirim otomatis)
  SEHAT: "https://c-care.ipb.ac.id/Poli/Index/4",  // v1.9.6: idem Kunjungan Sehat
};
BR.NAMA_POLI = { UMUM: "Poli Umum", KIA: "Poli KIA", TINDAKAN: "Ruang Tindakan", PROLANIS: "Poli Prolanis", GIZI: "Poli Gizi", GIGI: "Poli Gigi", SEHAT: "Kunjungan Sehat" };
BR.BRIDGING_POLI = ["UMUM", "TINDAKAN", "PROLANIS", "KIA", "GIZI"];   // urutan pencarian pasien PCare di C-CARE
BR.CCARE_TIDAK_DIREKAP = ["/poli/index/2", "/poli/index/4"];   // Poli Gigi, Kunjungan Sehat
// kode poli dari alamat halaman (huruf kecil, tanpa garis miring akhir / query)
BR.poliDariUrl = (href) => {
  const p = String(href || "").replace(/[?#].*$/, "").replace(/\/+$/, "").toLowerCase();
  for (const [k, u] of Object.entries(BR.CCARE_POLI)) if (p.endsWith(new URL(u).pathname.toLowerCase())) return k;
  return null;
};
// Logo IPB untuk kepala panel; aman bila konteks ekstensi sudah tidak berlaku (mis. setelah ekstensi diperbarui)
BR.urlLogo = () => { try { return chrome.runtime.getURL("ipb64.png"); } catch (e) { return ""; } };
// Panel/modal milik ekstensi ini: TIDAK boleh dianggap bagian dari halaman PCare / C-CARE
BR.UI_SENDIRI = "#br-panel, #br-fab, #br-pratinjau, #br-balon, #rkm-panel, #rkm-fab, #rkm-modal, [id^='br-'], [id^='rkm-']";
// Cari elemen teks yang labelnya cocok persis (atau diawali) dengan `label`
BR.findLabelEl = (label) => {
  const target = BR.norm(label);
  // Elemen yang membungkus field (mis. div satu baris form) BUKAN label -> dibuang.
  // Tanpa ini, bot mengambil field baris berikutnya (bug v0.4: isian bergeser 1 baris).
  const cands = [...document.querySelectorAll("label, th, td, span, div, b, strong, p")]
    .filter((el) => BR.visible(el) && el.children.length <= 2 && !el.closest(BR.UI_SENDIRI) &&
                    // label boleh berisi kotak centang/radio (mis. "☑ Makanan" di Riwayat Alergi PCare)
                    !el.querySelector("input:not([type=checkbox]):not([type=radio]), select, textarea"));
  const rank = (el) => (el.tagName === "LABEL" ? 0 : /^(TH|TD|B|STRONG)$/.test(el.tagName) ? 1 : 2);
  const pick = (fn) => cands.filter(fn).sort((a, b) => rank(a) - rank(b))[0];
  return (
    pick((el) => BR.norm(el.textContent) === target) ||
    pick((el) => BR.norm(el.textContent).startsWith(target))
  );
};

// Dari elemen label, cari kontrol input terdekat
BR.findControl = (label, kinds = "input:not([type=hidden]):not([type=radio]):not([type=checkbox]), select, textarea") => {
  const lab = BR.findLabelEl(label);
  if (!lab) return null;
  if (lab.tagName === "LABEL" && lab.htmlFor) {
    const el = document.getElementById(lab.htmlFor);
    if (el && !el.closest(BR.UI_SENDIRI)) return el;
  }
  let node = lab;
  for (let i = 0; i < 4 && node; i++) {
    // cek saudara setelahnya dulu
    let sib = node.nextElementSibling;
    while (sib) {
      const c = sib.matches?.(kinds) ? sib : sib.querySelector?.(kinds);
      if (c && BR.visible(c) && !c.closest(BR.UI_SENDIRI)) return c;
      sib = sib.nextElementSibling;
    }
    node = node.parentElement;
  }
  return null;
};

BR.fire = (el) => {
  ["input", "keyup", "change", "blur"].forEach((t) =>
    el.dispatchEvent(new Event(t, { bubbles: true }))
  );
  if (window.jQuery) try { window.jQuery(el).trigger("change"); } catch (e) {}
};

BR.setValue = (el, value) => {
  if (!el || value === undefined || value === null || value === "") return false;
  if (el.tagName === "SELECT") {
    const v = BR.norm(String(value));
    const opt =
      [...el.options].find((o) => BR.norm(o.text) === v) ||
      [...el.options].find((o) => BR.norm(o.text).includes(v)) ||
      [...el.options].find((o) => BR.norm(o.value) === v);
    if (!opt) return false;
    el.value = opt.value;
  } else {
    const proto = el.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto, "value").set.call(el, String(value));
  }
  BR.fire(el);
  return true;
};

// Klik radio/checkbox yang teks labelnya cocok (mis. "Compos mentis", "Berobat Jalan")
BR.clickChoice = (text) => {
  const t = BR.norm(text);
  const radios = [...document.querySelectorAll("input[type=radio], input[type=checkbox]")];
  for (const r of radios) {
    const lab =
      (r.id && document.querySelector(`label[for="${CSS.escape(r.id)}"]`)) ||
      r.closest("label") || r.parentElement;
    const txt = BR.norm(lab?.textContent || r.value);
    if (txt === t || BR.norm(r.value) === t) {
      if (!r.checked) r.click();
      return true;
    }
  }
  return false;
};

// Tekan Enter pada field (dipakai untuk kode diagnosa PCare agar nama penyakit dicari)
BR.pressEnter = (el) => {
  if (!el) return;
  el.focus();
  ["keydown", "keypress", "keyup"].forEach((t) =>
    el.dispatchEvent(new KeyboardEvent(t, { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true }))
  );
  if (window.jQuery) try {
    const e = window.jQuery.Event("keyup", { keyCode: 13, which: 13 });
    window.jQuery(el).trigger(e).trigger(window.jQuery.Event("keydown", { keyCode: 13, which: 13 }));
  } catch (e) {}
  el.dispatchEvent(new Event("blur", { bubbles: true }));
};

BR.clickButton = (text) => {
  const t = BR.norm(text);
  const btn = [...document.querySelectorAll("button, input[type=button], input[type=submit], a.btn")]
    .find((b) => BR.visible(b) && BR.norm(b.textContent || b.value) === t);
  if (btn) { btn.click(); return true; }
  return false;
};

BR.store = {
  get: (k) => new Promise((r) => chrome.storage.local.get(k, (o) => r(o[k]))),
  set: (k, v) => new Promise((r) => chrome.storage.local.set({ [k]: v }, r)),
};

// Kunci pencocokan pasien C-CARE <-> PCare
BR.nameKey = (s) => BR.norm(s)
  .replace(/,.*$/, " ")                                                    // v1.9.7: gelar di belakang koma ("…, S.SI,MSI")
  .replace(/\b[sm]\s*\.\s*(e|si|h|t|pd|kom|kes|ked|kep|farm|gz|gizi|sos|ag|ip|psi|ak|m|md|hum|ikom|kg|sc|sn|ds)\b\.?/g, " ")   // S.E., S.Si, M.Si …
  .replace(/\ba\s*\.\s*md\b\.?|\b(prof|ir|drs|dra)\b\.?/g, " ")
  .replace(/\b(hj|h|ny|nn|tn|an|by|sdr|sdri|dr|drg)\b\.?/g, " ")
  .replace(/[^a-z ]/g, " ").replace(/\s+/g, " ").trim();
// v1.9.0: satu kartu bisa punya beberapa pendaftaran PCare per hari (mis. Poli Umum lalu Ruang Tindakan).
// Status "sudah diproses" dicatat per KARTU + ANTREAN, dan kunjungan C-CARE yang sudah dipakai tidak dipilih lagi.
BR.kunciProses = (row) => `${row.kartu}|${row.antrean || ""}`;
// v3.4.4: POLI/KEGIATAN yang tidak diproses bot (Pengaturan → Poli yang dilewati). Bawaan: Konseling.
BR.POLI_KECUALI_BAWAAN = ["Konseling"];
BR.poliKecuali = async () => { const v = await BR.store.get("poliDikecualikan"); return Array.isArray(v) ? v : BR.POLI_KECUALI_BAWAAN; };
BR.cocokPoli = (poli, daftar) => { const p = String(poli || "").toUpperCase().replace(/\s+/g, " ").trim();
  return !!p && (daftar || []).some((x) => { const k = String(x || "").toUpperCase().replace(/\s+/g, " ").trim(); return k && (p === k || p.includes(k)); }); };
BR.sudahProses = (p, row) => !!p && p[BR.kunciProses(row)]?.tgl === BR.today();
BR.pathKunjungan = (u) => { try { return new URL(u, "https://c-care.ipb.ac.id").pathname.toLowerCase(); } catch (e) { return String(u || "").toLowerCase(); } };
BR.tandaiDipakai = async (url, antrean) => {
  if (!url) return;
  const key = BR.pathKunjungan(url);
  const u = (await BR.store.get("ccareDipakai")) || {};
  for (const k of Object.keys(u)) if (u[k].tgl !== BR.today()) delete u[k];
  u[key] = { tgl: BR.today(), antrean };
  await BR.store.set("ccareDipakai", u);
  const q = (await BR.store.get("ccareQueue")) || {};
  let ubah = false;
  for (const d of Object.values(q)) if (d.ccareUrl && BR.pathKunjungan(d.ccareUrl) === key) { d.dipakai = antrean; ubah = true; }
  if (ubah) await BR.store.set("ccareQueue", q);
};
BR.today = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`; };   // tanggal LOKAL (bukan UTC)
// Kemiripan nama (0..1): per kata, sama persis = 1, beda 1 huruf (kata ≥4 huruf, mis. FUTRI/PUTRI) = 0.8.
// Skor = jumlah kecocokan ÷ jumlah kata nama yang LEBIH PENDEK, dikali penalti bila panjangnya beda jauh.
BR.levenshtein = (a, b) => {
  const d = Array.from({ length: a.length + 1 }, (_, i) => [i]);
  for (let j = 1; j <= b.length; j++) d[0][j] = j;
  for (let i = 1; i <= a.length; i++) for (let j = 1; j <= b.length; j++)
    d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
  return d[a.length][b.length];
};
// v1.9.6: singkatan umum disamakan dulu (M. / Moch / Muh = Muhammad; Abd = Abdul)
const BAKU = { m: "muhammad", md: "muhammad", mhd: "muhammad", muh: "muhammad", moh: "muhammad", moch: "muhammad", mochammad: "muhammad",
  mochamad: "muhammad", mohammad: "muhammad", mohamad: "muhammad", muhamad: "muhammad", muhammmad: "muhammad", abd: "abdul" };
BR.kataNama = (s) => BR.nameKey(s).split(" ").filter(Boolean).map((w) => BAKU[w] || w);
BR.namaMirip = (x, y) => {
  const A = BR.kataNama(x), B = BR.kataNama(y);
  if (A.length && B.length && A.join(" ") === B.join(" ")) return 1;
  // v1.9.6: nama SATU kata di salah satu sistem (mis. C-CARE "Suparman", PCare "SUPARMAN BIN ...") — dulu maks. 0,7 = selalu "tidak ditemukan"
  if (A.length === 1 || B.length === 1) {
    const [s, l] = A.length === 1 ? [A[0], B] : [B[0], A];
    if (s.length >= 4 && l.some((w) => w === s || (w.length >= 5 && s.length >= 5 && BR.levenshtein(w, s) === 1))) return 0.8;
  }
  if (!A.length || !B.length) return 0;
  const gA = A.join(""), gB = B.join("");                       // spasi berbeda: "AL FATIH" = "ALFATIH"
  if (gA.length >= 6 && BR.levenshtein(gA, gB) <= (gA === gB ? 0 : 1)) return gA === gB ? 0.95 : 0.9;
  const [pendek, panjang] = A.length <= B.length ? [A, B] : [B, A];
  const pakai = new Set(); let skor = 0;
  for (const w of pendek) {
    let best = 0, bi = -1;
    panjang.forEach((v, i) => { if (pakai.has(i)) return;
      const s = v === w ? 1 : (w.length >= 4 && v.length >= 4 && BR.levenshtein(v, w) === 1) ? 0.8
        : ((w.length === 1 && v[0] === w) || (v.length === 1 && w[0] === v)) ? 0.8            // inisial: "R" = "Rizky"
        : (Math.min(w.length, v.length) >= 4 && (v.startsWith(w) || w.startsWith(v))) ? 0.75 : 0;   // awalan: "Fitri" ≈ "Fitriani"
      if (s > best) { best = s; bi = i; } });
    if (bi >= 0) pakai.add(bi); skor += best;
  }
  const kurang = panjang.length - pendek.length;               // kata tambahan di salah satu nama
  return (skor / pendek.length) * (pendek.length >= 2 ? 1 : 0.7) * (kurang > 1 ? 0.85 : 1);
};

// Kode tenaga medis di PCare (kode 6 & 7 memang tidak dipakai)
BR.DOKTER_KODE = {
  "dr. Mimi Oktafia": "1",
  "dr. Rizki Noorani Kusumastuti": "2",
  "dr. Vini Chumaira": "3",
  "dr. Agil Wahyu Wicaksono": "4",
  "dr. Wahyu Rachwaldy": "5",
  "dr. Isra Yasha Utami": "8",
  "dr. Sulpiana": "9",
};

// Dokter dari nomor antrean PCare: "A5-1" -> kode 5 -> dr. Wahyu Rachwaldy
BR.dokterDariAntrean = (antrean) => {
  const m = String(antrean || "").trim().match(/^[A-Za-z]+\s*(\d+)\s*-\s*\d+$/);
  if (!m) return { kode: null, nama: "" };
  const nama = Object.keys(BR.DOKTER_KODE).find((n) => BR.DOKTER_KODE[n] === String(parseInt(m[1], 10))) || "";
  return { kode: m[1], nama };
};

// Pilih dokter di dropdown PCare berdasarkan KODE, bukan teks nama yang mirip.
BR.pilihDokter = (sel, nama) => {
  if (!sel || sel.tagName !== "SELECT") return false;
  const kode = BR.DOKTER_KODE[nama];
  const nn = BR.norm(nama).replace(/^dr\.?\s*/, "");
  const opt =
    (kode && [...sel.options].find((o) => o.value.trim() === kode)) ||
    (kode && [...sel.options].find((o) => new RegExp("^\\s*" + kode + "\\s*[.\\-)]").test(o.text))) ||
    [...sel.options].find((o) => BR.norm(o.text).replace(/^\d+\s*[.\-)]\s*/, "").replace(/^dr\.?\s*/, "") === nn);
  if (!opt) return false;
  sel.value = opt.value;
  BR.fire(sel);
  return true;
};

BR.DOKTER = [
  "dr. Mimi Oktafia",
  "dr. Rizki Noorani Kusumastuti",
  "dr. Vini Chumaira",
  "dr. Agil Wahyu Wicaksono",
  "dr. Wahyu Rachwaldy",
  "dr. Isra Yasha Utami",
  "dr. Sulpiana",
];

// Kode ICD-10 format C-CARE (z001, r509, J06) -> format PCare (Z00.1, R50.9, J06)
// Mengembalikan daftar kode unik sesuai urutan kemunculan.
BR.icdList = (text) => {
  const out = [];
  for (const m of String(text || "").matchAll(/\b([A-Za-z])(\d{2})\.?(\d{1,2})?\b/g)) {
    const code = m[1].toUpperCase() + m[2] + (m[3] ? "." + m[3] : "");
    if (!out.includes(code)) out.push(code);
  }
  return out;
};

// ===== Riwayat Alergi: teks bebas C-CARE -> kategori PCare =====
// PCare: Makanan  = Tidak Ada | Seafood | Gandum | Susu Sapi | Kacang-Kacangan | Makanan Lain
//        Udara    = Tidak Ada | Udara Panas | Udara Dingin | Udara Kotor
//        Obat     = Tidak Ada | Antibiotik | Antiinflamasi Non Steroid | Aspirin | Kortikosteroid | Insulin | Obat-Obatan Lain
BR.ALERGI_NONE_RE = /^(-+|\.|tidak ada|tidak|tdk ada|tdk|disangkal|negatif|nihil|none|no|tidak ada alergi|belum diketahui|tidak diketahui)$/i;
const AL_RULES = {
  obat: [
    ["Aspirin", /aspirin|asetosal|asam asetil ?salisilat|\basa\b/],
    ["Antiinflamasi Non Steroid", /nsaid|oains|ains|ibuprofen|ibuprofen|mefenam|diklofenak|diclofenac|meloxicam|meloksikam|piroxicam|piroksikam|ketoprofen|naproxen|naproksen|ketorolac|ketorolak|celecoxib|metamizol|metampiron|antalgin|antiinflamasi/],
    ["Antibiotik", /antibiotik|antibiotic|amoxi|amoksi|ampisilin|ampicillin|penisilin|penicillin|sefa|cefa|cefi|cefo|cefu|ceftri|cefix|cipro|levoflox|oflox|azitro|azithro|eritro|erythro|klaritro|clarithro|kotrimoks|cotrimox|sulfa|metronidazol|tetrasiklin|tetracycline|doksisiklin|doxycycline|klindamisin|clindamycin|kloramfenikol|chloramphenicol|gentamisin|gentamicin|linkomisin|lincomycin/],
    ["Kortikosteroid", /kortikosteroid|corticosteroid|steroid|deksametason|dexamethason|metilprednisolon|methylprednisolon|prednison|hidrokortison|hydrocortison|betametason|triamsinolon/],
    ["Insulin", /insulin/],
  ],
  makanan: [
    ["Seafood", /seafood|makanan laut|udang|kepiting|rajungan|cumi|kerang|lobster|ikan laut|tongkol|tuna|ikan asin/],
    ["Gandum", /gandum|gluten|terigu|wheat/],
    ["Susu Sapi", /susu|laktosa|lactose|milk|dairy/],
    ["Kacang-Kacangan", /kacang|peanut|kedelai|soy|almond/],
  ],
  udara: [
    ["Udara Panas", /udara panas|panas|cuaca panas/],
    ["Udara Dingin", /udara dingin|dingin|cuaca dingin|ac\b/],
    ["Udara Kotor", /udara kotor|debu|asap|polusi|dust|serbuk|tungau/],
  ],
};
// return { makanan:[], udara:[], obat:[], kosong:bool, belumTerbaca:bool }
BR.alergiKategori = (teks) => {
  const t = BR.norm(teks).replace(/^alergi\s*:?\s*/, "");
  const out = { makanan: [], udara: [], obat: [], kosong: false, belumTerbaca: false };
  if (!t || BR.ALERGI_NONE_RE.test(t)) { out.kosong = true; return out; }
  for (const [grp, rules] of Object.entries(AL_RULES))
    for (const [kat, re] of rules) if (re.test(t) && !out[grp].includes(kat)) out[grp].push(kat);
  const kenal = out.makanan.length + out.udara.length + out.obat.length;
  if (!kenal) {
    // ada isi tapi tak dikenal: tebak kelompok dari kata kunci umum
    if (/obat|tablet|sirup|salep|injeksi|suntik/.test(t)) out.obat.push("Obat-Obatan Lain");
    else if (/makan|telur|ayam|daging|buah|coklat|cokelat|mie/.test(t)) out.makanan.push("Makanan Lain");
    else out.belumTerbaca = true;
  }
  return out;
};

BR.imt = (bb, tbCm) => {
  const b = parseFloat(bb), t = parseFloat(tbCm) / 100;
  return b && t ? (b / (t * t)).toFixed(2) : "";
};

// Salin daftar label + atribut field (id/name/placeholder), TANPA nilai isian,
// supaya selector bisa dikunci tanpa mengirim data pasien.
BR.copyStructure = async function () {
  const out = ["URL: " + location.pathname, ""];
  // termasuk field di tab yang sedang tersembunyi (ditandai [tersembunyi])
  const ctrls = [...document.querySelectorAll("input:not([type=hidden]), select, textarea")]
    .filter((el) => !el.closest("#br-panel, #rkm-panel") && (el.id || el.name));
  ctrls.forEach((el, i) => {
    let lab = "";
    if (el.id) lab = document.querySelector(`label[for="${CSS.escape(el.id)}"]`)?.textContent || "";
    if (!lab) {
      let n = el;
      for (let k = 0; k < 4 && n && !lab; k++) {
        let s = n.previousElementSibling;
        while (s && !lab) { lab = s.textContent.trim(); s = s.previousElementSibling; }
        n = n.parentElement;
      }
    }
    const tab = el.closest(".tab-pane, [role=tabpanel]");
    const where = (BR.visible(el) ? "" : " [tersembunyi]") + (tab && tab.id ? ` tab=#${tab.id}` : "");
    out.push(`${i + 1}.${where} [${el.tagName.toLowerCase()}${el.type ? ":" + el.type : ""}] label="${BR.norm(lab).slice(0, 40)}" id="${el.id}" name="${el.name || ""}" placeholder="${el.placeholder || ""}"`);
  });
  out.push("", "TOMBOL / LINK:");
  [...document.querySelectorAll("button, input[type=button], input[type=submit], a.btn, a[onclick], [role=button]")]
    .filter((b) => !b.closest("#br-panel, #rkm-panel"))
    .forEach((b, i) => {
      const t = BR.norm(b.textContent || b.value || b.title || "").slice(0, 30);
      if (!t && !b.id) return;
      out.push(`B${i + 1}.${BR.visible(b) ? "" : " [tersembunyi]"} <${b.tagName.toLowerCase()}> teks="${t}" id="${b.id}" class="${(b.className || "").toString().slice(0, 40)}" onclick="${(b.getAttribute("onclick") || "").slice(0, 50)}" href="${(b.getAttribute("href") || "").slice(0, 60)}"`);
    });
  out.push("", "LABEL TAMPILAN (teks pendek):");
  const labels = [...document.querySelectorAll("label, th, dt, b, strong")]
    .filter((e) => !e.closest("#br-panel, #rkm-panel"))
    .map((e) => BR.norm(e.textContent))
    .filter((t) => t && t.length < 40 && !/\d{6,}/.test(t));
  out.push([...new Set(labels)].join(" | "));
  const text = out.join("\n");
  try { await navigator.clipboard.writeText(text); }
  catch (e) {
    const ta = document.createElement("textarea"); ta.value = text; document.body.appendChild(ta);
    ta.select(); document.execCommand("copy"); ta.remove();
  }
  ["br-log", "rkm-log"].forEach((id) => { const el = document.getElementById(id); if (el) el.innerHTML =
    `<div class="br-ok rkm-ok">✓ Struktur disalin (${ctrls.length} field). Tempel (Ctrl+V) ke chat Claude.</div>`; });
}



// =====================================================================
// v2.0.0 — aplikasi Windows: LOG ke file (disamarkan) & LOGIN OTOMATIS
// =====================================================================
BR.VERSI = (() => { try { return chrome.runtime.getManifest().version; } catch (e) { return "?"; } })();
// Nama pasien yang dikenali bot disamarkan jadi inisial; angka panjang (No. Kartu, NIK, telepon) jadi ****1234
BR.namaRahasia = new Set();
BR.ingatNama = (n) => { n = String(n || "").replace(/\s+/g, " ").trim(); if (n.length >= 3 && /[a-z]/i.test(n)) BR.namaRahasia.add(n); };
const reEsc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
BR.samarkan = (s) => {
  s = String(s ?? "");
  for (const n of [...BR.namaRahasia].sort((a, b) => b.length - a.length)) {
    const ini = n.split(/[\s.,]+/).filter(Boolean).map((w) => w[0].toUpperCase() + ".").join("");
    s = s.replace(new RegExp("(?<!\\p{L})" + reEsc(n) + "(?!\\p{L})", "giu"), ini);   // v3.4.6: utuh per kata (dulu "Setelah" → "SetE.h")
  }
  return s.replace(/(?<!\d)(\d{9,16})(?!\d)/g, (m) => "*".repeat(m.length - 4) + m.slice(-4));
};
BR.jamLog = () => { const d = new Date(), p = (x) => String(x).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`; };
BR.keFile = (sumber, tingkat, pesan) => {
  try { chrome.runtime.sendMessage({ type: "logFile", baris: [`${BR.jamLog()} [${sumber} v${BR.VERSI}] ${tingkat} ${BR.samarkan(pesan)}`] }); } catch (e) {}
};
BR.keHost = (pesan) => new Promise((res) => { try { chrome.runtime.sendMessage({ type: "host", pesan }, (r) => res(r || { ok: false, pesan: "tidak ada jawaban" })); } catch (e) { res({ ok: false, pesan: String(e) }); } });
// galat JavaScript ikut tercatat
BR.pasangPencatatGalat = (sumber) => {
  window.addEventListener("error", (e) => BR.keFile(sumber, "ERROR", `${e.message} @ ${String(e.filename || "").split("/").pop()}:${e.lineno}`));
  window.addEventListener("unhandledrejection", (e) => BR.keFile(sumber, "ERROR", "promise: " + (e.reason && (e.reason.stack || e.reason.message) || e.reason)));
};

// ---------- LOGIN OTOMATIS ----------
// Nama pengguna & password diambil dari aplikasi Windows (terenkripsi DPAPI), diisi ke form login, lalu tombol Masuk diklik.
// Captcha / kotak Cloudflare TIDAK dikerjakan bot: bot menunggu Anda mengisinya. Maks. 2 percobaan per 10 menit (cegah akun terkunci).
BR.turnstileBelumLolos = () => {
  const tok = document.querySelector("input[name='cf-turnstile-response']");
  const widget = document.querySelector(".cf-turnstile, iframe[src*='challenges.cloudflare.com']") || tok;
  return !!widget && !!tok && !tok.value;
};
BR.formLogin = () => {
  // v2.1.0: PCare memakai id acak (username_xxxx / password_xxxx) dan kotak password bertipe "text";
  // C-CARE memakai #Username / #Password biasa. Keduanya dikenali.
  const terlihat = (e) => e && BR.visible(e) && !e.closest(BR.UI_SENDIRI);
  const cari = (sel) => [...document.querySelectorAll(sel)].find(terlihat);
  const pw = cari("input[type=password]") ||
    cari("input[id^='password' i], input[name^='password' i], input[placeholder='password' i], input[placeholder^='kata sandi' i]");
  if (!pw) return null;
  const form = pw.form || pw.closest("form") || pw.closest(".card, .panel, .login-box, .container") || document.body;
  const isian = [...form.querySelectorAll("input")].filter((i) => terlihat(i) && i !== pw && !/^(hidden|password|checkbox|radio|submit|button|image|file)$/i.test(i.type));
  const captcha = cari("#CaptchaInputTextLogin") ||
    isian.find((i) => /captcha|kode keamanan|security|verif/i.test(`${i.name} ${i.id} ${i.placeholder}`));
  const user = cari("input[id^='username' i], input[name^='username' i], input[placeholder='username' i], input#Username") ||
    isian.find((i) => i !== captcha);
  const tombol = cari("#btnLogin") || form.querySelector("button[type=submit], input[type=submit]") ||
    [...form.querySelectorAll("button, input[type=button], a.btn")].find((b) => terlihat(b) && /masuk|login|log in|sign in/i.test(b.textContent || b.value || ""));
  return { pw, form, user: user === pw ? null : user, captcha, tombol };
};
BR.kunciLogin = async (situs) => {   // satu tab saja yang login (tab latar C-CARE dibuka bersamaan)
  const k = (await BR.store.get("loginKunci_" + situs)) || {};
  if (k.at && Date.now() - k.at < 60000) return false;
  await BR.store.set("loginKunci_" + situs, { at: Date.now() });
  return true;
};
BR.lepasKunciLogin = (situs) => BR.store.set("loginKunci_" + situs, {});
BR.loginSedang = async (situs) => { const k = (await BR.store.get("loginKunci_" + situs)) || {}; return !!(k.at && Date.now() - k.at < 60000); };
// v3.0.6: login otomatis TIDAK memaksa.
// - Di halaman yang terlihat: hitung mundur 5 detik dengan tombol [Login sekarang] dan [×] (batal).
// - Gagal sekali (kembali ke halaman login / tetap di halaman login) → login otomatis DIJEDA sampai Anda
//   klik [Coba lagi], menyimpan ulang password, atau berhasil masuk manual. Tidak ada lagi percobaan beruntun
//   yang membuat akun harus menunggu beberapa menit.
const JEDA_GAGAL = 3 * 60000;
const namaSitus = (s) => (s === "pcare" ? "PCare" : "C-CARE");
BR.jedaLogin = async (situs, alasan) => {
  await BR.store.set("loginDijeda_" + situs, { at: Date.now(), alasan });
  BR.keFile(situs.toUpperCase(), "PERINGATAN", "login otomatis dijeda: " + alasan);
};
BR.loginOtomatis = async (situs, kabar, opsi = {}) => {
  const f = BR.formLogin(); if (!f) return "bukan-login";
  if (!(await BR.store.get("autoLogin_" + situs))) return "mati";
  if (!f.user) return "form-tak-dikenal";
  const kotak = !!opsi.kotak;
  const tampil = (teks, tombol) => { if (kotak) BR.kabarLogin(teks, tombol); else if (kabar) kabar(teks); };
  // v3.4.1: mode "Isi saja" — nama pengguna & password diisi, tombol Masuk TIDAK diklik (petugas yang klik)
  if ((await BR.store.get("loginKlik_" + situs)) === false) {
    if (!kotak && !opsi.paksa) return "isi-saja-latar";   // jendela latar bot tidak bisa diklik petugas
    const r = await BR.keHost({ cmd: "kredAmbil", situs });
    if (!r.ok) { tampil("Isi otomatis: " + (r.tanpaHost ? "bagian aplikasi belum terhubung" : r.pesan)); return "tanpa-kred"; }
    const g = BR.formLogin() || f;
    BR.setValue(g.user, r.user); BR.setValue(g.pw, r.pass);
    r.pass = ""; r.user = "";
    (g.captcha && !g.captcha.value ? g.captcha : g.tombol || g.pw).focus();
    tampil(`Nama pengguna & password ${namaSitus(situs)} sudah diisi. Centang Cloudflare bila ada, lalu klik Masuk.`);
    BR.keFile(situs.toUpperCase(), "INFO", "isi otomatis: nama pengguna & password diisi, Masuk diklik petugas");
    return "isi-saja";
  }
  const coba = ((await BR.store.get("loginCoba_" + situs)) || []).filter((t) => Date.now() - t < 600000);
  // percobaan terakhir belum lama, tetapi kita kembali di halaman login → anggap gagal (password salah / ditolak)
  const terakhir = coba.length ? coba[coba.length - 1] : 0;
  if (!opsi.paksa && terakhir && Date.now() - terakhir < JEDA_GAGAL && !(await BR.store.get("loginDijeda_" + situs)))
    await BR.jedaLogin(situs, "kembali ke halaman login sesudah percobaan otomatis (password salah atau ditolak)");
  const jeda = await BR.store.get("loginDijeda_" + situs);
  if (jeda && jeda.at && !opsi.paksa) {
    const ulang = async () => { await BR.store.set("loginDijeda_" + situs, null); await BR.store.set("loginCoba_" + situs, []);
      BR.loginOtomatis(situs, kabar, { ...opsi, paksa: true }); };
    tampil(`Login otomatis ${namaSitus(situs)} dihentikan: percobaan terakhir gagal. Periksa password di Pengaturan, atau login manual.`,
      kotak ? [["Coba lagi", ulang]] : []);
    return "dijeda";
  }
  if (coba.length >= 2 && !opsi.paksa) { tampil("Login otomatis dihentikan: sudah 2× dicoba dalam 10 menit. Login manual dulu (cek password di Pengaturan)."); BR.keFile(situs.toUpperCase(), "PERINGATAN", "login otomatis: batas percobaan"); return "batas"; }
  // hitung mundur di halaman yang terlihat: Anda bisa membatalkan
  if (kotak && !opsi.paksa) {
    const putusan = await new Promise((res) => {
      let n = 5, t = null;
      const tulis = () => BR.kabarLogin(`Login otomatis ${namaSitus(situs)} dalam ${n} detik…`, [["Login sekarang", () => { clearInterval(t); res("ya"); }]], () => { clearInterval(t); res("batal"); });
      tulis();
      t = setInterval(() => { n--; if (n <= 0) { clearInterval(t); res("ya"); } else tulis(); }, 1000);
    });
    if (putusan === "batal") { BR.kabarLogin(`Login otomatis ${namaSitus(situs)} dibatalkan. Silakan login manual.`, [["Login otomatis", () => BR.loginOtomatis(situs, kabar, { ...opsi, paksa: true })]]); BR.keFile(situs.toUpperCase(), "INFO", "login otomatis dibatalkan pengguna"); return "dibatalkan"; }
    if (!BR.formLogin()) return "bukan-login";
  }
  const r = await BR.keHost({ cmd: "kredAmbil", situs });
  if (!r.ok) { tampil("Login otomatis: " + (r.tanpaHost ? "bagian aplikasi belum terhubung" : r.pesan)); BR.keFile(situs.toUpperCase(), "PERINGATAN", "login otomatis: " + r.pesan); return "tanpa-kred"; }
  const g = BR.formLogin() || f;
  BR.setValue(g.user, r.user); BR.setValue(g.pw, r.pass);
  r.pass = ""; r.user = "";
  if (g.captcha && !g.captcha.value) { g.captcha.focus(); tampil("Nama pengguna & password sudah diisi. Ketik kode captcha, lalu tekan Enter / klik Sign In."); BR.keFile(situs.toUpperCase(), "INFO", "login otomatis: menunggu captcha diisi manusia"); return "isi-captcha"; }
  // tunggu widget Cloudflare selesai dimuat (PCare: #CaptchaMode = turnstile) sebelum memeriksa tokennya
  const modeTurnstile = () => /turnstile/i.test((document.querySelector("#CaptchaMode") || {}).value || "") || !!document.querySelector(".cf-turnstile");
  for (let i = 0; i < 20 && modeTurnstile() && !document.querySelector("input[name='cf-turnstile-response']"); i++) await BR.sleep(500);
  let batalCf = false;
  if (BR.turnstileBelumLolos()) { tampil("Centang kotak Cloudflare; bot klik Masuk sesudahnya.", []);
    if (kotak) BR.kabarLogin("Centang kotak Cloudflare; bot klik Masuk sesudahnya.", [], () => { batalCf = true; });
    for (let i = 0; i < 360 && BR.turnstileBelumLolos() && !batalCf; i++) await BR.sleep(500); }
  if (batalCf) { BR.kabarLogin(`Login otomatis ${namaSitus(situs)} dibatalkan.`); return "dibatalkan"; }
  if (BR.turnstileBelumLolos()) { BR.keFile(situs.toUpperCase(), "PERINGATAN", "login otomatis: Cloudflare belum lolos 3 menit"); return "turnstile"; }
  await BR.store.set("loginCoba_" + situs, coba.concat(Date.now()));
  const btn = g.tombol;
  BR.keFile(situs.toUpperCase(), "INFO", "login otomatis: form diisi, tombol Masuk diklik");
  if (kotak) BR.kabarLogin(`Login ${namaSitus(situs)} dikirim…`);
  if (btn) btn.click(); else if (g.form.requestSubmit) g.form.requestSubmit();
  // halaman tidak berpindah (mis. PCare menolak lewat pesan) → gagal: jeda, jangan dicoba lagi otomatis
  setTimeout(async () => {
    if (BR.formLogin() && (await BR.store.get("autoLogin_" + situs))) {
      await BR.jedaLogin(situs, "masih di halaman login 15 detik sesudah tombol Masuk diklik (password salah atau ditolak)");
      if (kotak) BR.kabarLogin(`Login ${namaSitus(situs)} gagal. Login otomatis dihentikan — periksa password di Pengaturan, atau login manual.`);
    }
  }, 15000);
  return "dikirim";
};
// kotak kabar kecil di halaman login: teks + tombol + [×]
BR.kabarLogin = (teks, tombol = [], saatTutup = null) => {
  let k = document.getElementById("br-kabar-login");
  if (!k) { k = document.createElement("div"); k.id = "br-kabar-login"; document.body.appendChild(k); }
  k.hidden = false;
  k.textContent = "";
  const t = document.createElement("span"); t.className = "br-kl-teks"; t.textContent = "Alvisya Bridging PCare: " + teks; k.appendChild(t);
  const baris = document.createElement("span"); baris.className = "br-kl-tombol";
  for (const [label, aksi] of tombol) { const b = document.createElement("button"); b.type = "button"; b.textContent = label; b.onclick = (e) => { e.preventDefault(); aksi(); }; baris.appendChild(b); }
  const x = document.createElement("button"); x.type = "button"; x.className = "br-kl-x"; x.title = "Tutup / batalkan login otomatis"; x.setAttribute("aria-label", "Tutup"); x.textContent = "×";
  x.onclick = (e) => { e.preventDefault(); k.hidden = true; if (saatTutup) saatTutup(); if (BR.diAplikasi) BR.store.set("kabarLogin_" + BR.situsIni(), null); };
  baris.appendChild(x);
  k.appendChild(baris);
  // v3.2.0: di aplikasi, kotak ini tampil di pita atas aplikasi (tidak menutupi halaman); tombolnya diteruskan lewat "klikKabar"
  if (BR.diAplikasi) {
    k.classList.add("br-jauh");
    BR._kabarAksi = { tombol, tutup: () => x.click() };
    BR.store.set("kabarLogin_" + BR.situsIni(), { teks, tombol: tombol.map((t) => t[0]), at: Date.now() });
  }
};
// v3.2.0: jalan di dalam aplikasi Alvisya Bridging PCare (bukan ekstensi Chrome)
BR.diAplikasi = !!(typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.id === "bridging-pcare");
BR.situsIni = () => (/pcare/i.test(location.hostname) ? "pcare" : "ccare");
if (BR.diAplikasi && chrome.storage && chrome.storage.onChanged) chrome.storage.onChanged.addListener((ch) => {
  const v = ch.klikKabar && ch.klikKabar.newValue;
  if (!v || v.situs !== BR.situsIni() || !BR._kabarAksi || Date.now() - (v.at || 0) > 15000) return;
  const k = document.getElementById("br-kabar-login");
  if (!k || k.hidden) return;
  if (v.tombol === "×") return BR._kabarAksi.tutup();
  const t = BR._kabarAksi.tombol.find((x) => x[0] === v.tombol);
  if (t) t[1]();
});
