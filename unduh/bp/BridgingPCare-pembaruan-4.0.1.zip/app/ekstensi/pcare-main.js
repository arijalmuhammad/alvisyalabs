// ===== Berjalan di dunia HALAMAN PCare (bukan dunia ekstensi) =====
// Hanya menangani window.alert = pemberitahuan dengan satu tombol OK (mis. "Peserta Berpotensi Menderita
// Penyakit Diabetes Melitus dan/atau Hipertensi ..."), dan HANYA saat bot sedang menyimpan.
// Isi pesan diteruskan ke panel bot (dicatat di Aktivitas), lalu halaman berjalan seperti setelah OK diklik.
// confirm()/prompt() (dialog KEPUTUSAN, mis. "Apakah Anda akan tetap melayani?") TIDAK disentuh.
(() => {
  const asli = window.alert;
  window.alert = function (pesan) {
    const html = document.documentElement;
    if (html && html.dataset.brSimpan === "1") {
      html.dataset.brAlert = String(pesan ?? "");
      html.dispatchEvent(new Event("br-alert"));
      return undefined;
    }
    return asli.apply(this, arguments);
  };
})();

// v1.9.4: tampilkan SEMUA baris tabel Riwayat Pendaftaran dalam satu halaman.
// Tabel PCare = DataTables server-side 15 baris/halaman dan urutan barisnya tidak tetap, sehingga membaca
// halaman 1, 2, 3 bergantian bisa melewatkan pasien. Di sini panjang halaman diperbesar lewat API DataTables
// (hanya tampilan; tidak mengubah data). Diminta oleh panel bot lewat event "br-perbesar-antrean".
document.addEventListener("br-perbesar-antrean", () => {
  const html = document.documentElement;
  const tulis = (v) => { html.dataset.brPerbesar = v; };
  try {
    const $ = window.jQuery;
    if (!$ || !$.fn || !$.fn.dataTable) return tulis("tidak:datatables");
    const tb = document.getElementById("example") ||
      [...document.querySelectorAll("table")].find((t) => $.fn.dataTable.isDataTable(t) && /status/i.test(t.tHead ? t.tHead.textContent : ""));
    if (!tb || !$.fn.dataTable.isDataTable(tb)) return tulis("tidak:tabel");
    const dt = $(tb).DataTable(), info = dt.page.info();
    const n = Math.max(100, info.recordsTotal || 0);
    if (info.pages <= 1 && dt.page.len() >= (info.recordsTotal || 0)) return tulis("ok:" + info.recordsTotal);
    if (!html.dataset.brLenAsli) html.dataset.brLenAsli = String(dt.page.len());
    dt.one("draw", () => tulis("ok:" + dt.page.info().recordsTotal + ":" + dt.page.info().pages));
    dt.page.len(n).draw();
  } catch (e) { tulis("galat:" + e); }
});
// Server menolak memberi semua baris sekaligus → kembalikan panjang halaman asli supaya bot bisa membuka halaman satu per satu
document.addEventListener("br-kembalikan-antrean", () => {
  const html = document.documentElement;
  try {
    const $ = window.jQuery, tb = document.getElementById("example");
    const asli = +(html.dataset.brLenAsli || 15);
    if ($ && tb && $.fn.dataTable.isDataTable(tb)) { const dt = $(tb).DataTable(); dt.one("draw", () => { html.dataset.brKembali = "ok"; }); dt.page.len(asli).draw(); }
    else html.dataset.brKembali = "tidak";
  } catch (e) { html.dataset.brKembali = "galat"; }
});

// v3.4.5: jawaban server saat Sign In. Halaman login PCare DIAM untuk banyak penolakan (selain kode 427/428 tidak
// ada pesan; Cloudflare langsung diulang). Di sini hanya kode + pesan jawaban yang diteruskan ke bot supaya
// petugas tahu alasannya. Isi permintaan (nama pengguna, password, token) TIDAK dibaca dan tidak diteruskan.
(() => {
  if (!/\/eclaim\/login/i.test(location.pathname)) return;
  const X = XMLHttpRequest.prototype, buka = X.open, kirim = X.send;
  X.open = function (m, url) { this.__brLogin = /\/login\/login(\?|$)/i.test(String(url || "")); return buka.apply(this, arguments); };
  X.send = function () {
    if (this.__brLogin) this.addEventListener("loadend", () => {
      let kode = "", pesan = "";
      try { const j = JSON.parse(this.responseText); kode = String(j?.metaData?.code ?? ""); pesan = String(j?.metaData?.message ?? ""); } catch (e) {}
      const html = document.documentElement;
      html.dataset.brLoginJawab = JSON.stringify({ http: this.status, kode, pesan: pesan.slice(0, 240), waf: this.getResponseHeader("X-PCare-Turnstile-Failed") === "1" });
      html.dispatchEvent(new Event("br-login-jawab"));
    });
    return kirim.apply(this, arguments);
  };
})();

// v3.4.7: di halaman tanpa #pcare-turnstile-slot, PCare memakai Turnstile mode 'execute': challenge baru
// dijalankan saat token pertama kali dibutuhkan, jadi kotak Cloudflare tidak pernah muncul selama bot menunggu.
// Bot meminta PCare menjalankan challenge-nya sendiri (sama seperti saat petugas menekan Cari). Bila Cloudflare
// butuh centang, kotaknya tampil untuk petugas; bot tidak mencentangnya.
document.documentElement.addEventListener("br-turnstile-mulai", () => {
  try { if (window.PCareTurnstile && !document.getElementById("pcare-turnstile-slot")) window.PCareTurnstile.isiKolam(); } catch (e) {}
});
