/* Siap dipanggil — memberi tahu dokter saat pasien pindah ke "Menunggu Pemeriksaan Dokter"
 * (perawat selesai menyimpan pengkajian). Hanya MEMBACA daftar poli & ringkasan kunjungan; tidak membuka Ubah,
 * tidak menekan Simpan, tidak mengirim data ke mana pun. Status tersimpan lokal (hari ini saja), log tanpa nama pasien.
 * Berjalan tiap ±30 detik hanya bila sakelar aktif, jam 06–22 WIB, dan ada tab C-CARE terbuka (sudah login). */
const PANTAU_POLI_BAWAAN = [1, 5, 8, 4, '4mcu'];
/* '4mcu' BUKAN JenisPoliId C-CARE tersendiri — Kunjungan Sehat & MCU sama-sama poli 4, dibedakan lewat tautan "Periksa"
 * tiap baris: /Poli/Ubah/… (Kunjungan Sehat, dibaca Auto Fill) vs /Poli/Mcu/… (MCU, formnya sendiri, belum didukung Auto Fill).
 * Dipisah di sini supaya "Siap dipanggil" bisa dinyalakan/dimatikan sendiri-sendiri untuk tiap jenis kunjungan. */
const SEMUA_POLI = [1, 5, 8, 4, '4mcu', 2, 'kia', 7];
/** aturan per poli {id: {notif, bunyi, cepat}} — dari 'pantauPer', atau diturunkan dari pengaturan lama (v2.9.0–2.9.3) */
function aturanPer(s) {
  if (s.pantauPer && typeof s.pantauPer === 'object') {
    const o = s.pantauPer;
    if (o[4] && !o['4mcu']) o['4mcu'] = Object.assign({}, o[4]);    // migrasi: MCU baru dipisah dari Kunjungan Sehat — warisi pengaturan lama, jangan tiba-tiba mati
    return o;
  }
  const lama = Array.isArray(s.pantauPoli) && s.pantauPoli.length ? s.pantauPoli.map(String) : PANTAU_POLI_BAWAAN.map(String), o = {};
  SEMUA_POLI.forEach(id => { const on = s.pantauSiap !== false && (lama.includes(String(id)) || (id === '4mcu' && lama.includes('4'))); o[id] = { notif: on, bunyi: on && s.pantauBunyi !== false, cepat: on && id === 1 }; });
  return o;
}
async function bacaAturan() {
  const s = await chrome.storage.local.get(['pantauPer', 'pantauSiap', 'pantauPoli', 'pantauBunyi', 'isiCepat', 'grupPoli']);
  const sembunyi = s.grupPoli || {};                                   // Atur gabungan → Sembunyikan: poli tidak dibaca/dipantau
  const mati = !!(s.isiCepat && s.isiCepat.mati);                       // sakelar utama Auto Fill: Mati = tidak membaca C-CARE sama sekali
  const per = aturanPer(s), ids = mati ? [] : SEMUA_POLI.filter(id => per[id] && per[id].notif && sembunyi[id] !== 'X');
  return { per, poli: ids, cepat: ids.filter(id => per[id].cepat && id !== 'kia'), aktif: ids.length > 0, mati };
}

/* ---------- dijalankan DI tab C-CARE (chrome.scripting) — harus mandiri ---------- */
/* Kedua fungsi di bawah dijalankan di tab C-CARE. Prinsip: tab utama tidak boleh terganggu —
 *  - bila Anda sedang memakai tab ini (klik/ketik/gulir < 4 dtk, tab terlihat) → tidak membaca, kembalikan {sibuk}
 *  - fetch berprioritas rendah, dibatalkan saat Anda pindah halaman / menekan Simpan (aktivitas.js)
 *  - HTML dibaca dengan teks biasa (tanpa membangun DOM) → tidak membebani halaman */
async function ambilAntrean(tanggal, poliIds, pulih, paksa, asal = '') {
  const DOK = typeof document !== 'undefined', G = globalThis;
  if (!paksa && DOK && document.visibilityState === 'visible' && Date.now() - (window.__sjcAktif || 0) < 4000) return { sibuk: true };
  const ENT = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ' };
  const bersih = h => String(h).replace(/<[^>]*>/g, ' ').replace(/&(#x?[0-9a-f]+|[a-z]+);/gi, (m, e) => e[0] === '#' ? String.fromCodePoint(e[1].toLowerCase() === 'x' ? parseInt(e.slice(2), 16) : +e.slice(1)) : (ENT[e.toLowerCase()] ?? m)).replace(/\s+/g, ' ').trim();
  const tokenDari = h => (h.match(/name=["']__RequestVerificationToken["'][^>]*value=["']([^"']+)/i) || h.match(/value=["']([^"']+)["'][^>]*name=["']__RequestVerificationToken/i) || [])[1];
  let TM = {}; try { TM = (await chrome.storage.local.get('tandaMcu')).tandaMcu || {}; } catch (e) {}   // kunjungan MCU (dialihkan ke /Poli/Mcu/), dikenali daftar-ringkas
  const ctl = new AbortController(); (G.__sjcCtrl = G.__sjcCtrl || new Set()).add(ctl);
  const ambil = (url, opsi) => fetch(asal + url, Object.assign({ credentials: 'include', cache: 'no-store', priority: 'low', signal: ctl.signal }, opsi));
  try {
    let token = (DOK && (document.querySelector('input[name=__RequestVerificationToken]') || {}).value) || G.__sjcToken;
    if (!token) { const h = await (await ambil('/Poli/Index/1')).text(); if (/type=["']?password/i.test(h)) return { login: true }; token = G.__sjcToken = tokenDari(h); }
    if (!token) return { login: true };
    const t0 = performance.now();
    const satu = async id => {
      const kia = id === 'kia', nyata = id === '4mcu' ? 4 : id;
      const q = new URLSearchParams(kia ? { Tanggal: tanggal, __Invariant: '', StatusKunjunganId: '', __RequestVerificationToken: token }
        : { JenisPoliId: nyata, Tanggal: tanggal, __Invariant: '', StatusKunjunganId: '', __RequestVerificationToken: token });
      const html = await (await ambil(kia ? '/Kia' : '/Poli/Index/' + nyata, { method: 'POST', body: q })).text();
      const i = html.indexOf(kia ? 'datatable-kia' : 'datatable-poli');
      if (i < 0) return /type=["']?password/i.test(html) ? 'login' : 'galat';
      const tabel = html.slice(i, html.indexOf('</table>', i)), tbody = (tabel.match(/<tbody[\s\S]*?<\/tbody>/i) || [''])[0];
      const k = kia ? { rm: 2, pasien: 3, status: 4 } : { rm: 3, pasien: 4, status: 5 }, out = [];
      for (const m of tbody.matchAll(/<tr\b[\s\S]*?<\/tr>/gi)) {
        const tr = m[0], det = (tr.match(/\/RekapRekamMedis\/Detail\/(\d+)/i) || [])[1]; if (!det) continue;
        const sel = [...tr.matchAll(/<td\b[^>]*>([\s\S]*?)<\/td>/gi)].map(x => x[1]); if (sel.length < 6) continue;
        const tUbah = (tr.match(/href=["']([^"']*\/Ubah\/\d+)/i) || [])[1] || '', tMcu = (tr.match(/href=["']([^"']*\/Mcu\/\d+)/i) || [])[1] || '';
        const mcu = !!tMcu || TM[(tUbah.match(/(\d+)$/) || [])[1]] === 1;
        if (nyata === 4 && (id === '4mcu') !== mcu) continue;       // poli 4: pisahkan baris Kunjungan Sehat dari MCU
        const ubah = tUbah || tMcu;
        /* kunjungan dibatalkan (batal berobat): C-CARE menghapus tombol Ubah & Batalkan, status tetap "Menunggu …" → bukan antrean */
        out.push({ poli: id, kunjungan: det, ubah, jam: (bersih(sel[kia ? 1 : 2]).match(/(\d{1,2})[.:](\d{2})(?:[.:]\d{2})?\s*$/) || []).slice(1, 3).join('.'), rm: bersih(sel[k.rm]), pasien: bersih(sel[k.pasien]), status: ubah || kia ? bersih(sel[k.status]) : 'Batal berobat' });
      }
      return out;
    };
    let semua;
    try { semua = await Promise.all(poliIds.map(id => satu(id).catch(e => e && e.name === 'AbortError' ? 'batal' : 'galat'))); }
    finally {                     // C-CARE menyimpan filter terakhir (Tanggal + Status) di sesi server, dipakai juga oleh tab dokter →
      const st = pulih ? pulih.st || '' : '', tgl = pulih ? pulih.tgl || tanggal : tanggal;    // kembalikan ke pilihan dokter (lewat Poli Gizi: jawaban kecil)
      if (pulih && !(st === '' && tgl === tanggal)) try { await fetch(asal + '/Poli/Index/7', { method: 'POST', credentials: 'include', cache: 'no-store', priority: 'low',
        body: new URLSearchParams({ JenisPoliId: 7, Tanggal: tgl, __Invariant: '', StatusKunjunganId: st, __RequestVerificationToken: token }) }); } catch (e) {}
    }
    if (semua.includes('batal')) return { batal: true };
    if (semua.includes('login')) { G.__sjcToken = null; return { login: true }; }
    return { baris: [].concat(...semua.filter(Array.isArray)), galat: semua.filter(x => x === 'galat').length, ms: Math.round(performance.now() - t0) };
  } catch (e) { return e && e.name === 'AbortError' ? { batal: true } : { galat: 1 }; }
  finally { G.__sjcCtrl.delete(ctl); }
}
/** cepat: hanya pasien "Menunggu Pemeriksaan Dokter" (filter C-CARE StatusKunjunganId=3, ±18 KB, ±0,4 dtk) — semua poli SEKALIGUS */
async function bacaDokter(tanggal, polis, pulih, paksa, asal = '') {
  const DOK = typeof document !== 'undefined', G = globalThis;
  if (!paksa && DOK && document.visibilityState === 'visible' && Date.now() - (window.__sjcAktif || 0) < 4000) return { sibuk: true };
  const ENT = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ' };
  const bersih = h => String(h).replace(/<[^>]*>/g, ' ').replace(/&(#x?[0-9a-f]+|[a-z]+);/gi, (m, e) => e[0] === '#' ? String.fromCodePoint(e[1].toLowerCase() === 'x' ? parseInt(e.slice(2), 16) : +e.slice(1)) : (ENT[e.toLowerCase()] ?? m)).replace(/\s+/g, ' ').trim();
  const tokenDari = h => (h.match(/name=["']__RequestVerificationToken["'][^>]*value=["']([^"']+)/i) || h.match(/value=["']([^"']+)["'][^>]*name=["']__RequestVerificationToken/i) || [])[1];
  let TM = {}; try { TM = (await chrome.storage.local.get('tandaMcu')).tandaMcu || {}; } catch (e) {}   // kunjungan MCU (dialihkan ke /Poli/Mcu/), dikenali daftar-ringkas
  const ctl = new AbortController(); (G.__sjcCtrl = G.__sjcCtrl || new Set()).add(ctl);
  const ambil = (url, opsi) => fetch(asal + url, Object.assign({ credentials: 'include', cache: 'no-store', priority: 'low', signal: ctl.signal }, opsi));
  try {
    let token = (DOK && (document.querySelector('input[name=__RequestVerificationToken]') || {}).value) || G.__sjcToken;
    if (!token) { const h = await (await ambil('/Poli/Index/1')).text(); if (/type=["']?password/i.test(h)) return { login: true }; token = G.__sjcToken = tokenDari(h); if (!token) return { login: true }; }
    const satu = async poli => {
      const nyata = poli === '4mcu' ? 4 : poli;
      const html = await (await ambil('/Poli/Index/' + nyata, { method: 'POST', body: new URLSearchParams({ JenisPoliId: nyata, Tanggal: tanggal, __Invariant: '', StatusKunjunganId: '3', __RequestVerificationToken: token }) })).text();
      const i = html.indexOf('datatable-poli');
      if (i < 0) return /type=["']?password/i.test(html) ? 'login' : 'galat';
      const tbody = (html.slice(i, html.indexOf('</table>', i)).match(/<tbody[\s\S]*?<\/tbody>/i) || [''])[0], baris = [];
      for (const m of tbody.matchAll(/<tr\b[\s\S]*?<\/tr>/gi)) {
        const tr = m[0], det = (tr.match(/\/RekapRekamMedis\/Detail\/(\d+)/i) || [])[1]; if (!det) continue;
        const sel = [...tr.matchAll(/<td\b[^>]*>([\s\S]*?)<\/td>/gi)].map(x => x[1]); if (sel.length < 6) continue;
        const status = bersih(sel[5]); if (!/menunggu pemeriksaan dokter/i.test(status)) continue;     // filter diabaikan C-CARE → tetap aman
        const tUbah = (tr.match(/href=["']([^"']*\/Ubah\/\d+)/i) || [])[1] || '', tMcu = (tr.match(/href=["']([^"']*\/Mcu\/\d+)/i) || [])[1] || '';
        const mcu = !!tMcu || TM[(tUbah.match(/(\d+)$/) || [])[1]] === 1;
        if (nyata === 4 && (poli === '4mcu') !== mcu) continue;     // poli 4: pisahkan baris Kunjungan Sehat dari MCU
        const ubah = tUbah || tMcu; if (!ubah) continue;             // batal berobat: tanpa tombol Ubah/Mcu
        baris.push({ poli, kunjungan: det, ubah, jam: (bersih(sel[2]).match(/(\d{1,2})[.:](\d{2})(?:[.:]\d{2})?\s*$/) || []).slice(1, 3).join('.'), rm: bersih(sel[3]), pasien: bersih(sel[4]), status });
      }
      return baris;
    };
    const t0 = performance.now();
    let semua;
    try { semua = await Promise.all(polis.map(p => satu(p).catch(e => e && e.name === 'AbortError' ? 'batal' : 'galat'))); }
    finally {                                                                // kembalikan filter C-CARE ke pilihan dokter (lihat ambilAntrean)
      if (pulih) try { await fetch(asal + '/Poli/Index/7', { method: 'POST', credentials: 'include', cache: 'no-store', priority: 'low',
        body: new URLSearchParams({ JenisPoliId: 7, Tanggal: pulih.tgl || tanggal, __Invariant: '', StatusKunjunganId: pulih.st || '', __RequestVerificationToken: token }) }); } catch (e) {}
    }
    if (semua.includes('batal')) return { batal: true };
    const hasil = {}; let login = false, galat = 0;
    semua.forEach((x, i) => { if (x === 'login') login = true; else if (x === 'galat') galat++; else hasil[polis[i]] = x; });
    if (login || galat) G.__sjcToken = null;
    return { hasil, login, galat, ms: Math.round(performance.now() - t0) };
  } catch (e) { return e && e.name === 'AbortError' ? { batal: true } : { galat: 1 }; }
  finally { G.__sjcCtrl.delete(ctl); }
}
/** TTV di ringkasan kunjungan (hanya baca): {id: {label: n baris TTV, isi: n berisi angka}} */
async function cekTtv(ids) {
  const RE = /^(tekanan darah|td\b|tensi|sistol|diastol|nadi|denyut|suhu|respirasi|pernapasan|pernafasan|frekuensi napas|rr\b|spo2|saturasi)/i;
  const out = {};
  for (const id of ids) {
    try {
      const d = new DOMParser().parseFromString(await (await fetch('/RekapRekamMedis/Detail/' + id, { credentials: 'include' })).text(), 'text/html');
      if (d.querySelector('input[type=password]')) { out[id] = null; continue; }
      let label = 0, isi = 0;
      d.querySelectorAll('tr').forEach(tr => {
        if (tr.cells.length < 2) return;
        if (!RE.test(tr.cells[0].textContent.replace(/\s+/g, ' ').trim())) return;
        label++; if (/\d/.test(tr.cells[1].textContent)) isi++;
      });
      out[id] = { label, isi };
    } catch (e) { out[id] = null; }
  }
  return out;
}

/* ---------- fungsi murni (diuji di Node) ---------- */
function jenisStatus(s) { const t = String(s || '').toLowerCase(); return /dokter/.test(t) && /menunggu/.test(t) ? 'dokter' : /perawat/.test(t) && /menunggu/.test(t) ? 'perawat' : 'lain'; }
/** state hari ini (salinan) */
function stateHari(lama, tanggal) {
  const st = lama && lama.tanggal === tanggal ? JSON.parse(JSON.stringify(lama)) : { tanggal, kenal: {}, siap: {}, baris: [] };
  st.dasar = st.dasar || {}; st.baca = st.baca || {}; st.selesai = st.selesai || {}; st.baris = st.baris || []; st.diberitahu = st.diberitahu || {}; return st;
}
/* jam = jam kunjungan di C-CARE (kolom Tanggal Pemeriksaan), bukan waktu pemantau melihatnya */
const entriSiap = (b, notif, sekarang) => ({ poli: b.poli, rm: b.rm, nama: b.pasien, ubah: b.ubah, jam: b.jam || '', sejak: sekarang, baru: notif, dibuka: false });
/** daftar LENGKAP untuk poliIds → { state, baru }. Pembacaan pertama tiap poli per hari (dasar) tidak memberi tahu. */
function olahAntrean(lama, baris, tanggal, sekarang, poliIds) {
  const st = stateHari(lama, tanggal), baru = [], ada = new Set();
  const ps = (poliIds || [...new Set(baris.map(b => b.poli))]).map(String);
  baris.forEach(b => {
    const j = jenisStatus(b.status), prev = st.kenal[b.kunjungan], dasar = !!st.dasar[String(b.poli)]; ada.add(b.kunjungan);
    if (j === 'dokter') { if (prev !== 'dokter' && dasar && !st.diberitahu[b.kunjungan]) { baru.push(b); st.diberitahu[b.kunjungan] = 1; } st.siap[b.kunjungan] = st.siap[b.kunjungan] || entriSiap(b, dasar, sekarang); }
    else delete st.siap[b.kunjungan];
    st.kenal[b.kunjungan] = j;
  });
  Object.keys(st.siap).forEach(k => { if (ps.includes(String(st.siap[k].poli)) && !ada.has(k)) delete st.siap[k]; });
  st.baris = st.baris.filter(x => !ps.includes(String(x.poli))).concat(baris.map(b => ({ k: b.kunjungan, poli: b.poli, status: b.status })));
  ps.forEach(p => { st.dasar[p] = true; st.baca[p] = sekarang; }); st.waktu = sekarang;
  return { state: st, baru };
}
/** daftar CEPAT: hanya pasien berstatus Menunggu Pemeriksaan Dokter di satu poli (filter C-CARE StatusKunjunganId=3) */
function olahDokter(lama, poli, baris, tanggal, sekarang) {
  const st = stateHari(lama, tanggal), baru = [], ada = new Set(), dasar = !!st.dasar[String(poli)];
  baris.forEach(b => {
    ada.add(b.kunjungan);
    if (st.kenal[b.kunjungan] !== 'dokter' && dasar && !st.diberitahu[b.kunjungan]) { baru.push(b); st.diberitahu[b.kunjungan] = 1; }
    st.siap[b.kunjungan] = st.siap[b.kunjungan] || entriSiap(b, dasar, sekarang);
    st.kenal[b.kunjungan] = 'dokter';
    const x = st.baris.find(y => y.k === b.kunjungan);
    if (x) x.status = b.status; else st.baris.push({ k: b.kunjungan, poli: b.poli, status: b.status });
  });
  Object.keys(st.siap).forEach(k => { if (String(st.siap[k].poli) === String(poli) && !ada.has(k)) { delete st.siap[k]; st.kenal[k] = 'lain'; } });
  st.dasar[String(poli)] = true; st.baca[String(poli)] = sekarang; st.waktu = sekarang;
  return { state: st, baru };
}
/** entri yang masih bisa dipercaya: poli-nya terbaca < 2 menit lalu (entri lama tanpa jejak baca tidak ditampilkan),
    dan belum Anda simpan CPPT-nya / sembunyikan dari balon hari ini */
const UMUR_SIAP = 120000;
function siapTerkini(st, sekarang) {
  const o = {}, baca = (st && st.baca) || {}, selesai = (st && st.selesai) || {};
  Object.entries((st && st.siap) || {}).forEach(([k, x]) => { if (!selesai[k] && sekarang - (baca[String(x.poli)] || 0) < UMUR_SIAP) o[k] = x; });
  return o;
}
function singkatNama(n) { const t = String(n || '').trim().split(/\s+/); return t.length <= 2 ? t.join(' ') : t.slice(0, 2).join(' ') + ' ' + t.slice(2).map(x => x[0] + '.').join(' '); }

/* ---------- berjalan di service worker ---------- */
const NAMA_POLI = { 1: 'Poli Umum', 2: 'Poli Gigi', kia: 'KIA', 4: 'Kunjungan Sehat', '4mcu': 'MCU', 5: 'Ruang Tindakan', 8: 'Prolanis', 7: 'Poli Gizi' };
let pantauJalan = false, pantauTerakhir = 0;
async function aturAlarmPantau() {
  const { aktif, mati } = await bacaAturan();
  if (mati) { await chrome.alarms.clear('pantau-siap'); chrome.action.setBadgeBackgroundColor({ color: '#4F6478' }); chrome.action.setBadgeText({ text: 'OFF' }); chrome.action.setTitle({ title: 'Scan Jasa C-CARE — Auto Fill dimatikan' }); return; }
  if (!aktif) { await chrome.alarms.clear('pantau-siap'); chrome.action.setBadgeText({ text: '' }); return; }
  chrome.action.getBadgeText({}).then(t => { if (t === 'OFF') { chrome.action.setBadgeText({ text: '' }); chrome.action.setTitle({ title: 'Scan Jasa C-CARE' }); } }).catch(() => {});
  if (!(await chrome.alarms.get('pantau-siap'))) chrome.alarms.create('pantau-siap', { delayInMinutes: 0.5, periodInMinutes: 0.5 });
}
let antreSW = Promise.resolve();
/* Penyimpanan pemantau: 'pantau' (daftar & Siap dipanggil, ±10–15 KB) hanya ditulis bila isinya BERUBAH;
   jejak baca per poli + waktu baca terakhir disimpan terpisah di 'pantauBaca' (kecil, tiap putaran). */
let pantauMem = null, tulisTerakhir = '';
async function muatPantau() {
  const { pantau, pantauBaca: b } = await chrome.storage.local.get(['pantau', 'pantauBaca']);
  if (pantau && b && b.tanggal === pantau.tanggal) { pantau.baca = Object.assign({}, pantau.baca, b.baca); pantau.waktu = Math.max(pantau.waktu || 0, b.waktu || 0); }
  return pantau;
}
async function simpanPantau(st) {
  pantauMem = st;
  const { baca, waktu, ...inti } = st, teks = JSON.stringify(inti);
  const tugas = [chrome.storage.local.set({ pantauBaca: { tanggal: st.tanggal, baca: baca || {}, waktu: waktu || 0 } })];
  if (teks !== tulisTerakhir) { tulisTerakhir = teks; tugas.push(chrome.storage.local.set({ pantau: inti })); }
  await Promise.all(tugas);
}
const berurut = fn => (antreSW = antreSW.then(fn, fn));
function lencana(state) {
  const n = Object.keys(siapTerkini(state, Date.now())).length;
  chrome.action.setBadgeBackgroundColor({ color: '#263C92' });
  chrome.action.setBadgeText({ text: n ? String(n) : '' });
  chrome.action.setTitle({ title: n ? `Siap dipanggil: ${n} pasien menunggu dokter` : 'Alvisya Dokter' });
}
/** notifikasi ringkas SEKETIKA (klik = buka CPPT di tab baru); bunyi pilihan; cek TTV menyusul */
async function beritahu(baru, state, tabId, per) {
  if (!baru.length) return;
  const { siapNotif } = await chrome.storage.local.get('siapNotif');
  if (baru.some(b => per && per[b.poli] && per[b.poli].bunyi)) bunyiSiap();                  // bunyi dulu, lalu kartu
  if (siapNotif !== false) {
    baru.slice(0, 3).forEach(b => chrome.notifications.create('siap:' + b.kunjungan, { type: 'basic', iconUrl: 'ikon/128.png', priority: 2, silent: true,
      title: singkatNama(b.pasien), message: 'Siap dipanggil · ' + (NAMA_POLI[b.poli] || 'Poli') }));
    if (baru.length > 3) chrome.notifications.create('siap:lain', { type: 'basic', iconUrl: 'ikon/128.png', silent: true, title: '+' + (baru.length - 3) + ' pasien', message: 'Siap dipanggil' });
  }
  tulisLog('info', 'siap dipanggil', `${baru.length} pasien baru menunggu dokter`);
  if (!tabId) return;
  try {
    const ttv = (await chrome.scripting.executeScript({ target: { tabId }, func: cekTtv, args: [baru.map(b => b.kunjungan).slice(0, 5)] }))[0].result || {};
    const kosong = baru.filter(b => { const t = ttv[b.kunjungan]; return t && t.label > 0 && t.isi === 0; });
    if (!kosong.length) return;
    await berurut(async () => {
      const pantau = await muatPantau();
      kosong.forEach(b => { if (pantau && pantau.siap && pantau.siap[b.kunjungan]) pantau.siap[b.kunjungan].ttvKosong = true;
        chrome.notifications.update('siap:' + b.kunjungan, { message: 'Siap dipanggil · ' + (NAMA_POLI[b.poli] || 'Poli') + ' · TTV kosong' }); });
      if (pantau) await simpanPantau(pantau);
    });
  } catch (e) { /* cek TTV hanya pelengkap */ }
}
/** filter daftar pilihan dokter (dicatat filter-daftar.js saat Tampilkan); bawaan: hari ini + semua status */
async function filterDokter(tanggal) {
  const { filterDaftar: f } = await chrome.storage.local.get('filterDaftar');
  return f && f.hari === tanggal ? { st: f.st || '', tgl: f.tgl || tanggal } : { st: '', tgl: tanggal };
}
function jamPantau() { const w = new Date(Date.now() + 7 * 36e5); return { tanggal: w.toISOString().slice(0, 10), buka: w.getUTCHours() >= 6 && w.getUTCHours() < 22 }; }
/** daftar lengkap semua poli yang dipantau (alarm 30 detik / tab terlihat tiap 30 detik) */
async function pantauSiap(tabPilihan) {
  if (pantauJalan || Date.now() - pantauTerakhir < 8000) return; pantauJalan = true; pantauTerakhir = Date.now();
  try {
    const A = await bacaAturan();
    if (!A.aktif) return;
    const { tanggal, buka } = jamPantau();
    if (!buka) { chrome.action.setBadgeText({ text: '' }); return; }
    const tabs = (await chrome.tabs.query({ url: CCARE + '/*' })).filter(t => !t.discarded && t.status === 'complete');
    if (!tabs.length) { chrome.action.setBadgeText({ text: '' }); return; }
    const tab = tabs.find(t => t.id === tabPilihan) || tabs.find(t => !t.active) || tabs[0];
    const poli = A.poli;
    const r = await jalankanBaca(ambilAntrean, [tanggal, poli, await filterDokter(tanggal), false], tab.id);
    if (r && (r.sibuk || r.batal)) { pantauTerakhir = Date.now() - 25000; return; }        // Anda sedang memakai tab → coba ±5 dtk lagi
    if (!r || r.login) { chrome.action.setBadgeBackgroundColor({ color: '#B45309' }); chrome.action.setBadgeText({ text: '!' }); chrome.action.setTitle({ title: 'Siap dipanggil: C-CARE perlu login ulang' }); return; }
    let baru = [], state;
    await berurut(async () => {
      const pantau = await muatPantau();
      ({ state, baru } = olahAntrean(pantau, r.baris, tanggal, Date.now(), poli));
      await simpanPantau(state); lencana(state);
    });
    beritahu(baru, state, tab.id, A.per);
  } catch (e) { tulisLog('awas', 'siap dipanggil', 'Gagal membaca antrean: ' + (e.message || e)); }
  finally { pantauJalan = false; }
}
/** hasil cepat dari tab yang terlihat (antrean-langsung.js): pasien Menunggu Dokter satu poli */
async function terimaCepat(poli, baris, tabId) {
  const A = await bacaAturan();
  if (!A.per[poli] || !A.per[poli].notif) return;
  const { tanggal } = jamPantau();
  let baru = [], state;
  await berurut(async () => {
    const pantau = await muatPantau();
    ({ state, baru } = olahDokter(pantau, poli, baris, tanggal, Date.now()));
    await simpanPantau(state); lencana(state);
  });
  beritahu(baru, state, tabId, A.per);
}
/* Lingkar cepat di service worker: tiap ±2 detik membaca Poli Umum (Menunggu Dokter) lewat tab C-CARE mana pun —
   tab boleh di belakang, di jendela lain, atau jendelanya diminimalkan; cukup tetap terbuka & login.
   Tiap ±30 detik juga pembacaan lengkap semua poli yang dipantau. Alarm 30 detik = penjaga bila lingkar berhenti. */
let lingkarJalan = false, paksaCek = 0, lambatTerakhir = 0;
const JEDA_LAMBAT = 10000;
/* Jalur baca: LANGSUNG dari ekstensi (tidak menyentuh tab mana pun, tidak menunggu Anda selesai mengetik) bila C-CARE
   menerima sesi login dari ekstensi; bila ditolak → lewat tab C-CARE seperti sebelumnya, dicoba ulang tiap 10 menit. */
const jalur = { mode: null, coba: 0 };
const berhasilBaca = r => !!(r && !r.login && (Array.isArray(r.baris) ? !r.galat : r.hasil && Object.keys(r.hasil).length > 0));
async function jalankanBaca(fn, args, tabId) {
  if (jalur.mode !== 'tab' || Date.now() - jalur.coba > 600000) {
    jalur.coba = Date.now();
    let r = null; try { r = await fn(...args, CCARE); } catch (e) { r = null; }
    if (berhasilBaca(r)) { if (jalur.mode !== 'langsung') tulisLog('info', 'siap dipanggil', 'Membaca C-CARE langsung dari ekstensi (tab tidak dipakai)'); jalur.mode = 'langsung'; return r; }
    if (jalur.mode !== 'tab') tulisLog('info', 'siap dipanggil', 'Jalur langsung ditolak C-CARE → membaca lewat tab');
    jalur.mode = 'tab';
  }
  if (!tabId) return null;
  return (await chrome.scripting.executeScript({ target: { tabId }, func: fn, args }))[0].result;
}
/* Pemantauan cerdas: pasien hanya bisa menjadi "siap dipanggil" dari tahap Menunggu Perawat.
   Poli dengan pasien di perawat → dibaca tiap putaran (±2 dtk); ada pasien siap (perlu tahu kapan keluar) → ±6 dtk;
   sepi → ±15 dtk (poli tanpa Cepat: 10 / 10 / 20 dtk). Pendaftaran baru terlihat dari pembacaan lengkap 30 dtk. */
function jedaPoli(st, poli, cepat, sekarang) {
  const p = String(poli), perawat = ((st && st.baris) || []).some(b => String(b.poli) === p && jenisStatus(b.status) === 'perawat');
  const siap = Object.values(siapTerkini(st, sekarang)).some(x => String(x.poli) === p);
  return cepat ? (perawat ? 0 : siap ? 6000 : 15000) : (perawat || siap ? 10000 : 20000);
}
const tidurSW = ms => new Promise(r => setTimeout(r, ms));
const JEDA_CEPAT = 2000;                                            // bawaan; Pengaturan → Pantau → Refresh latar
/** detak tiap putaran → Pengaturan menampilkan "berjalan · x dtk lalu" (storage.session: tidak menulis ke disk) */
function detak(o) { try { chrome.storage.session.set({ pantauDetak: Object.assign({ waktu: Date.now(), versi: chrome.runtime.getManifest().version }, o) }); } catch (e) {} }
async function mulaiLingkar() {
  if (lingkarJalan) return; lingkarJalan = true;
  let gagalBeruntun = 0;
  try {
    for (;;) {
      const A = await bacaAturan();
      if (!A.aktif) { detak({ keadaan: A.mati ? 'af-mati' : 'mati' }); break; }
      const { tanggal, buka } = jamPantau(); if (!buka) { detak({ keadaan: 'luar-jam' }); break; }
      let tabs = (await chrome.tabs.query({ url: CCARE + '/*' })).filter(t => !t.discarded);
      if (!tabs.length) { chrome.action.setBadgeText({ text: '' }); detak({ keadaan: 'tanpa-tab' }); break; }
      const siap = tabs.filter(t => t.status === 'complete');
      if (!siap.length) { await tidurSW(500); continue; }               // tab sedang dimuat ulang → tunggu, jangan berhenti
      const tab = siap.find(t => !t.active) || siap[0];
      if (tab.autoDiscardable !== false) chrome.tabs.update(tab.id, { autoDiscardable: false }).catch(() => {});   // jangan "ditidurkan" Hemat Memori
      if (Date.now() - pantauTerakhir >= 30000) pantauSiap(tab.id);
      const kini = Date.now(), paksa = kini - paksaCek < 6000, mem = pantauMem || await muatPantau(), baca = (mem && mem.tanggal === tanggal && mem.baca) || {};
      const jatuh = id => paksa ? 0 : (baca[String(id)] || 0) + jedaPoli(mem && mem.tanggal === tanggal ? mem : null, id, A.cepat.includes(id), kini);
      const calon = A.poli.filter(id => id !== 'kia'), polis = calon.filter(id => jatuh(id) <= kini);
      const giliranLambat = polis.some(id => !A.cepat.includes(id));
      if (!polis.length) {                                                // tidak ada yang perlu dibaca sekarang → tidur sampai giliran berikutnya
        detak({ keadaan: 'hemat', cepat: A.cepat, jalur: jalur.mode });
        await tidurSW(Math.min(Math.max(500, Math.min(...calon.map(jatuh), kini + 5000) - kini), 5000)); continue;
      }
      const pulih = await filterDokter(tanggal), bawaan = pulih.st === '' && pulih.tgl === tanggal;
      /* CPPT terbuka → dokter bisa menekan Simpan kapan saja, lalu C-CARE memuat daftar dengan filter tersimpan di sesi.
         Selama itu dibaca daftar LENGKAP (hari ini + semua status = filter bawaan), jadi filter dokter tidak pernah tergeser. */
      const cppt = bawaan && tabs.some(t => /\/(?:Ubah|Mcu)\/\d+/i.test(t.url || ''));
      let r = null, ok = false;
      if (cppt) {
        try { r = await jalankanBaca(ambilAntrean, [tanggal, polis, pulih, paksa], tab.id); } catch (e) { r = null; }
        if (r && r.baris && !r.galat) {
          let baru = [], state;
          await berurut(async () => { const pantau = await muatPantau(); ({ state, baru } = olahAntrean(pantau, r.baris, tanggal, Date.now(), polis)); await simpanPantau(state); lencana(state); });
          beritahu(baru, state, tab.id, A.per); ok = true;
        }
      } else {
        try { r = await jalankanBaca(bacaDokter, [tanggal, polis, pulih, paksa], tab.id); } catch (e) { r = null; }
        if (r && r.hasil) for (const poli of Object.keys(r.hasil)) await terimaCepat(isNaN(poli) ? poli : Number(poli), r.hasil[poli], tab.id);
        ok = !!(r && !r.login && !r.galat);
      }
      if (r && r.login) { chrome.action.setBadgeBackgroundColor({ color: '#B45309' }); chrome.action.setBadgeText({ text: '!' }); chrome.action.setTitle({ title: 'Siap dipanggil: C-CARE perlu login ulang' }); }
      detak({ keadaan: r && r.login ? 'login' : ok ? (cppt ? 'cppt' : 'cepat') : 'galat', ms: r && r.ms, cepat: A.cepat, jalur: jalur.mode, dibaca: polis });
      if (ok && giliranLambat) lambatTerakhir = Date.now();
      if (r && r.sibuk) { detak({ keadaan: 'sibuk', cepat: A.cepat, jalur: jalur.mode }); await tidurSW(1500); continue; }   // Anda sedang memakai tab → tunggu
      gagalBeruntun = ok ? 0 : r && r.batal ? gagalBeruntun : gagalBeruntun + 1;
      const { siapJeda } = await chrome.storage.local.get('siapJeda');
      const jeda = Math.max((+siapJeda || JEDA_CEPAT / 1000) * 1000, giliranLambat ? 0 : Math.round(((r && r.ms) || 0) * 2));   // putaran yang ikut membaca poli lambat tidak memperlambat poli Cepat   // server lambat → ikut melambat
      await tidurSW(ok || (r && r.batal) ? jeda : Math.min(2000 * gagalBeruntun, 10000));
    }
  } catch (e) { tulisLog('awas', 'siap dipanggil', 'Lingkar cepat berhenti: ' + (e.message || e)); detak({ keadaan: 'galat' }); }
  finally { lingkarJalan = false; }
}
chrome.tabs.onUpdated.addListener((id, info, t) => { if (info.status === 'complete' && t.url && t.url.startsWith(CCARE)) mulaiLingkar(); });
async function tandaiDibuka(id) {
  const pantau = await muatPantau();
  if (pantau && pantau.siap && pantau.siap[id] && !pantau.siap[id].dibuka) { pantau.siap[id].dibuka = true; await simpanPantau(pantau); }
  chrome.notifications.clear('siap:' + id);
}
async function bukaCppt(id) {
  const pantau = await muatPantau();
  const x = pantau && pantau.siap && pantau.siap[id]; if (!x || !x.ubah) return;
  const url = new URL(x.ubah, CCARE).href;
  const [t] = await chrome.tabs.query({ url: CCARE + '/*' });                 // tab baru di jendela C-CARE; tab utama tidak diganggu
  const tb = await chrome.tabs.create({ url, active: true, windowId: t ? t.windowId : undefined }); if (tb.windowId) chrome.windows.update(tb.windowId, { focused: true });
  tandaiDibuka(id);
}
chrome.notifications.onClicked.addListener(nid => { if (nid.startsWith('siap:') && nid !== 'siap:lain') bukaCppt(nid.slice(5)); chrome.notifications.clear(nid); });
chrome.runtime.onMessage.addListener((m, _s, balas) => { if (m && m.aksi === 'bukaCppt' && m.id) { bukaCppt(String(m.id)); balas && balas({ ok: true }); } });
/* ---------- Periksa di C-CARE (Pengaturan → Pantau): struktur daftar poli, hanya baca, tanpa nama pasien ---------- */
async function ambilTeks(url, asal = '') { const r = await fetch(asal + url, { credentials: 'include', cache: 'no-store' }); return { url: r.url, teks: await r.text() }; }
async function periksaDaftar() {
  const hasil = { jalur: null };
  let r = null;
  try { r = await ambilTeks('/Poli/Index/1', CCARE); if (/datatable-poli/.test(r.teks)) hasil.jalur = 'langsung'; } catch (e) { r = null; }
  if (!hasil.jalur) {
    const [tab] = (await chrome.tabs.query({ url: CCARE + '/*' })).filter(t => !t.discarded && t.status === 'complete');
    if (!tab) return { galat: 'Buka tab C-CARE (sudah login), lalu periksa lagi.' };
    try { r = (await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: ambilTeks, args: ['/Poli/Index/1'] }))[0].result; hasil.jalur = 'tab'; } catch (e) { return { galat: 'Tab C-CARE tidak bisa dibaca.' }; }
  }
  const h = r.teks, i = h.indexOf('datatable-poli');
  if (i < 0) return Object.assign(hasil, { galat: /type=["']?password/i.test(h) ? 'C-CARE perlu login ulang.' : 'Tabel daftar poli tidak ditemukan.' });
  const tabel = h.slice(i, h.indexOf('</table>', i)), bersih = x => x.replace(/<[^>]*>/g, ' ').replace(/&nbsp;/g, ' ').replace(/\s+/g, ' ').trim();
  hasil.kolom = [...((tabel.match(/<thead[\s\S]*?<\/thead>/i) || [''])[0]).matchAll(/<th\b[^>]*>([\s\S]*?)<\/th>/gi)].map(m => bersih(m[1]));
  const st = {}; let tanpaUbah = 0, baris = 0;
  for (const m of ((tabel.match(/<tbody[\s\S]*?<\/tbody>/i) || [''])[0]).matchAll(/<tr\b[\s\S]*?<\/tr>/gi)) {
    const sel = [...m[0].matchAll(/<td\b[^>]*>([\s\S]*?)<\/td>/gi)].map(x => bersih(x[1])); if (sel.length < 6) continue;
    baris++; st[sel[5]] = (st[sel[5]] || 0) + 1; if (!/\/Ubah\/\d+/i.test(m[0])) tanpaUbah++;
  }
  hasil.status = st; hasil.baris = baris; hasil.tanpaUbah = tanpaUbah; hasil.token = /__RequestVerificationToken/.test(h);
  return hasil;
}
chrome.runtime.onMessage.addListener((m, _s, balas) => { if (m && m.aksi === 'periksaDaftar') { periksaDaftar().then(balas, e => balas({ galat: String(e.message || e) })); return true; } });
/** CPPT disimpan dokter / disembunyikan dari balon → keluar dari Siap dipanggil hari ini (status C-CARE tidak disentuh) */
async function tandaiSelesai(id, dariSimpan) {
  await berurut(async () => {
    const pantau = await muatPantau(); if (!pantau) return;
    pantau.selesai = pantau.selesai || {}; pantau.selesai[id] = 1; if (dariSimpan) chrome.storage.local.set({ diagSimpan: { waktu: Date.now() } });
    await simpanPantau(pantau); lencana(pantau);
  });
  chrome.notifications.clear('siap:' + id);
}
chrome.runtime.onMessage.addListener((m, _s, balas) => { if (m && (m.aksi === 'cpptDisimpan' || m.aksi === 'sembunyikanSiap') && m.id) { tandaiSelesai(String(m.id), m.aksi === 'cpptDisimpan'); balas && balas({ ok: true }); } });
chrome.tabs.onUpdated.addListener((id, info) => { const m = info.url && info.url.startsWith(CCARE) && info.url.match(/\/(?:Ubah|Mcu)\/(\d+)/); if (m) tandaiDibuka(m[1]); });
chrome.storage.onChanged.addListener((c, area) => { if (area === 'local' && (c.pantauPer || c.isiCepat)) { aturAlarmPantau(); mulaiLingkar(); if (c.pantauPer) rapikanState(); } });
/** poli yang dimatikan → keluar dari hitungan ikon; poli yang baru dinyalakan → pembacaan pertamanya jadi dasar (tanpa banjir notifikasi) */
async function rapikanState() {
  await berurut(async () => {
    const [pantau, A] = await Promise.all([muatPantau(), bacaAturan()]);
    if (!pantau || !pantau.siap) return;
    Object.keys(pantau.siap).forEach(k => { if (!A.poli.map(String).includes(String(pantau.siap[k].poli))) delete pantau.siap[k]; });
    Object.keys(pantau.dasar || {}).forEach(p => { if (!A.poli.map(String).includes(p)) delete pantau.dasar[p]; });
    await simpanPantau(pantau); lencana(pantau);
  });
}
mulaiLingkar();
