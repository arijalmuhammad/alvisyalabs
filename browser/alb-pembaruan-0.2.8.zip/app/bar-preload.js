const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('cd', {
  kirim: (aksi, a) => ipcRenderer.send('bar', aksi, a),
  dengar: (nama, f) => ipcRenderer.on(nama, (e, d) => f(d)),
});
