// Cetak lewat internet: halaman surat dienkripsi di PC ini lalu dititipkan ke alvisyalabs-app; hanya PC printer
// tujuan yang bisa membukanya (kunci AES dibungkus RSA-OAEP milik PC printer). Server tidak bisa membaca isinya.
const crypto = require('crypto');

const URL_CETAK = 'https://alvisyalabs-app.muhammad-arijal-fba.workers.dev';
// Grup = SHA-256("printer-klinik|" + sandi akun cetak), sama dengan PRINTER-KLINIK.bat (sandi bawaan klinik).
const GRUP = crypto.createHash('sha256').update('printer-klinik|KlinikCetak2026').digest('hex');
const BATAS_B64 = 1_700_000;

const b64url = (s) => s.replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');

async function minta(fetchFn, jalur, opsi = {}, batasMs = 8000) {
  const ac = new AbortController(), t = setTimeout(() => ac.abort(), batasMs);
  try {
    const r = await fetchFn(URL_CETAK + jalur, { ...opsi, signal: ac.signal });
    const j = await r.json().catch(() => null);
    if (!j || !j.ok) throw new Error((j && j.error && j.error.message) || `server menjawab ${r.status}`);
    return j.data;
  } finally { clearTimeout(t); }
}

// [{agen, printer, nama_pc, n, e}] untuk setiap printer di PC printer yang sedang menyala
async function daftarPrinter(fetchFn) {
  const agen = await minta(fetchFn, `/api/cetak/agen?grup=${GRUP}`, {}, 4000);
  return agen.filter((a) => a.online).flatMap((a) => a.printer.map((p) => ({ agen: a.id, printer: p, nama_pc: a.nama_pc, n: a.n, e: a.e })));
}

// halaman: [{w, h (pt), jpeg (Buffer)}] → paket terenkripsi untuk satu PC printer
function bungkus(tujuan, halaman) {
  const kEnc = crypto.randomBytes(32), kMac = crypto.randomBytes(32);
  const pub = crypto.createPublicKey({ key: { kty: 'RSA', n: b64url(tujuan.n), e: b64url(tujuan.e) }, format: 'jwk' });
  const kunci = crypto.publicEncrypt({ key: pub, padding: crypto.constants.RSA_PKCS1_OAEP_PADDING, oaepHash: 'sha1' }, Buffer.concat([kEnc, kMac]));
  const isi = halaman.map((h) => {
    const kepala = Buffer.alloc(8);
    kepala.writeUInt32BE(Math.round(h.w * 100), 0); kepala.writeUInt32BE(Math.round(h.h * 100), 4);   // ukuran kertas (pt × 100)
    const iv = crypto.randomBytes(16), c = crypto.createCipheriv('aes-256-cbc', kEnc, iv);
    const data = Buffer.concat([c.update(Buffer.concat([kepala, h.jpeg])), c.final()]);
    const mac = crypto.createHmac('sha256', kMac).update(Buffer.concat([iv, data])).digest();
    return { iv: iv.toString('base64'), mac: mac.toString('base64'), data: data.toString('base64') };
  });
  const besar = isi.find((h) => h.data.length > BATAS_B64);
  if (besar) throw new Error('halaman terlalu besar untuk dikirim lewat internet');
  return { kunci: kunci.toString('base64'), halaman: isi };
}

async function kirim(fetchFn, tujuan, halaman, judul, pengirim) {
  const paket = bungkus(tujuan, halaman);
  const body = JSON.stringify({ grup: GRUP, agen: tujuan.agen, printer: tujuan.printer, judul, pengirim, ...paket });
  return (await minta(fetchFn, '/api/cetak/kirim', { method: 'POST', headers: { 'content-type': 'application/json' }, body }, 30000)).id;
}

// Tunggu laporan PC printer (selesai/gagal) paling lama batasMs
async function tungguHasil(fetchFn, id, batasMs = 90000) {
  const akhir = Date.now() + batasMs;
  while (Date.now() < akhir) {
    const s = await minta(fetchFn, `/api/cetak/status?id=${id}`, {}, 8000).catch(() => null);
    if (s && ['selesai', 'gagal', 'kedaluwarsa'].includes(s.status)) return s;
    await new Promise((r) => setTimeout(r, 2500));
  }
  return { status: 'menunggu' };
}

module.exports = { URL_CETAK, GRUP, daftarPrinter, bungkus, kirim, tungguHasil };
