"use strict";
const { contextBridge, ipcRenderer } = require("electron");
const pendengar = [];
ipcRenderer.on("st:berubah", (_e, ch) => { for (const f of pendengar) { try { f(ch); } catch (e) {} } });
contextBridge.exposeInMainWorld("app", {
  tampil: (v) => ipcRenderer.invoke("ui:tampil", v),
  muatUlang: () => ipcRenderer.invoke("ui:muatUlang"),
  kembali: () => ipcRenderer.invoke("ui:kembali"),
  beranda: () => ipcRenderer.invoke("ui:beranda"),
  zoom: (arah) => ipcRenderer.invoke("ui:zoom", arah),
  pengaturan: () => ipcRenderer.invoke("bukaPengaturan"),
  salinLog: () => ipcRenderer.invoke("ui:salinLog"),
  folderLog: () => ipcRenderer.invoke("host", { cmd: "bukaFolder", apa: "log" }),
  info: () => ipcRenderer.invoke("ui:info"),
  onStatus: (f) => ipcRenderer.on("ui:status", (_e, x) => f(x)),
  // v3.1.0 Meja kerja
  area: (r) => ipcRenderer.invoke("ui:area", r),
  ambil: (k) => ipcRenderer.invoke("st:get", k),
  simpan: (o) => ipcRenderer.invoke("st:set", o),
  onBerubah: (f) => pendengar.push(f),
  kirimBot: (pesan) => ipcRenderer.invoke("rt:kirim", pesan),
  bukaCcare: (p) => ipcRenderer.invoke("ui:bukaCcare", p),
  salin: (t) => ipcRenderer.invoke("ui:salin", t),
  bersihCache: () => ipcRenderer.invoke("ui:bersihCache"),
});
