<# : PRINTER-KLINIK.bat - file gabungan Batch + PowerShell. JANGAN ubah baris ini.
@echo off
title Printer Klinik
fltmc >nul 2>&1 && goto :admin
if "%~1"=="" powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
if not "%~1"=="" powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -ArgumentList '%*' -Verb RunAs"
exit /b
:admin
cd /d "%~dp0"
set "KP_SELF=%~f0"
set "KP_DIR=%~dp0"
set "KP_ARGS=%*"
powershell -NoProfile -ExecutionPolicy Bypass -Command "iex ([IO.File]::ReadAllText($env:KP_SELF))"
set "RC=%errorlevel%"
if "%~1"=="" pause
exit /b %RC%
#>

# =====================================================================
#  PRINTER KLINIK - UNIVERSAL (semua merk/tipe printer)
#
#  Printer dicolok ke satu PC ("PC printer"), dibagikan ke jaringan, dan
#  PC lain mencetak ke sana. Nama printer: (Merk) (Tipe) - (posisi).
#
#  Klik dua kali file ini lalu pilih menu. Silent (CMD Administrator):
#    PRINTER-KLINIK.bat printer Apotek       bagikan semua printer USB di PC ini, posisi "Apotek"
#    PRINTER-KLINIK.bat lain                 sambung ke semua printer yang ditemukan di jaringan
#    PRINTER-KLINIK.bat lain PC-A,PC-B       sambung ke printer di PC-A dan PC-B
#    PRINTER-KLINIK.bat perbaiki | driver | pindah | lepas | scan | diagnosa
#    PRINTER-KLINIK.bat pulihkan             (otomatis tiap 10 menit di PC lain) cari ulang PC printer yang pindah alamat
#    PRINTER-KLINIK.bat lapor                (otomatis tiap 10 menit di PC printer) lapor alamat ke buku alamat
#
#  Alamat jaringan PC printer boleh berubah tiap hari: PC lain menyambung lewat NAMA PC printer.
#  Bila namanya tidak dikenali jaringan, alamat terakhir dicatat di berkas hosts Windows (baris "# PRINTER-KLINIK")
#  dan tugas terjadwal "Printer Klinik - Sambung Ulang" mencari alamat barunya lalu memperbarui baris itu.
# =====================================================================

$ErrorActionPreference = 'Stop'
$Dir        = $env:KP_DIR
# Akun khusus cetak di PC printer (bukan admin, disembunyikan dari layar login). PC lain memakainya otomatis.
# Sandi bawaan dipakai tanpa ditanya (permintaan pemilik: tanpa sandi). Ganti di sini bila perlu (sama di semua PC).
$PrintUser  = 'cetakklinik'
$PrintPassBawaan = 'KlinikCetak2026'
$PrintPass  = $null
$Prefix     = 'KP'                                   # nama share printer: KP1, KP2, ...
$ShareRx    = '^(KP\d+|L3210)$'                      # L3210 = share versi lama
$PubShare   = 'KPDRV$'                               # folder bersama tersembunyi: daftar printer + driver
$AppDir     = Join-Path $env:ProgramData 'Printer-Klinik'
$PubDir     = Join-Path $AppDir 'share'
$PubList    = Join-Path $PubDir 'printers.txt'       # SHARE|NAMA|DRIVER|POSISI|ADA_DRIVER
$AddrFile   = Join-Path $Dir 'ALAMAT-PRINTER.txt'    # NAMA_PC|IP
$LogFile    = Join-Path $env:TEMP 'printer-klinik.log'
$HostsFile  = Join-Path $env:SystemRoot 'System32\drivers\etc\hosts'
$HostsTag   = '# PRINTER-KLINIK'
$TaskName   = 'Printer Klinik - Sambung Ulang'
$TaskLapor  = 'Printer Klinik - Lapor Alamat'
# Buku alamat di Google Sheet "Printer Klinik - Buku Alamat" (Apps Script). PC printer melapor alamatnya,
# PC lain mencari alamat terbaru dari nama PC printer. Kosong = buku alamat tidak dipakai.
$BukuUrl    = 'https://script.google.com/macros/s/AKfycbx5QVWJRgmihgWcII47qeztG8_-4JJ9ZoqtQWNGYciEKKXKUcoRUuJ5NOuIc8lKGYg/exec'
$PassFileLama = Join-Path $AppDir 'sandi-cetak.txt'          # dari versi yang sempat meminta sandi; dihapus
$UserFile   = Join-Path $AppDir 'nama-pengguna.txt'          # nama pengguna PC printer di buku alamat (mis. Toyib)
$ScanFile   = Join-Path $AppDir 'pulihkan-terakhir.txt'  # NAMA|waktu pemindaian terakhir (batas sekali per jam)
$argv       = @("$env:KP_ARGS" -split '\s+' | Where-Object { $_ })
$Silent     = $argv.Count -gt 0
$Mode       = if ($argv.Count -gt 0) { $argv[0].ToLower() } else { '' }
$Server     = if ($argv.Count -gt 1) { $argv[1..($argv.Count - 1)] -join ' ' } else { '' }
Start-Transcript -Path $LogFile -Append | Out-Null

function Say($m, $c = 'Gray') { Write-Host $m -ForegroundColor $c }
function Ok($m)   { Say "[OK] $m" Green }
function Warn($m) { Say "[!]  $m" Yellow }
function Fail($m) {
    Say "[X]  $m" Red
    Say "Log lengkap: $LogFile"
    Stop-Transcript | Out-Null
    exit 1
}
function Ask($q, $default = '') {
    if ($Silent) { return $default }
    $a = Read-Host $q
    if ([string]::IsNullOrWhiteSpace($a)) { return $default }
    return $a.Trim()
}
function Yes($q, $default) { return ((Ask $q $default) -match '^[yY]') }

# Pilih beberapa item dari daftar bernomor. Jawaban: "1,3" atau Enter = semua.
function Select-Items($items, $question) {
    $items = @($items)
    if ($items.Count -le 1) { return , $items }
    $ans = Ask "$question [contoh 1,3 | Enter = semua]" 'semua'
    if ($ans -eq 'semua') { return , $items }
    $picked = @()
    foreach ($tok in "$ans".Split(',') | ForEach-Object { $_.Trim() }) {
        if ($tok -match '^\d+$' -and [int]$tok -ge 1 -and [int]$tok -le $items.Count) { $picked += $items[[int]$tok - 1] }
    }
    return , $picked
}

# ---------------------------------------------------------------- KOMPONEN WINDOWS
function Get-Components {
    foreach ($s in 'Spooler', 'LanmanServer', 'LanmanWorkstation', 'MpsSvc', 'wuauserv') {
        $svc = Get-Service $s -ErrorAction SilentlyContinue
        [pscustomobject]@{ Komponen = $s; Status = $(if ($svc) { "$($svc.Status) / $($svc.StartType)" } else { 'TIDAK ADA' }) }
    }
    foreach ($m in 'PrintManagement', 'NetConnection') {
        [pscustomobject]@{ Komponen = $m; Status = $(if (Get-Module -ListAvailable $m) { 'ada' } else { 'TIDAK ADA' }) }
    }
}
function Assert-Components([string[]]$need) {
    $all  = @(Get-Components)
    $miss = @($all | Where-Object { $need -contains $_.Komponen -and $_.Status -eq 'TIDAK ADA' })
    if ($miss.Count -eq 0) { return }
    $all | Format-Table -AutoSize | Out-String | Write-Host
    $names = ($miss | ForEach-Object Komponen) -join ', '
    if ($names -match 'Spooler') { Fail "Windows di PC ini tidak punya fitur cetak ($names). Windows Lite ini harus diganti." }
    if ($names -match 'LanmanServer') { Fail "Windows di PC ini tidak bisa membagikan printer ($names). Colokkan printer ke PC lain." }
    Fail "Komponen Windows hilang: $names. Jalankan menu 0 (DIAGNOSA) dan kirim hasilnya."
}
# Windows Lite sering mematikan layanan: aktifkan lagi.
function Enable-Svc($name) {
    $svc = Get-Service $name -ErrorAction SilentlyContinue
    if (-not $svc) { return }
    if ($svc.StartType -ne 'Automatic') { Set-Service $name -StartupType Automatic }
    if ((Get-Service $name).Status -ne 'Running') { Start-Service $name }
}

# ---------------------------------------------------------------- BANTUAN UMUM
function Test-Port($h, $p = 445) {
    try {
        $c = New-Object Net.Sockets.TcpClient
        $r = $c.BeginConnect($h, $p, $null, $null)
        $ok = $r.AsyncWaitHandle.WaitOne(3000) -and $c.Connected
        $c.Close()
        return $ok
    } catch { return $false }
}
function Get-MyIP {
    [Net.NetworkInformation.NetworkInterface]::GetAllNetworkInterfaces() |
        Where-Object { $_.OperationalStatus -eq 'Up' -and $_.NetworkInterfaceType -ne 'Loopback' } |
        Sort-Object @{ Expression = { $_.GetIPProperties().GatewayAddresses.Count -gt 0 }; Descending = $true } |
        ForEach-Object { $_.GetIPProperties().UnicastAddresses } |
        Where-Object { $_.Address.AddressFamily -eq 'InterNetwork' -and $_.Address.ToString() -notlike '169.254.*' } |
        Select-Object -First 1 | ForEach-Object { $_.Address.ToString() }
}
function Set-Default($printerName) {
    Set-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows NT\CurrentVersion\Windows' -Name LegacyDefaultPrinterMode -Value 1 -Type DWord
    (New-Object -ComObject WScript.Network).SetDefaultPrinter($printerName)
    Ok "Printer default: $printerName"
}
function Print-TestPage($printerName) {
    & rundll32.exe 'printui.dll,PrintUIEntry' /k /n "$printerName"
    Ok "Halaman uji dikirim ke: $printerName"
}
function Get-ErrCode($err) {
    try {
        $c = $err.Exception.ErrorData.CimInstanceProperties['error_Code'].Value
        if ($c) { return ('0x{0:X8}' -f [int64]$c) }
    } catch { }
    return ('0x{0:X8}' -f $err.Exception.HResult)
}

# ---------------------------------------------------------------- FOLDER APLIKASI
# Folder data (ProgramData) memakai izin bawaan Windows. Versi sebelumnya mengunci folder ini dan di beberapa PC
# membuat Administrator sendiri ditolak ("Access ... is denied"): pemilik dikembalikan ke Administrators dan izin
# dikembalikan ke bawaan. Skrip yang dijalankan tugas SYSTEM ditaruh di Program Files (bawaan: pengguna biasa baca saja).
$TaskDir = Join-Path $env:ProgramFiles 'Printer-Klinik'
function Repair-AppDir {
    if (-not (Test-Path $AppDir)) { New-Item -ItemType Directory -Force -Path $AppDir | Out-Null; return }
    & takeown.exe /F "$AppDir" /R /D Y /A 2>&1 | Out-Null
    & icacls.exe "$AppDir" /reset /T /C /Q 2>&1 | Out-Null
    & attrib.exe -R "$AppDir\*" /S /D 2>&1 | Out-Null
    Remove-Item $PassFileLama -Force -ErrorAction SilentlyContinue   # semua PC kini memakai sandi bawaan yang sama
}
# Tulis berkas di folder aplikasi; bila ditolak Windows, perbaiki izin folder lalu coba sekali lagi.
function Write-AppFile($path, $value) {
    try { Set-Content -Path $path -Value $value -ErrorAction Stop; return }
    catch [UnauthorizedAccessException] { }
    catch { if ($_.Exception -isnot [UnauthorizedAccessException] -and $_.Exception.InnerException -isnot [UnauthorizedAccessException]) { throw } }
    Warn "Izin folder $AppDir diperbaiki..."
    Repair-AppDir
    Remove-Item $path -Force -ErrorAction SilentlyContinue
    try { Set-Content -Path $path -Value $value -ErrorAction Stop }
    catch { throw "Tidak bisa menulis $path. Izin folder: $((& icacls.exe "$AppDir" 2>&1) -join ' | ')" }
}
function Get-PrintPass { return $PrintPassBawaan }

# ---------------------------------------------------------------- BUKU ALAMAT (Google Sheet)
# Sidik = SHA-256 dari sandi akun cetak: buku hanya melayani PC yang tahu sandinya; sandi tidak dikirim.
function Get-Sidik {
    $h = [Security.Cryptography.SHA256]::Create().ComputeHash([Text.Encoding]::UTF8.GetBytes("printer-klinik|$PrintPass"))
    return (($h | ForEach-Object { $_.ToString('x2') }) -join '')
}
function Invoke-Buku($q) {
    if (-not $BukuUrl -or $BukuUrl -like '@*') { return $null }
    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
        $r = Invoke-RestMethod -Uri "$BukuUrl`?$q&sidik=$(Get-Sidik)" -UseBasicParsing -TimeoutSec 20
        if ($r.ok) { return $r }
        Warn "Buku alamat menolak: $($r.galat)"
    } catch { Warn "Buku alamat tidak terjangkau: $($_.Exception.Message)" }
    return $null
}
function Send-Lapor {
    $ip = Get-MyIP
    if (-not $ip) { Warn 'Alamat jaringan PC ini tidak terbaca; buku alamat tidak diperbarui.'; return }
    # Nama pengguna: yang diisi di menu 1 (mis. "Toyib"); bila kosong, buku memakai nama akun Windows yang login.
    $pengguna = if (Test-Path $UserFile) { "$(Get-Content $UserFile -Raw)".Trim() } else { '' }
    $akun = "$((Get-CimInstance Win32_ComputerSystem -ErrorAction SilentlyContinue).UserName)" -replace '^.*\\', ''
    if (-not $akun -and $env:USERNAME -notlike '*$') { $akun = $env:USERNAME }   # tugas otomatis berjalan sebagai SYSTEM
    $r = Invoke-Buku "op=lapor&nama=$([uri]::EscapeDataString($env:COMPUTERNAME))&ip=$ip&pengguna=$([uri]::EscapeDataString($pengguna))&akun=$([uri]::EscapeDataString($akun))"
    if ($r) { Ok "Buku alamat: $env:COMPUTERNAME = $ip" }
}
# Semua PC printer di buku: @{ Name; IP }. $nama kosong = semua.
function Get-BukuServers($nama = '') {
    $q = 'op=cari' + $(if ($nama) { "&nama=$([uri]::EscapeDataString($nama))" } else { '' })
    $r = Invoke-Buku $q
    if (-not $r) { return , @() }
    return , @($r.data | Where-Object { Test-IsIP $_.ip } | ForEach-Object { [pscustomobject]@{ Name = "$($_.nama)"; IP = "$($_.ip)" } })
}

# ---------------------------------------------------------------- NAMA PC PRINTER (alamat boleh berubah)
function Test-IsIP($t) { return ("$t" -match '^\d{1,3}(\.\d{1,3}){3}$') }
function Resolve-IPv4($name) {
    try { return ([Net.Dns]::GetHostAddresses($name) | Where-Object { $_.AddressFamily -eq 'InterNetwork' } | Select-Object -First 1).ToString() } catch { return $null }
}
# Alamat dari DNS/jaringan saja (tanpa berkas hosts), untuk mencari alamat baru.
function Resolve-IPv4Net($name) {
    try { return (Resolve-DnsName $name -Type A -NoHostsFile -ErrorAction Stop | Where-Object IPAddress | Select-Object -First 1).IPAddress } catch { return $null }
}
function Get-NbName($ip) {
    $nb = (& cmd.exe /c "nbtstat -A $ip 2>nul") -join "`n"
    if ($nb -match '(?m)^\s*(\S+)\s+<00>\s+UNIQUE') { return $Matches[1] }
    return $null
}
# Baris "ALAMAT NAMA # PRINTER-KLINIK" di berkas hosts: NAMA -> alamat terakhir.
function Get-HostsMap {
    $m = @{}
    if (Test-Path $HostsFile) {
        foreach ($l in Get-Content $HostsFile) {
            if ($l -match "^\s*(\d+\.\d+\.\d+\.\d+)\s+(\S+)\s+$([regex]::Escape($HostsTag))") { $m[$Matches[2].ToUpper()] = $Matches[1] }
        }
    }
    return $m
}
function Set-HostsEntry($name, $ip) {
    $old = @()
    if (Test-Path $HostsFile) { $old = @(Get-Content $HostsFile) }
    $keep = @($old | Where-Object { $_ -notmatch "^\s*\S+\s+$([regex]::Escape($name))\s+$([regex]::Escape($HostsTag))" })
    Copy-Item $HostsFile "$HostsFile.kp-cadangan" -Force -ErrorAction SilentlyContinue
    Set-Content -Path $HostsFile -Value ($keep + "$ip`t$name`t$HostsTag") -Encoding ASCII
    & ipconfig.exe /flushdns | Out-Null
}
# Port 445 terbuka di daftar alamat (dicek serentak). Mengembalikan alamat yang terbuka.
function Find-Open445([string[]]$ips) {
    $open = @()
    for ($b = 0; $b -lt $ips.Count; $b += 256) {
        $jobs = foreach ($ip in $ips[$b..([Math]::Min($b + 255, $ips.Count - 1))]) {
            $c = New-Object Net.Sockets.TcpClient
            try { [pscustomobject]@{ IP = $ip; Client = $c; Async = $c.BeginConnect($ip, 445, $null, $null) } } catch { }
        }
        Start-Sleep -Milliseconds 2500
        $open += @($jobs | Where-Object { $_.Async.IsCompleted -and $_.Client.Connected } | ForEach-Object { $_.IP })
        foreach ($j in $jobs) { try { $j.Client.Close() } catch { } }
    }
    return , $open
}
# Nama PC printer yang tercatat di daftar bagi PC itu (baris "#PC|NAMA"), atau dari NetBIOS.
function Get-PcName($target) {
    try {
        $l = Get-Content "\\$target\$PubShare\printers.txt" -ErrorAction Stop | Where-Object { $_ -like '#PC|*' } | Select-Object -First 1
        if ($l) { return $l.Substring(4).Trim() }
    } catch { }
    return (Get-NbName $target)
}
# Apakah alamat ini PC printer bernama $name? Nama dicek dulu lewat NetBIOS (tanpa login), jadi
# akun cetak TIDAK dicoba ke PC lain di jaringan kampus. $percaya = alamat dari DNS/catatan sendiri:
# boleh login walau NetBIOS tidak menjawab.
function Test-PcMatch($ip, $name, [switch]$percaya) {
    $nb = Get-NbName $ip
    if ($nb -and $nb -ne $name) { return $false }
    if (-not $nb -and -not $percaya) { return $false }
    $rc = Connect-Auth $ip $name
    if ($rc -ne 0 -and $rc -ne 1219) { return $false }
    $cocok = (Test-PubList $ip) -and ((Get-PcName $ip) -eq $name)
    if (-not $cocok -and $rc -eq 0) { & cmd.exe /c "net use \\$ip\IPC$ /delete /y >nul 2>&1" }
    return $cocok
}
# Cari alamat baru PC printer: DNS, lalu kelompok alamat terakhirnya, lalu kelompok alamat PC ini.
function Find-PcPrinter($name, $lastIp, [switch]$tanpaPindai) {
    $buku = @(Get-BukuServers $name | ForEach-Object { $_.IP })
    foreach ($ip in @($buku + @((Resolve-IPv4Net $name), $lastIp)) | Where-Object { $_ } | Select-Object -Unique) {
        if ((Test-Port $ip) -and (Test-PcMatch $ip $name -percaya)) { return $ip }
    }
    if ($tanpaPindai) { return $null }
    $pre = @()
    foreach ($a in @($lastIp, (Get-MyIP))) { if ("$a" -match '^(\d+\.\d+\.\d+)\.\d+$') { $pre += $Matches[1] } }
    foreach ($p in $pre | Select-Object -Unique) {
        Say "Mencari $name di jaringan $p.x ..."
        foreach ($c in (Find-Open445 @(1..254 | ForEach-Object { "$p.$_" }))) { if (Test-PcMatch $c $name) { return $c } }
    }
    return $null
}

# ---------------------------------------------------------------- NAMA PRINTER
# "EPSON L3210 Series (Copy 1)" -> "EPSON L3210"
function Get-Model($driverName) {
    $m = "$driverName" -replace '\s*\(Copy \d+\)', '' -replace '\s+(Series|Class Driver|Printer Driver)\b.*$', '' -replace '\s+(PCL|PS|XPS|UFR|GDI)\s?\w*$', ''
    return $m.Trim()
}
function Format-Text($t) { return ("$t" -replace '[\\,!\*\?\[\]\|]', ' ' -replace '\s+', ' ').Trim() }
# (Merk) (Tipe) - (posisi)
function Get-NiceName($model, $posisi) {
    $m = Format-Text $model
    $p = Format-Text $posisi
    if ($p) { return "$m - $p" }
    return $m
}

# ---------------------------------------------------------------- PRINTER DI PC INI
$VirtualPortRx   = '^(\\\\|PORTPROMPT:|nul:|FILE:|XPSPort:|SHRFAX:|Microsoft\.|COM\d|TS\d)'
$VirtualDriverRx = 'Microsoft (Print To PDF|XPS|Shared Fax|Software)|OneNote|Fax|PDF'

# Printer fisik yang terpasang langsung di PC ini (USB / jaringan langsung), bukan printer virtual.
function Get-HostPrinters {
    Get-Printer -ErrorAction SilentlyContinue | Where-Object {
        $_.Type -eq 'Local' -and $_.PortName -notmatch $VirtualPortRx -and $_.DriverName -notmatch $VirtualDriverRx
    }
}
# Printer klinik yang dibagikan PC ini.
function Get-SharedPrinters { Get-HostPrinters | Where-Object { $_.Shared -and $_.ShareName -match $ShareRx } }
# Printer klinik milik PC lain yang tersambung di PC ini.
function Get-ClientPrinters {
    Get-Printer -ErrorAction SilentlyContinue | Where-Object {
        ($_.Type -eq 'Local' -and $_.PortName -match '^\\\\[^\\]+\\(KP\d+|L3210)$') -or
        ($_.Type -eq 'Connection' -and $_.ShareName -match $ShareRx)
    }
}
# Perangkat printer USB yang terlihat Windows, dan perangkat USB yang belum punya driver.
function Get-UsbPrinters {
    Get-CimInstance Win32_PnPEntity -ErrorAction SilentlyContinue |
        Where-Object { $_.DeviceID -like 'USBPRINT\*' -or ($_.DeviceID -like 'USB\VID_*' -and $_.ConfigManagerErrorCode -eq 28) }
}
function Show-UsbStatus {
    $dev = @(Get-UsbPrinters)
    if ($dev.Count -eq 0) { Warn 'USB: tidak ada printer USB yang terlihat oleh Windows.'; return }
    foreach ($d in $dev) {
        $state = if ($d.ConfigManagerErrorCode -eq 0) { 'normal' } elseif ($d.ConfigManagerErrorCode -eq 28) { 'BELUM ADA DRIVER' } else { "error kode $($d.ConfigManagerErrorCode)" }
        Say "USB: $($d.Name)  -> $state"
    }
}
function Show-Printers($list) {
    $list = @($list)
    for ($i = 0; $i -lt $list.Count; $i++) {
        $x = $list[$i]
        $share = if ($x.Shared) { "dibagikan ($($x.ShareName))" } else { '-' }
        Say ("  {0}. {1}   [port {2} | {3} | status {4} | antre {5}]" -f ($i + 1), $x.Name, $x.PortName, $share, $x.PrinterStatus, $x.JobCount)
    }
}

# ---------------------------------------------------------------- DRIVER
# Driver lewat Windows Update: untuk perangkat printer yang tercolok dan belum punya driver.
function Install-DriverFromWU {
    $svc = Get-Service wuauserv -ErrorAction SilentlyContinue
    if (-not $svc) { Warn 'Windows Update tidak ada di Windows ini (dibuang Windows Lite).'; return $false }
    $oldType = $svc.StartType
    $ids = @(Get-UsbPrinters | ForEach-Object { $_.HardwareID } | Where-Object { $_ })
    try {
        if ($oldType -eq 'Disabled') { Set-Service wuauserv -StartupType Manual }
        Start-Service wuauserv -ErrorAction SilentlyContinue
        Say 'Mencari driver printer lewat Windows Update (butuh internet, 1-5 menit)...' Cyan
        $session  = New-Object -ComObject Microsoft.Update.Session
        $searcher = $session.CreateUpdateSearcher()
        $searcher.ServerSelection = 2
        $searcher.Online = $true
        $res  = $searcher.Search("IsInstalled=0 and Type='Driver'")
        $coll = New-Object -ComObject Microsoft.Update.UpdateColl
        foreach ($u in $res.Updates) {
            $isPrinter = "$($u.DriverClass)" -match 'Print'
            $isMine    = $ids -contains "$($u.DriverHardwareID)"
            if ($isPrinter -or $isMine) { Say "  driver ditemukan: $($u.Title)"; [void]$coll.Add($u) }
        }
        if ($coll.Count -eq 0) { Warn 'Windows Update tidak menemukan driver printer untuk perangkat yang tercolok.'; return $false }
        foreach ($u in $coll) { if (-not $u.EulaAccepted) { $u.AcceptEula() } }
        $dl = $session.CreateUpdateDownloader(); $dl.Updates = $coll; [void]$dl.Download()
        $in = $session.CreateUpdateInstaller();  $in.Updates = $coll; [void]$in.Install()
        Ok 'Driver dari Windows Update dipasang.'
        return $true
    } catch {
        Warn "Windows Update gagal: $($_.Exception.Message)"
        return $false
    } finally {
        if ($oldType -eq 'Disabled') {
            Stop-Service wuauserv -Force -ErrorAction SilentlyContinue
            Set-Service wuauserv -StartupType Disabled
        }
    }
}

# Installer driver resmi (.exe) di folder yang sama dengan file ini. Hanya dijalankan bila dipilih pengguna.
function Install-DriverFromExe {
    if ($Silent) { return $false }
    $exes = @(Get-ChildItem $Dir -Filter *.exe -ErrorAction SilentlyContinue | Where-Object { $_.Name -notlike '*Web*' })
    if ($exes.Count -eq 0) { return $false }
    Say 'Installer (.exe) di folder ini:'
    for ($i = 0; $i -lt $exes.Count; $i++) { Say ("  {0}. {1}" -f ($i + 1), $exes[$i].Name) }
    $n = Ask 'Nomor installer DRIVER PRINTER yang dijalankan [Enter = lewati]' '0'
    if ($n -notmatch '^\d+$' -or [int]$n -lt 1 -or [int]$n -gt $exes.Count) { return $false }
    $exe = $exes[[int]$n - 1]
    Unblock-File $exe.FullName -ErrorAction SilentlyContinue
    Say "Menjalankan: $($exe.Name). Ikuti jendela installer sampai selesai." Cyan
    Start-Process $exe.FullName -Wait
    Read-Host 'Tekan Enter setelah installer selesai' | Out-Null
    return $true
}

# Pastikan printer yang tercolok punya driver dan antrean printernya muncul di Windows.
function Install-Drivers {
    Show-UsbStatus
    $noDriver = @(Get-UsbPrinters | Where-Object { $_.ConfigManagerErrorCode -ne 0 })
    $usbCount = @(Get-UsbPrinters).Count
    $queues   = @(Get-HostPrinters).Count
    if ($noDriver.Count -eq 0 -and ($queues -gt 0 -or $usbCount -eq 0)) { return }

    Say 'Ada printer yang belum punya driver. Mencoba memasang...' Cyan
    $did = Install-DriverFromExe
    if (-not $did) { $did = Install-DriverFromWU }
    try { & pnputil.exe /scan-devices | Out-Null } catch { }
    for ($i = 0; $i -lt 8 -and @(Get-HostPrinters).Count -le $queues; $i++) { Start-Sleep -Seconds 5 }
    if (-not $did) {
        Warn ('Driver belum bisa dipasang otomatis. Unduh "Printer Driver" Windows 64-bit dari situs resmi merk printernya ' +
              '(versi offline, bukan "Web installer"), taruh .exe-nya di folder yang sama dengan file ini, lalu jalankan lagi.')
    }
}

# ---------------------------------------------------------------- AKUN CETAK + FOLDER BERSAMA (PC PRINTER)
function Test-LocalUser($name) {
    & cmd.exe /c "net user $name >nul 2>&1"
    return ($LASTEXITCODE -eq 0)
}
function Set-PrintAccount {
    if (Test-LocalUser $PrintUser) {
        & net.exe user $PrintUser $PrintPass /active:yes | Out-Null
    } else {
        & net.exe user $PrintUser $PrintPass /add /expires:never /passwordchg:no /comment:"Akun cetak printer klinik" | Out-Null
    }
    if (-not (Test-LocalUser $PrintUser)) { Warn 'Akun cetak tidak bisa dibuat; PC lain tidak akan bisa tersambung otomatis.'; return }
    try {
        $u = [ADSI]"WinNT://$env:COMPUTERNAME/$PrintUser,user"
        $u.UserFlags.Value = [int]$u.UserFlags.Value -bor 0x10000
        $u.CommitChanges()
    } catch { }
    $hide = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon\SpecialAccounts\UserList'
    New-Item -Path $hide -Force | Out-Null
    Set-ItemProperty -Path $hide -Name $PrintUser -Value 0 -Type DWord
    Ok "Akun cetak '$PrintUser' siap (dipakai PC lain secara otomatis)."
}
function Read-PubList($path) {
    if (-not (Test-Path $path)) { return }
    foreach ($line in Get-Content $path) {
        $f = "$line".Split('|')
        if ($f.Count -ge 4 -and $f[0].Trim()) {
            [pscustomobject]@{ Share = $f[0].Trim(); Name = $f[1].Trim(); Driver = $f[2].Trim(); Posisi = $f[3].Trim(); HasDrv = ("$($f[4])".Trim() -eq '1') }
        }
    }
}
# Tulis daftar printer yang dibagikan PC ini + bagikan foldernya (hanya-baca).
function Publish-List {
    New-Item -ItemType Directory -Force -Path $PubDir | Out-Null
    $lines = @("#PC|$env:COMPUTERNAME")   # PC lain mengenali PC ini dari namanya walau alamatnya berubah
    foreach ($p in @(Get-SharedPrinters | Where-Object { $_.ShareName -match '^KP\d+$' })) {
        $has = if (Test-Path (Join-Path $PubDir "$($p.ShareName)\*.inf")) { '1' } else { '0' }
        $lines += "$($p.ShareName)|$($p.Name)|$($p.DriverName)|$(Format-Text $p.Location)|$has"
    }
    Set-Content -Path $PubList -Value $lines
    $everyone = (New-Object Security.Principal.SecurityIdentifier 'S-1-1-0').Translate([Security.Principal.NTAccount]).Value
    & cmd.exe /c "net share $PubShare /delete /y >nul 2>&1"
    & cmd.exe /c "net share $PubShare=`"$PubDir`" /grant:`"$everyone`",READ >nul 2>&1"
    if ($LASTEXITCODE -eq 0) { Ok "Daftar printer dan driver dibagikan untuk PC lain ($($lines.Count - 1) printer)." }
    else { Warn 'Folder daftar printer tidak bisa dibagikan; PC lain tidak akan menemukan printer PC ini.' }
}
function Get-NextShare {
    $used = @(Get-Printer -ErrorAction SilentlyContinue | Where-Object { $_.ShareName } | ForEach-Object { $_.ShareName })
    for ($i = 1; $i -lt 100; $i++) { if ($used -notcontains "$Prefix$i") { return "$Prefix$i" } }
    Fail 'Terlalu banyak printer yang dibagikan di PC ini.'
}

# Bagikan satu printer: tanya merk/tipe + posisi, ganti nama, bagikan, salin drivernya untuk PC lain.
function Publish-Printer($p) {
    Say ''
    Say "-- Printer: $($p.Name)  (driver: $($p.DriverName), port: $($p.PortName)) --" Cyan
    $curModel = if ($p.Name -match '^(.+?) - ') { $Matches[1] } else { Get-Model $p.DriverName }
    $model  = Ask "MERK & TIPE [Enter = $curModel]" $curModel
    $posDef = if ($Silent -and $Server) { $Server } else { "$($p.Location)" }
    $posisi = Ask "POSISI printer ini, teks bebas (contoh: Apotek, Nurse Station Poli 1) [Enter = $posDef]" $posDef
    $nice   = Get-NiceName $model $posisi
    $name   = $p.Name
    if ($name -ne $nice) {
        if (Get-Printer -Name $nice -ErrorAction SilentlyContinue) { Warn "Nama '$nice' sudah dipakai printer lain; nama lama dipertahankan." }
        else { Rename-Printer -Name $name -NewName $nice; $name = $nice }
    }
    $share = if ($p.Shared -and $p.ShareName -match '^KP\d+$') { $p.ShareName } else { Get-NextShare }
    Set-Printer -Name $name -Shared $true -ShareName $share -Comment 'PRINTER-KLINIK'
    if (Format-Text $posisi) { Set-Printer -Name $name -Location (Format-Text $posisi) }
    Ok "Dibagikan: $name   (\\$env:COMPUTERNAME\$share)"

    # Salin driver agar PC lain bisa memasangnya tanpa installer.
    try {
        $drv = Get-PrinterDriver -Name $p.DriverName -ErrorAction Stop
        $dst = Join-Path $PubDir $share
        Remove-Item $dst -Recurse -Force -ErrorAction SilentlyContinue
        if ($drv.InfPath -and (Test-Path $drv.InfPath)) {
            New-Item -ItemType Directory -Force -Path $dst | Out-Null
            Copy-Item (Join-Path (Split-Path -Parent $drv.InfPath) '*') $dst -Recurse -Force
        } else {
            Warn 'Driver printer ini bawaan Windows; PC lain akan memakai sambungan printer biasa.'
        }
    } catch { Warn "Driver tidak bisa disalin untuk PC lain: $($_.Exception.Message)" }
    return $name
}

# ---------------------------------------------------------------- 1. PC PRINTER
function Invoke-Printer {
    Say '=== 1. PC PRINTER (printer dicolok / terpasang di PC ini) ===' Cyan
    Assert-Components @('Spooler', 'LanmanServer', 'PrintManagement')
    Enable-Svc Spooler
    Enable-Svc LanmanServer
    Repair-AppDir
    Install-Drivers

    # Antrean yang tidak bisa mencetak jangan dibagikan: sedang dihapus Windows (PendingDeletion), atau port LPT/COM
    # sementara printer USB tidak terlihat (antrean sisa; printer sebenarnya belum tersambung ke PC ini).
    $adaUsb = @(Get-UsbPrinters).Count -gt 0
    $cands = @()
    foreach ($h in @(Get-HostPrinters)) {
        if ("$($h.PrinterStatus)" -match 'PendingDeletion') { Warn "$($h.Name): sedang dihapus Windows (PendingDeletion). Jalankan menu 3 (PERBAIKI) lalu restart PC ini."; continue }
        if ($h.PortName -match '^(LPT|COM)\d' -and -not $adaUsb) { Warn "$($h.Name): memakai port $($h.PortName), bukan USB, dan printer USB tidak terlihat. Printer ini belum tersambung ke PC ini; tidak dibagikan."; continue }
        $cands += $h
    }
    if ($cands.Count -eq 0) {
        Fail ('Belum ada printer yang terpasang di PC ini. Nyalakan printer, colok kabel USB langsung ke PC (port belakang), ' +
              'pasang driver resminya, lalu jalankan lagi. Menu 4 (CEK) menunjukkan apakah Windows melihat printernya.')
    }
    Say ''
    Say 'Printer yang terpasang di PC ini:'
    Show-Printers $cands
    $picked = if ($Silent) { , $cands } else { Select-Items $cands 'Nomor printer yang DIBAGIKAN ke PC lain' }
    if ($picked.Count -eq 0) { Fail 'Tidak ada printer yang dipilih.' }

    New-Item -ItemType Directory -Force -Path $PubDir | Out-Null
    $names = @()
    foreach ($p in $picked) { $names += @(Publish-Printer $p)[-1] }

    Say ''
    Set-PrintAccount
    Publish-List
    if (Get-Service MpsSvc -ErrorAction SilentlyContinue) {
        # Grup firewall "File and Printer Sharing" (nama netral bahasa).
        # Bawaan Windows: aturan ini hanya menerima PC dari subnet yang sama (mis. 10.7.73.x). PC klinik lain bisa
        # di subnet berbeda (10.7.72.x) -> izinkan juga seluruh jaringan lokal privat (10.x, 172.16-31.x, 192.168.x).
        & netsh.exe advfirewall firewall set rule group="@FirewallAPI.dll,-28502" new enable=Yes remoteip=localsubnet,10.0.0.0/8,172.16.0.0/12,192.168.0.0/16 | Out-Null
        Ok 'Firewall berbagi printer dibuka untuk PC di jaringan klinik (juga subnet lain).'
    }
    if (Get-Module -ListAvailable NetConnection) {
        Get-NetConnectionProfile -ErrorAction SilentlyContinue | Where-Object NetworkCategory -eq 'Public' | ForEach-Object {
            try {
                Set-NetConnectionProfile -InterfaceIndex $_.InterfaceIndex -NetworkCategory Private
                Ok "Jaringan '$($_.Name)' diubah ke Private agar printer terlihat PC lain."
            } catch { Warn "Profil jaringan '$($_.Name)' tidak bisa diubah: $($_.Exception.Message)" }
        }
    }
    & powercfg.exe /change standby-timeout-ac 0 | Out-Null
    Ok 'Mode tidur (sleep) saat dicolok listrik dimatikan, agar PC lain selalu bisa mencetak.'
    $ip = Get-MyIP
    try { Save-Server $env:COMPUTERNAME $ip } catch { }
    $lama = if (Test-Path $UserFile) { "$(Get-Content $UserFile -Raw)".Trim() } else { '' }
    $nm = Format-Text (Ask "NAMA PENGGUNA PC ini untuk buku alamat (contoh: Toyib) [Enter = $(if ($lama) { $lama } else { 'nama akun Windows' })]" $lama)
    if ($nm -and $nm -ne $lama) {
        try { Write-AppFile $UserFile $nm; Ok "Nama pengguna PC ini: $nm" }
        catch { Warn "Nama pengguna tidak tersimpan ($($_.Exception.Message)); buku alamat memakai nama akun Windows." }
    }
    Send-Lapor
    Install-Tugas $TaskLapor 'lapor' 'Lapor alamat PC printer ke buku alamat'

    if (Yes 'Cetak halaman uji sekarang? (y/N)' 'n') { foreach ($n in $names) { Print-TestPage $n } }
    Say ''
    Say '================================================================' Green
    Say " SELESAI. PC PRINTER: $env:COMPUTERNAME   (IP: $ip)" Green
    foreach ($n in $names) { Say "   - $n" Green }
    Say '================================================================' Green
    Say 'Di PC lain: jalankan file ini, pilih 2. Printer di atas akan ditemukan otomatis.' Cyan
}

# ---------------------------------------------------------------- DAFTAR PC PRINTER
function Read-Servers {
    $list = @()
    if (Test-Path $AddrFile) {
        foreach ($line in Get-Content $AddrFile) {
            $f = "$line".Split('|')
            if ($f[0].Trim() -and $f[0] -notmatch '=') { $list += [pscustomobject]@{ Name = $f[0].Trim(); IP = "$($f[1])".Trim() } }
        }
    }
    return , $list
}
function Save-Server($name, $ip) {
    $all  = Read-Servers
    $list = @($all | Where-Object { $_.Name -ne $name })
    $list += [pscustomobject]@{ Name = $name; IP = "$ip" }
    Set-Content -Path $AddrFile -Value @($list | ForEach-Object { "$($_.Name)|$($_.IP)" })
}

# Login ke PC printer memakai akun cetak. Mengembalikan 0 bila berhasil, atau nomor error Windows.
function Connect-Auth($target, $hostName) {
    $out = (& cmd.exe /c "net use \\$target\IPC$ /user:$hostName\$PrintUser `"$PrintPass`" 2>&1") -join ' '
    if ($LASTEXITCODE -eq 0) { return 0 }
    if (" $out " -match '\s(\d{1,5})\s') { return [int]$Matches[1] }
    return -1
}
function Get-AuthHint($n) {
    switch ($n) {
        1326    { 'Akun/sandi cetak ditolak: jalankan menu 1 versi TERBARU di PC printer (versi file harus sama di semua PC).' }
        86      { 'Sandi cetak salah: jalankan menu 1 versi TERBARU di PC printer.' }
        1385    { 'Akun cetak tidak diizinkan masuk lewat jaringan: jalankan lagi menu 1 di PC printer.' }
        1219    { 'PC ini sudah tersambung ke PC printer dengan akun lain: restart PC ini lalu ulangi.' }
        53      { 'PC printer tidak ditemukan di jaringan: cek kabel/Wi-Fi dan pastikan PC printer menyala.' }
        67      { 'PC printer tidak ditemukan di jaringan: cek kabel/Wi-Fi dan pastikan PC printer menyala.' }
        5       { 'Akses ditolak oleh PC printer: jalankan lagi menu 1 di PC printer.' }
        default { '' }
    }
}
function Test-PubList($target) {
    try { return [bool](Test-Path "\\$target\$PubShare\printers.txt") } catch { return $false }
}

# Cari otomatis PC printer yang sedang menyala di jaringan yang sama (subnet /24).
function Find-Servers {
    $me = Get-MyIP
    $pre = @()
    foreach ($a in @($me) + @((Get-HostsMap).Values) + @(Read-Servers | ForEach-Object { $_.IP })) { if ("$a" -match '^(\d+\.\d+\.\d+)\.\d+$') { $pre += $Matches[1] } }
    $pre = @($pre | Select-Object -Unique)
    if ($pre.Count -eq 0) { return , @() }
    Say "Mencari PC printer di jaringan $(($pre | ForEach-Object { "$_.x" }) -join ', ') (sekitar 10-30 detik)..."
    $open = Find-Open445 @($pre | ForEach-Object { $p = $_; 1..254 | ForEach-Object { "$p.$_" } } | Where-Object { $_ -ne $me })

    $found = @()
    foreach ($ip in $open) {
        # Sambungan jaringan yang sudah ada milik pengguna tidak diputus.
        $rc = Connect-Auth $ip $ip
        if (($rc -eq 0 -or $rc -eq 1219) -and (Test-PubList $ip)) {
            $name = Get-PcName $ip
            if (-not $name) { $name = $ip }
            $found += [pscustomobject]@{ Name = $name; IP = $ip }
        } elseif ($rc -eq 0) {
            & cmd.exe /c "net use \\$ip\IPC$ /delete /y >nul 2>&1"
        }
    }
    return , $found
}

# Gabungkan daftar tersimpan + hasil pencarian + nama yang diketik. Mengembalikan daftar PC printer.
function Get-Servers {
    if ($Server -and $Mode -match '^(2|lain|klien|6|pindah)$') {
        $known = Read-Servers
        $list = @()
        foreach ($tok in "$Server".Split(',') | ForEach-Object { $_.Trim() } | Where-Object { $_ }) {
            $hit = $known | Where-Object { $_.Name -eq $tok } | Select-Object -First 1
            if (-not $hit -and -not (Test-IsIP $tok)) { $hit = @(Get-BukuServers $tok)[0] }
            if ($hit) { $list += $hit } else { $list += [pscustomobject]@{ Name = $tok; IP = '' } }
        }
        return , $list
    }
    $list = @()
    foreach ($b in @(Get-BukuServers | Where-Object { $_.Name -ne $env:COMPUTERNAME })) {
        if (Test-Port $b.IP) { $list += $b; Say "Dari buku alamat: $($b.Name) ($($b.IP))" }
        else { Warn "$($b.Name) ($($b.IP)) ada di buku alamat, tetapi tidak menjawab (port 445 tertutup). Di PC itu: jalankan menu 1 versi terbaru (membuka firewall untuk subnet lain), pastikan menyala dan tidak sleep." }
    }
    foreach ($f in @(Find-Servers)) { if (-not ($list | Where-Object { $_.Name -eq $f.Name -or $_.IP -eq $f.IP })) { $list += $f } }
    $saved = Read-Servers
    foreach ($k in $saved) {
        if ($k.Name -eq $env:COMPUTERNAME) { continue }
        if (-not ($list | Where-Object { $_.Name -eq $k.Name -or ($k.IP -and $_.IP -eq $k.IP) })) { $list += $k }
    }
    if ($list.Count -eq 0) {
        $typed = Ask 'Tidak ada PC printer ditemukan otomatis. Ketik NAMA PC PRINTER (pisahkan koma) [Enter = batal]' ''
        foreach ($tok in "$typed".Split(',') | ForEach-Object { $_.Trim() } | Where-Object { $_ }) { $list += [pscustomobject]@{ Name = $tok; IP = '' } }
    }
    return , $list
}

# Hubungi satu PC printer: login, baca daftar printernya. Mengembalikan daftar printer di PC itu.
function Get-RemotePrinters($s) {
    $target = $null
    foreach ($c in @($s.Name, $s.IP) | Where-Object { $_ } | Select-Object -Unique) {
        if (Test-Port $c) { $target = $c; break }
    }
    if (-not $target) { Warn "PC printer $($s.Name) tidak terjangkau (mati / sleep / beda jaringan)."; return }
    foreach ($t in @($target, $s.Name, $s.IP) | Where-Object { $_ } | Select-Object -Unique) {
        & cmdkey.exe /add:$t /user:"$($s.Name)\$PrintUser" /pass:$PrintPass | Out-Null
    }
    $auth = Connect-Auth $target $s.Name
    if ($auth -ne 0 -and $auth -ne 1219) { Warn "Login ke $($s.Name) gagal (kode $auth). $(Get-AuthHint $auth)" }
    if (-not (Test-PubList $target)) {
        Warn "$($s.Name): daftar printer tidak terbaca. Jalankan menu 1 versi TERBARU di PC itu."
        return
    }
    $ip = if (Test-IsIP $target) { $target } else { Resolve-IPv4 $target }
    $pc = Get-PcName $target
    if (-not $pc -and -not (Test-IsIP $s.Name)) { $pc = $s.Name }
    try { Save-Server $(if ($pc) { $pc } else { $s.Name }) $(if ($ip) { $ip } else { '' }) } catch { }
    foreach ($r in @(Read-PubList "\\$target\$PubShare\printers.txt")) {
        $r | Add-Member -NotePropertyName Server -NotePropertyValue $(if ($pc) { $pc } else { $s.Name })
        $r | Add-Member -NotePropertyName Target -NotePropertyValue $target
        $r | Add-Member -NotePropertyName IP -NotePropertyValue $ip
        $r | Add-Member -NotePropertyName PcName -NotePropertyValue $pc
        $r
    }
}

# Sambungkan PC ini ke satu printer. Mengembalikan nama printer di PC ini, atau $null.
function Connect-Printer($r) {
    # Sambung lewat NAMA PC printer (alamat jaringan bisa berubah tiap hari). Nama tak dikenali jaringan -> dicatat di hosts.
    $hostRef = $r.Target
    if ($r.PcName -and $r.IP) {
        if ((Resolve-IPv4 $r.PcName) -ne $r.IP) { Set-HostsEntry $r.PcName $r.IP; Ok "Nama $($r.PcName) dicatat ke alamat $($r.IP) (diperbarui otomatis bila berubah)." }
        & cmdkey.exe /add:$($r.PcName) /user:"$($r.PcName)\$PrintUser" /pass:$PrintPass | Out-Null
        [void](Connect-Auth $r.PcName $r.PcName)
        $hostRef = $r.PcName
    }
    $unc = "\\$hostRef\$($r.Share)"
    # Sambungan lama lewat alamat (versi sebelumnya) -> dipindah ke nama, printer & antreannya tetap.
    $lama = Get-Printer -ErrorAction SilentlyContinue | Where-Object { $_.Type -eq 'Local' -and $r.IP -and $_.PortName -eq "\\$($r.IP)\$($r.Share)" } | Select-Object -First 1
    if ($lama -and $unc -ne $lama.PortName) {
        if (-not (Get-PrinterPort -Name $unc -ErrorAction SilentlyContinue)) { Add-PrinterPort -Name $unc }
        $portLama = $lama.PortName
        Set-Printer -Name $lama.Name -PortName $unc
        Remove-PrinterPort -Name $portLama -ErrorAction SilentlyContinue
        Ok "Sambungan $($lama.Name) dipindah dari alamat $($r.IP) ke nama $hostRef."
    }
    $existing = Get-Printer -ErrorAction SilentlyContinue | Where-Object { $_.Type -eq 'Local' -and $_.PortName -eq $unc } | Select-Object -First 1
    if ($existing) {
        if ($existing.Name -ne $r.Name -and -not (Get-Printer -Name $r.Name -ErrorAction SilentlyContinue)) {
            Rename-Printer -Name $existing.Name -NewName $r.Name
            Ok "Sudah tersambung, nama disesuaikan: $($r.Name)"
            return $r.Name
        }
        Ok "Sudah tersambung: $($existing.Name)"
        return $existing.Name
    }

    # Jalur utama: printer lokal bernama rapi yang port-nya mengarah ke PC printer.
    try {
        if (-not (Get-PrinterDriver -Name $r.Driver -ErrorAction SilentlyContinue) -and $r.HasDrv) {
            Say "Mengambil driver '$($r.Driver)' dari $($r.Server)..."
            $tmp = Join-Path $env:TEMP "kp-driver-$($r.Share)"
            Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
            New-Item -ItemType Directory -Force -Path $tmp | Out-Null
            Copy-Item "\\$($r.Target)\$PubShare\$($r.Share)\*" $tmp -Recurse -Force
            foreach ($inf in Get-ChildItem $tmp -Recurse -Filter *.inf) { & pnputil.exe /add-driver $inf.FullName /install | Out-Null }
            Add-PrinterDriver -Name $r.Driver
        }
        if (Get-PrinterDriver -Name $r.Driver -ErrorAction SilentlyContinue) {
            if (-not (Get-PrinterPort -Name $unc -ErrorAction SilentlyContinue)) { Add-PrinterPort -Name $unc }
            $pname = $r.Name
            if (Get-Printer -Name $pname -ErrorAction SilentlyContinue) { $pname = "$pname ($($r.Server))" }
            if (-not (Get-Printer -Name $pname -ErrorAction SilentlyContinue)) {
                Add-Printer -Name $pname -DriverName $r.Driver -PortName $unc
                if ($r.Posisi) { Set-Printer -Name $pname -Location $r.Posisi }
            }
            Ok "Tersambung: $pname"
            return $pname
        }
    } catch { Warn "Printer '$($r.Name)' tidak bisa dibuat sebagai printer lokal: $($_.Exception.Message)" }

    # Cadangan: sambungan printer Windows biasa (nama akan memuat nama PC printer).
    $code = $null
    try { Add-Printer -ConnectionName $unc } catch { $code = Get-ErrCode $_ }
    $conn = Get-Printer -ErrorAction SilentlyContinue | Where-Object { $_.Type -eq 'Connection' -and $_.ShareName -eq $r.Share -and ($_.ComputerName -eq $r.Target -or $_.Name -like "\\$($r.Target)\*") } | Select-Object -First 1
    if (-not $conn) {
        Warn "Gagal tersambung ke '$($r.Name)' di $($r.Server) (kode $code). Jalankan menu 0 (DIAGNOSA) dan kirim hasilnya."
        return $null
    }
    & rundll32.exe 'printui.dll,PrintUIEntry' /ga /n"$unc"
    Ok "Tersambung (sambungan biasa): $($conn.Name)"
    return $conn.Name
}

# ---------------------------------------------------------------- 2. PC LAIN
function Invoke-Lain {
    Say '=== 2. PC LAIN (mencetak ke printer di PC lain lewat jaringan) ===' Cyan
    Assert-Components @('Spooler', 'LanmanWorkstation', 'PrintManagement')
    Enable-Svc Spooler
    Enable-Svc LanmanWorkstation
    Repair-AppDir

    $servers = Get-Servers
    if ($servers.Count -eq 0) { Fail 'Tidak ada PC printer. Jalankan dulu menu 1 di PC yang dicolok printer.' }
    $all = @()
    foreach ($s in $servers) { $all += @(Get-RemotePrinters $s) }
    if ($all.Count -eq 0) { Fail 'Tidak ada printer yang dibagikan. Jalankan menu 1 versi TERBARU di PC printer.' }

    Say ''
    Say 'Printer yang tersedia di jaringan:'
    for ($i = 0; $i -lt $all.Count; $i++) { Say ("  {0}. {1}   (di {2})" -f ($i + 1), $all[$i].Name, $all[$i].Server) }
    $picked = Select-Items $all 'Nomor printer yang dipasang di PC ini'
    if ($picked.Count -eq 0) { Fail 'Tidak ada printer yang dipilih.' }

    $names = @()
    foreach ($r in $picked) {
        $n = @(Connect-Printer $r)[-1]
        if ($n) { $names += $n }
    }
    if ($names.Count -eq 0) { Fail 'Tidak ada printer yang berhasil disambung.' }

    Say ''
    Say "SELESAI. Printer di PC ini ($($names.Count)):" Green
    for ($i = 0; $i -lt $names.Count; $i++) { Say ("  {0}. {1}" -f ($i + 1), $names[$i]) Green }
    Say 'Saat Ctrl+P, pilih printer sesuai posisinya di kolom Destination / Printer.' Cyan
    $d = Ask 'Nomor printer DEFAULT untuk PC ini [Enter = tidak ada]' '0'
    if ($d -match '^\d+$' -and [int]$d -ge 1 -and [int]$d -le $names.Count) { Set-Default $names[[int]$d - 1] }
    if (Yes 'Cetak halaman uji ke printer di atas? (y/N)' 'n') { foreach ($n in $names) { Print-TestPage $n } }
    if ($names.Count -lt $picked.Count) { Warn 'Sebagian printer gagal disambung, lihat pesan [!] di atas.' }
    Install-Tugas $TaskName 'pulihkan' 'Sambung ulang printer jaringan'
}

# ---------------------------------------------------------------- PULIHKAN (tugas terjadwal)
function Install-Tugas($nama, $mode, $ket) {
    try {
        New-Item -ItemType Directory -Force -Path $TaskDir | Out-Null
        $dst = Join-Path $TaskDir 'PRINTER-KLINIK.bat'
        if ($env:KP_SELF -ne $dst) { Copy-Item $env:KP_SELF $dst -Force }
        $act = New-ScheduledTaskAction -Execute 'cmd.exe' -Argument "/c `"$dst`" $mode"
        $trg = @((New-ScheduledTaskTrigger -AtStartup), (New-ScheduledTaskTrigger -AtLogOn),
                 (New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(2) -RepetitionInterval (New-TimeSpan -Minutes 10)))
        $pr  = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
        $set = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Minutes 10)
        Register-ScheduledTask -TaskName $nama -Action $act -Trigger $trg -Principal $pr -Settings $set -Force | Out-Null
        Ok "Tugas '$nama' dipasang: tiap 10 menit, saat PC menyala, dan saat login."
    } catch { Warn "Tugas '$ket' tidak bisa dipasang: $($_.Exception.Message)" }
}
# Printer jaringan yang PC printer-nya tidak menjawab -> cari alamat barunya, perbarui hosts.
# Pemindaian jaringan paling sering sekali per jam per PC printer (malam hari PC printer biasa mati).
function Invoke-Pulihkan {
    Say '=== PULIHKAN SAMBUNGAN PRINTER JARINGAN ===' Cyan
    $map = Get-HostsMap
    $akhir = @{}
    if (Test-Path $ScanFile) { foreach ($l in Get-Content $ScanFile) { $f = "$l".Split('|'); if ($f.Count -eq 2) { $akhir[$f[0]] = [int64]$f[1] } } }
    $pulih = @()
    $sudah = @{}
    foreach ($p in @(Get-ClientPrinters | Where-Object Type -eq 'Local')) {
        try {
            if ($p.PortName -notmatch '^\\\\([^\\]+)\\') { continue }
            $h = $Matches[1]
            if ($sudah.ContainsKey($h)) { if ($sudah[$h]) { $pulih += $p.Name }; continue }
            $sudah[$h] = $false
            if (Test-Port $h) { continue }
            if (Test-IsIP $h) { Warn "$($p.Name) masih memakai alamat $h. Jalankan menu 6 (PINDAH) sekali agar memakai nama PC printer."; continue }
            $k = $h.ToUpper()
            $boleh = -not $akhir.ContainsKey($k) -or ((Get-Date).Ticks - $akhir[$k]) -gt [TimeSpan]::FromHours(1).Ticks
            $ip = Find-PcPrinter $h $map[$k] -tanpaPindai:(-not $boleh)
            if (-not $ip -and $boleh) { $akhir[$k] = (Get-Date).Ticks }
            if ($ip) {
                Set-HostsEntry $h $ip; $map[$k] = $ip; $akhir.Remove($k); $sudah[$h] = $true; $pulih += $p.Name
                Ok "PC printer $h kini di alamat $ip."
            } elseif ($boleh) { Warn "PC printer $h tidak ditemukan (mati / sleep / pindah jaringan). Dicari lagi sejam lagi." }
        } catch { Warn "$($p.Name): $($_.Exception.Message)" }
    }
    try { Set-Content -Path $ScanFile -Value @($akhir.GetEnumerator() | ForEach-Object { "$($_.Key)|$($_.Value)" }) } catch { }
    if ($pulih.Count -eq 0) { return }
    # Cetakan yang tertahan dikirim ulang. Spooler hanya dinyalakan ulang bila PC ini tidak membagikan printer
    # (PC printer untuk PC lain tidak boleh terputus cetakannya).
    if (@(Get-SharedPrinters).Count -eq 0) { Restart-Service Spooler -Force; Ok 'Print Spooler dinyalakan ulang; cetakan yang tertunda dikirim ulang.' }
    else { foreach ($n in $pulih | Select-Object -Unique) { Get-PrintJob -PrinterName $n -ErrorAction SilentlyContinue | ForEach-Object { try { Restart-PrintJob -InputObject $_ } catch { } } }; Ok 'Cetakan yang tertunda dikirim ulang.' }
}

# ---------------------------------------------------------------- 3. PERBAIKI
function Invoke-Perbaiki {
    Say '=== 3. PERBAIKI ANTREAN CETAK MACET ===' Cyan
    Assert-Components @('Spooler')
    Stop-Service Spooler -Force
    Remove-Item (Join-Path $env:SystemRoot 'System32\spool\PRINTERS\*') -Force -ErrorAction SilentlyContinue
    Enable-Svc Spooler
    Ok 'Antrean cetak dibersihkan dan Print Spooler dinyalakan ulang.'
    Say 'Jika ini PC lain dan masih gagal: pastikan PC printer menyala dan tidak sedang sleep.' Cyan
}

# ---------------------------------------------------------------- 4. CEK
function Invoke-Cek {
    Say '=== 4. CEK KOMPONEN WINDOWS + PRINTER ===' Cyan
    Get-Components | Format-Table -AutoSize | Out-String | Write-Host
    Show-UsbStatus
    if (Get-Module -ListAvailable PrintManagement) {
        Say ''
        Say 'Printer fisik di PC ini:'
        $h = @(Get-HostPrinters); if ($h.Count) { Show-Printers $h } else { Say '  (tidak ada)' }
        Say 'Printer klinik dari PC lain:'
        $c = @(Get-ClientPrinters); if ($c.Count) { Show-Printers $c } else { Say '  (tidak ada)' }
    }
    Say ''
    Say 'Spooler wajib di semua PC. LanmanServer wajib di PC printer. LanmanWorkstation wajib di PC lain.'
    Say 'TIDAK ADA = komponen dibuang Windows Lite. Stopped/Disabled tidak masalah, dinyalakan otomatis.'
}

# ---------------------------------------------------------------- 5. DRIVER SAJA
function Invoke-Driver {
    Say '=== 5. DRIVER SAJA (pasang driver printer yang dicolok di PC ini, tanpa dibagikan) ===' Cyan
    Assert-Components @('Spooler', 'PrintManagement')
    Enable-Svc Spooler
    Install-Drivers
    $h = @(Get-HostPrinters)
    if ($h.Count -eq 0) { Fail 'Belum ada printer yang terpasang. Pasang driver resminya, lalu jalankan lagi.' }
    Say 'Printer yang siap dipakai di PC ini:'
    Show-Printers $h
}

# ---------------------------------------------------------------- 6. PINDAH / 8. LEPAS
function Remove-ClientPrinters {
    $n = 0
    foreach ($c in @(Get-ClientPrinters)) {
        try {
            if ($c.Type -eq 'Connection') {
                & rundll32.exe 'printui.dll,PrintUIEntry' /gd /q /n"\\$($c.ComputerName)\$($c.ShareName)"
                Remove-Printer -Name $c.Name
            } else {
                Remove-Printer -Name $c.Name
                Remove-PrinterPort -Name $c.PortName -ErrorAction SilentlyContinue
            }
            Ok "Dilepas: $($c.Name)"
            $n++
        } catch { Warn "Tidak bisa melepas $($c.Name): $($_.Exception.Message)" }
    }
    return $n
}
function Invoke-Pindah {
    Say '=== 6. PINDAH (lepas semua printer jaringan di PC ini, lalu pilih ulang) ===' Cyan
    Assert-Components @('Spooler', 'LanmanWorkstation', 'PrintManagement')
    Enable-Svc Spooler
    [void](Remove-ClientPrinters)
    Invoke-Lain
}
function Invoke-Lepas {
    Say '=== 8. LEPAS ===' Cyan
    Say 'PC lain   : semua printer jaringan klinik dihapus dari PC ini.'
    Say 'PC printer: berbagi printer dihentikan dan akun cetak dihapus (printer dan driver tetap ada).'
    Assert-Components @('Spooler', 'PrintManagement')
    if (-not (Yes 'Lanjutkan? (y/N)' $(if ($Silent) { 'y' } else { 'n' }))) { Say 'Dibatalkan.'; return }
    Enable-Svc Spooler
    $n = Remove-ClientPrinters
    $shared = @(Get-SharedPrinters)
    foreach ($sp in $shared) { Set-Printer -Name $sp.Name -Shared $false; Ok "Berbagi dihentikan: $($sp.Name)" }
    if ($shared.Count -gt 0 -or (Test-Path $PubDir)) {
        & cmd.exe /c "net share $PubShare /delete /y >nul 2>&1"
        Remove-Item $AppDir -Recurse -Force -ErrorAction SilentlyContinue
    }
    foreach ($tn in $TaskName, $TaskLapor) { if (Get-ScheduledTask -TaskName $tn -ErrorAction SilentlyContinue) { Unregister-ScheduledTask -TaskName $tn -Confirm:$false; Ok "Tugas '$tn' dihapus." } }
    if ((Get-HostsMap).Count -gt 0) {
        try {
            Copy-Item $HostsFile "$HostsFile.kp-cadangan" -Force -ErrorAction SilentlyContinue
            Set-Content -Path $HostsFile -Value @(Get-Content $HostsFile | Where-Object { $_ -notmatch "$([regex]::Escape($HostsTag))\s*$" }) -Encoding ASCII
            & ipconfig.exe /flushdns | Out-Null
            Ok 'Catatan alamat PC printer di berkas hosts dihapus.'
        } catch { Warn "Berkas hosts tidak bisa dibersihkan: $($_.Exception.Message)" }
    }
    Remove-Item $AppDir, $TaskDir -Recurse -Force -ErrorAction SilentlyContinue
    foreach ($acct in $PrintUser, 'cetakl3210') {
        if (Test-LocalUser $acct) {
            & net.exe user $acct /delete | Out-Null
            Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon\SpecialAccounts\UserList' -Name $acct -ErrorAction SilentlyContinue
            Ok "Akun cetak '$acct' dihapus."
        }
    }
    if ($n -eq 0 -and $shared.Count -eq 0) { Warn 'Tidak ada printer klinik di PC ini.' }
    Say 'SELESAI.' Green
}

# ---------------------------------------------------------------- 7. TES CETAK
function Invoke-Tes {
    Say '=== 7. STATUS PRINTER + TES CETAK ===' Cyan
    Assert-Components @('Spooler', 'PrintManagement')
    Enable-Svc Spooler
    $list = @(@(Get-HostPrinters) + @(Get-ClientPrinters) | Sort-Object Name -Unique)
    if ($list.Count -eq 0) { Fail 'Belum ada printer di PC ini. Jalankan menu 1 atau 2.' }
    Show-Printers $list
    $picked = Select-Items $list 'Nomor printer yang dites'
    foreach ($p in $picked) {
        if ($p.PortName -match '^\\\\([^\\]+)\\' -and -not (Test-Port $Matches[1])) {
            Warn "PC printer ($($Matches[1])) tidak terjangkau: pastikan menyala dan tidak sleep."
        }
        Print-TestPage $p.Name
    }
}

# ---------------------------------------------------------------- 9. GANTI NAMA
function Invoke-Rename {
    Say '=== 9. GANTI NAMA PRINTER ===' Cyan
    Assert-Components @('Spooler', 'PrintManagement')
    Enable-Svc Spooler
    $list = @(@(Get-HostPrinters) + @(Get-ClientPrinters | Where-Object Type -eq 'Local') | Sort-Object Name -Unique)
    if ($list.Count -eq 0) { Fail 'Tidak ada printer yang bisa diganti namanya di PC ini.' }
    Show-Printers $list
    $n = if ($list.Count -gt 1) { Ask 'Nomor printer yang diganti namanya [Enter = 1]' '1' } else { '1' }
    if ($n -notmatch '^\d+$' -or [int]$n -lt 1 -or [int]$n -gt $list.Count) { Fail 'Nomor tidak dikenal.' }
    $p = $list[[int]$n - 1]
    $curModel = if ($p.Name -match '^(.+?) - ') { $Matches[1] } else { Get-Model $p.DriverName }
    $model  = Ask "MERK & TIPE [Enter = $curModel]" $curModel
    $posisi = if ($Silent) { $Server } else { Ask 'POSISI baru, teks bebas (contoh: Apotek)' "$($p.Location)" }
    $new = Get-NiceName $model $posisi
    if ($new -eq $p.Name) { Say 'Nama tidak berubah.'; return }
    if (Get-Printer -Name $new -ErrorAction SilentlyContinue) { Fail "Sudah ada printer bernama '$new' di PC ini." }
    Rename-Printer -Name $p.Name -NewName $new
    if (Format-Text $posisi) { Set-Printer -Name $new -Location (Format-Text $posisi) }
    Ok "Nama printer: $($p.Name) -> $new"
    if ($p.Shared -and $p.ShareName -match $ShareRx) {
        Publish-List
        Say 'Di PC lain: jalankan menu 2 lagi agar nama di sana ikut berubah.' Cyan
    }
}

# ---------------------------------------------------------------- S. SCAN ULANG
function Invoke-Scan {
    Say '=== S. SCAN ULANG (hapus daftar tersimpan, cari PC printer yang sedang menyala) ===' Cyan
    if (Test-Path $AddrFile) { try { Remove-Item $AddrFile -Force; Ok 'Daftar PC printer yang tersimpan dihapus.' } catch { } }
    $found = Find-Servers
    if ($found.Count -eq 0) {
        Warn 'Tidak ada PC printer yang sedang menyala di jaringan ini.'
        Say 'Pastikan PC printer menyala, satu jaringan, dan menu 1 versi terbaru sudah dijalankan di sana.'
        return
    }
    foreach ($s in $found) {
        Say ''
        Say "PC printer: $($s.Name)   (IP $($s.IP))" Green
        foreach ($r in @(Get-RemotePrinters $s)) { Say "   - $($r.Name)" }
    }
    Say ''
    Say 'Daftar baru disimpan. Jalankan menu 2 untuk memasang, atau menu 6 untuk mengganti yang lama.' Cyan
}

# ---------------------------------------------------------------- 0. DIAGNOSA
function Invoke-Diagnosa {
    Say '=== 0. DIAGNOSA (laporan lengkap, disimpan ke Desktop) ===' Cyan
    $script:Rep = @()
    function D($m) { Say $m; $script:Rep += "$m" }
    $cv = Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion' -ErrorAction SilentlyContinue
    D "Waktu      : $(Get-Date -Format 'yyyy-MM-dd HH:mm')"
    D "PC         : $env:COMPUTERNAME   akun: $env:USERNAME"
    D "Windows    : $($cv.ProductName) $($cv.DisplayVersion) build $($cv.CurrentBuild).$($cv.UBR)"
    D "IP         : $(Get-MyIP)"
    D ''
    D '-- Komponen Windows --'
    foreach ($c in Get-Components) { D ("{0,-18} {1}" -f $c.Komponen, $c.Status) }
    D ''
    D '-- Printer di PC ini --'
    foreach ($d in @(Get-UsbPrinters)) { D "USB        : $($d.Name) (kode $($d.ConfigManagerErrorCode))" }
    if (Get-Module -ListAvailable PrintManagement) {
        foreach ($x in @(Get-Printer -ErrorAction SilentlyContinue)) {
            D ("Printer    : {0} | {1} | driver {2} | port {3} | share {4} | status {5}" -f $x.Name, $x.Type, $x.DriverName, $x.PortName, $x.ShareName, $x.PrinterStatus)
        }
    } else { D 'Modul PrintManagement TIDAK ADA' }
    D ("Akun cetak : " + $(if (Test-LocalUser $PrintUser) { 'ada di PC ini' } else { 'tidak ada di PC ini (wajar untuk PC lain)' }))
    D ("Daftar bagi: " + $(if (Test-Path $PubList) { (Get-Content $PubList) -join ' ; ' } else { 'tidak ada (wajar untuk PC lain)' }))
    $hm = Get-HostsMap
    D ("Catatan hosts: " + $(if ($hm.Count) { ($hm.GetEnumerator() | ForEach-Object { "$($_.Key)=$($_.Value)" }) -join ' ; ' } else { 'tidak ada' }))
    $tk = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
    D ("Sambung ulang otomatis: " + $(if ($tk) { "terpasang ($($tk.State)), terakhir: $((Get-ScheduledTaskInfo -TaskName $TaskName).LastRunTime)" } else { 'belum (jalankan menu 2 atau 6)' }))
    $tl = Get-ScheduledTask -TaskName $TaskLapor -ErrorAction SilentlyContinue
    D ("Lapor alamat otomatis: " + $(if ($tl) { "terpasang ($($tl.State)), terakhir: $((Get-ScheduledTaskInfo -TaskName $TaskLapor).LastRunTime)" } else { 'tidak (wajar untuk PC lain)' }))
    $bk = @(Get-BukuServers)
    D ("Buku alamat: " + $(if ($bk.Count) { ($bk | ForEach-Object { "$($_.Name)=$($_.IP)" }) -join ' ; ' } else { 'kosong / tidak terjangkau' }))

    $targets = @(Read-Servers | ForEach-Object { $_ })
    foreach ($c in @(Get-ClientPrinters)) {
        $h = if ($c.PortName -match '^\\\\([^\\]+)\\') { $Matches[1] } else { $c.ComputerName }
        if ($h -and -not ($targets | Where-Object { $_.Name -eq $h -or $_.IP -eq $h })) { $targets += [pscustomobject]@{ Name = $h; IP = '' } }
    }
    foreach ($s in $targets | Where-Object { $_.Name -ne $env:COMPUTERNAME }) {
        D ''
        D "-- Uji ke PC printer: $($s.Name) --"
        $ipRes = ''
        try { $ipRes = ([Net.Dns]::GetHostAddresses($s.Name) | Where-Object { $_.AddressFamily -eq 'InterNetwork' } | Select-Object -First 1).ToString() } catch { }
        D ("Nama -> IP : " + $(if ($ipRes) { $ipRes } else { "GAGAL (nama tidak dikenali jaringan); IP tersimpan: $($s.IP)" }))
        $t = if ($ipRes) { $s.Name } elseif ($s.IP) { $s.IP } else { $null }
        if (-not $t) { continue }
        $p445 = Test-Port $t
        D ("Port 445   : " + $(if ($p445) { 'terbuka' } else { 'TERTUTUP (PC mati / firewall / beda jaringan)' }))
        if (-not $p445) { continue }
        $a = Connect-Auth $t $s.Name
        D ("Login cetak: " + $(if ($a -eq 0) { 'berhasil' } else { "kode $a. $(Get-AuthHint $a)" }))
        if (Test-PubList $t) {
            foreach ($r in @(Read-PubList "\\$t\$PubShare\printers.txt")) { D "Dibagikan  : $($r.Share) | $($r.Name) | driver $($r.Driver) | salinan driver: $($r.HasDrv)" }
        } else { D 'Daftar printer: TIDAK terbaca (jalankan menu 1 versi terbaru di PC printer)' }
    }
    $file = Join-Path ([Environment]::GetFolderPath('Desktop')) "Diagnosa-Printer-$env:COMPUTERNAME.txt"
    try { Set-Content -Path $file -Value $script:Rep; Ok "Laporan disimpan: $file (kirim file ini bila perlu bantuan)" }
    catch { Warn "Laporan tidak bisa disimpan: $($_.Exception.Message)" }
}

# ---------------------------------------------------------------- MENU
if (-not $Mode) {
    Say ''
    Say '  ====================  PRINTER KLINIK  ====================' Cyan
    Say '           semua merk/tipe  |  (Merk) (Tipe) - (posisi)'
    Say ''
    Say '  PASANG' Yellow
    Say '    1  PC PRINTER    bagikan printer yang dicolok di PC ini'
    Say '    2  PC LAIN       pasang printer dari PC lain (bisa beberapa)'
    Say '    5  DRIVER SAJA   pasang driver printer di PC ini, tanpa dibagikan'
    Say ''
    Say '  KELOLA' Yellow
    Say '    S  SCAN ULANG    hapus daftar lama, cari PC printer yang menyala'
    Say '    6  PINDAH        lepas printer jaringan di PC ini, pilih ulang'
    Say '    9  GANTI NAMA    ganti merk/tipe/posisi pada nama printer'
    Say '    8  LEPAS         hapus printer jaringan / hentikan berbagi'
    Say ''
    Say '  BANTUAN' Yellow
    Say '    7  TES CETAK     status printer + halaman uji'
    Say '    3  PERBAIKI      cetakan macet / antre terus'
    Say '    4  CEK           komponen Windows + printer yang terlihat'
    Say '    0  DIAGNOSA      cek lengkap + laporan ke Desktop'
    Say ''
    $Mode = (Read-Host '  Ketik pilihan lalu Enter').Trim().ToLower()
}
try {
    if ($Mode -match '^(1|printer|host|2|lain|klien|6|pindah|0|diagnosa|s|scan|pulihkan|lapor)$') { $PrintPass = Get-PrintPass }
    switch -Regex ($Mode) {
        '^(1|printer|host)$'  { Invoke-Printer; break }
        '^(2|lain|klien)$'    { Invoke-Lain; break }
        '^(3|perbaiki)$'      { Invoke-Perbaiki; break }
        '^(4|cek)$'           { Invoke-Cek; break }
        '^(5|driver)$'        { Invoke-Driver; break }
        '^(6|pindah)$'        { Invoke-Pindah; break }
        '^(7|tes)$'           { Invoke-Tes; break }
        '^(8|lepas)$'         { Invoke-Lepas; break }
        '^(9|rename|nama)$'   { Invoke-Rename; break }
        '^(0|diagnosa)$'      { Invoke-Diagnosa; break }
        '^(s|scan)$'          { Invoke-Scan; break }
        '^(pulihkan)$'        { Invoke-Pulihkan; break }
        '^(lapor)$'           { Send-Lapor; break }
        default               { Fail "Pilihan tidak dikenal: $Mode" }
    }
} catch {
    Fail $_.Exception.Message
}
Stop-Transcript | Out-Null
exit 0
