/* CPPT (Poli/Ubah): tambahan untuk dr. pemakai ekstensi ini saja.
 * 1. Surat istirahat: − [n] + hari di baris Status Kunjungan → Diagnosa, Tanggal Mulai, Tanggal Selesai diisi ke formulir
 *    Surat Keterangan Sakit C-CARE (yang biasa dibuka di Detail). Tombol Cetak = tombol Cetak formulir itu (dokter/perawat yang menekan).
 * 2. ICD-10 favorit: 10 diagnosis yang paling sering Anda simpan, sekali klik menambah ke Diagnosa. Dipelajari di komputer ini.
 * 3. Ctrl+S (⌘S) = tombol Simpan C-CARE (sama seperti mengklik Simpan sendiri).
 * 4. Diagnosa (isian utama, bukan Surat istirahat): otomatis mengikuti ICD-10 yang dipilih selama belum diketik manual.
 * 5. Log anamnesa: Keluhan + Anamnesa + ICD-10 tiap CPPT disimpan (tanpa nama/No. RM) — bahan perkiraan diagnosa nanti.
 * Semua (kecuali #4) bisa dimatikan di Pengaturan → Tampilan. */
(() => {
  const m = location.pathname.match(/\/Poli\/Ubah\/(\d+)/i);
  if (!m || window.__sjcTambahan) return; window.__sjcTambahan = true;
  const ID = m[1];
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const bersih = s => String(s == null ? '' : s).replace(/\s+/g, ' ').trim();
  const wib = (n = 0) => new Date(Date.now() + 7 * 36e5 + n * 864e5).toISOString().slice(0, 10);
  const tglId = t => t ? t.slice(8, 10) + '/' + t.slice(5, 7) + '/' + t.slice(0, 4) : '';
  const BLN = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
  const tglPendek = t => +t.slice(8, 10) + ' ' + BLN[+t.slice(5, 7) - 1];
  const IK = {
    min: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M19 13H5v-2h14v2z"/></svg>',
    plus: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/></svg>',
    ok: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm-2 15-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg>',
    awas: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M1 21h22L12 2 1 21zm12-3h-2v-2h2v2zm0-4h-2v-4h2v4z"/></svg>',
    jam: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm1 11h-5v-2h3V7h2v6z"/></svg>',
    cetak: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M19 8H5a3 3 0 0 0-3 3v6h4v4h12v-4h4v-6a3 3 0 0 0-3-3zm-3 11H8v-5h8v5zm3-7a1 1 0 1 1 0-2 1 1 0 0 1 0 2zm-1-9H6v4h12V3z"/></svg>',
    bintang: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 17.27 18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/></svg>',
  };
  const gaya = document.createElement('style');
  gaya.textContent = `
  .sjc-surat-blok{margin-top:8px;padding-top:8px;border-top:1px dashed #D5E0E0;display:flex;flex-wrap:wrap;align-items:flex-start;gap:8px 12px}
  .sjc-surat-blok.tanpa-garis{margin-top:0;padding-top:0;border-top:0}.sjc-surat-fg{display:flex;flex-wrap:wrap}.sjc-st:empty,.sjc-st[hidden],.sjc-surat-blok [hidden]{display:none!important}
  .sjc-surat-blok .sjc-lbl{font-weight:700;color:#0F2742;white-space:nowrap;line-height:36px}.sjc-surat-blok .sjc-surat{flex:1 1 420px;min-width:0}
  .sjc-surat{display:flex;flex-wrap:wrap;align-items:center;gap:8px 12px;font:14px/1.4 inherit}
  .sjc-step{display:inline-flex;align-items:center;gap:6px}
  .sjc-step button{display:grid;place-items:center;width:36px;height:36px;border:1px solid #D5E0E0;border-radius:8px;background:#fff;color:#0F2742;cursor:pointer;padding:0}
  .sjc-step button:hover{border-color:#263C92;color:#263C92}.sjc-step button:disabled{opacity:.4;cursor:default}
  .sjc-step svg,.sjc-st svg,.sjc-fav svg{width:18px;height:18px;fill:currentColor}
  .sjc-step input{width:56px;height:36px;text-align:center;border:1px solid #D5E0E0;border-radius:8px;font:600 16px/1 inherit;font-variant-numeric:tabular-nums}
  .sjc-surat .sjc-cetak{display:inline-flex;align-items:center;gap:6px;height:36px;padding:0 12px;border:1px solid #263C92;border-radius:8px;background:#fff;color:#263C92;font:600 14px/1 inherit;cursor:pointer}
  .sjc-surat .sjc-cetak:hover{background:#E8ECF7}.sjc-surat .sjc-cetak:disabled{opacity:.5;cursor:default}.sjc-surat .sjc-cetak svg{width:18px;height:18px;fill:currentColor}
  .sjc-surat .sjc-rentang{color:#4F6478;font-variant-numeric:tabular-nums;min-width:120px}
  .sjc-surat .sjc-dg{flex:1 1 260px;min-width:0;height:36px;border:1px solid #D5E0E0;border-radius:8px;padding:0 10px;font:inherit}
  .sjc-st{display:inline-flex;align-items:center;gap:4px;font-size:13px;font-weight:600;flex-basis:100%}
  .sjc-st.ok{color:#3B7A1E}.sjc-st.awas{color:#B45309}.sjc-st.info{color:#4F6478}
  .sjc-fav{display:grid;grid-template-columns:repeat(auto-fill,minmax(190px,1fr));gap:6px;margin:0 0 8px}
  .sjc-fav button{display:flex;align-items:center;gap:8px;min-width:0;height:34px;border:1px solid #D5E0E0;border-radius:8px;background:#fff;color:#0F2742;padding:0 10px 0 6px;font-size:13px;line-height:1.2;text-align:left;cursor:pointer}
  .sjc-fav button i{flex:none;width:20px;height:20px;display:grid;place-items:center;border-radius:6px;background:#F2F6F6;color:#4F6478;font-style:normal;font-size:11px;font-weight:700;font-variant-numeric:tabular-nums}
  .sjc-fav button b{flex:none;font-variant-numeric:tabular-nums}.sjc-fav button span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#4F6478}
  .sjc-fav button[aria-pressed=true] i{background:#263C92;color:#fff}.sjc-fav button[aria-pressed=true] span{color:#263C92}
  .sjc-fav .sjc-fav-j{grid-column:1/-1}
  .sjc-fav button:hover{border-color:#263C92;color:#263C92}.sjc-fav button[aria-pressed=true]{background:#E8ECF7;border-color:#263C92;color:#263C92}
  .sjc-fav .sjc-fav-j{display:inline-flex;align-items:center;gap:4px;color:#4F6478;font-size:12px;font-weight:600}
  .sjc-kunci{display:inline-block;margin-left:8px;padding:1px 6px;border:1px solid #D5E0E0;border-radius:6px;color:#4F6478;font:600 11px/1.4 inherit;vertical-align:middle}`;

  function setNilai(el, v) {
    const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : el.tagName === 'SELECT' ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto, 'value').set.call(el, v);
    el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true }));
  }
  const kp = () => document.getElementById('KodePenyakit');
  const icdTerpilih = () => { const s = kp(); return s ? [...s.options].filter(o => o.selected && o.value).map(o => ({ kode: o.value, teks: bersih(o.textContent) })) : []; };

  /* ---------- 1. Surat istirahat ---------- */
  function pasangSurat() {
    if (document.getElementById('sjcSurat')) return;
    /* tempat: di baris Status Kunjungan (dekat Simpan, selalu terlihat); cadangan: baris sendiri di bawah Tindak Lanjut */
    const stk = document.getElementById('StatusKunjunganID'), tdSt = stk && stk.closest('td'), fgSt = stk && !tdSt && stk.closest('.form-group');
    const tl = document.getElementById('TindakLanjutPengobatanId'), trTl = tl && tl.closest('tr');
    if (!tdSt && !fgSt && !trTl) return;
    const td = document.createElement('div'); td.id = 'sjcSurat'; td.className = 'sjc-surat-blok';
    td.innerHTML = `<span class="sjc-lbl" id="sjcLbl">Surat istirahat</span><div class="sjc-surat">
      <span class="sjc-step" role="group" aria-labelledby="sjcLbl"><button type="button" data-d="-1" aria-label="Kurangi hari">${IK.min}</button><input id="sjcHari" inputmode="numeric" aria-label="Jumlah hari istirahat" value="0"><button type="button" data-d="1" aria-label="Tambah hari">${IK.plus}</button></span>
      <span class="sjc-rentang" id="sjcRentang">Tidak perlu</span>
      <button type="button" class="sjc-cetak" id="sjcCetak" hidden title="Cetak Surat Keterangan Sakit">${IK.cetak}Cetak</button>
      <input class="sjc-dg" id="sjcDg" aria-label="Diagnosa di surat" placeholder="Diagnosa di surat (dari ICD-10)">
      <span class="sjc-st info" id="sjcSt" role="status" aria-live="polite"></span></div>`;
    if (tdSt) tdSt.appendChild(td);
    else if (fgSt) {                                   // C-CARE asli: Status Kunjungan di kotak form-group (bukan tabel) → baris sendiri tepat di bawahnya
      const fg = document.createElement('div'); fg.className = 'form-group sjc-surat-fg';
      fg.innerHTML = '<div class="col-md-3 text-bold"><p class="media-body">Surat istirahat</p><p class="media-right">:</p></div><div class="col-md-8"></div>';
      td.querySelector('.sjc-lbl').hidden = true; td.classList.add('tanpa-garis');
      fg.querySelector('.col-md-8').appendChild(td); fgSt.after(fg);
    } else {
      const tr = document.createElement('tr'), lbl = trTl.cells[0].cloneNode(false), sel = document.createElement('td');
      lbl.textContent = 'Surat istirahat'; td.querySelector('.sjc-lbl').hidden = true;
      sel.colSpan = Math.max(1, trTl.cells.length - 1); sel.appendChild(td); tr.append(lbl, sel); trTl.after(tr);
    }
    const hari = td.querySelector('#sjcHari'), dg = td.querySelector('#sjcDg'), st = td.querySelector('#sjcSt'), rentang = td.querySelector('#sjcRentang');
    const cetak = td.querySelector('#sjcCetak');
    let token = null, tersembunyi = [], dgManual = false, tunda = null, tersimpan = null;
    const status = (k, t) => { st.className = 'sjc-st ' + k; st.innerHTML = (k === 'ok' ? IK.ok : k === 'awas' ? IK.awas : IK.jam) + '<span></span>'; st.lastChild.textContent = t; st.hidden = !t; };
    const n = () => Math.max(0, Math.min(30, parseInt(hari.value, 10) || 0));
    const tanggal = () => ({ mulai: wib(), selesai: wib(Math.max(0, n() - 1)) });
    const dgOtomatis = () => icdTerpilih().map(x => x.teks.replace(/^[A-Z]\d+(\.\d+)?\s*\/\s*/, '')).join(', ');
    function gambar() {
      const k = n(), t = tanggal();
      td.querySelector('[data-d="-1"]').disabled = k === 0;
      rentang.textContent = k ? `${k} hari · ${tglPendek(t.mulai)}${k > 1 ? '–' + tglPendek(t.selesai) : ''}` : 'Tidak perlu';
      dg.hidden = !k; cetak.hidden = !k;
      if (k && !dgManual) dg.value = dgOtomatis();
    }
    async function bacaForm() {                                      // nilai yang sudah tersimpan + token formulir
      const d = new DOMParser().parseFromString(await (await fetch('/RekapRekamMedis/SuratKeteranganSakit/' + ID, { credentials: 'include', cache: 'no-store', priority: 'low' })).text(), 'text/html');
      const f = d.querySelector('form'); if (!f) throw new Error('formulir surat tidak ditemukan');
      token = (f.querySelector('[name=__RequestVerificationToken]') || {}).value || token;
      tersembunyi = $$('input[type=hidden]', f).filter(i => i.name && i.name !== '__RequestVerificationToken').map(i => [i.name, i.value]);   // Id, __Invariant, … persis seperti formulir C-CARE
      try { chrome.storage.local.set({ diagSurat: { waktu: Date.now(), ok: !!(f.querySelector('[name=Diagnosa]') && f.querySelector('[name=Tmt]') && f.querySelector('[name=Tst]') && token) } }); } catch (e) {}   // Periksa di C-CARE
      return { dg: bersih((f.querySelector('[name=Diagnosa]') || {}).value), mulai: (f.querySelector('[name=Tmt]') || {}).value || '', selesai: (f.querySelector('[name=Tst]') || {}).value || '' };
    }
    async function simpan() {
      const k = n(); if (!k) return;
      const t = tanggal(), dgv = bersih(dg.value);
      if (!dgv) { status('awas', 'Isi diagnosa di surat dulu (pilih ICD-10 atau ketik).'); return; }
      status('info', 'Mengisi surat sakit di C-CARE…');
      try {
        if (!token) await bacaForm();
        const body = new URLSearchParams(tersembunyi.length ? tersembunyi : [['Id', ID]]);
        body.append('Diagnosa', dgv); body.append('Tmt', t.mulai); body.append('Tst', t.selesai); body.append('__RequestVerificationToken', token);
        await fetch('/RekapRekamMedis/SuratKeteranganSakit/' + ID, { method: 'POST', body, credentials: 'include' });
        const cek = await bacaForm();                                 // pastikan benar-benar tersimpan
        if (cek.mulai === t.mulai && cek.selesai === t.selesai) { tersimpan = cek; status('ok', `Terisi di C-CARE ${new Date().toTimeString().slice(0, 5).replace(':', '.')} · perawat tinggal mencetak (Detail → Cetak Surat Keterangan Sakit)`); }
        else status('awas', 'Terkirim, tetapi C-CARE tidak menampilkannya kembali. Periksa di Detail → Cetak Surat Keterangan Sakit.');
      } catch (e) { status('awas', 'Gagal mengisi surat sakit: ' + (e.message || e) + '. Coba ubah jumlah hari lagi.'); }
    }
    const jadwal = () => { clearTimeout(tunda); gambar(); if (n()) { status('info', 'Akan diisi ke C-CARE…'); tunda = setTimeout(simpan, 1200); } else status('info', tersimpan && tersimpan.mulai ? `Surat sakit sudah terisi sebelumnya (${tglId(tersimpan.mulai)}–${tglId(tersimpan.selesai)}); ubah di Detail bila perlu dibatalkan.` : ''); };
    td.querySelectorAll('[data-d]').forEach(b => b.onclick = () => { hari.value = Math.max(0, Math.min(30, n() + +b.dataset.d)); jadwal(); });
    hari.addEventListener('input', () => { hari.value = hari.value.replace(/\D/g, '').slice(0, 2); jadwal(); });
    hari.addEventListener('keydown', e => { if (e.key === 'ArrowUp' || e.key === 'ArrowDown') { e.preventDefault(); hari.value = Math.max(0, Math.min(30, n() + (e.key === 'ArrowUp' ? 1 : -1))); jadwal(); } });
    dg.addEventListener('input', () => { dgManual = true; clearTimeout(tunda); if (n()) { status('info', 'Akan diisi ke C-CARE…'); tunda = setTimeout(simpan, 1500); } });
    const s = kp(); if (s) { s.addEventListener('change', () => { if (!dgManual && n()) { gambar(); jadwal(); } }); document.addEventListener('isicepat-ubah', e => { if (/KodePenyakit/.test(e.detail || '') && !dgManual && n()) { gambar(); jadwal(); } }); }
    /* Cetak = tombol Cetak di formulir Surat Keterangan Sakit C-CARE (POST yang sama). C-CARE membalas PDF:
       di Alvisya Browser langsung ke dialog Cetak, di Chrome menjadi unduhan. Isian disimpan dulu bila belum. */
    cetak.onclick = async () => {
      if (!n()) return;
      cetak.disabled = true;
      try {
        clearTimeout(tunda);
        const t = tanggal();
        if (!tersimpan || tersimpan.mulai !== t.mulai || tersimpan.selesai !== t.selesai || tersimpan.dg !== bersih(dg.value)) await simpan();
        if (!tersimpan || tersimpan.mulai !== t.mulai) return;           // simpan gagal: pesan sudah tampil
        await bacaForm();                                                 // token formulir terbaru
        let fr = document.getElementById('sjcCetakFr');
        if (!fr) { fr = document.createElement('iframe'); fr.id = fr.name = 'sjcCetakFr'; fr.hidden = true; fr.title = 'cetak'; document.body.appendChild(fr); }
        const f = document.createElement('form'); f.method = 'post'; f.action = '/RekapRekamMedis/SuratKeteranganSakit/' + ID; f.target = 'sjcCetakFr'; f.hidden = true;
        const isian = (tersembunyi.length ? tersembunyi : [['Id', ID]]).concat([['Diagnosa', tersimpan.dg], ['Tmt', tersimpan.mulai], ['Tst', tersimpan.selesai], ['__RequestVerificationToken', token]]);
        for (const [k, v] of isian) { const i = document.createElement('input'); i.type = 'hidden'; i.name = k; i.value = v; f.appendChild(i); }
        document.body.appendChild(f); f.submit(); f.remove();
        status('ok', 'Surat dikirim ke pencetak…');
      } catch (e) { status('awas', 'Surat tidak bisa dicetak: ' + (e.message || e)); }
      finally { setTimeout(() => { cetak.disabled = false; }, 2500); }
    };
    gambar(); status('info', '');
    bacaForm().then(v => {                                           // sudah pernah diisi → tampilkan
      tersimpan = v;
      if (v.mulai && v.selesai) {
        const k = Math.round((Date.parse(v.selesai) - Date.parse(v.mulai)) / 864e5) + 1;
        if (k > 0 && k <= 30) { hari.value = k; dgManual = !!v.dg; dg.value = v.dg; gambar(); }
        status('ok', `Sudah terisi di C-CARE: ${tglId(v.mulai)}–${tglId(v.selesai)}`);
      }
    }).catch(() => {});
  }

  /* ---------- 2. ICD-10 favorit ---------- */
  async function pasangFavorit() {
    const s = kp(); if (!s) return;
    const trDg = s.closest('tr'), sel = trDg ? [...trDg.cells].find(c => c.contains(s)) : s.parentElement;
    if (!sel || sel.querySelector('.sjc-fav')) return;
    const { icdFavorit = {}, icdPilihan = [] } = await chrome.storage.local.get(['icdFavorit', 'icdPilihan']);
    /* daftar 1–12 yang Anda atur sendiri (Pengaturan → Tampilan) didahulukan; bila belum diatur → 12 tersering */
    const top = icdPilihan.filter(x => x && x.kode).length
      ? icdPilihan.filter(x => x && x.kode).slice(0, 12).map(x => [x.kode, { teks: x.teks || x.kode }])
      : Object.entries(icdFavorit).sort((a, b) => b[1].n - a[1].n || b[1].t - a[1].t).slice(0, 12);
    top.forEach(([k, x]) => { if (!icdFavorit[k]) icdFavorit[k] = x; });
    const w = document.createElement('div'); w.className = 'sjc-fav'; w.setAttribute('role', 'group'); w.setAttribute('aria-label', 'ICD-10 yang sering dipakai');
    if (!top.length) { w.innerHTML = `<span class="sjc-fav-j">${IK.bintang}ICD-10 favorit muncul setelah beberapa CPPT disimpan</span>`; sel.prepend(w); return; }
    w.innerHTML = top.map(([kode, x], i) => `<button type="button" data-k="${kode}" title="${x.teks.replace(/"/g, '&quot;')}"><i>${i + 1}</i><b>${kode}</b><span>${x.teks.replace(/^[A-Z]\d+(\.\d+)?\s*\/\s*/, '').replace(/</g, '&lt;')}</span></button>`).join('');
    sel.prepend(w);
    const tanda = () => { const ada = new Set(icdTerpilih().map(x => x.kode)); w.querySelectorAll('button').forEach(b => b.setAttribute('aria-pressed', String(ada.has(b.dataset.k)))); };
    w.addEventListener('click', e => {
      const b = e.target.closest('button'); if (!b) return;
      const x = icdFavorit[b.dataset.k]; let o = [...s.options].find(o => o.value === b.dataset.k);
      if (!o) { o = new Option(x.teks, b.dataset.k, false, false); s.appendChild(o); }
      o.selected = !o.selected; s.dispatchEvent(new Event('change', { bubbles: true })); tanda();
    });
    s.addEventListener('change', tanda); document.addEventListener('isicepat-ubah', e => { if (/KodePenyakit/.test(e.detail || '')) tanda(); }); tanda();
  }
  function catatFavorit() {                                          // dipanggil saat Simpan: hitung ICD-10 yang dipakai
    let icd = icdTerpilih(); if (!icd.length) return;
    /* v4.6.4: Simpan yang terulang di kunjungan yang sama (gagal simpan, klik dua kali) tidak dihitung lagi.
     * Penanda hanya di sessionStorage tab ini — tidak disimpan permanen. */
    const kunciSesi = 'sjcFav:' + location.pathname;
    let sudah = []; try { sudah = JSON.parse(sessionStorage.getItem(kunciSesi) || '[]'); } catch (e) {}
    icd = icd.filter(x => !sudah.includes(x.kode)); if (!icd.length) return;
    try { sessionStorage.setItem(kunciSesi, JSON.stringify(sudah.concat(icd.map(x => x.kode)))); } catch (e) {}
    chrome.storage.local.get('icdFavorit', ({ icdFavorit = {} }) => {
      icd.forEach(x => { const a = icdFavorit[x.kode] || { n: 0 }; icdFavorit[x.kode] = { n: a.n + 1, t: Date.now(), teks: x.teks }; });
      const k = Object.keys(icdFavorit); if (k.length > 300) k.sort((a, b) => icdFavorit[a].n - icdFavorit[b].n).slice(0, k.length - 300).forEach(x => delete icdFavorit[x]);
      chrome.storage.local.set({ icdFavorit });
    });
  }

  /* ---------- 5. Log anamnesa: Keluhan + Anamnesa + ICD-10 tiap CPPT disimpan (tanpa nama/No. RM) ----------
   * Bahan untuk nanti menyimpulkan diagnosa dari kata kunci (lihat Pengaturan → Tampilan → Log anamnesa). */
  function catatLogAnamnesa() {
    const icd = icdTerpilih();
    const potong = s => bersih(s).slice(0, 400);
    const keluhan = potong((document.getElementById('Keluhan') || {}).value);
    const anamnesa = potong((document.getElementById('AmnesaDokter') || {}).value);
    if (!icd.length && !keluhan && !anamnesa) return;                // tidak ada apa pun yang berarti untuk dicatat
    const kunciSesi = 'sjcLog:' + location.pathname;               // Simpan ulang kunjungan yang sama → perbarui catatan, bukan tambah
    let tLama = 0; try { tLama = +sessionStorage.getItem(kunciSesi) || 0; } catch (e) {}
    chrome.storage.local.get('logAnamnesa', ({ logAnamnesa = [] }) => {
      const baru = { t: Date.now(), keluhan, anamnesa, icd };
      const i = tLama ? logAnamnesa.findIndex(x => x.t === tLama) : -1;
      if (i >= 0) logAnamnesa[i] = baru; else logAnamnesa.push(baru);
      try { sessionStorage.setItem(kunciSesi, String(baru.t)); } catch (e) {}
      if (logAnamnesa.length > 3000) logAnamnesa = logAnamnesa.slice(logAnamnesa.length - 3000);   // batasi agar storage tidak membengkak
      chrome.storage.local.set({ logAnamnesa });
    });
  }

  /* ---------- 4. Diagnosa (isian utama) mengikuti ICD-10 terpilih ---------- */
  function pasangSinkronDiagnosa() {
    const dx = document.getElementById('Diagnosa'), s = kp();
    if (!dx || !s || window.__sjcSinkronDiagnosa) return; window.__sjcSinkronDiagnosa = true;
    const teksIcd = () => icdTerpilih().map(x => x.teks).join(', ');
    let otomatis = !bersih(dx.value);                       // kosong di awal → boleh diisi otomatis; sudah ada isi → dianggap manual, tidak ditimpa
    let sedangMengisi = false;
    function sinkron() {
      const teks = teksIcd(); if (!teks || !otomatis) return;
      sedangMengisi = true; setNilai(dx, teks); sedangMengisi = false;
    }
    dx.addEventListener('input', () => { if (!sedangMengisi) otomatis = false; });   // ketikan manual → berhenti mengikuti ICD-10 (sampai kolom dikosongkan & ICD-10 diganti lagi)
    dx.addEventListener('input', () => { if (!bersih(dx.value)) otomatis = true; });
    s.addEventListener('change', sinkron);
    document.addEventListener('isicepat-ubah', e => { if (/KodePenyakit/.test(e.detail || '')) sinkron(); });
  }

  /* ---------- 3. Ctrl+S = Simpan ---------- */
  function pasangPintasan() {
    const btn = document.getElementById('btn-simpan'); if (!btn) return;
    if (!btn.parentElement.querySelector('.sjc-kunci')) { const k = document.createElement('span'); k.className = 'sjc-kunci'; k.textContent = /Mac/i.test(navigator.platform) ? '⌘S' : 'Ctrl+S'; k.title = 'Pintasan Simpan (Alvisya Dokter)'; btn.after(k); }
    document.addEventListener('keydown', e => {
      if (!(e.ctrlKey || e.metaKey) || e.altKey || e.shiftKey || e.key.toLowerCase() !== 's') return;
      if (!ATUR.pintasan) return;
      e.preventDefault();
      if ($$('.modal.in, .modal.show').some(x => x.offsetParent !== null)) return;   // ada jendela C-CARE terbuka → jangan
      btn.click();                                                    // tombol Simpan milik C-CARE (validasi C-CARE tetap berjalan)
    }, true);
  }

  const ATUR = { surat: true, favorit: true, pintasan: true, log: true };
  chrome.storage.local.get('isiCepat', ({ isiCepat: ic = {} }) => {
    if (ic.mati) return;
    ATUR.surat = !ic.suratMati; ATUR.favorit = !ic.favoritMati; ATUR.pintasan = !ic.pintasanMati; ATUR.log = !ic.logMati;
    document.head.appendChild(gaya);
    if (ATUR.surat) pasangSurat();
    if (ATUR.favorit) pasangFavorit();
    pasangPintasan();
    pasangSinkronDiagnosa();
    const f = document.getElementById('btn-simpan') && document.getElementById('btn-simpan').form;
    if (f) f.addEventListener('submit', () => { catatFavorit(); if (ATUR.log) catatLogAnamnesa(); }, true);
  });
})();
