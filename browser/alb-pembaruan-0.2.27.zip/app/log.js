// LOG diagnostik Alvisya Browser: data\log\YYYY-MM-DD.log (14 hari, maks 5 MB/hari).
// Mencatat galat, peringatan, permintaan C-CARE yang gagal, halaman lambat/macet, dan catatan "[SJC]" dari ekstensi.
// Privasi: tanpa query string, deret angka ≥ 8 digit (NIK, no. BPJS, no. HP) disamarkan, pesan dipotong 500 karakter.
const fs = require('fs'), path = require('path');
let DIR = null;
const bersih = (s) => String(s == null ? '' : s)
  .replace(/(https?:\/\/[^\s?#"']+)[?#][^\s"']*/g, '$1?…')
  .replace(/\d{8,}/g, (m) => m.slice(0, 2) + '…' + m.slice(-2))
  .replace(/\s+/g, ' ').slice(0, 500);
function mulai(dir) {
  DIR = dir; fs.mkdirSync(DIR, { recursive: true });
  const batas = Date.now() - 14 * 864e5;
  for (const f of fs.readdirSync(DIR)) { try { if (fs.statSync(path.join(DIR, f)).mtimeMs < batas) fs.unlinkSync(path.join(DIR, f)); } catch (e) { /* abaikan */ } }
}
function tulis(sumber, tingkat, pesan) {
  if (!DIR) return;
  try {
    const d = new Date(), tgl = d.toLocaleDateString('sv'), f = path.join(DIR, tgl + '.log');
    try { if (fs.statSync(f).size > 5 * 1024 * 1024) return; } catch (e) { /* berkas baru */ }
    fs.appendFileSync(f, `${d.toLocaleTimeString('sv')} ${tingkat.padEnd(5)} [${sumber}] ${bersih(pesan)}\n`);
  } catch (e) { /* log tidak boleh mengganggu aplikasi */ }
}
const sumberDari = (u) => { const s = String(u || ''); if (s.startsWith('chrome-extension://')) return 'ekstensi:' + (s.split('/')[3] || '').split('?')[0]; try { return new URL(s).pathname.replace(/\/\d+(?=\/|$)/g, '/#'); } catch (e) { return 'halaman'; } };
/** Pasang pada satu webContents (tab, jembatan, popup, bar). */
function pantau(w, nama) {
  let mulaiMuat = 0;
  w.on('console-message', (e, lv, msg, baris, src) => {
    const lvl = e && e.level ? e.level : ['info', 'info', 'warning', 'error'][lv] || 'info';
    const m = e && e.message !== undefined ? e.message : msg, sumber = e && e.sourceId !== undefined ? e.sourceId : src;
    if (lvl === 'error' || lvl === 'warning' || /^\[(SJC|aldesk)\]/.test(m)) tulis(nama + ' ' + sumberDari(sumber), lvl === 'warning' ? 'WARN' : lvl === 'error' ? 'GALAT' : 'INFO', m);
  });
  w.on('did-fail-load', (e, kode, ket, u, utama) => { if (kode !== -3) tulis(nama, 'GALAT', `gagal muat ${utama ? 'halaman' : 'bingkai'} ${ket} (${kode}) ${u}`); });
  w.on('render-process-gone', (e, d) => tulis(nama, 'GALAT', `proses halaman berhenti: ${d.reason} (kode ${d.exitCode}) ${w.getURL()}`));
  w.on('unresponsive', () => tulis(nama, 'WARN', 'halaman tidak merespons ' + w.getURL()));
  w.on('responsive', () => tulis(nama, 'INFO', 'halaman merespons lagi'));
  w.on('preload-error', (e, p, g) => tulis(nama, 'GALAT', 'preload ' + p + ': ' + g));
  w.on('did-start-loading', () => { mulaiMuat = Date.now(); });
  w.on('did-stop-loading', () => { const ms = Date.now() - mulaiMuat; if (mulaiMuat && ms > 10000) tulis(nama, 'WARN', `muat lambat ${Math.round(ms / 1000)} dtk ${w.getURL()}`); mulaiMuat = 0; });
}
/** Permintaan ke C-CARE yang gagal (status ≥ 400 atau putus) — termasuk Simpan/AJAX yang ditolak server. */
function pantauJaringan(ses) {
  const f = { urls: ['https://c-care.ipb.ac.id/*'] };
  ses.webRequest.onCompleted(f, (d) => { if (d.statusCode >= 400) tulis('jaringan', 'GALAT', `${d.method} ${d.url} → ${d.statusCode}`); });
  ses.webRequest.onErrorOccurred(f, (d) => { if (d.error !== 'net::ERR_ABORTED') tulis('jaringan', 'GALAT', `${d.method} ${d.url} → ${d.error}`); });
  try { ses.serviceWorkers.on('console-message', (e, d) => { const x = d || e; if (x && (x.level >= 2 || /^\[(SJC|aldesk)\]/.test(x.message))) tulis('ekstensi:latar', x.level >= 3 ? 'GALAT' : x.level >= 2 ? 'WARN' : 'INFO', x.message); }); } catch (e) { /* versi Electron lama */ }
}
module.exports = { mulai, tulis, pantau, pantauJaringan, bersih, folder: () => DIR };
