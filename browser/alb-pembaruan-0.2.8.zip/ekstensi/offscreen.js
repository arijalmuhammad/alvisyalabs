/* Dokumen tersembunyi khusus memutar bunyi (service worker tidak bisa memutar audio).
 * {jenis:'selesai'|'perhatian'} = bunyi scan; {nama, volume, ulang, data} = bunyi Siap dipanggil (nama berkas di bunyi/ atau 'sendiri'). */
let sedang = null, giliran = 0;
const BOLEH = /^[a-z0-9-]+$/;
function sumber(m) {
  if (m.jenis) return m.jenis === 'perhatian' ? 'bunyi-perhatian.wav' : 'bunyi-selesai.wav';
  if (m.nama === 'sendiri' && m.data) return m.data;
  return 'bunyi/' + (BOLEH.test(m.nama || '') && m.nama !== 'sendiri' ? m.nama : 'kapsul') + '.wav';
}
async function putar(m) {
  const saya = ++giliran, src = sumber(m);
  if (sedang) { sedang.pause(); sedang = null; }
  for (let i = 0; i < (m.ulang || 1) && saya === giliran; i++) {
    const a = new Audio(src); a.volume = m.volume == null ? 0.8 : Math.max(0, Math.min(1, m.volume)); sedang = a;
    try { await a.play(); await new Promise(ok => { a.onended = ok; a.onerror = ok; setTimeout(ok, 10000); }); } catch (e) { break; }
  }
}
const awal = new URLSearchParams(location.search).get('jenis');
if (awal) putar({ jenis: awal });
chrome.runtime.onMessage.addListener((m, _p, balas) => { if (m && m.target === 'bunyi') { putar(m); balas && balas({ ok: true }); } });
