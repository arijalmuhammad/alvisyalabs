// ===== Sisi PCare: panel bridging, isi form Pelayanan, dan Mode Otomatis (▶ Jalankan) =====

// ID asli field PCare yang sudah diketahui. Field lain dicari lewat teks label.
const SELECTOR_OVERRIDE = {
  noPencarian: "#txtnokartu",          // halaman Pendaftaran (EntriDaftarDokkel)
  keluhan: "", anamnesa: "", terapiObat: "", terapiNonObat: "", bmhp: "",
  diagnosa: "", suhu: "", tb: "", bb: "", lp: "", imt: "",
  sistole: "", diastole: "", rr: "", hr: "", tglKunjungan: "", dokter: "",
};

const URL_DAFTAR = "/eclaim/EntriDaftarDokkel";
const URL_KUNJ = "/eclaim/EntriKunjunganDokkel";   // halaman Pelayanan Pasien

const DOKTER = BR.DOKTER;

// field: [key, label di PCare, label di panel, tipe]
const FIELDS = [
  ["keluhan", "Keluhan", "Keluhan", "area"],
  ["anamnesa", "Anamnesa", "Anamnesa", "area"],
  ["terapiObat", "Terapi Obat", "Terapi Obat", "area"],
  ["terapiNonObat", "Terapi Non Obat", "Terapi Non Obat", "area"],
  ["bmhp", "BMHP", "BMHP (alat kesehatan)", "area"],
  ["diagnosa", "Diagnosa", "Diagnosa (kode ICD-10)", "text"],
  ["suhu", "Suhu", "Suhu (℃)", "num"],
  ["tb", "Tinggi Badan", "TB (cm)", "num"],
  ["bb", "Berat Badan", "BB (kg)", "num"],
  ["lp", "Lingkar Perut", "Lingkar Perut (cm)", "num"],
  ["sistole", "Sistole", "Sistole", "num"],
  ["diastole", "Diastole", "Diastole", "num"],
  ["rr", "Respiratory Rate", "RR (/menit)", "num"],
  ["hr", "Heart Rate", "HR (bpm)", "num"],
];

const DEFAULTS = {
  jenisKunjungan: "Kunjungan Sakit",
  perawatan: "Rawat Jalan",
  poli: "POLI UMUM",
  prognosa: "Bonam (Baik)",
  kesadaran: "Compos mentis",
  statusPulang: "Berobat Jalan",
  alergi: "Tidak Ada",
  terapiNonObat: "Edukasi mengenai penyakit pasien dan penanganan saat dirumah.",
  bmhp: "Tidak ada alat yang digunakan",
};

// ---------- Panel ----------
function buildPanel() {
  if (document.getElementById("br-panel")) return;
  const p = document.createElement("div");
  p.id = "br-panel";
  p.innerHTML = `
    <div class="br-head">
      <div class="br-brand"><img class="br-logo" alt="IPB" src="${BR.urlLogo()}" onerror="this.style.visibility='hidden'"><div><div class="br-title">Bridging PCare</div><div class="br-sub">C-CARE → PCare · Klinik IPB · v${BR.VERSI}</div></div></div>
      <button id="br-min" class="br-ikon" title="Kecilkan / besarkan">–</button></div>
    <div class="br-proses" aria-hidden="true"></div>
    <div class="br-body">
      <button id="br-refresh" class="br-refresh">🔄 Refresh daftar pasien Baru</button>
      <div class="br-run">
        <div id="br-status" data-st="siap">Siap</div>
        <div id="br-pasien"></div>
        <button id="br-run" class="br-primary br-lebar">▶ Jalankan semua</button>
        <button id="br-nonstop" class="br-nonstop br-lebar">🌙 Jalankan Nonstop<small>tanpa pemantauan · pasien bermasalah dilewati &amp; dicatat</small></button>
        <div class="br-btns br-kontrol">
          <button id="br-next" title="Lanjutkan setelah Anda selesai">⏭ Lanjut</button>
          <button id="br-skip" title="Lewati pasien ini">⏩ Lewati</button>
          <button id="br-stop" title="Hentikan bot sekarang (tidak ada yang disimpan sesudahnya)">⏹ Berhenti</button>
        </div>
        <label class="br-switch"><input type="checkbox" id="br-auto"><span class="br-tuas"></span><span>Simpan otomatis <small>bila tidak ada peringatan</small></span></label>
        <label class="br-switch"><input type="checkbox" id="br-lanjut"><span class="br-tuas"></span><span>Lanjut otomatis <small>ke pasien berikutnya setelah tersimpan</small></span></label>
        <div id="br-lewat"></div>
      </div>
      <details class="br-manual" id="br-riwayat-box"><summary>🧹 Tanda selesai &amp; bersihkan data</summary>
        <div class="br-muted">Pasien yang ditandai bot "sudah diproses" hari ini. Salah klik? Klik ↩ agar pasien diproses lagi.</div>
        <div id="br-riwayat"></div>
        <div class="br-btns" style="flex-wrap:wrap">
          <button id="br-bersih-log" title="Kosongkan kotak Aktivitas di panel ini">🧾 Bersihkan log</button>
          <button id="br-bersih-cc" title="Hapus data C-CARE yang tersimpan di bot hari ini (diambil ulang saat dibutuhkan)">🗂 Bersihkan cache C-CARE</button>
          <button id="br-bersih-semua" class="br-bahaya" title="Hapus SEMUA tanda selesai, cache C-CARE, dan daftar dilewati hari ini">🧹 Reset semua hari ini</button>
        </div>
      </details>
      <details class="br-manual"><summary>Manual / per langkah</summary>
        <div class="br-row">
          <input id="br-kartu" placeholder="No. Kartu (13 digit)">
          <input id="br-antrean" placeholder="Antrean (A8-27)" style="width:42%">
        </div>
        <div class="br-btns">
          <button id="br-antre">📋 Baca antrean</button>
          <button id="br-cari">🔎 Cari</button>
        </div>
        <div id="br-queue"></div>
        <div id="br-fields"></div>
        <input id="br-alergi" placeholder="Riwayat alergi (teks C-CARE)" title="Riwayat alergi dari C-CARE">
        <label>Dokter
          <select id="br-dokter"><option value="">— pilih —</option>
          ${DOKTER.map((d) => `<option value="${d}">${BR.DOKTER_KODE[d]}. ${d}</option>`).join("")}</select></label>
        <div class="br-muted">Default: ${Object.entries(DEFAULTS).filter(([k]) => k !== "terapiNonObat" && k !== "bmhp").map(([, v]) => v).join(" · ")}</div>
        <div class="br-btns">
          <button id="br-ambil">⬇️ Ambil dari C-CARE</button>
          <button id="br-isi">✍️ Isi form</button>
        </div>
        <button id="br-lihatq" style="margin-top:6px">📥 Lihat antrian C-CARE</button>
        <div id="br-ccq"></div>
        <button id="br-struktur" style="margin-top:6px">🧩 Salin struktur halaman (tanpa data pasien)</button>
      </details>
      <button id="br-setelan" class="br-lebar br-setelan">⚙️ Pengaturan · Password · Log · Pembaruan</button>
      <div class="br-log-judul">Aktivitas</div>
      <div id="br-log"></div>
    </div>`;
  document.body.appendChild(p);

  const wrap = p.querySelector("#br-fields");
  FIELDS.forEach(([k, , lab, type]) => {
    const el = type === "area" ? document.createElement("textarea") : document.createElement("input");
    el.id = "br-f-" + k;
    el.placeholder = lab;
    el.title = lab;
    wrap.appendChild(el);
  });
  p.querySelector("#br-f-terapiNonObat").value = DEFAULTS.terapiNonObat;
  p.querySelector("#br-f-bmhp").value = DEFAULTS.bmhp;

  p.querySelector("#br-min").onclick = () => p.classList.toggle("br-collapsed");
  p.querySelector("#br-setelan").onclick = () => { try { chrome.runtime.sendMessage({ type: "bukaPengaturan" }); } catch (e) { log("Ekstensi baru diperbarui: muat ulang halaman ini (F5).", false); } };
  p.querySelector("#br-run").onclick = runStart;
  p.querySelector("#br-nonstop").onclick = runNonstopMulai;
  tampilLewat();
  p.querySelector("#br-refresh").onclick = refreshBersih;
  p.querySelector("#br-next").onclick = runResume;
  p.querySelector("#br-stop").onclick = runStop;
  p.querySelector("#br-skip").onclick = runSkip;
  p.querySelector("#br-antre").onclick = () => readQueue(true);
  p.querySelector("#br-cari").onclick = () => searchPatient(document.getElementById("br-kartu").value.trim());
  p.querySelector("#br-ambil").onclick = () => loadFromCcare();
  p.querySelector("#br-isi").onclick = () => fillForm({ allowAutoSave: true });
  p.querySelector("#br-struktur").onclick = BR.copyStructure;
  p.querySelector("#br-lihatq").onclick = showCcareQueue;
  p.querySelector("#br-bersih-log").onclick = () => { document.getElementById("br-log").innerHTML = ""; };
  p.querySelector("#br-bersih-cc").onclick = () => duaKali(p.querySelector("#br-bersih-cc"), async () => {
    await BR.store.set("ccareQueue", {}); await BR.store.set("ccareDipakai", {});
    log("Cache C-CARE hari ini dibersihkan. Data akan diambil ulang dari C-CARE.", "info"); tampilRiwayat(); });
  p.querySelector("#br-bersih-semua").onclick = () => duaKali(p.querySelector("#br-bersih-semua"), async () => {
    const r = await getRun(); if (r.active) await runStop();
    await BR.store.set("processed", {}); await BR.store.set("ccareQueue", {}); await BR.store.set("ccareDipakai", {});
    await BR.store.set("lewatHariIni", { tgl: BR.today(), item: {} });
    document.getElementById("br-log").innerHTML = "";
    log("🧹 Semua tanda selesai, cache C-CARE, dan daftar dilewati hari ini sudah direset. Klik 🔄 Refresh.", "info");
    tampilLewat(); tampilRiwayat(); });
  p.querySelector("#br-riwayat-box").addEventListener("toggle", tampilRiwayat);
  tampilRiwayat();
  p.querySelector("#br-auto").onchange = (e) => BR.store.set("autoSave", e.target.checked);
  BR.store.get("autoSave").then((v) => (p.querySelector("#br-auto").checked = !!v));
  p.querySelector("#br-lanjut").onchange = (e) => BR.store.set("lanjutOtomatis", e.target.checked);
  BR.store.get("lanjutOtomatis").then((v) => (p.querySelector("#br-lanjut").checked = v !== false));   // bawaan: AKTIF
}

// v1.9.9: tombol berbahaya harus diklik DUA kali (tanpa dialog browser)
function duaKali(btn, aksi) {
  if (btn.dataset.yakin === "1") { btn.dataset.yakin = ""; btn.textContent = btn.dataset.asli; aksi(); return; }
  btn.dataset.asli = btn.textContent; btn.dataset.yakin = "1"; btn.textContent = "Klik lagi untuk yakin";
  setTimeout(() => { if (btn.dataset.yakin === "1") { btn.dataset.yakin = ""; btn.textContent = btn.dataset.asli; } }, 4000);
}
// Daftar tanda "sudah diproses" hari ini, dengan ↩ per pasien
async function tampilRiwayat() {
  const box = document.getElementById("br-riwayat"); if (!box) return;
  const p = (await BR.store.get("processed")) || {};
  const item = Object.entries(p).filter(([, v]) => v.tgl === BR.today());
  if (!item.length) { box.innerHTML = `<div class="br-kosong">Belum ada pasien yang ditandai hari ini.</div>`; return; }
  const stPcare = (k) => { const [kartu, antre] = k.split("|"); const r = ANTREAN_TERAKHIR.find((x) => x.kartu === kartu && (!antre || x.antrean === antre)); return r ? r.status : ""; };
  const LABEL = { otomatis: "disimpan bot", manual: "ditandai selesai manual", dilewati: "dilewati" };
  box.innerHTML = item.map(([k, v], i) => { const st = stPcare(k); const curiga = /^baru$/i.test(st) && v.hasil !== "dilewati";
    return `<div class="br-p ${curiga ? "br-p-lewat" : ""}"><span class="br-chip">${(v.antrean || k.split("|")[1] || "?").replace(/[<>&"]/g, "")}</span>
      <div class="br-pinfo"><div class="br-pnama"></div><div class="br-pmeta"></div></div>
      <button class="br-mini" data-k="${i}" title="Batalkan tanda: pasien akan diproses lagi">↩</button></div>`; }).join("");
  box.querySelectorAll(".br-p").forEach((el, i) => { const [k, v] = item[i]; const st = stPcare(k);
    el.querySelector(".br-pnama").textContent = v.nama || k.split("|")[0];
    el.querySelector(".br-pmeta").textContent = `${v.jam || ""} · ${LABEL[v.hasil] || v.hasil}${st ? ` · PCare: ${st}` : ""}${/^baru$/i.test(st) && v.hasil !== "dilewati" ? " ⚠️ belum tersimpan di PCare?" : ""}`; });
  box.querySelectorAll("button[data-k]").forEach((b) => (b.onclick = async () => {
    const [k, v] = item[+b.dataset.k]; const antre = v.antrean || k.split("|")[1] || "";
    const pp = (await BR.store.get("processed")) || {}; delete pp[k]; await BR.store.set("processed", pp);
    // kunjungan C-CARE yang ditandai terpakai untuk antrean ini dilepas lagi
    const dp = (await BR.store.get("ccareDipakai")) || {}; for (const x of Object.keys(dp)) if (dp[x].antrean === antre) delete dp[x]; await BR.store.set("ccareDipakai", dp);
    const q = (await BR.store.get("ccareQueue")) || {}; for (const x of Object.values(q)) if (x.dipakai === antre) delete x.dipakai; await BR.store.set("ccareQueue", q);
    log(`↩ Tanda selesai ${antre} ${v.nama || ""} dibatalkan. Klik 🔄 Refresh lalu ▶.`, "info");
    tampilRiwayat();
  }));
}

const PANJANG_PCARE = { keluhan: ["Keluhan", 4, 5000], anamnesa: ["Anamnesa", 10, 5000], terapiObat: ["Terapi Obat", 4, 255], terapiNonObat: ["Terapi Non Obat", 4, 255], bmhp: ["BMHP", 0, 255] };
// v1.9.9: isian yang bisa dikoreksi langsung di pratinjau → ditulis ke form PCare saat 💾 Simpan
// v3.0.3: diagnosa sampai 4 (utama + #2, #3, #4 sekunder) — bila PCare hanya menyediakan sampai #3, sisanya dilaporkan
const MAKS_DX = 4;
const EDIT_PV = [["keluhan", "Keluhan", "area"], ["anamnesa", "Anamnesa", "area"], ["diagnosa", "Diagnosa utama", "kode"],
  ["diagnosa2", "Diagnosa #2", "kode"], ["diagnosa3", "Diagnosa #3", "kode"], ["diagnosa4", "Diagnosa #4", "kode"], ["terapiObat", "Terapi Obat", "area"],
  ["terapiNonObat", "Terapi Non Obat", "area"], ["bmhp", "BMHP", "area"], ["sistole", "Sistole", "num"], ["diastole", "Diastole", "num"],
  ["hr", "Heart Rate", "num"], ["rr", "Respiratory Rate", "num"], ["suhu", "Suhu", "num"], ["tb", "Tinggi Badan", "num"], ["bb", "Berat Badan", "num"], ["lp", "Lingkar Perut", "num"]];
const nomorDx = (k) => (k === "diagnosa" ? 1 : /^diagnosa(\d)$/.test(k) ? +k.slice(8) : 0);
const elEdit = (k, lab) => { const n = nomorDx(k); return n === 1 ? kotakDiagnosaUtama() : n ? kotakSekunderTampil(n) : ctl(k, lab); };
let peringatanPasien = [], catatanRujukan = "", catatanSkrining = "", JK_PASIEN = "";
let cekNamaDiagnosa = () => true;   // dicek ulang tepat sebelum Pratinjau (nama penyakit bisa muncul belakangan)   // peringatan untuk pasien yang sedang diisi (ditampilkan di Pratinjau)
const log = (msg, ok = true) => {
  BR.keFile("PCARE", ok === false ? "PERINGATAN" : ok === "info" ? "INFO" : "OK", msg);   // v2.0.0: juga ke file log
  if (meja) meja.aktivitas(msg, ok);   // v3.1.0: juga tampil di kolom Antrean aplikasi
  if (ok === false) peringatanPasien.push(msg);
  const box = document.getElementById("br-log");
  if (!box) return;
  const line = document.createElement("div");
  line.className = "br-l " + (ok === "info" ? "br-info" : ok ? "br-ok" : "br-err");
  const jam = document.createElement("span"); jam.className = "br-jam"; jam.textContent = new Date().toLocaleTimeString("id-ID").slice(0, 5);
  const isi = document.createElement("span"); isi.textContent = msg;
  line.append(jam, isi);
  box.prepend(line);
  while (box.children.length > 40) box.lastChild.remove();
};
const status = (msg) => {
  if (meja) meja.status(msg);
  const s = document.getElementById("br-status"); if (!s) return;
  s.textContent = msg;
  s.dataset.st = /menunggu|berhenti|⏸/i.test(msg) ? "tunggu" : /selesai|✓/i.test(msg) ? "selesai" : /gagal|✗|error/i.test(msg) ? "gagal" : /▶|mengambil|mencari|memuat|mengisi|menyimpan|berjalan/i.test(msg) ? "jalan" : "siap";
  // animasi "sedang berproses": garis berjalan di bawah judul + kartu pasien yang sedang dikerjakan berdenyut
  const panel = document.getElementById("br-panel");
  if (panel) panel.classList.toggle("br-sibuk", s.dataset.st === "jalan");
  const kode = (msg.match(/\b[A-Z]\d{1,2}-\d{1,3}\b/) || [])[0];
  document.querySelectorAll("#br-pasien .br-p").forEach((c) => c.classList.toggle("br-aktif", s.dataset.st === "jalan" && !!kode && c.querySelector(".br-chip")?.textContent === kode));
};

const ctl = (key, label) =>
  (SELECTOR_OVERRIDE[key] && document.querySelector(SELECTOR_OVERRIDE[key])) || BR.findControl(label);

// ---------- Dialog & warning ----------
// Dialog KEPUTUSAN (mis. "Apakah Anda akan tetap melayani?") TIDAK pernah dijawab bot.
let dataAktif = null;    // v1.9.0: kunjungan C-CARE yang sedang dipakai mengisi form (untuk ditandai setelah tersimpan)
let alergiHasil = null;   // hasil klasifikasi alergi (lokal + online) untuk pasien yang sedang diisi
let blockAuto = false; // diset bila ada dialog keputusan / alergi / rujukan / kartu tidak cocok
const DECISION_RE = /apakah anda|tetap melayani|yakin|konfirmasi|hapus/i;

function findDecisionDialog() {
  return [...document.querySelectorAll(".modal, .bootbox, .swal2-popup, [role=dialog]")]
    .find((m) => BR.visible(m) && DECISION_RE.test(m.innerText || ""));
}

function closeWarnings() {
  const dec = findDecisionDialog();
  if (dec) {
    dec.style.outline = "4px solid #f39c12";
    blockAuto = true;
    log("PCare meminta keputusan → \"" + (dec.innerText || "").replace(/\s+/g, " ").trim().slice(0, 140) +
        "\". Pilih sendiri (Ya/Tidak).", false);
    return -1;
  }
  let n = 0; // hanya [×] pada pop-up informasi; tidak pernah menekan Ya/OK
  document.querySelectorAll(".modal.in .close, .modal.show .close, .bootbox .close, .swal2-close")
    .forEach((b) => { if (BR.visible(b)) { b.click(); n++; } });
  return n;
}

// ---------- Antrean (tabel Riwayat Pendaftaran) ----------
// kolom STATUS di tabel ("Baru" / "Sudah Dilayani"); dicari dari judul kolom, cadangan: isi sel
function kolomStatus(table) {
  const th = [...(table?.querySelectorAll("thead th, tr:first-child th") || [])];
  return th.findIndex((h) => BR.norm(h.textContent) === "status");
}
function queueRows(akar = document) {
  return [...akar.querySelectorAll("table tr")].map((tr) => {
    const c = tr.querySelectorAll("td");
    if (c.length < 3 || !/^\d{13}$/.test(c[1].textContent.trim())) return null;
    const color = akar === document ? getComputedStyle(c[2].querySelector("*") || c[2]).color : "rgb(51, 51, 51)";
    const iSt = kolomStatus(tr.closest("table"));
    const stSel = iSt >= 0 ? c[iSt] : [...c].find((td) => /^\s*(baru|sudah dilayani|dilayani|sedang dilayani|batal)\s*$/i.test(td.textContent));
    return {
      status: stSel ? stSel.textContent.replace(/\s+/g, " ").trim() : "",
      antrean: c[0].textContent.trim(), kartu: c[1].textContent.trim(), nama: c[2].textContent.trim(),
      kelamin: (c[3]?.textContent || "").trim().toUpperCase().charAt(0),
      usia: parseInt((c[4]?.textContent || "").trim(), 10),
      poli: (c[5]?.textContent || "").replace(/\s+/g, " ").trim(),   // v1.9.7: "POLI UMUM", "POLI KIA", "Konseling"
      warnaBeda: color !== "rgb(51, 51, 51)" && color !== "rgb(0, 0, 0)",
    };
  }).filter(Boolean).map((r) => (BR.ingatNama(r.nama), r));
}
// HANYA pasien berstatus "Baru" yang dilayani bot; "Sudah Dilayani" (dan status lain) dilewati.
// Bila kolom STATUS tidak terbaca, kembali ke cara lama (warna baris).
const perluDilayani = (r) => (r.status ? /^baru$/i.test(r.status) : !r.warnaBeda);

// ---------- v1.9.4: tabel Riwayat Pendaftaran berhalaman (mis. 15 per halaman) ----------
// Dulu hanya halaman yang sedang tampil yang terbaca, jadi pasien di halaman 2, 3, dst. tidak terdeteksi.
// Kini: (a) bila ada pilihan jumlah baris per halaman, dipilih yang terbesar; (b) semua halaman dibuka satu per satu
// (tombol nomor halaman / Next / ›); tautan halaman yang memuat ulang halaman dibaca lewat fetch tanpa berpindah halaman;
// (c) sesudahnya kembali ke halaman 1. Baris ganda (antrean + kartu sama) hanya dihitung sekali.
let ANTREAN_TERAKHIR = [], HALAMAN_TERBACA = 1;
const tabelAntrean = (akar = document) => {
  const tr = [...akar.querySelectorAll("table tr")].find((t) => { const c = t.querySelectorAll("td"); return c.length >= 3 && /^\d{13}$/.test(c[1].textContent.trim()); });
  return tr ? tr.closest("table") : null;
};
const sidikTabel = () => queueRows().map((r) => r.antrean + r.kartu).join(",");
async function tungguSampai(fn, ms) { for (let t = 0; t < ms; t += 200) { await BR.sleep(200); if (fn()) return true; } return false; }
// wadah navigasi halaman milik tabel antrean (bukan milik panel bot)
function kontrolHalaman(tb, akar = document) {
  const wadah = [tb.closest(".dataTables_wrapper"), tb.parentElement, tb.parentElement && tb.parentElement.parentElement,
    tb.closest(".table-responsive, .box, .panel, .card, .tab-pane, form")].filter(Boolean);
  for (const w of wadah) {
    const el = [...w.querySelectorAll(".pagination a, .pagination button, .pagination li, .dataTables_paginate a, .dataTables_paginate span a, .paginate_button, a[rel=next], a[aria-label], li.next, li.prev")]
      .filter((e) => !e.closest(BR.UI_SENDIRI) && (akar !== document || BR.visible(e)));
    if (el.length) return el;
  }
  return [];
}
const teksKontrol = (e) => (e.textContent || e.getAttribute("aria-label") || e.title || "").replace(/\s+/g, " ").trim();
const kontrolMati = (e) => e.matches(".disabled, [disabled], [aria-disabled=true], .current, .active") || !!e.closest("li.disabled, li.active, .paginate_button.disabled");
// Tombol ke halaman berikutnya: utamakan nomor (halaman aktif + 1), cadangan Next/Selanjutnya/›/»/>
function halamanBerikut(tb, akar = document) {
  const el = kontrolHalaman(tb, akar);
  if (!el.length) return null;
  const aktif = el.find((e) => /^\d+$/.test(teksKontrol(e)) && (e.matches(".active, .current") || e.closest("li.active") || e.getAttribute("aria-current")));
  const n = aktif ? +teksKontrol(aktif) : 1;
  const nomor = el.find((e) => teksKontrol(e) === String(n + 1) && !kontrolMati(e));
  if (nomor) return nomor.matches("li") ? (nomor.querySelector("a, button") || nomor) : nomor;
  const lanjut = el.find((e) => /^(next|selanjutnya|berikut(nya)?|›|»|>)$/i.test(teksKontrol(e)) || e.matches(".paginate_button.next, li.next, a[rel=next]"));
  if (!lanjut || kontrolMati(lanjut)) return null;
  return lanjut.matches("li") ? (lanjut.querySelector("a, button") || lanjut) : lanjut;
}
const tautanAsli = (a) => { const h = a.getAttribute && a.getAttribute("href"); return h && !/^(#|javascript:)/i.test(h) ? new URL(h, location.href).href : ""; };
// pilih jumlah baris per halaman terbesar (Semua / All / -1 / angka terbesar) bila PCare menyediakannya
async function perbesarHalaman(tb) {
  const w = tb.closest(".dataTables_wrapper") || (tb.parentElement && tb.parentElement.parentElement) || document;
  const s = [...w.querySelectorAll("select")].find((x) => !x.closest(BR.UI_SENDIRI) && x.options.length >= 2 &&
    [...x.options].every((o) => /^(-?\d+|all|semua)$/i.test((o.value || o.text).trim())));
  if (!s) return false;
  const nilai = (o) => { const v = (o.value || o.text).trim(); return /^(-1|all|semua)$/i.test(v) ? 1e9 : +v; };
  const best = [...s.options].sort((a, b) => nilai(b) - nilai(a))[0];
  if (!best || s.value === best.value) return false;
  const sebelum = sidikTabel();
  s.value = best.value; BR.fire(s);
  await tungguSampai(() => sidikTabel() !== sebelum, 4000);
  return true;
}
// jumlah total menurut PCare, dari teks "Showing 1 to 15 of 40 entries" / "dari 40"
function totalAntrean() {
  const el = document.querySelector("#example_info, .dataTables_info");
  const m = el && el.textContent.match(/(?:of|dari)\s+([\d.,]+)/i);
  return m ? +m[1].replace(/[.,]/g, "") : null;
}
async function mintaSatuHalaman() {
  const html = document.documentElement;
  delete html.dataset.brPerbesar;
  const sebelum = sidikTabel();
  document.dispatchEvent(new Event("br-perbesar-antrean"));
  await tungguSampai(() => !!html.dataset.brPerbesar, 8000);
  const hasil = html.dataset.brPerbesar || "waktu habis";
  if (/^ok:/.test(hasil) && sidikTabel() === sebelum) await BR.sleep(400);
  return hasil;
}
async function bacaSemuaHalaman() {
  let tb = tabelAntrean();
  if (!tb) return queueRows();
  const total = totalAntrean();
  if (total == null || queueRows().length < total) {
    const h = await mintaSatuHalaman();
    if (!/^ok:/.test(h)) await perbesarHalaman(tb);
    tb = tabelAntrean() || tb;
  }
  if (total == null || queueRows().length >= total) { HALAMAN_TERBACA = 1; return queueRows(); }
  // server membatasi jumlah baris per permintaan → kembalikan panjang halaman asli, lalu baca per halaman
  if (!halamanBerikut(tabelAntrean() || tb)) {
    const html = document.documentElement; delete html.dataset.brKembali;
    document.dispatchEvent(new Event("br-kembalikan-antrean"));
    await tungguSampai(() => !!html.dataset.brKembali, 6000); await BR.sleep(300);
  }
  // cadangan: buka halaman satu per satu; urutan server bisa berubah → ulangi sampai jumlahnya cocok (maks. 3 putaran)
  const gabung = new Map();
  for (let putaran = 0; putaran < 3; putaran++) {
    const rows = await bacaPerHalaman(tabelAntrean() || tb);
    rows.forEach((r) => { const k = r.antrean + "|" + r.kartu; if (!gabung.has(k)) gabung.set(k, r); });
    if (gabung.size >= total) break;
  }
  if (gabung.size < total) log(`⚠️ PCare mencatat ${total} pendaftaran, bot hanya membaca ${gabung.size}. Klik 🔄 Refresh lagi; bila tetap kurang, cek halaman terakhir secara manual.`, false);
  return [...gabung.values()];
}
async function bacaPerHalaman(tb) {
  const semua = new Map(), tambah = (rows) => rows.forEach((r) => { const k = r.antrean + "|" + r.kartu; if (!semua.has(k)) semua.set(k, r); });
  let hal = 1, berpindah = false;
  tambah(queueRows());
  let btn = halamanBerikut(tb);
  // (1) tautan biasa yang memuat ulang halaman → baca lewat fetch, tampilan PCare tidak berubah
  if (btn && tautanAsli(btn)) {
    let url = tautanAsli(btn); const dikunjungi = new Set([location.href]);
    while (url && !dikunjungi.has(url) && hal < 40) {
      dikunjungi.add(url);
      try {
        const html = await (await fetch(url, { credentials: "include" })).text();
        const doc = new DOMParser().parseFromString(html, "text/html");
        const rows = queueRows(doc); if (!rows.length) break;
        tambah(rows); hal++;
        const t2 = tabelAntrean(doc); const b2 = t2 && halamanBerikut(t2, doc); url = b2 ? tautanAsli(b2) : "";
      } catch (e) { log("Halaman antrean berikutnya gagal dibaca: " + e, false); break; }
    }
  } else {
    // (2) halaman berganti tanpa muat ulang (AJAX) → klik, tunggu isi tabel berubah
    while (btn && hal < 40) {
      const sebelum = sidikTabel();
      btn.click(); berpindah = true;
      if (!(await tungguSampai(() => sidikTabel() !== sebelum && queueRows().length > 0, 5000))) break;
      tambah(queueRows()); hal++;
      tb = tabelAntrean() || tb; btn = halamanBerikut(tb);
    }
    if (berpindah) {                                   // kembali ke halaman 1
      const satu = kontrolHalaman(tabelAntrean() || tb).find((e) => /^(1|first|pertama|«|<<)$/i.test(teksKontrol(e)) && !kontrolMati(e));
      if (satu) { (satu.matches("li") ? (satu.querySelector("a, button") || satu) : satu).click(); await BR.sleep(800); }
    }
  }
  HALAMAN_TERBACA = hal;
  return [...semua.values()];
}

async function readQueue(show) {
  if (closeWarnings() < 0) return null;
  if (BR.clickButton("Refresh")) { await BR.sleep(2000); }
  const rows = await bacaSemuaHalaman();
  ANTREAN_TERAKHIR = rows;
  { const t = totalAntrean(); if (t != null && t > 15) log(`Antrean PCare: ${rows.length} dari ${t} pendaftaran terbaca${HALAMAN_TERBACA > 1 ? ` (${HALAMAN_TERBACA} halaman)` : " (semua dalam satu halaman)"}.`, rows.length >= t ? "info" : false); }
  if (show) {
    const box = document.getElementById("br-queue");
    box.innerHTML = rows.map((r) => `<div class="br-q ${perluDilayani(r) ? "" : "br-done"}" data-kartu="${r.kartu}" data-no="${r.antrean}">
      <b>${r.antrean}</b> ${r.kartu} <span>${r.nama}</span></div>`).join("");
    box.querySelectorAll(".br-q").forEach((d) => (d.onclick = () => {
      document.getElementById("br-kartu").value = d.dataset.kartu;
      document.getElementById("br-antrean").value = d.dataset.no;
    }));
    log(rows.length ? `${rows.length} pasien terbaca dari antrean.` : "Tabel Riwayat Pendaftaran tidak ditemukan.", !!rows.length);
  }
  return rows;
}

// ---------- Cari peserta ----------
async function searchPatient(kartu) {
  if (!/^\d{13}$/.test(kartu)) { log("No. Kartu harus 13 digit.", false); return "error"; }
  if (closeWarnings() < 0) return "decision";
  const inp =
    (SELECTOR_OVERRIDE.noPencarian && document.querySelector(SELECTOR_OVERRIDE.noPencarian)) ||
    BR.findControl("No. Pencarian") ||
    document.querySelector("input[placeholder*='encarian'], input[placeholder*='Kartu']");
  if (!inp) { log("Field No. Pencarian tidak ditemukan.", false); return "error"; }
  BR.setValue(inp, kartu);
  await BR.sleep(200);
  if (!BR.clickButton("Cari")) { log("Tombol Cari tidak ditemukan.", false); return "error"; }
  log("Mencari " + kartu + " …");
  for (let i = 0; i < 8; i++) {
    await BR.sleep(500);
    if (findDecisionDialog()) { closeWarnings(); return "decision"; }
  }
  return "ok";
}

// Apakah form Pelayanan sudah tampil? (label Anamnesa & Terapi Obat terlihat)
const formPelayananTampil = () => !!(BR.findLabelEl("Anamnesa") && BR.findLabelEl("Terapi Obat"));

// Coba buka form Pelayanan: klik tombol/link yang memuat kata "Pelayanan" (bagian bawah halaman)
async function bukaPelayanan() {
  if (formPelayananTampil()) return true;
  const btn = [...document.querySelectorAll("button, a, input[type=button]")]
    .filter((b) => BR.visible(b) && !b.closest("#br-panel") && !b.closest(".navbar, nav"))
    .find((b) => /pelayanan/i.test(b.textContent || b.value || ""));
  if (btn) {
    btn.click();
    for (let i = 0; i < 12; i++) { await BR.sleep(500); if (formPelayananTampil()) return true; if (findDecisionDialog()) return false; }
  }
  return formPelayananTampil();
}

// ---------- Halaman Pelayanan: muat pasien lewat Sumber Data "No.Antrian" ----------
// Nilai yang tampil di sebelah label (mis. "No.Kartu BPJS  0002694519448")
function readShown(label) {
  const el = BR.findLabelEl(label);
  if (!el) return "";
  let sib = el.nextElementSibling;
  if (sib && sib.textContent.trim()) return sib.textContent.trim();
  const row = el.closest(".form-group, .row, tr") || el.parentElement;
  return row ? row.textContent.replace(el.textContent, "").replace(/\s+/g, " ").trim() : "";
}
const kartuTampil = () => (readShown("No.Kartu BPJS").match(/\d{13}/) || [""])[0];

// Cloudflare Turnstile: bot TIDAK pernah mengerjakan/melewati verifikasi ini.
// Bila widget ada dan belum lolos, bot berhenti dan meminta Anda.
// ---------- Hasil ukur (tanda vital & antropometri) ----------
const BATAS_UKUR = {   // v1.9.2: sama dengan aturan validasi form Pelayanan PCare (dibaca 16-10-2026)
  suhu: [25, 45, "℃"], tb: [30, 250, "cm"], bb: [2, 300, "kg"], lp: [25, 300, "cm"],
  sistole: [40, 250, "mmHg"], diastole: [30, 180, "mmHg"], rr: [5, 70, "/menit"], hr: [30, 160, "bpm"],
};
function hasilUkurTidakSesuai(v) {
  const keluar = new Map();
  // a) pesan validasi PCare yang tampil di halaman, mis. "Suhu tidak sesuai"
  [...document.querySelectorAll("span, small, div, label, p")]
    .filter((el) => el.children.length === 0 && BR.visible(el) && !el.closest(BR.UI_SENDIRI) && /tidak sesuai/i.test(el.textContent))
    .forEach((el) => {
      const nama = el.textContent.replace(/\s+/g, " ").replace(/\s*tidak sesuai.*$/i, "").trim();
      const inp = (el.closest(".form-group, .input-group, td, [class*='col-']") || el.parentElement)?.querySelector("input");
      keluar.set(BR.norm(nama), `${nama}: hasil ukur tidak sesuai (${inp?.value ?? "?"})`);
    });
  // b) batas wajar sendiri (bila pesan PCare tidak muncul)
  for (const [k, lab] of FIELDS) {
    const b = BATAS_UKUR[k]; if (!b || v[k] === undefined || v[k] === "") continue;
    const n = parseFloat(String(v[k]).replace(",", "."));
    const maxl = k === "suhu" ? 5 : 3;   // v1.9.2: panjang maksimal isian di form PCare
    if (String(v[k]).trim().length > maxl) { const key = BR.norm(lab); if (!keluar.has(key)) keluar.set(key, `${lab}: lebih dari ${maxl} karakter (${v[k]}), PCare menolak`); continue; }
    if (isNaN(n) || n < b[0] || n > b[1]) { const key = BR.norm(lab); if (!keluar.has(key)) keluar.set(key, `${lab}: hasil ukur tidak sesuai (${v[k]} ${b[2]})`); }
  }
  return [...keluar.values()];
}

// ---------- Diagnosa (utama, #2, #3) ----------
// Isi kode lalu TINGGALKAN kotaknya (blur sungguhan): PCare baru mencari nama penyakit saat itu.
async function isiKodeDiagnosa(el) {
  const row = el.closest(".input-group, .form-group, div");
  const nameBox = row && [...row.querySelectorAll("input")].find((x) => x !== el && x.type !== "hidden");
  const tinggalkan = () => { BR.pressEnter(el); el.blur(); el.dispatchEvent(new FocusEvent("focusout", { bubbles: true }));
    if (window.jQuery) try { window.jQuery(el).trigger("blur").trigger("focusout").trigger("change"); } catch (e) {} };
  tinggalkan();
  for (let i = 0; i < 10 && nameBox && !nameBox.value; i++) await BR.sleep(500);   // tunggu s.d. 5 detik
  if (nameBox && !nameBox.value) {                                                  // coba sekali lagi
    el.focus(); await BR.sleep(150); tinggalkan();
    for (let i = 0; i < 8 && !nameBox.value; i++) await BR.sleep(500);
  }
  return { nameBox };
}
// Kotak kode Diagnosa UTAMA: label persis "Diagnosa" (tanpa "#2/#3"), input di baris yang sama
function kotakDiagnosaUtama() {
  const o = SELECTOR_OVERRIDE.diagnosa && document.querySelector(SELECTOR_OVERRIDE.diagnosa);
  if (o) return o;
  const id = document.getElementById("kddiagnosa1"); if (id && BR.visible(id)) return id;   // v3.4.8
  const labels = [...document.querySelectorAll("label, th, td, div, span, b, strong")]
    .filter((x) => !x.closest(BR.UI_SENDIRI) && x.children.length <= 5 && !x.querySelector("input, select, textarea") && BR.norm(x.textContent) === "diagnosa" && BR.visible(x));
  for (const lab of labels) {
    const baris = lab.closest(".form-group, tr, .row");
    const inp = baris && [...baris.querySelectorAll("input:not([type=hidden])")].find((i) => BR.visible(i) && !i.readOnly && !i.disabled);
    if (inp && !/#\s*\d/.test(baris.textContent.replace(lab.textContent, ""))) return inp;   // baris ini bukan "#2/#3"
  }
  return BR.findControl("Diagnosa");
}
// Kotak kode "Diagnosa #n (sekunder)" yang sedang tampil (atau null)
// v3.4.8: PCare (diperiksa 24 Nov 2026) memakai id tetap #kddiagnosaN / #nmdiagnosaN / #adddiagnosaN; label tanpa "for".
function kotakSekunderTampil(n) {
  const e = document.getElementById(`kddiagnosa${n}`) || BR.findControl(`Diagnosa #${n} (sekunder)`, "input:not([type=hidden])") || BR.findControl(`Diagnosa #${n}`, "input:not([type=hidden])");
  return e && BR.visible(e) ? e : null;
}
// mengosongkan kotak isian (BR.setValue menolak nilai kosong)
function kosongkan(el) {
  const proto = el.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
  Object.getOwnPropertyDescriptor(proto, "value").set.call(el, "");
  for (const t of ["input", "change"]) el.dispatchEvent(new Event(t, { bubbles: true }));
  if (window.jQuery) try { window.jQuery(el).trigger("change"); } catch (e) {}
}
const nomorSekunder = () => Array.from({ length: MAKS_DX - 1 }, (_, i) => i + 2);
// kotak NAMA penyakit di baris yang sama dengan kotak kode
const kotakNamaDx = (el) => [...(el.closest(".input-group, .form-group, div")?.querySelectorAll("input") || [])].find((x) => x !== el && x.type !== "hidden") || null;
// Kotak kode "Diagnosa #n (sekunder)"; bila barisnya belum tampil, klik ⊕ pada baris diagnosa sebelumnya
async function kotakDiagnosaSekunder(n, elSebelum) {
  const cari = () => kotakSekunderTampil(n);
  let el = cari();
  if (el) return el;
  const baris = elSebelum && (elSebelum.closest(".form-group, .row") || elSebelum.closest(".input-group"));
  const plus = document.getElementById(`adddiagnosa${n}`) || baris && [...baris.querySelectorAll("button, a, span.input-group-addon, span.input-group-btn > *")]
    .find((b) => b.querySelector(".fa-plus-circle, .fa-plus, .glyphicon-plus, .glyphicon-plus-sign") || /tambah|add|\+|⊕/i.test((b.title || "") + (b.textContent || "")));
  if (!plus) return null;
  plus.click();
  for (let i = 0; i < 10; i++) { await BR.sleep(300); el = cari(); if (el && BR.visible(el)) return el; }
  return null;
}

// Memanggil Anda: bunyi singkat, judul tab berkedip, status kuning, notifikasi Windows. return fungsi penghenti.
function panggilAnda(judul, pesan) {
  status(judul);
  try { chrome.runtime.sendMessage({ type: "panggil", judul, pesan }); } catch (e) {}
  const asli = document.title; let t = 0;
  const kedip = setInterval(() => { document.title = (t++ % 2) ? asli : "👆 PERLU ANDA – PCare"; }, 900);
  const bunyi = () => { try {
    const ac = new (window.AudioContext || window.webkitAudioContext)();
    [0, 0.25].forEach((d) => { const o = ac.createOscillator(), g = ac.createGain(); o.frequency.value = 880; g.gain.value = 0.08;
      o.connect(g); g.connect(ac.destination); o.start(ac.currentTime + d); o.stop(ac.currentTime + d + 0.15); });
    setTimeout(() => ac.close(), 800);
  } catch (e) {} };
  bunyi(); const ulang = setInterval(bunyi, 20000);       // bunyi lagi tiap 20 dtk selama menunggu
  return () => { clearInterval(kedip); clearInterval(ulang); document.title = asli; };
}
// "lolos" (kotak Cloudflare menampilkan "Berhasil!") | "menunggu" (kotak ada, belum lolos) | "tidak ada" (kotak tidak muncul)
function statusCloudflare() {
  const tok = document.querySelector("input[name='cf-turnstile-response']");
  const widget = document.querySelector(".cf-turnstile, iframe[src*='challenges.cloudflare.com']");
  if (tok && tok.value) return "lolos";
  return widget || tok ? "menunggu" : "tidak ada";
}
const SARAN_RELOAD = "Kotak Cloudflare belum menampilkan \"Berhasil!\" → centang kotaknya, atau reload halaman PCare 1× (F5), lalu ▶ lagi";
function turnstileBelumLolos() {
  const tok = document.querySelector("input[name='cf-turnstile-response']");
  const widget = document.querySelector(".cf-turnstile, iframe[src*='challenges.cloudflare.com']") || tok;
  return !!widget && !!tok && !tok.value;
}

// Notifikasi PCare (toast merah). v4.0.1: hanya pesan yang MUNCUL SESUDAH tombol cari diklik yang dihitung.
// Di 4.0.0 toast "Data tidak ditemukan" sisa saat halaman Pelayanan dibuka ikut terbaca → No.Kartu yang benar
// dilaporkan "tidak ditemukan".
const SEL_TOAST = ".toast, .toast-error, #toast-container > *, .alert, .notifyjs-corner > *, .jq-toast-single, .swal2-popup";
function toastTampil() { return [...document.querySelectorAll(SEL_TOAST)].filter((el) => BR.visible(el) && !el.closest(BR.UI_SENDIRI)); }
function tutupToast(el) { const x = el.querySelector(".close, .toast-close-button, button"); if (x) x.click(); else el.remove(); }
// Sebelum mencari: tutup toast lama, lalu kembalikan himpunan yang masih ada (diabaikan saat menilai hasil).
async function bersihkanToast() {
  for (const el of toastTampil()) tutupToast(el);
  await BR.sleep(300);
  return new Set(toastTampil());
}
// "tidak" (Data tidak ditemukan) | "ulang" (Permintaan tidak dapat diproses / muat ulang halaman) | ""
function toastBaru(lama) {
  for (const el of toastTampil()) {
    if (lama.has(el)) continue;
    const t = el.textContent || "";
    if (/tidak dapat diproses|muat ulang halaman/i.test(t)) { tutupToast(el); return "ulang"; }
    if (/tidak ditemukan/i.test(t)) { tutupToast(el); return "tidak"; }
  }
  return "";
}

// Kotak isian No. Pendaftaran (setelah Sumber Data dipilih)
function kotakNoPendaftaran() {
  const label = BR.findLabelEl("No. Pendaftaran") || BR.findLabelEl("No. Kartu") || BR.findLabelEl("No.Kartu");
  const row = label && (label.closest(".form-group, .row") || label.parentElement);
  const inputs = row ? [...row.querySelectorAll("input:not([type=hidden]):not([type=radio]):not([type=checkbox])")].filter(BR.visible) : [];
  const inp = inputs.find((x) => !x.readOnly && !x.disabled && /nomor|kartu/i.test(x.placeholder || "")) ||
              inputs.find((x) => !x.readOnly && !x.disabled);
  return { label, row, inp };
}

// Balon catatan di dekat kotak No. Pendaftaran: "Nomor antrian pasien ini adalah A8-27"
function pasangBalon(inp, cur) {
  document.getElementById("br-balon")?.remove();
  const d = BR.dokterDariAntrean(cur.antrean);
  const b = document.createElement("div");
  b.id = "br-balon";
  b.innerHTML = `<button title="Tutup">×</button>📌 Nomor antrian pasien ini adalah <b>${cur.antrean}</b><br>
    <span>${cur.nama} · ${cur.kelamin || "?"} · ${isNaN(cur.usia) ? "?" : cur.usia} th${d.nama ? " · " + d.nama : ""}</span><br>
    <span>No.Kartu ${cur.kartu}</span>`;
  b.querySelector("button").onclick = () => b.remove();
  document.body.appendChild(b);
  const posisikan = () => {
    if (!document.body.contains(b) || !document.body.contains(inp)) return;
    const r = inp.getBoundingClientRect();
    b.style.top = (window.scrollY + r.top - b.offsetHeight - 10) + "px";
    b.style.left = (window.scrollX + r.left) + "px";
  };
  posisikan();
  window.addEventListener("scroll", posisikan, { passive: true });
  window.addEventListener("resize", posisikan);
}

// return: "ok" | "decision" | "turnstile" | "error:<pesan>"
// Sumber Data "No.Kartu" dulu, cadangan "No.Antrian" ("A8-27" -> awalan A + nomor "8-27").
async function muatPasienPelayanan(cur) {
  if (closeWarnings() < 0) return "decision";
  const m = cur.antrean.match(/^([A-Za-z]+)\s*(.+)$/);           // "A8-27" -> "A" + "8-27"
  const prefix = m ? m[1].toUpperCase() : "", nomor = m ? m[2] : cur.antrean;
  // Sumber Data = No.Kartu (andal); nomor antrean ditampilkan di BALON CATATAN agar mudah dicocokkan.
  // Cadangan: No.Antrian bila No.Kartu tidak ditemukan.
  const percobaan = [
    { sumber: ["No.Kartu", "No. Kartu"], nilai: cur.kartu, tampil: cur.kartu },
    { sumber: ["No.Antrian", "No. Antrian"], nilai: nomor, tampil: `${prefix}${nomor}`, prefix },
  ];
  const gagal = [];
  for (const c of percobaan) {
    if (!c.sumber.some((s) => BR.clickChoice(s))) { gagal.push(`pilihan Sumber Data ${c.sumber[0]} tak ditemukan`); continue; }
    await BR.sleep(500);
    const { row, inp } = kotakNoPendaftaran();
    if (!inp) { gagal.push(`kotak isian (${c.sumber[0]}) tak ditemukan`); continue; }
    const pre = c.prefix && row.querySelector("select");
    if (pre) BR.setValue(pre, c.prefix);
    BR.setValue(inp, c.nilai);
    pasangBalon(inp, cur);
    if (turnstileBelumLolos()) {
      log("Menunggu verifikasi Cloudflare selesai otomatis…");
      const mulaiTs = () => document.documentElement.dispatchEvent(new Event("br-turnstile-mulai"));   // v3.4.7
      mulaiTs();
      for (let i = 0; i < 20 && turnstileBelumLolos() && !BERHENTI; i++) await BR.sleep(500);     // 10 dtk: sering lolos sendiri
      if (BERHENTI) return "berhenti";
      if (turnstileBelumLolos()) {
        // Bot TIDAK mencentang kotak ini. Bot memanggil Anda, lalu lanjut sendiri begitu Anda mencentangnya.
        const henti = panggilAnda("👆 Centang kotak Cloudflare di PCare", `Bot menunggu Anda untuk ${cur.antrean} ${cur.nama}. Setelah dicentang, bot lanjut sendiri.`);
        log("👆 Kotak Cloudflare perlu dicentang oleh Anda. Bot menunggu s.d. 3 menit, lalu lanjut sendiri.", "info");
        for (let i = 0; i < 360 && turnstileBelumLolos() && !BERHENTI; i++) { if (i % 40 === 39) mulaiTs(); await BR.sleep(500); }
        henti();
        if (BERHENTI) return "berhenti";
        if (turnstileBelumLolos()) return "turnstile";
      }
      log("Verifikasi Cloudflare lolos.");
    }
    const btn = inp.closest(".input-group, .form-group, .row")?.querySelector("button, .btn, input[type=button]");
    if (!btn) { gagal.push(`tombol cari (${c.sumber[0]}) tak ditemukan`); continue; }
    const lama = await bersihkanToast();
    btn.click();
    log(`Memuat pasien lewat ${c.sumber[0]} ${c.tampil} …`);
    let hasil = "";
    for (let i = 0; i < 16 && !hasil; i++) {
      await BR.sleep(500);
      if (BERHENTI) return "berhenti";
      if (findDecisionDialog()) { closeWarnings(); return "decision"; }
      if (kartuTampil()) hasil = "ok";
      else hasil = toastBaru(lama);
    }
    if (hasil === "ok") return "ok";
    // PCare: "Permintaan tidak dapat diproses. Silakan muat ulang halaman lalu ulangi." → halaman dimuat ulang (oleh pemanggil)
    if (hasil === "ulang") { log(`PCare minta halaman dimuat ulang (${c.sumber[0]} ${c.tampil}).`, "info"); return "reload"; }
    gagal.push(`${c.sumber[0]} ${c.tampil}: ${hasil === "tidak" ? "Data tidak ditemukan" : "tidak ada respons"}`);
    await BR.sleep(800);
  }
  if (gagal.some((g) => /Data tidak ditemukan/.test(g)))
    return `error:PCare: "Data tidak ditemukan" (No.Kartu ${cur.kartu} / antrean ${prefix}${nomor}). Koreksi nomor di kotak No. Pendaftaran, klik 🔍`;
  return "error:" + gagal.join(" · ");
}

// ---------- Riwayat Alergi: lokal + online (RxNav/ATC) ----------
const AL_STOP = /^(alergi|alergy|allergy|obat|obatan|terhadap|dengan|dan|serta|atau|riwayat|pasien|ada|jika|minum|makan|ringan|berat|gatal|ruam|bengkak|sesak|biduran|kemerahan)$/i;
const AL_NONDRUG = /udang|kepiting|cumi|kerang|ikan|seafood|gandum|terigu|susu|kacang|telur|ayam|daging|coklat|cokelat|debu|asap|dingin|panas|polusi|bulu|kucing|anjing|tungau|serbuk/i;

function kirimKeBackground(term) {
  return new Promise((res) => {
    try { chrome.runtime.sendMessage({ type: "klasifikasiObat", term }, (r) => res(r || null)); }
    catch (e) { res(null); }
    setTimeout(() => res(null), 12000);
  });
}

// return objek seperti BR.alergiKategori + daftar sumber online
async function alergiKategoriLengkap(teks) {
  const ak = BR.alergiKategori(teks);
  ak.online = [];
  if (ak.kosong) return ak;
  // kata/frasa kandidat nama obat yang belum dikenali aturan lokal
  const parts = BR.norm(teks).split(/[,;/+()]|\bdan\b|\bserta\b|\batau\b/).map((s) => s.trim()).filter(Boolean);
  const kandidat = [];
  for (const part of parts) {
    if (BR.alergiKategori(part).obat.some((k) => k !== "Obat-Obatan Lain")) continue;   // sudah dikenali lokal
    if (AL_NONDRUG.test(part)) continue;                                                // makanan/udara/hewan
    const kata = part.split(/\s+/).filter((w) => w.length >= 4 && !AL_STOP.test(w));
    if (kata.length) kandidat.push(kata.join(" "));
  }
  for (const term of kandidat.slice(0, 4)) {
    const r = await kirimKeBackground(term);
    if (r && r.kategori) {
      ak.online.push(`"${term}" → ${r.nama} [${r.atc.join(", ")}] → ${r.kategori}`);
      ak.obat = ak.obat.filter((k) => k !== "Obat-Obatan Lain");
      if (!ak.obat.includes(r.kategori)) ak.obat.push(r.kategori);
      ak.belumTerbaca = false;
    } else {
      ak.online.push(`"${term}" → tidak ditemukan di database obat${r && r.error ? " (" + r.error + ")" : ""}`);
    }
  }
  return ak;
}

// ---------- Tanggal Pendaftaran PCare (yyyy-mm-dd) ----------
function tglPcare() {
  const el = document.getElementById("bulanRiwayat") || BR.findControl("Tanggal Pendaftaran", "input");
  const v = (el && el.value || "").trim();
  let m = v.match(/^(\d{2})-(\d{2})-(\d{4})$/);           // 13-10-2026
  if (m) return `${m[3]}-${m[2]}-${m[1]}`;
  m = v.match(/^(\d{4})-(\d{2})-(\d{2})$/);                // 2026-10-13
  if (m) return v;
  return BR.today();
}

// 🔄 Refresh: tampilkan pasien yang belum terisi, masing-masing dengan tombol ▶
// v1.9.9: 🔄 Refresh = hentikan dulu semua proses (putaran bot, pencarian C-CARE, hitung mundur simpan), lalu baca ulang
let REFRESH_ID = 0;
async function refreshBersih() {
  const r = await getRun();
  if (r.active || looping) { await runStop(); log("🔄 Refresh: proses sebelumnya dihentikan.", "info"); await BR.sleep(400); }
  document.getElementById("br-pratinjau")?.remove();
  tampilkanPasien();
}
async function tampilkanPasien() {
  const idIni = ++REFRESH_ID;
  if (!location.pathname.startsWith(URL_DAFTAR)) {
    log("Membuka halaman Pendaftaran untuk membaca antrean…");
    await BR.store.set("bukaDaftarLaluTampilkan", true);
    location.href = URL_DAFTAR; return;
  }
  const rows = await readQueue(false);
  if (idIni !== REFRESH_ID) return;                    // ada Refresh yang lebih baru
  const box = document.getElementById("br-pasien");
  if (!rows) { box.innerHTML = ""; return; }
  const processed = (await BR.store.get("processed")) || {};
  const belum = rows.filter((r) => perluDilayani(r) && !BR.sudahProses(processed, r));
  const tgl = tglPcare();
  meja.baris = rows; meja.tgl = tgl; meja.belum = belum; meja.dibaca = Date.now(); meja.simpan();
  const tglTampil = /^\d{4}-\d{2}-\d{2}$/.test(tgl) ? tgl.split("-").reverse().join("/") : tgl;
  box.innerHTML = `<div class="br-ringkas"><span>📅 ${tglTampil}</span><span class="br-badge">${belum.length} pasien Baru</span><span class="br-muted">· ${rows.filter((r) => !perluDilayani(r)).length} sudah dilayani (dilewati)</span></div>` +
    (belum.length ? "" : `<div class="br-kosong">🎉 Tidak ada pasien berstatus Baru.</div>`) +
    belum.map((r, i) => `<div class="br-p">
      <span class="br-chip">${r.antrean}</span>
      <div class="br-pinfo"><div class="br-pnama">${r.nama}</div>
        <div class="br-pmeta">${r.kelamin === "P" ? "♀" : r.kelamin === "L" ? "♂" : ""} ${isNaN(r.usia) ? "?" : r.usia} th · ${BR.dokterDariAntrean(r.antrean).nama || "dokter ?"}</div></div>
      <button data-i="${i}" class="br-play" title="Proses pasien ini">▶</button></div>`).join("");
  box.querySelectorAll("button[data-i]").forEach((b) => (b.onclick = () => runStartFor(belum[+b.dataset.i], tgl)));
  tampilRiwayat();
}

// ---------- Ambil data pasien dari C-CARE lewat tab latar belakang ----------
function mintaCcare(cur) {
  return new Promise((res) => {
    try { chrome.runtime.sendMessage({ type: "ambilCcare", req: { nama: cur.nama, kelamin: cur.kelamin, usia: cur.usia, tgl: cur.tgl, kartu: cur.kartu, antrean: cur.antrean, poliPcare: cur.poli || "", abaikanJK: !!cur.abaikanJK } }, (r) => res(r || { ok: false, pesan: "tidak ada jawaban dari ekstensi" })); }
    catch (e) { res({ ok: false, pesan: String(e) }); }
  });
}

// ---------- Data C-CARE ----------
async function showCcareQueue() {
  const q = (await BR.store.get("ccareQueue")) || {};
  const rows = ANTREAN_TERAKHIR.length ? ANTREAN_TERAKHIR : await bacaSemuaHalaman();
  const list = Object.values(q).filter((d) => d.tgl === BR.today());
  const box = document.getElementById("br-ccq");
  if (!list.length) {
    box.innerHTML = `<div class="br-err">Antrian C-CARE hari ini KOSONG. Di C-CARE (ekstensi v0.5), buka kunjungan → klik Kirim.</div>`;
    return;
  }
  box.innerHTML = list.map((d) => {
    const m = rows.find((r) => (d.kartu && r.kartu === d.kartu) ||
      (BR.nameKey(r.nama) === BR.nameKey(d.nama) && (!d.kelamin || d.kelamin === r.kelamin) && (d.umur == null || Math.abs(d.umur - r.usia) <= 1)));
    return `<div class="${m ? "br-ok" : "br-err"}">${m ? "✓ " + m.antrean : "✗ tak cocok"} · ${d.nama || "(tanpa nama)"} · ${d.kelamin || "?"} · ${d.umur ?? "?"} th</div>`;
  }).join("") + `<div class="br-muted">✗ = tidak ada di antrean PCare (semua halaman sudah dibaca; cek ejaan nama / JK / umur).</div>`;
}

// Cocokkan pasien antrean PCare dengan data C-CARE.
// C-CARE tidak memuat No. BPJS -> pakai 3 identitas: Nama + Jenis Kelamin + Umur.
//   kuat  : nama sama persis + JK sama + umur sama   -> boleh simpan otomatis
//   lemah : nama mirip (satu memuat yang lain) atau umur selisih 1 -> bot berhenti sebelum simpan
async function findCcareData(row, jelaskan) {
  const q = (await BR.store.get("ccareQueue")) || {};
  // v1.9.8: kunjungan yang sudah dipilih di langkah pencarian dipakai langsung (dulu dicocokkan ulang dengan aturan lain
  // → "data C-CARE pasien ini tidak ditemukan" padahal baru saja diambil)
  if (row.ccareUrl) {
    const t = q["url:" + BR.pathKunjungan(row.ccareUrl)];
    if (t && t.tgl === BR.today() && (!t.dipakai || t.dipakai === row.antrean)) {
      const strong = (!t.kelamin || !row.kelamin || t.kelamin === row.kelamin) && (t.umur == null || isNaN(row.usia) || Math.abs(t.umur - row.usia) <= 1);
      return { data: t, via: "kunjungan terpilih", strong };
    }
  }
  const semuaHariIni = Object.values(q).filter((d) => d.tgl === BR.today());
  const list = semuaHariIni.filter((d) => !d.dipakai || d.dipakai === row.antrean);   // v1.9.0: kunjungan yang sudah dipakai antrean LAIN tidak dipakai lagi
  const byCard = list.find((d) => d.kartu && d.kartu === row.kartu);
  if (byCard) return { data: byCard, via: "No. Kartu", strong: true };
  const nk = BR.kataNama(row.nama).join(" ");
  const alasan = [];
  const scored = list.map((d) => {
    const dn = BR.kataNama(d.nama).join(" ");
    if (!dn || !nk) { alasan.push(`"${d.nama || "?"}": nama kosong`); return null; }
    const exact = dn === nk;
    const skor = exact ? 1 : BR.namaMirip(d.nama, row.nama);       // v1.9.8: aturan nama sama dengan langkah pencarian
    if (skor < 0.75) return null;
    if (d.kelamin && row.kelamin && d.kelamin !== row.kelamin && !row.abaikanJK) { alasan.push(`"${d.nama}": jenis kelamin ${d.kelamin} ≠ ${row.kelamin}`); return null; }
    const ageDiff = (d.umur == null || isNaN(row.usia)) ? null : Math.abs(d.umur - row.usia);   // umur tak terbaca = tidak menolak
    if (ageDiff != null && ageDiff > 1) { alasan.push(`"${d.nama}": umur ${d.umur} ≠ ${row.usia}`); return null; }
    return { d, strong: exact && d.kelamin === row.kelamin && ageDiff === 0 };
  }).filter(Boolean);
  if (scored.length !== 1) {
    if (scored.length > 1) log(`${row.antrean} ${row.nama}: lebih dari satu data C-CARE mirip — tidak diproses otomatis.`, false);
    else if (jelaskan) {
      const dipakaiLain = semuaHariIni.filter((d) => d.dipakai && d.dipakai !== row.antrean && BR.namaMirip(d.nama, row.nama) >= 0.75);
      log(`Rincian: ${semuaHariIni.length} data C-CARE tersimpan hari ini.` +
        (dipakaiLain.length ? ` Kunjungan ${dipakaiLain.map((d) => d.nama).join(", ")} sudah ditandai terpakai untuk antrean ${dipakaiLain.map((d) => d.dipakai).join(", ")}.` : "") +
        (alasan.length ? ` Ditolak: ${alasan.slice(0, 3).join("; ")}.` : ""), false);
    }
    return null;
  }
  const s0 = scored[0];
  return { data: s0.d, via: s0.strong ? "Nama + JK + Umur" : "nama mirip (perlu cek)", strong: s0.strong };
}

async function loadFromCcare(dataArg) {
  blockAuto = false;
  peringatanPasien = []; catatanRujukan = ""; catatanSkrining = "";
  const data = dataArg || (await BR.store.get("ccareData"));
  if (data && data.nama) BR.ingatNama(data.nama);
  dataAktif = data ? { url: data.ccareUrl || "", kartu: (document.getElementById("br-kartu")?.value || "").trim() } : null;
  if (!data) { log("Belum ada data. Buka kunjungan di C-CARE, klik 'Kirim ke PCare'.", false); return false; }
  if (!data.v || data.v < 3) {
    log(`Data C-CARE "${data.nama || "?"}" dikirim dengan versi ekstensi LAMA (tanpa Tata Laksana/BMHP). Buka kunjungannya di C-CARE dan klik Kirim ULANG.`, false);
    return false;
  }
  const kartuNow = document.getElementById("br-kartu").value.trim();
  if (data.kartu && kartuNow && data.kartu !== kartuNow) {
    blockAuto = true; log(`PERINGATAN: data C-CARE milik kartu ${data.kartu}, bukan ${kartuNow}.`, false);
  }
  FIELDS.forEach(([k]) => { document.getElementById("br-f-" + k).value = data[k] || ""; });
  document.getElementById("br-f-terapiNonObat").value = data.terapiNonObat || DEFAULTS.terapiNonObat;
  document.getElementById("br-f-bmhp").value = data.bmhp || DEFAULTS.bmhp;     // alkes kosong -> teks standar
  if (!data.terapiNonObat) log("Tata Laksana kosong di C-CARE → Terapi Non Obat diisi teks edukasi standar.", false);
  // Dokter ditentukan dari NOMOR ANTREAN (A5-1 -> kode 5); C-CARE hanya pembanding
  const dA = BR.dokterDariAntrean(document.getElementById("br-antrean").value);
  if (dA.nama) {
    document.getElementById("br-dokter").value = dA.nama;
  } else {
    document.getElementById("br-dokter").value = data.dokter || "";
    if (dA.kode) { blockAuto = true; log(`Kode dokter ${dA.kode} dari antrean tidak ada di daftar. Pilih dokter manual.`, false); }
  }
  if (data.kartu && !kartuNow) document.getElementById("br-kartu").value = data.kartu;
  if (!data.anamnesa) log("Anamnesa dokter (isian dokter) kosong di C-CARE.", false);
  if (data.bmhp) log(`BMHP (alkes, tidak masuk Terapi Obat): ${data.bmhp}`);
  if (data._alkesDipindah && data._alkesDipindah.length)
    log(`Dipindah dari resep obat ke BMHP (terdeteksi sebagai alkes): ${data._alkesDipindah.join(", ")}. Periksa.`, false);
  const rj = BR.norm(data.rujukan || "");
  if (rj && /rujuk/.test(rj) && !/tidak|belum|^-/.test(rj)) {
    // v3.2.2: rujukan hanya CATATAN (tidak menahan simpan otomatis); isi spesialis di PCare bersifat opsional
    catatanRujukan = [data.rujukan, data.tindakLanjut ? "tindak lanjut " + data.tindakLanjut : "", data.ketRujukan ? `"${data.ketRujukan}"` : ""].filter(Boolean).join(" · ");
    log(`Catatan rujukan C-CARE: ${catatanRujukan}. Isi spesialis di PCare opsional.`, "info");
  }
  document.getElementById("br-alergi").value = data.alergi || "";
  const ak = await alergiKategoriLengkap(data.alergi);
  alergiHasil = { teks: data.alergi || "", ak };
  for (const o of ak.online) log("Cek online golongan obat: " + o, !/tidak ditemukan/.test(o));
  if (!ak.kosong) {
    blockAuto = true;   // alergi = informasi klinis penting: selalu dicek manusia sebelum simpan
    const ringkas = [...ak.makanan.map((x) => "Makanan: " + x), ...ak.udara.map((x) => "Udara: " + x), ...ak.obat.map((x) => "Obat: " + x)];
    log(`ALERGI di C-CARE: "${data.alergi}" → ${ringkas.length ? ringkas.join(", ") : "kategori TIDAK dikenali, pilih manual"}. Periksa sebelum simpan.`, false);
  }
  log(`Data C-CARE dimuat (${data.nama || "tanpa nama"}).`);
  return true;
}

// ---------- Isi form Pelayanan ----------
// Mengembalikan { missing:[], saved:bool|null }
async function fillForm({ allowAutoSave }) {
  const v = {};
  FIELDS.forEach(([k]) => (v[k] = document.getElementById("br-f-" + k).value.trim()));
  if (findDecisionDialog()) { closeWarnings(); return { missing: ["(dialog keputusan)"], saved: null }; }
  if (location.pathname.startsWith(URL_KUNJ) && !kartuTampil()) {
    log("Pasien belum termuat di form Pelayanan (No.Kartu BPJS kosong). Muat pasien dulu.", false);
    return { missing: ["(pasien belum termuat)"], saved: null };
  }
  if (!v.bmhp) v.bmhp = DEFAULTS.bmhp;
  v.imt = BR.imt(v.bb, v.tb);
  const icds = BR.icdList(v.diagnosa);
  if (icds.length) {
    v.diagnosa = icds[0];
    document.getElementById("br-f-diagnosa").value = icds.join(", ");
    // v3.0.3: sampai MAKS_DX diagnosa (utama + sekunder #2…#4); urutan mengikuti C-CARE
    if (icds.length > MAKS_DX) { blockAuto = true; log(`C-CARE punya ${icds.length} diagnosa, bot mengisi maksimal ${MAKS_DX}. Tidak dimasukkan: ${icds.slice(MAKS_DX).join(", ")}. Pilih sendiri mana yang dipakai.`, false); }
  }
  closeWarnings();

  [["jenisKunjungan", "Jenis Kunjungan"], ["perawatan", "Perawatan"], ["poli", "Poli"], ["prognosa", "Prognosa"]]
    .forEach(([k, lab]) => { const el = ctl(k, lab); if (el && el.tagName === "SELECT") BR.setValue(el, DEFAULTS[k]); });
  await BR.sleep(300);

  const missing = [];
  for (const [k, lab] of FIELDS) {
    if (!v[k]) { if (k !== "bmhp") missing.push(lab); continue; }
    const el = k === "diagnosa" ? kotakDiagnosaUtama() : ctl(k, lab);
    if (!BR.setValue(el, v[k])) { missing.push(lab + " (field tak ditemukan)"); continue; }
    if (k === "diagnosa") {
      const kotakNama = [];
      let utama = await isiKodeDiagnosa(el);
      // v3.4.6: kode 5 karakter (mis. R10.30, J45.20 — gaya ICD-10-CM) sering tidak dikenal PCare (ICD-10 WHO).
      // Coba 4 karakter (R10.3); bila diterima tetap WAJIB dicek petugas (simpan otomatis dimatikan).
      const m5 = /^([A-Z]\d{2}\.\d)\d$/.exec(v[k]);
      if (m5 && !(el.value || "").trim()) {
        BR.setValue(el, m5[1]); utama = await isiKodeDiagnosa(el);
        if ((el.value || "").trim()) {
          blockAuto = true; icds[0] = m5[1];
          log(`Diagnosa utama ${v[k]} tidak dikenal PCare → diganti ${m5[1]}${utama.nameBox?.value ? ` (${utama.nameBox.value})` : ""}. Periksa sebelum simpan.`, false);
        }
      }
      kotakNama.push(utama.nameBox);
      const kodeUtama = (el.value || "").trim();
      if (!kodeUtama) {
        // PCare mengosongkan kotak → kode tidak diterima. Diagnosa sekunder TIDAK diisi (agar tidak "utama kosong, sekunder terisi").
        missing.push(`Diagnosa utama: kode ${v[k]} tidak diterima PCare (kotak dikosongkan). Cek kode di C-CARE`);
        cekNamaDiagnosa = () => false;
        await BR.sleep(60);
        continue;
      }
      if (utama.nameBox && !utama.nameBox.value) missing.push("Diagnosa (nama penyakit belum muncul" + (statusCloudflare() === "lolos" ? ", klik [...])" : `). ${SARAN_RELOAD}`));
      else if (utama.nameBox) log(`Diagnosa ${v[k]} → ${utama.nameBox.value}`);
      // Diagnosa #2, #3, #4 (sekunder)
      let barisSebelum = el;
      for (const [n, kode] of icds.slice(1, MAKS_DX).map((x, i) => [i + 2, x])) {
        const lab = `Diagnosa #${n} (sekunder)`;
        const elN = await kotakDiagnosaSekunder(n, barisSebelum);
        if (!elN || !BR.setValue(elN, kode)) {
          missing.push(`${lab}: ${kode} (kotak tak ditemukan${n >= 4 ? " — PCare mungkin hanya menyediakan sampai #3" : ""})`);
          // v3.4.6: catat susunan baris diagnosa (label, tombol, kelas — TANPA isi) supaya pencari kotak bisa diperbaiki
          const b = barisSebelum?.closest(".form-group, .row, tr")?.parentElement;
          if (b) BR.keFile("PCARE", "INFO", "Struktur baris diagnosa: " + [...b.querySelectorAll("label, button, a, input, span[class*=addon], i[class*=fa-], i[class*=glyphicon]")].slice(0, 40)
            .map((x) => `${x.tagName.toLowerCase()}${x.id ? "#" + x.id : ""}${x.className ? "." + String(x.className).trim().split(/\s+/).slice(0, 3).join(".") : ""}${x.title ? `[${x.title}]` : ""}${/^(LABEL|BUTTON|A)$/.test(x.tagName) ? `"${x.textContent.trim().slice(0, 30)}"` : ""}`).join(" "));
          continue;
        }
        const h = await isiKodeDiagnosa(elN);
        kotakNama.push(h.nameBox);
        if (h.nameBox && !h.nameBox.value) missing.push(`${lab}: ${kode} (nama penyakit belum muncul)`);
        else log(`${lab} ${kode} → ${h.nameBox ? h.nameBox.value : "?"}`);
        barisSebelum = elN;
      }
      // Pemeriksaan akhir: kode di tiap baris harus sama persis dengan urutan C-CARE
      const harus = icds.slice(0, MAKS_DX), baris = [el, ...nomorSekunder().map((n) => kotakSekunderTampil(n))];
      const sama = (a, b) => String(a || "").toUpperCase().replace(/[^A-Z0-9]/g, "") === String(b || "").toUpperCase().replace(/[^A-Z0-9]/g, "");
      const salah = harus.map((kd, i) => (sama(baris[i]?.value, kd) ? null : `${i ? `#${i + 1}` : "utama"} seharusnya ${kd}, di form "${baris[i]?.value || "kosong"}"`)).filter(Boolean);
      const lebih = baris.slice(harus.length).filter((b) => b && b.value.trim()).map((b) => b.value.trim());
      if (salah.length || lebih.length) missing.push(`Diagnosa tidak sesuai: ${[...salah, ...lebih.map((x) => `ada kode lebih "${x}"`)].join("; ")}`);
      cekNamaDiagnosa = () => !salah.length && !lebih.length && kotakNama.every((b) => !b || !!b.value);
    }
    await BR.sleep(60);
  }
  // v1.9.3: panjang isian teks sesuai aturan form PCare (dibaca 16-10-2026). Nilai yang diisi lewat skrip
  // melewati batas maxlength di layar, jadi diperiksa di sini supaya tidak ditolak / terpotong saat Simpan.
  for (const [k, [lab, mn, mx]] of Object.entries(PANJANG_PCARE)) {
    const n = String(v[k] || "").trim().length;
    if (v[k] && (n < mn || n > mx)) missing.push(`${lab}: ${n} karakter, PCare meminta ${mn ? mn + "–" : "paling banyak "}${mx}`);
  }
  const imtEl = ctl("imt", "IMT");
  if (imtEl && v.imt && !imtEl.value) BR.setValue(imtEl, v.imt);
  // Hasil ukur: pesan merah PCare "… tidak sesuai" + batas wajar sendiri → TIDAK disimpan, diisi manual
  await BR.sleep(500);
  for (const m of hasilUkurTidakSesuai(v)) missing.push(m);

  // Riwayat Alergi: pilih kategori PCare (Makanan / Udara / Obat-Obatan) dari teks C-CARE
  const teksAl = document.getElementById("br-alergi").value;
  const ak = (alergiHasil && alergiHasil.teks === teksAl) ? alergiHasil.ak : await alergiKategoriLengkap(teksAl);
  for (const [grp, lab] of [["makanan", "Makanan"], ["udara", "Udara"], ["obat", "Obat-Obatan"]]) {
    const sel = BR.findControl(lab, "select");
    if (!sel) { if (!ak.kosong && ak[grp].length) missing.push(`Alergi ${lab} (dropdown tak ditemukan)`); continue; }
    const pilih = ak[grp][0] || DEFAULTS.alergi;
    if (!BR.setValue(sel, pilih)) missing.push(`Alergi ${lab}: opsi "${pilih}" tak ditemukan`);
    if (ak[grp].length > 1) log(`Alergi ${lab}: lebih dari satu kategori (${ak[grp].join(", ")}). Dipilih "${pilih}", periksa.`, false);
  }
  if (ak.belumTerbaca) missing.push("Riwayat Alergi (teks C-CARE tidak bisa dikategorikan)");

  BR.clickChoice(DEFAULTS.kesadaran) || BR.setValue(ctl("kesadaran", "Kesadaran"), DEFAULTS.kesadaran);
  BR.clickChoice(DEFAULTS.statusPulang) || BR.setValue(ctl("statusPulang", "Status Pulang"), DEFAULTS.statusPulang);

  if (!document.getElementById("br-dokter").value) {
    const dA2 = BR.dokterDariAntrean(document.getElementById("br-antrean").value);
    if (dA2.nama) document.getElementById("br-dokter").value = dA2.nama;
  }
  const dok = document.getElementById("br-dokter").value;
  if (dok) {
    const el = ctl("dokter", "Tenaga Medis") || ctl("dokter", "Dokter");
    if (BR.pilihDokter(el, dok)) log(`Dokter: kode ${BR.DOKTER_KODE[dok]} · ${dok}`);
    else missing.push("Dokter (kode " + (BR.DOKTER_KODE[dok] || "?") + " tidak ditemukan di dropdown)");
  }
  else missing.push("Dokter");

  if (missing.length) log("Periksa manual: " + missing.join(", "), false);
  else log("Semua field terisi.");

  catatStrukturSkrining();
  catatanSkrining = isiSkriningNormal();
  if (!allowAutoSave) return { missing, saved: null };
  const keputusan = await pratinjau(missing);
  // v3.2.4: Simpan di form PCare diklik langsung saat pratinjau terbuka → hasilnya dipantau seperti simpan oleh bot
  if (keputusan === "sudahDiklik") return { missing, saved: await watchResult() };
  if (keputusan !== "simpan") return { missing, saved: null };
  return { missing, saved: await klikSimpan() };
}

// v3.2.4: catat BENTUK isian skrining di form Pelayanan (judul, label, jenis isian, pilihan) — tanpa data pasien —
// sekali per jenis kelamin per hari, untuk menyiapkan pengisian skrining otomatis laki-laki/perempuan.
function catatStrukturSkrining() {
  try {
    const judul = [...document.querySelectorAll("legend, h3, h4, h5, label, .box-title, .panel-title, .modal-title, th, b, strong")]
      .filter((e) => !e.closest(BR.UI_SENDIRI) && BR.visible(e) && /skrining|screening|srk/i.test(e.textContent || ""));
    if (!judul.length) return;
    const jk = (document.getElementById("br-jk") || {}).value || kelaminTampil() || "?";
    const kunci = "br-skrining-" + jk + "-" + BR.today();
    if (localStorage.getItem(kunci)) return;
    localStorage.setItem(kunci, "1");
    const wadah = [...new Set(judul.map((e) => e.closest("fieldset, .box, .panel, .card, .modal-content, .form-group, table") || e.parentElement))].slice(0, 4);
    const bagian = wadah.map((w) => {
      const kontrol = [...w.querySelectorAll("input:not([type=hidden]), select, textarea")].slice(0, 40).map((el) => {
        const lab = (el.id && document.querySelector(`label[for="${CSS.escape(el.id)}"]`)?.textContent) || el.closest("label")?.textContent || el.closest("tr, .form-group, div")?.querySelector("label, th, td")?.textContent || "";
        const opsi = el.tagName === "SELECT" ? " [" + [...el.options].map((o) => o.text.trim()).slice(0, 8).join("/") + "]" : "";
        return `${lab.replace(/\s+/g, " ").trim().slice(0, 60)}=${el.tagName.toLowerCase()}${el.type ? ":" + el.type : ""}${el.name ? "(" + el.name + ")" : el.id ? "(#" + el.id + ")" : ""}${opsi}`;
      });
      return `«${(w.querySelector("legend, h3, h4, h5, .box-title, .panel-title, .modal-title, th") || {}).textContent?.replace(/\s+/g, " ").trim().slice(0, 60) || "?"}» ` + kontrol.join("; ");
    });
    BR.keFile("PCARE", "INFO", `Struktur skrining PCare (JK ${jk}, tanpa data pasien): ` + bagian.join(" || ").slice(0, 2500));
  } catch (e) { BR.keFile("PCARE", "INFO", "Struktur skrining tidak terbaca: " + e); }
}
// v3.2.5: SKRINING DIISI "NORMAL" OTOMATIS (keputusan petugas: skrining pasien poli tidak bermasalah).
// Hanya di bagian berjudul Skrining/Screening. Tiap pertanyaan pilihan (radio/dropdown) yang BELUM dijawab diisi jawaban
// normal: Normal > Negatif > Tidak ada > Tidak > Baik. Pertanyaan khusus perempuan (hamil, haid, payudara, serviks/IVA)
// dilewati untuk pasien laki-laki, dan sebaliknya. Isian teks/angka tidak disentuh. Semua isian tercatat di log rinci.
const JAWAB_NORMAL = [/^normal\b/, /^negatif\b|^\(-\)$/, /^tidak ada\b|^tidak ditemukan\b/, /^tidak\b|^tdk\b|^no$/, /^baik\b/];
const KHUSUS_P = /hamil|kehamilan|haid|menstruasi|menopause|payudara|sadanis|serviks|iva\b|pap ?smear|keputihan|kontrasepsi|kb\b/;
const KHUSUS_L = /prostat|testis|skrotum/;
function wadahSkrining() {
  const judul = [...document.querySelectorAll("legend, h3, h4, h5, .box-title, .panel-title, .modal-title, label, th, b, strong")]
    .filter((e) => !e.closest(BR.UI_SENDIRI) && BR.visible(e) && /skrining|screening/i.test(e.textContent || ""));
  // v3.2.8: Skrining Riwayat Kesehatan (SRK) = jawaban PASIEN sendiri → TIDAK pernah diisi otomatis
  return [...new Set(judul.map((e) => e.closest("fieldset, .box, .panel, .card, .modal-content, table") || e.parentElement))]
    .filter((w) => !/riwayat kesehatan|\bsrk\b/i.test(w.textContent || ""));
}
const labelOpsi = (r) => BR.norm((r.id && document.querySelector(`label[for="${CSS.escape(r.id)}"]`)?.textContent) || r.closest("label")?.textContent || r.nextSibling?.textContent || r.value || "");
const labelSoal = (el) => BR.norm((el.closest("tr")?.querySelector("td, th")?.textContent) || el.closest(".form-group, .row, li, div")?.querySelector("label, .control-label, b, span")?.textContent || el.name || "");
function isiSkriningNormal() {
  const wadah = wadahSkrining();
  if (!wadah.length) return "";
  const jk = JK_PASIEN || kelaminTampil();
  let terisi = 0, lewat = 0, tanpaNormal = [];
  const cocokNormal = (teks) => { for (let i = 0; i < JAWAB_NORMAL.length; i++) if (JAWAB_NORMAL[i].test(teks)) return i; return -1; };
  const bolehUntuk = (soal) => !((jk === "L" && KHUSUS_P.test(soal)) || (jk === "P" && KHUSUS_L.test(soal)));
  for (const w of wadah) {
    // radio per nama
    const grup = {};
    for (const r of w.querySelectorAll("input[type=radio]")) if (r.name && !r.disabled && BR.visible(r)) (grup[r.name] = grup[r.name] || []).push(r);
    for (const [nama, rs] of Object.entries(grup)) {
      if (rs.some((r) => r.checked)) continue;                 // sudah dijawab: tidak diubah
      const soal = labelSoal(rs[0]);
      if (!bolehUntuk(soal)) { lewat++; continue; }
      const kandidat = rs.map((r) => [r, cocokNormal(labelOpsi(r))]).filter(([, i]) => i >= 0).sort((a, b) => a[1] - b[1]);
      if (!kandidat.length) { tanpaNormal.push(soal.slice(0, 40) || nama); continue; }
      const r = kandidat[0][0]; r.click(); BR.fire(r);
      BR.keFile("PCARE", "RINCI", `Skrining: "${soal.slice(0, 60)}" → ${labelOpsi(r)}`); terisi++;
    }
    // dropdown
    for (const sel of w.querySelectorAll("select")) {
      if (sel.disabled || !BR.visible(sel) || (sel.value && sel.selectedIndex > 0)) continue;
      const soal = labelSoal(sel);
      if (!bolehUntuk(soal)) { lewat++; continue; }
      const o = [...sel.options].filter((o) => o.value).map((o) => [o, cocokNormal(BR.norm(o.text))]).filter(([, i]) => i >= 0).sort((a, b) => a[1] - b[1])[0];
      if (!o) { tanpaNormal.push(soal.slice(0, 40) || sel.name || sel.id); continue; }
      sel.value = o[0].value; BR.fire(sel); if (window.jQuery) try { window.jQuery(sel).trigger("change"); } catch (e) {}
      BR.keFile("PCARE", "RINCI", `Skrining: "${soal.slice(0, 60)}" → ${o[0].text.trim()}`); terisi++;
    }
  }
  if (!terisi && !tanpaNormal.length) return "";
  if (tanpaNormal.length) log(`Skrining: ${tanpaNormal.length} pertanyaan tanpa pilihan "normal" (${tanpaNormal.slice(0, 3).join("; ")}). Isi manual.`, false);
  const ringkas = `${terisi} pertanyaan diisi normal (${jk === "P" ? "perempuan" : jk === "L" ? "laki-laki" : "JK ?"})${lewat ? `, ${lewat} khusus ${jk === "L" ? "perempuan" : "laki-laki"} dilewati` : ""}`;
  log("Skrining: " + ringkas + ".", "info");
  return ringkas;
}
function kelaminTampil() { const t = BR.norm(readShown("Kelamin") || readShown("Jenis Kelamin") || ""); return /^p|perempuan|wanita/.test(t) ? "P" : /^l|laki/.test(t) ? "L" : ""; }

// Klik Simpan PCare (dengan cek ulang No.Kartu) lalu tunggu "Menunggu Verifikasi"
async function klikSimpan() {
  if (BERHENTI) { log("Simpan dibatalkan: bot dihentikan.", false); return null; }
  const runNow = await getRun();
  if (runNow.dihentikan) { log("Simpan dibatalkan: bot dihentikan.", false); return null; }
  if (runNow.active && runNow.current && kartuTampil() && kartuTampil() !== runNow.current.kartu) {
    log("Simpan dibatalkan: No.Kartu di form berubah / tidak cocok.", false); return null;
  }
  BOT_KLIK_SIMPAN = true;
  const ada = BR.clickButton("Simpan");
  BOT_KLIK_SIMPAN = false;
  // tombol hilang = biasanya sudah disimpan (mis. Anda klik Simpan PCare lebih dulu) → dicek di daftar antrean, tidak disimpan ulang
  if (!ada) { log("Tombol Simpan tidak ada di form. Status dicek di daftar antrean PCare.", "info"); return "?"; }
  log("Simpan diklik…");
  return await watchResult();
}

// =====================================================================
// PRATINJAU SEBELUM SIMPAN
// Menampilkan isi yang BENAR-BENAR terisi di form PCare + peringatan.
// - Simpan otomatis ON & tanpa peringatan: hitung mundur 5 dtk lalu simpan (bisa dibatalkan)
// - Selain itu: menunggu Anda klik 💾 Simpan atau ✏️ Koreksi
// return "simpan" | "koreksi"
// =====================================================================
function nilaiForm(key, label) {
  const el = ctl(key, label);
  if (!el) return "";
  if (el.tagName === "SELECT") return el.options[el.selectedIndex]?.text || "";
  return el.value || "";
}
function pilihanRadio(teksList) {
  for (const t of teksList) {
    const r = [...document.querySelectorAll("input[type=radio]:checked")].find((x) => {
      const lab = (x.id && document.querySelector(`label[for="${CSS.escape(x.id)}"]`)) || x.closest("label") || x.parentElement;
      return BR.norm(lab?.textContent || "") === BR.norm(t);
    });
    if (r) return t;
  }
  return "";
}
function pratinjau(missing) {
  return new Promise((resolve) => {
    document.getElementById("br-pratinjau")?.remove();
    const dxEl = kotakDiagnosaUtama();
    const dxRow = dxEl && dxEl.closest(".input-group, .form-group, div");
    const dxNama = dxRow ? ([...dxRow.querySelectorAll("input")].find((x) => x !== dxEl)?.value || "") : "";
    const sel = (lab) => { const s = BR.findControl(lab, "select"); return s ? s.options[s.selectedIndex]?.text || "" : ""; };
    const dokEl = ctl("dokter", "Tenaga Medis") || ctl("dokter", "Dokter");
    const baris = [
      ["Keluhan", nilaiForm("keluhan", "Keluhan")],
      ["Anamnesa", nilaiForm("anamnesa", "Anamnesa")],
      ["Diagnosa", `${dxEl?.value || ""} ${dxNama ? "– " + dxNama : ""}`.trim()],
      ...nomorSekunder().map((n) => { const e = kotakSekunderTampil(n); if (!e || !e.value) return null;
        const nm = [...(e.closest(".input-group, .form-group, div")?.querySelectorAll("input") || [])].find((x) => x !== e && x.type !== "hidden")?.value || "";
        return [`Diagnosa #${n}`, `${e.value} ${nm ? "– " + nm : ""}`.trim()]; }).filter(Boolean),
      ["Terapi Obat", nilaiForm("terapiObat", "Terapi Obat")],
      ["Terapi Non Obat", nilaiForm("terapiNonObat", "Terapi Non Obat")],
      ["BMHP", nilaiForm("bmhp", "BMHP")],
      ["Alergi", `Makanan: ${sel("Makanan") || "?"} · Udara: ${sel("Udara") || "?"} · Obat: ${sel("Obat-Obatan") || "?"}`],
      ["TTV", `TD ${nilaiForm("sistole", "Sistole")}/${nilaiForm("diastole", "Diastole")} · N ${nilaiForm("hr", "Heart Rate")} · RR ${nilaiForm("rr", "Respiratory Rate")} · S ${nilaiForm("suhu", "Suhu")}`],
      ["Antropometri", `TB ${nilaiForm("tb", "Tinggi Badan")} · BB ${nilaiForm("bb", "Berat Badan")} · LP ${nilaiForm("lp", "Lingkar Perut")} · IMT ${nilaiForm("imt", "IMT")}`],
      ["Kesadaran", nilaiForm("kesadaran", "Kesadaran") || pilihanRadio(["Compos mentis"])],
      ["Status Pulang", pilihanRadio(["Berobat Jalan", "Rujuk", "Rujuk Atas Permintaan Sendiri (APS)", "Meninggal"]) || nilaiForm("statusPulang", "Status Pulang")],
      ["Dokter", dokEl && dokEl.tagName === "SELECT" ? dokEl.options[dokEl.selectedIndex]?.text || "" : ""],
      ...(catatanSkrining ? [["Skrining", catatanSkrining]] : []),
      ...(catatanRujukan ? [["Catatan rujukan", catatanRujukan + " (opsional)"]] : []),
    ];
    const kosong = (v) => !String(v).replace(/[\s·?/:–-]|TD|N|RR|S|TB|BB|LP|IMT|Makanan|Udara|Obat/g, "");
    if (cekNamaDiagnosa()) missing = missing.filter((m) => !/^Diagnosa \(nama penyakit belum muncul/.test(m));   // sudah muncul belakangan
    const warn = [...new Set([...missing.map((m) => "Belum terisi: " + m), ...peringatanPasien.filter((p) => !(cekNamaDiagnosa() && /nama penyakit belum muncul/.test(p)))])];
    const auto = (document.getElementById("br-auto").checked || runNonstop) && !blockAuto && !missing.length;
    if (runNonstop && !auto) { resolve("lewati"); return; }   // Nonstop: ada peringatan → TIDAK disimpan, pasien dilewati

    const box = document.createElement("div");
    box.id = "br-pratinjau";
    box.setAttribute("role", "dialog"); box.setAttribute("aria-modal", "true"); box.setAttribute("aria-labelledby", "br-pv-judul");
    const subjudul = `${document.getElementById("br-antrean").value || "?"} · No.Kartu ${kartuTampil() ? "****" + kartuTampil().slice(-4) : "belum termuat"}`;
    box.innerHTML = `
      <div class="br-pv-head"><div><div class="br-pv-judul" id="br-pv-judul">Pratinjau sebelum simpan</div><div class="br-pv-sub"></div></div>
        <button type="button" class="br-pv-x" id="br-pv-x" title="Batal (Esc) — tidak disimpan" aria-label="Batal">×</button></div>
      <div class="br-pv-isi">
        ${warn.length ? `<div class="br-pv-warn"><b>Perlu dicek (${warn.length})</b><ul>${warn.map(() => "<li></li>").join("")}</ul></div>` : `<div class="br-pv-ok">Siap disimpan — tidak ada peringatan</div>`}
        <table>${baris.map(([k, v]) => `<tr class="${kosong(v) ? "br-pv-kosong" : ""}"><th>${k}</th><td></td></tr>`).join("")}</table>
      </div>
      <div class="br-pv-kaki"><div id="br-pv-hitung" class="br-muted"></div>
        <div class="br-pv-btns"><button type="button" id="br-pv-batal" class="br-pv-tautan">Batal</button><span class="br-pv-celah"></span>
          <button type="button" id="br-pv-koreksi">Koreksi</button><button type="button" id="br-pv-simpan" class="br-primary">Simpan ke PCare</button></div></div>`;
    // isi teks lewat textContent (aman dari HTML di data pasien)
    box.querySelector(".br-pv-sub").textContent = subjudul;
    box.querySelectorAll("td").forEach((td, i) => (td.textContent = kosong(baris[i][1]) ? "Kosong" : baris[i][1]));
    box.querySelectorAll(".br-pv-warn li").forEach((li, i) => (li.textContent = warn[i]));
    document.body.appendChild(box);
    if (BR.diAplikasi) cerminPv.pasang(box);          // v3.2.0: tampil di kolom kanan aplikasi, bukan menutupi PCare
    else box.querySelector("#br-pv-simpan").focus();

    let timer = null;
    const tutupEsc = (e) => { if (e.key === "Escape" && !BR.diAplikasi) batal(); };   // di aplikasi: Esc ditangani kolom kanan (Esc di form PCare tidak membatalkan)
    const selesai = (hasil) => { clearInterval(timer); PRATINJAU_BATAL = null; PRATINJAU_SIMPAN_PCARE = null; document.removeEventListener("keydown", tutupEsc, true); cerminPv.lepas(box); box.remove(); resolve(hasil); };
    const batal = () => { log("Pratinjau dibatalkan: tidak disimpan. Perbaiki di form PCare lalu klik Simpan PCare, atau ⏭ Lanjut / ⏩ Lewati.", "info"); selesai("koreksi"); };
    document.addEventListener("keydown", tutupEsc, true);
    PRATINJAU_BATAL = () => { log("Hitung mundur simpan dibatalkan: bot dihentikan.", "info"); selesai("koreksi"); };
    PRATINJAU_SIMPAN_PCARE = () => { log("Simpan di form PCare diklik langsung → pratinjau ditutup, hasil simpan dipantau.", "info"); selesai("sudahDiklik"); };
    box.querySelector("#br-pv-simpan").onclick = () => selesai("simpan");
    box.querySelector("#br-pv-x").onclick = batal;
    box.querySelector("#br-pv-batal").onclick = batal;
    // v1.9.9: Koreksi TIDAK menutup pratinjau; isian berubah jadi kotak edit, lalu Simpan menulis ke form PCare dan menyimpan
    box.querySelector("#br-pv-koreksi").onclick = () => { clearInterval(timer); box.querySelector("#br-pv-hitung").textContent = ""; modeEdit(box, warn, selesai); };
    if (auto) {
      let n = 5;
      const hit = box.querySelector("#br-pv-hitung");
      hit.textContent = `Simpan otomatis dalam ${n} detik — klik Koreksi atau Batal untuk menahan.`;
      timer = setInterval(() => {
        n--;
        if (BERHENTI) { selesai("koreksi"); return; }
        if (n <= 0) selesai("simpan");
        else hit.textContent = `Simpan otomatis dalam ${n} detik — klik Koreksi atau Batal untuk menahan.`;
      }, 1000);
    }
  });
}

// =====================================================================
// v3.2.0 PRATINJAU DI KOLOM KANAN APLIKASI
// Kotak pratinjau tetap dibuat di halaman (logika & validasi sama), tetapi disembunyikan;
// isinya dicerminkan ke penyimpanan "pratinjauAktif" dan aplikasi menggambarnya di kolom kanan.
// Klik di aplikasi dikirim balik lewat perintahBot {cmd:"pv"} lalu tombol yang sama diklik di sini.
// =====================================================================
var cerminPv = {
  box: null, obs: null, t: null,
  pasang(box) {
    this.box = box; box.classList.add("br-jauh");
    box.dataset.pvid = Date.now().toString(36); box.dataset.gen = "1";
    this.obs = new MutationObserver(() => this.kirim());
    this.obs.observe(box, { subtree: true, childList: true, characterData: true, attributes: true });
    this.kirim(0);
  },
  kirim(tunda = 60) {
    clearTimeout(this.t);
    this.t = setTimeout(() => { if (this.box && this.box.isConnected) BR.store.set("pratinjauAktif", uraiPv(this.box)); }, tunda);
  },
  lepas(box) {
    if (!this.box || this.box !== box) return;
    this.obs.disconnect(); clearTimeout(this.t); this.box = null;
    BR.store.set("pratinjauAktif", null);
  },
};
function uraiPv(box) {
  const tx = (s) => (box.querySelector(s)?.textContent || "").trim();
  const pe = box.querySelector(".br-pv-warn, .br-pv-ok");
  const pesan = pe ? { jenis: pe.classList.contains("br-pv-warn") ? "warn" : "ok",
    judul: (pe.querySelector("b") ? pe.querySelector("b").textContent : pe.textContent).trim(),
    item: [...pe.querySelectorAll("li")].map((li) => li.textContent) } : null;
  const baris = [...box.querySelectorAll("table tr")].map((tr) => {
    const th = (tr.querySelector("th")?.textContent || "").trim(), td = tr.querySelector("td"), f = td && td.querySelector("[data-k]");
    if (f) return { th, k: f.dataset.k, tipe: f.tagName === "TEXTAREA" ? "area" : f.getAttribute("inputmode") ? "num" : "teks",
      baris: +(f.getAttribute("rows") || 0), nilai: f.value, mati: f.disabled, contoh: f.placeholder };
    return { th, td: td ? td.textContent : "", kosong: tr.classList.contains("br-pv-kosong"), catatan: !!(td && td.classList.contains("br-muted")) };
  });
  const tombol = [...box.querySelectorAll(".br-pv-btns button")].filter((b) => b.id !== "br-pv-kecil")
    .map((b) => ({ id: b.id, teks: b.textContent.trim(), primer: b.classList.contains("br-primary"), tautan: b.classList.contains("br-pv-tautan"), mati: b.disabled }));
  return { id: box.dataset.pvid, gen: box.dataset.gen, edit: box.classList.contains("br-pv-edit"), judul: tx(".br-pv-judul"), sub: tx(".br-pv-sub"),
    antrean: (document.getElementById("br-antrean") || {}).value || "", kartu: kartuTampil() || "", pesan, baris, hitung: tx("#br-pv-hitung"), tombol, at: Date.now() };
}
// klik dari kolom kanan aplikasi → tombol yang sama di kotak pratinjau
function pvDariAplikasi(c) {
  const box = document.getElementById("br-pratinjau");
  if (!box || box.dataset.pvid !== c.pvId) return lapor(c.id, false, "Pratinjau sudah ditutup.");
  if (c.nilai) for (const [k, v] of Object.entries(c.nilai)) { const f = box.querySelector(`[data-k="${CSS.escape(k)}"]`); if (f && !f.disabled) f.value = String(v); }
  const b = box.querySelector("#" + CSS.escape(String(c.tombol || "")));
  if (!b || b.disabled) return lapor(c.id, false, "Tombol itu tidak tersedia lagi.");
  if (c.tombol === "br-pv-koreksi" || c.tombol === "br-pv-muat") box.dataset.gen = String(+box.dataset.gen + 1);   // isian dimuat ulang dari form
  lapor(c.id, true, "");
  b.click();
  cerminPv.kirim(0);
}

function modeEdit(box, warn, selesai) {
  box.classList.add("br-pv-edit");
  box.querySelector(".br-pv-judul").textContent = "Koreksi sebelum simpan";
  const tb = box.querySelector("table");
  tb.innerHTML = EDIT_PV.map(([k, lab, t]) => `<tr><th>${lab}</th><td>${t === "area" ? `<textarea data-k="${k}" rows="${k === "terapiObat" || k === "anamnesa" ? 3 : 2}"></textarea>` : `<input data-k="${k}" ${t === "num" ? 'inputmode="decimal"' : ""}>`}</td></tr>`).join("") +
    `<tr><th>Lainnya</th><td class="br-muted">Diagnosa: isi kode ICD-10 (mis. J06.9). Kosongkan kotak #2–#4 untuk menghapus diagnosa sekunder. Alergi, Kesadaran, Status Pulang, Dokter: ubah langsung di form PCare${BR.diAplikasi ? "" : " (pratinjau boleh dikecilkan)"}.</td></tr>`;
  const asal = {};
  const muat = () => EDIT_PV.forEach(([k, lab]) => { const el = elEdit(k, lab); const v = el ? (el.tagName === "SELECT" ? el.options[el.selectedIndex]?.text || "" : el.value || "") : "";
    asal[k] = v; const inp = tb.querySelector(`[data-k="${k}"]`); inp.value = v;
    const dxSek = nomorDx(k) > 1; inp.disabled = !el && !dxSek; inp.placeholder = el ? "" : dxSek ? "(kosong — isi kode untuk menambah)" : "(isian tidak ada di form)"; });
  muat();
  const pesan = box.querySelector(".br-pv-warn, .br-pv-ok");
  const tulisPesan = (list) => { if (!pesan) return; pesan.className = list.length ? "br-pv-warn" : "br-pv-ok";
    pesan.innerHTML = list.length ? `<b>Perlu dicek (${list.length})</b><ul>${list.map(() => "<li></li>").join("")}</ul>` : "Tidak ada peringatan";
    pesan.querySelectorAll("li").forEach((li, i) => (li.textContent = list[i])); };
  const btns = box.querySelector(".br-pv-btns");
  btns.innerHTML = `<button type="button" id="br-pv-tutup" class="br-pv-tautan">Batal</button><button type="button" id="br-pv-muat" class="br-pv-tautan">Muat ulang dari form</button><span class="br-pv-celah"></span>
    <button type="button" id="br-pv-kecil">Kecilkan</button><button type="button" id="br-pv-tulis" class="br-primary">Simpan ke PCare</button>`;
  btns.querySelector("#br-pv-muat").onclick = muat;
  btns.querySelector("#br-pv-kecil").onclick = (e) => { box.classList.toggle("br-pv-kecil"); e.target.textContent = box.classList.contains("br-pv-kecil") ? "Besarkan" : "Kecilkan"; };
  const tutupEdit = () => { log("Koreksi dibatalkan: tidak disimpan. Perbaiki di form PCare, klik Simpan PCare, lalu ⏭ Lanjut.", "info"); selesai("koreksi"); };
  btns.querySelector("#br-pv-tutup").onclick = tutupEdit;
  box.querySelector("#br-pv-x").onclick = tutupEdit;
  btns.querySelector("#br-pv-tulis").onclick = async (e) => {
    const b = e.target; b.disabled = true; b.textContent = "Menulis ke form…";
    const nilai = {}; tb.querySelectorAll("[data-k]").forEach((x) => (nilai[x.dataset.k] = x.value.trim()));
    // cek dulu: batas hasil ukur dan panjang teks PCare
    const masalah = [];
    for (const [k, [lab, mn, mx]] of Object.entries(PANJANG_PCARE)) { const n = (nilai[k] || "").length; if (nilai[k] && (n < mn || n > mx)) masalah.push(`${lab}: ${n} karakter, PCare meminta ${mn ? mn + "–" : "paling banyak "}${mx}`); }
    for (const [k, [lo, hi, sat]] of Object.entries(BATAS_UKUR)) { const s = nilai[k]; if (!s) continue; const n = parseFloat(s.replace(",", "."));
      if (s.length > (k === "suhu" ? 5 : 3) || isNaN(n) || n < lo || n > hi) masalah.push(`${(EDIT_PV.find((x) => x[0] === k) || [, k])[1]}: ${s} ${sat} di luar batas PCare (${lo}–${hi})`); }
    if (nilai.diastole && nilai.sistole && +nilai.diastole >= +nilai.sistole) masalah.push("Diastole harus lebih kecil dari Sistole");
    // diagnosa: kode ICD-10 sah, tanpa lompatan (#3 terisi tetapi #2 kosong), tanpa kode ganda
    const dx = [1, 2, 3, 4].map((n) => (nilai[n === 1 ? "diagnosa" : "diagnosa" + n] || "").toUpperCase().replace(/\s+/g, ""));
    dx.forEach((kd, i) => { if (kd && !/^[A-Z]\d{2}(\.?\d{1,2})?$/.test(kd)) masalah.push(`Diagnosa ${i ? "#" + (i + 1) : "utama"}: "${kd}" bukan kode ICD-10`); });
    if (!dx[0]) masalah.push("Diagnosa utama wajib diisi");
    dx.forEach((kd, i) => { if (kd && i && !dx[i - 1]) masalah.push(`Diagnosa #${i + 1} terisi tetapi ${i === 1 ? "utama" : "#" + i} kosong — isi berurutan`); });
    const dup = dx.filter((kd, i) => kd && dx.indexOf(kd) !== i); if (dup.length) masalah.push(`Kode diagnosa ganda: ${[...new Set(dup)].join(", ")}`);
    if (masalah.length) { tulisPesan(masalah); b.disabled = false; b.textContent = "Simpan ke PCare"; return; }
    const gagalTulis = (m) => { tulisPesan([].concat(m)); b.disabled = false; b.textContent = "Simpan ke PCare"; };
    for (const [k, lab] of EDIT_PV) {
      if (nomorDx(k) || nilai[k] === asal[k]) continue;
      const el = elEdit(k, lab); if (!el) continue;
      if (nilai[k]) BR.setValue(el, nilai[k]); else if (el.tagName !== "SELECT") kosongkan(el);
    }
    // diagnosa ditulis berurutan: utama, #2, #3, #4 (baris sekunder dibuka dengan ⊕ bila perlu)
    let sebelum = null;
    for (let n = 1; n <= MAKS_DX; n++) {
      const k = n === 1 ? "diagnosa" : "diagnosa" + n, lab = n === 1 ? "Diagnosa utama" : `Diagnosa #${n}`;
      const baru = nilai[k], lama = asal[k];
      let el = n === 1 ? kotakDiagnosaUtama() : kotakSekunderTampil(n);
      if (baru === lama) { if (el) sebelum = el; continue; }
      if (!baru) {   // hapus diagnosa sekunder
        if (el) { kosongkan(el); const nb = kotakNamaDx(el); if (nb) kosongkan(nb); el.blur();
          if ((el.value || "").trim()) return gagalTulis(`${lab}: PCare tidak mengizinkan kotaknya dikosongkan. Hapus manual di form PCare.`);
          log(`Koreksi ${lab}: ${lama} dihapus`, "info"); }
        continue;
      }
      if (!el && n > 1) el = await kotakDiagnosaSekunder(n, sebelum);
      if (!el) return gagalTulis(`${lab}: kotaknya tidak ada di form PCare${n >= 4 ? " (PCare mungkin hanya menyediakan sampai #3)" : ""}.`);
      BR.setValue(el, baru);
      const { nameBox } = await isiKodeDiagnosa(el);
      if (!(el.value || "").trim() || (nameBox && !nameBox.value)) return gagalTulis(`${lab}: kode ${baru} tidak dikenali PCare (nama penyakit tidak muncul).`);
      log(`Koreksi ${lab}: ${lama || "(kosong)"} → ${baru} (${nameBox ? nameBox.value : "?"})`, "info");
      sebelum = el;
    }
    await BR.sleep(400);
    const merah = hasilUkurTidakSesuai({}).filter((m) => /tidak sesuai/.test(m));
    if (merah.length) { tulisPesan(merah); b.disabled = false; b.textContent = "Simpan ke PCare"; return; }
    log("Koreksi dari pratinjau ditulis ke form PCare.", "info");
    selesai("simpan");
  };
}

// true = "Menunggu Verifikasi" terlihat; false = gagal / tidak terlihat
// v3.2.1: hasil simpan dinilai dari pesan yang BARU muncul sesudah Simpan diklik (dulu seluruh teks halaman,
// sehingga kata "gagal"/"error" yang memang sudah ada di halaman dianggap gagal → bot mengulang simpan).
// Hasil: true = berhasil · false = PCare menolak (pesannya dicatat) · "?" = tidak pasti → dicek di daftar antrean PCare.
const PESAN_PCARE = ".modal.in, .modal.show, .swal2-popup, .sweet-alert, .bootbox, .alert, .toast, #toast-container, .notifyjs-corner, .jconfirm-box, .ui-dialog, [role=alert], [role=dialog]";
const teksPesan = () => [...document.querySelectorAll(PESAN_PCARE)].filter((e) => !e.closest(BR.UI_SENDIRI) && BR.visible(e))
  .map((e) => BR.norm(e.innerText || "")).filter(Boolean);
const hitungKata = (t, k) => t.split(k).length - 1;
let ALERT_SIMPAN = [], POTRET_SIMPAN = null, TOLAK_TERAKHIR = "";
// v3.2.6: PCare menolak karena kunjungan peserta ini SUDAH ADA → tidak perlu diulang; dianggap selesai
const sudahAdaDiPcare = (t) => /sudah pernah dilayani|sudah dilayani|sudah ada kunjungan|data kunjungan sudah ada/.test(BR.norm(t || ""));
const potretSimpan = () => ({ pesan: new Set(teksPesan()), mv: hitungKata(BR.norm(document.body.innerText), "menunggu verifikasi"), alert: ALERT_SIMPAN.length, at: Date.now() });
async function watchResult() {
  const awal = POTRET_SIMPAN && Date.now() - POTRET_SIMPAN.at < 5000 ? POTRET_SIMPAN : potretSimpan();
  TOLAK_TERAKHIR = "";
  const ringkas = (t) => t.replace(/\s+/g, " ").slice(0, 160);
  for (let i = 0; i < 30; i++) {
    await BR.sleep(500);
    if (hitungKata(BR.norm(document.body.innerText), "menunggu verifikasi") > awal.mv) { log("Berhasil: Menunggu Verifikasi."); return true; }
    const baru = [...teksPesan().filter((t) => !awal.pesan.has(t)), ...ALERT_SIMPAN.slice(awal.alert).map((t) => BR.norm(t))];
    for (const t of baru) {
      if (/tidak berhasil|gagal|error|tidak dapat|tidak bisa|sudah ada|sudah (di)?layani|harus|wajib|salah|tidak valid/.test(t)) { TOLAK_TERAKHIR = t; log(`PCare menolak simpan: "${ringkas(t)}"`, false); return false; }
      if (/berhasil|sukses|tersimpan|menunggu verifikasi/.test(t)) { log(`Berhasil: "${ringkas(t)}"`); return true; }
    }
  }
  log("Hasil simpan tidak terlihat jelas. Dicek di daftar antrean PCare (tidak disimpan ulang).", "info");
  return "?";
}

// =====================================================================
// MODE OTOMATIS — state disimpan di chrome.storage agar tetap jalan
// meskipun PCare berpindah halaman.
// step: pick -> search -> open -> fill -> (save) -> pick ...
// =====================================================================
let runAktif = false, runNonstop = false;   // salinan SINKRON status bot
// v1.9.5: tombol Berhenti. Dulu putaran yang sedang berjalan menulis balik salinan lama {active:true} setelah
// langkahnya selesai, sehingga bot hidup lagi. Kini setiap putaran punya `gen`; Berhenti menandai gen itu
// "dihentikan", dan setRun MENOLAK menghidupkan gen yang sudah dihentikan. BERHENTI = tanda sinkron di tab ini.
let BERHENTI = false, PRATINJAU_BATAL = null;
var PRATINJAU_SIMPAN_PCARE = null, BOT_KLIK_SIMPAN = false;   // v3.2.4: Simpan PCare & Simpan bot bereaksi sama
const genBaru = () => Date.now() + "-" + Math.random().toString(36).slice(2, 6);
const getRun = async () => { const r = (await BR.store.get("run")) || { active: false }; runAktif = !!r.active; runNonstop = !!(r.active && r.nonstop); return r; };
const setRun = async (r) => {
  if (r.active) {
    const kini = (await BR.store.get("run")) || {};
    if (BERHENTI || (kini.dihentikan && kini.gen === r.gen)) { r.active = false; runAktif = false; runNonstop = false; return false; }
  }
  runAktif = !!r.active; runNonstop = !!(r.active && r.nonstop);
  const jejak = `${r.active ? (r.paused ? "jeda" : "aktif") : "mati"}:${r.step || "-"}:${r.current ? r.current.antrean : "-"}`;
  if (jejak !== setRun._akhir) { BR.keFile("PCARE", "RINCI", `Langkah bot → ${jejak}${r.tries ? " (ulang " + r.tries + ")" : ""}`); setRun._akhir = jejak; }
  await BR.store.set("run", r);
  return true;
};
// masih boleh lanjut? (dipanggil sesudah setiap langkah yang lama)
const masih = async (r) => { if (BERHENTI) return false; const k = (await BR.store.get("run")) || {}; return !!k.active && !k.dihentikan && k.gen === r.gen; };
// Berhenti ditekan di tab PCare lain → tab ini ikut berhenti seketika
chrome.storage.onChanged.addListener((ch, area) => {
  if (area !== "local" || !ch.run) return;
  const v = ch.run.newValue || {};
  if (v.dihentikan && !v.active) { BERHENTI = true; runAktif = false; runNonstop = false; if (PRATINJAU_BATAL) PRATINJAU_BATAL(); }
  else if (v.active && !v.dihentikan) BERHENTI = false;
});

async function markProcessed(row, hasil) {
  // v1.9.0: dicatat per kartu + antrean (satu kartu bisa terdaftar 2x sehari)
  const kartu = typeof row === "string" ? row : row.kartu;
  const p = (await BR.store.get("processed")) || {};
  for (const k of Object.keys(p)) if (p[k].tgl !== BR.today()) delete p[k];
  p[typeof row === "string" ? row : BR.kunciProses(row)] = { tgl: BR.today(), hasil, nama: row.nama || "", antrean: row.antrean || "", jam: new Date().toTimeString().slice(0, 5) };
  await BR.store.set("processed", p);
  if (hasil !== "dilewati" && typeof row !== "string" && dataAktif && dataAktif.url && (!dataAktif.kartu || dataAktif.kartu === kartu)) {
    await BR.tandaiDipakai(dataAktif.url, row.antrean);
    log(`Kunjungan C-CARE ${dataAktif.url} ditandai terpakai untuk ${row.antrean}.`);
  }
  if (hasil !== "dilewati") hapusDariLewat(kartu);
  tampilRiwayat();
}

async function pause(run, msg) {
  if (run.nonstop && run.current) return lewatiNonstop(run, msg);
  run.paused = true;
  if (!(await setRun(run))) return;                   // v1.9.5: sudah dihentikan
  status("⏸ Menunggu Anda: " + msg);
  log("BERHENTI — " + msg + " Setelah selesai, klik ⏭ Lanjut.", false);
}

// ===================== MODE NONSTOP =====================
// Pasien bermasalah TIDAK disimpan: dicatat di "Perlu dikerjakan manual", lalu bot lanjut ke pasien berikutnya.
const MASALAH_UMUM = /cloudflare|belum login|sesi habis/i;   // masalah menyeluruh (bukan milik satu pasien)
const ringkasAlasan = (m) => m.replace(/\s*\((⏩|pasien|atau)[^)]*\)\s*/g, " ").replace(/\s*(Setelah|Jika Ya|Muat|Bot tidak mengisi)[^.]*\.?/g, "").replace(/\s+/g, " ").trim().slice(0, 220);
async function lewatiNonstop(run, msg) {
  const cur = run.current;
  if (/cloudflare/i.test(msg) && !run.cfUlang) {               // muat ulang halaman SEKALI lalu coba pasien yang sama
    run.cfUlang = true; run.step = "load";
    if (!(await setRun(run))) return;
    log(`Cloudflare belum lolos → halaman dimuat ulang 1× untuk ${cur.antrean}.`, "info");
    setTimeout(() => location.reload(), 300);
    return;
  }
  const item = { kartu: cur.kartu, antrean: cur.antrean, nama: cur.nama, kelamin: cur.kelamin, usia: cur.usia, tgl: cur.tgl,
    alasan: ringkasAlasan(msg), jam: new Date().toLocaleTimeString("id-ID").slice(0, 5) };
  run.lewat = [...(run.lewat || []).filter((x) => x.kartu !== cur.kartu), item];
  const daftar = await bacaLewat(); daftar[cur.kartu] = item; await BR.store.set("lewatHariIni", { tgl: BR.today(), item: daftar });
  log(`⏭ Dilewati ${cur.antrean} ${cur.nama}: ${item.alasan}`, "info");
  run.beruntunUmum = MASALAH_UMUM.test(msg) ? (run.beruntunUmum || 0) + 1 : 0;
  if (run.beruntunUmum >= 3) {
    run.active = false; await setRun(run);
    status("⏸ Nonstop berhenti: 3 pasien berturut-turut gagal karena masalah yang sama");
    log(`Nonstop dihentikan: 3 pasien berturut-turut gagal (${item.alasan}). Perbaiki dulu (mis. reload PCare / login C-CARE), lalu jalankan lagi.`, false);
    tampilLewat();
    return;
  }
  run.paused = false; run.step = "pick"; run.current = null; run.tries = 0; run.cfUlang = false;
  if (!(await setRun(run))) { tampilLewat(); return; }
  tampilLewat();
  setTimeout(runLoop, 800);
}
async function bacaLewat() {
  const l = await BR.store.get("lewatHariIni");
  return l && l.tgl === BR.today() ? l.item || {} : {};
}
async function hapusDariLewat(kartu) {
  const d = await bacaLewat(); if (!d[kartu]) return;
  delete d[kartu]; await BR.store.set("lewatHariIni", { tgl: BR.today(), item: d }); tampilLewat();
}
async function tampilLewat() {
  const box = document.getElementById("br-lewat"); if (!box) return;
  const d = Object.values(await bacaLewat());
  if (!d.length) { box.innerHTML = ""; return; }
  box.innerHTML = `<div class="br-lewat-judul">⚠️ Perlu dikerjakan manual <span class="br-badge br-badge-kuning">${d.length}</span>
      <button class="br-mini" id="br-lewat-hapus" title="Kosongkan daftar">Kosongkan</button></div>` +
    d.map((x, i) => `<div class="br-p br-p-lewat"><span class="br-chip">${x.antrean}</span>
      <div class="br-pinfo"><div class="br-pnama"></div><div class="br-pmeta br-alasan"></div></div>
      <button data-i="${i}" class="br-play" title="Kerjakan pasien ini (dengan pemantauan)">▶</button></div>`).join("");
  box.querySelectorAll(".br-p-lewat").forEach((el, i) => {   // teks lewat textContent (aman)
    el.querySelector(".br-pnama").textContent = d[i].nama;
    el.querySelector(".br-alasan").textContent = `${d[i].jam} · ${d[i].alasan}`;
  });
  box.querySelectorAll("button[data-i]").forEach((b) => (b.onclick = () => { const x = d[+b.dataset.i]; runStartFor(x, x.tgl); }));
  box.querySelector("#br-lewat-hapus").onclick = async () => { await BR.store.set("lewatHariIni", { tgl: BR.today(), item: {} }); tampilLewat(); };
}
async function runNonstopMulai() {
  BERHENTI = false; await klaimTab(true);
  await setRun({ gen: genBaru(), active: true, nonstop: true, paused: false, step: "pick", tries: 0, current: null, lewat: [], beruntunUmum: 0 });
  log("🌙 Nonstop dimulai: pasien tanpa peringatan disimpan otomatis; pasien bermasalah dilewati & dicatat.", "info");
  runLoop();
}

async function runStartFor(row, tgl) {
  BERHENTI = false; await klaimTab(true);
  await setRun({ gen: genBaru(), active: true, single: true, paused: false, step: "ccare", tries: 0, current: { ...row, tgl } });
  log(`▶ ${row.antrean} ${row.nama} — mengambil data C-CARE tanggal ${tgl}…`);
  runLoop();
}

async function runStart() {
  BERHENTI = false; await klaimTab(true);
  await setRun({ gen: genBaru(), active: true, paused: false, step: "pick", tries: 0, current: null });
  log("Mode Otomatis dimulai.");
  runLoop();
}

async function runStop() {
  BERHENTI = true; runAktif = false; runNonstop = false;
  const r = await getRun();
  r.active = false; r.paused = false; r.dihentikan = true;
  await BR.store.set("run", r);                       // langsung, tanpa penjaga setRun
  if (PRATINJAU_BATAL) PRATINJAU_BATAL();             // hitung mundur simpan dibatalkan
  status("⏹ Bot dihentikan");
  log("⏹ Bot dihentikan. Tidak ada pasien yang disimpan sesudah ini. Klik ▶ untuk mulai lagi.", "info");
}

// ⏭ Lanjut: melanjutkan dari langkah yang tertunda
async function runResume() {
  await klaimTab(true);
  const r = await getRun();
  if (!r.active) return runStart();
  r.paused = false;
  if (r.step === "load") r.step = kartuTampil() ? "verify" : "load";   // sudah termuat? verifikasi : muat ulang
  else if (r.step === "ccare") { /* coba ambil lagi (mis. setelah Kirim manual dari C-CARE) */ }
  else if ((r.step === "fill" || r.step === "saved?") && r.belumIsi) {   // v1.9.8: form belum diisi bot → ambil ulang dari C-CARE
    r.belumIsi = false; r.step = "ccare"; if (r.current) delete r.current.ccareUrl;
  }
  else if (r.step === "fill" || r.step === "saved?") {
    // v3.4.3: JANGAN menganggap tersimpan hanya karena Lanjut diklik (dulu: pratinjau dibatalkan → Lanjut → ditandai
    // "tersimpan" padahal di PCare masih Baru). Cek status di daftar antrean PCare: bukan Baru = tersimpan,
    // masih Baru = form diisi ulang dan pratinjau muncul lagi (simpan otomatis dimatikan untuk pasien ini).
    r.step = "cekSimpan"; r.hasilSimpan = "lanjut";
    if (r.current) r.current.tahanAuto = true;
    await setRun(r);
    log(`${r.current?.antrean || "Pasien"}: Lanjut diklik → status dicek di daftar antrean PCare dulu.`, "info");
    location.href = URL_DAFTAR; return;
  }
  await setRun(r);
  runLoop();
}

async function runSkip() {
  const r = await getRun();
  if (!r.active || !r.current) return log("Tidak ada pasien yang sedang diproses.", false);
  await markProcessed(r.current, "dilewati");
  log(`Dilewati: ${r.current.antrean} ${r.current.nama}.`, false);
  r.paused = false; r.step = "pick"; r.current = null; r.tries = 0; await setRun(r);
  runLoop();
}

// Setelah tersimpan: lanjut ke pasien berikutnya (bila sakelar "Lanjut otomatis" aktif). return true = loop lanjut
async function lanjutKePasienBerikut(r, cur) {
  const lanjut = r.nonstop || document.getElementById("br-lanjut")?.checked !== false;
  if (!lanjut) {
    r.active = false; await setRun(r);
    status(`✅ ${cur.antrean} ${cur.nama} tersimpan. Klik ▶ untuk pasien berikutnya.`);
    return false;
  }
  log(`✅ ${cur.antrean} ${cur.nama} tersimpan → lanjut ke pasien berikutnya.`);
  status(`▶ Lanjut ke pasien berikutnya…`);
  r.single = false; r.paused = false; r.step = "pick"; r.current = null; r.tries = 0; r.cfUlang = false;   // ▶ satu pasien pun lanjut ke sisa daftar
  return await setRun(r);
}

// Anda memperbaiki form lalu klik "Simpan" PCare sendiri → bila "Menunggu Verifikasi" muncul, bot lanjut tanpa ⏭ Lanjut
function intaiSimpanManual(cur) {
  const tombol = [...document.querySelectorAll("button, input[type=button], input[type=submit], a.btn")]
    .filter((b) => !b.closest(BR.UI_SENDIRI) && BR.norm(b.textContent || b.value) === "simpan");
  tombol.forEach((b) => b.addEventListener("click", async () => {
    const ok = await watchResult();
    if (ok === "?") {   // v3.2.4: hasil tidak jelas → cek di daftar antrean PCare, lalu bot lanjut sendiri
      const r = await getRun();
      if (!r.active || !r.paused || r.current?.kartu !== cur.kartu) return;
      r.paused = false; r.step = "cekSimpan"; r.hasilSimpan = "?";
      if (await setRun(r)) location.href = URL_DAFTAR;
      return;
    }
    if (ok === false && sudahAdaDiPcare(TOLAK_TERAKHIR)) {
      const r = await getRun();
      log(`PCare: ${cur.antrean} sudah pernah dilayani di poli ini → dianggap selesai.`, "info");
      await markProcessed(cur, "manual");
      if (r.active && r.paused && r.current?.kartu === cur.kartu && (await lanjutKePasienBerikut(r, cur))) runLoop();
      return;
    }
    if (ok !== true) return;                               // gagal simpan → tetap menunggu Anda
    const r = await getRun();
    if (!r.active || !r.paused || r.step !== "fill" || r.current?.kartu !== cur.kartu) return;   // sudah dilanjutkan / pasien lain
    await markProcessed(cur, "manual");
    if (await lanjutKePasienBerikut(r, cur)) runLoop();
  }, { once: true }));
}

// v1.9.8: hanya SATU tab PCare yang menjalankan bot. Dulu setiap tab PCare yang terbuka saat bot aktif ikut berjalan,
// sehingga dua tab bisa memproses pasien yang sama (mis. menandai kunjungan C-CARE "terpakai" dua kali).
const TAB_ID = (() => { try { let x = sessionStorage.getItem("br-tab"); if (!x) { x = genBaru(); sessionStorage.setItem("br-tab", x); } return x; } catch (e) { return genBaru(); } })();
async function klaimTab(paksa) {
  // v3.2.3: di aplikasi hanya ada SATU halaman PCare. Pemilik lama (mis. sebelum aplikasi dimulai ulang sesudah
  // pembaruan) tidak boleh membuat bot macet "berjalan di tab PCare lain".
  if (BR.diAplikasi) paksa = true;
  const p = (await BR.store.get("runPemilik")) || {};
  if (!paksa && p.tab && p.tab !== TAB_ID && Date.now() - (p.at || 0) < 20000) return false;
  await BR.store.set("runPemilik", { tab: TAB_ID, at: Date.now() });
  return true;
}
let looping = false;
async function runLoop() {
  if (looping) return;
  if (!(await klaimTab(false))) { status("Bot sedang berjalan di tab PCare lain. Dicoba lagi 25 detik lagi."); setTimeout(runLoop, 25000); return; }
  looping = true;
  const detak = setInterval(() => { if (looping && !BERHENTI) BR.store.set("runPemilik", { tab: TAB_ID, at: Date.now() }); }, 5000);
  try {
    while (true) {
      if (BERHENTI) break;
      const r = await getRun();
      if (!r.active || r.paused || r.dihentikan) break;
      const cur = r.current;
      status(`▶ ${r.step}${cur ? ` · ${cur.antrean} ${cur.nama}` : ""}`);

      if (r.step === "pick") {
        if (!location.pathname.startsWith(URL_DAFTAR)) { location.href = URL_DAFTAR; return; }
        const rows = await readQueue(false);
        if (!(await masih(r))) break;
        if (rows === null) { await pause(r, "ada dialog keputusan di halaman antrean."); break; }
        const processed = (await BR.store.get("processed")) || {};
        const kecuali = await BR.poliKecuali();
        let next = null; const tanpaData = [];
        const tgl = tglPcare();
        for (const row of rows) {
          if (!perluDilayani(row) || BR.sudahProses(processed, row)) continue;   // hanya status "Baru"
          if (BR.cocokPoli(row.poli, kecuali)) continue;                          // v3.4.4: poli dikecualikan (mis. Konseling)
          if (r.nonstop && (r.lewat || []).some((x) => x.kartu === row.kartu)) continue;     // sudah dilewati di putaran ini
          next = { ...row, tgl }; break;          // data C-CARE diambil otomatis di langkah "ccare"
        }
        if (!next) {
          r.active = false; await setRun(r);
          if (r.nonstop) {
            const n = (r.lewat || []).length;
            status(n ? `✅ Nonstop selesai · ${n} pasien perlu dikerjakan manual` : "✅ Nonstop selesai · semua pasien Baru tersimpan");
            log(`🌙 Nonstop selesai.${n ? ` ${n} pasien dilewati, lihat "Perlu dikerjakan manual".` : ""}`, n ? "info" : true);
            tampilLewat(); tampilkanPasien();
            break;
          }
          status("✅ Selesai — tidak ada pasien lagi yang siap.");
          log("Selesai." + (tanpaData.length ? ` Belum ada data C-CARE: ${tanpaData.join(", ")}` : ""), !tanpaData.length);
          // jelaskan nasib tiap data C-CARE yang sudah dikirim hari ini
          const qList = Object.values((await BR.store.get("ccareQueue")) || {}).filter((d) => d.tgl === BR.today());
          if (!qList.length) log("Antrian C-CARE kosong: klik Kirim di C-CARE untuk tiap pasien dulu.", false);
          for (const d of qList) {
            const row = rows.find((rw) => BR.nameKey(rw.nama) === BR.nameKey(d.nama));
            const who = `${d.nama || "(tanpa nama)"} · ${d.kelamin || "?"} · ${d.umur ?? "?"} th`;
            if (!row) log(`C-CARE "${who}": TIDAK ADA di antrean PCare hari ini (kunjungan lama / belum mendaftar di PCare?).`, false);
            else if (!perluDilayani(row) || BR.sudahProses(processed, row)) log(`C-CARE "${who}" = ${row.antrean}: ${row.status || "sudah selesai"} di PCare, dilewati.`);
            else if (d.kelamin && d.kelamin !== row.kelamin) log(`C-CARE "${who}" vs ${row.antrean}: jenis kelamin BEDA (${row.kelamin}).`, false);
            else if (d.umur != null && Math.abs(d.umur - row.usia) > 1) log(`C-CARE "${who}" vs ${row.antrean}: umur BEDA (${row.usia} th di PCare).`, false);
          }
          break;
        }
        log(`Pasien berikutnya: ${next.antrean} ${next.nama} (tanggal ${next.tgl}).`);
        document.getElementById("br-kartu").value = next.kartu;
        document.getElementById("br-antrean").value = next.antrean;
        r.current = next; r.step = "ccare";
        if (!(await setRun(r))) break;
        continue;
      }

      if (r.step === "cekSimpan") {
        if (!location.pathname.startsWith(URL_DAFTAR)) { location.href = URL_DAFTAR; return; }
        await BR.sleep(800);
        const rows = await readQueue(false);
        if (!(await masih(r))) break;
        const row = (rows || []).find((x) => x.antrean === cur.antrean && x.kartu === cur.kartu);
        if (row && !perluDilayani(row)) {
          log(`Daftar antrean PCare: ${cur.antrean} berstatus "${row.status || "sudah dilayani"}" → tersimpan.`);
          await markProcessed(cur, "otomatis");
          if (cur.ccareUrl) await BR.tandaiDipakai(cur.ccareUrl, cur.antrean);   // kunjungan C-CARE tidak dipakai lagi
          r.hasilSimpan = null; r.beruntunUmum = 0;
          if (!(await lanjutKePasienBerikut(r, cur))) break;
          continue;
        }
        if (row && r.hasilSimpan === "lanjut") {   // v3.4.3: Lanjut diklik tetapi pasien masih Baru → isi ulang, pratinjau lagi
          r.step = "load"; r.hasilSimpan = null; r.tries = 0;
          if (!(await setRun(r))) break;
          log(`${cur.antrean} BELUM tersimpan (status PCare "${row.status || "Baru"}"). Form diisi ulang; periksa pratinjau lalu Simpan ke PCare, atau Lewati.`, false);
          location.href = URL_KUNJ; return;
        }
        if (row && r.hasilSimpan === false && (r.tries || 0) < 1) {   // PCare jelas menolak & status masih Baru → ulang sekali
          r.tries = (r.tries || 0) + 1; r.step = "load"; r.hasilSimpan = null;
          if (!(await setRun(r))) break;
          log(`Status ${cur.antrean} masih Baru. Mengulang sekali…`, false);
          location.href = URL_KUNJ; return;
        }
        r.step = "load"; r.hasilSimpan = null;
        await pause(r, row ? `simpan ${cur.antrean} tidak terkonfirmasi (status di PCare masih "${row.status || "Baru"}"). Periksa di PCare; bot TIDAK menyimpan ulang otomatis.`
          : `${cur.antrean} tidak ditemukan di daftar antrean PCare. Periksa di PCare apakah kunjungan sudah tersimpan.`);
        break;
      }

      if (r.step === "ccare") {
        const ada = await findCcareData(cur);
        if (ada && ada.data.tglKunjungan === cur.tgl && ada.data.v >= 3) {
          log(`Data C-CARE ${cur.nama} sudah ada (tanggal ${cur.tgl}).`);
          if (ada.data.ccareUrl) { cur.ccareUrl = ada.data.ccareUrl; r.current = cur; }
        } else {
          status(`▶ Mencari di C-CARE (5 poli) · ${cur.antrean} ${cur.nama}`);
          const res = await mintaCcare(cur);
          (res.namaTerlihat || []).forEach(BR.ingatNama); if (res.nama) BR.ingatNama(res.nama);
          if (!(await masih(r))) break;
          if (!res.ok) { await pause(r, `C-CARE: ${res.pesan} (⏩ Lewati, atau buka kunjungan di C-CARE → Kirim → ⏭ Lanjut)`); break; }
          log(`Data C-CARE ${res.nama} diambil dari ${res.poli || "C-CARE"} (tanggal ${cur.tgl}).`);
          if (res.url) { cur.ccareUrl = res.url; r.current = cur; }   // v1.9.8: langkah isi memakai kunjungan INI, tidak mencocokkan ulang
          for (const c of res.catatan || []) { blockAuto = true; log("Perhatian: " + c + ". Periksa sebelum simpan.", false); }
        }
        r.step = "load";
        if (!(await setRun(r))) break;
        continue;
      }

      if (r.step === "load") {
        if (!location.pathname.startsWith(URL_KUNJ)) { location.href = URL_KUNJ; return; }
        await BR.sleep(800);
        const res = await muatPasienPelayanan(cur);
        if (res === "berhenti" || !(await masih(r))) break;
        if (res === "reload") {
          // v4.0.1: muat ulang halaman Pelayanan maks. 2× per pasien, lalu coba pasien yang sama lagi
          r.muatUlang = (r.muatUlang || 0) + 1;
          if (r.muatUlang <= 2) {
            if (!(await setRun(r))) break;
            log(`Halaman Pelayanan dimuat ulang (${r.muatUlang}/2) untuk ${cur.antrean}.`, "info");
            setTimeout(() => location.reload(), 300); return;
          }
          r.muatUlang = 0;
          await pause(r, `PCare tetap menolak ("Permintaan tidak dapat diproses") sesudah halaman dimuat ulang 2×. Tekan F5 di PCare, muat ${cur.antrean} sendiri, lalu klik ⏭ Lanjut.`); break;
        }
        r.muatUlang = 0;
        if (res === "decision") { await pause(r, "pilih Ya/Tidak pada dialog PCare. Jika Ya → ⏭ Lanjut; jika Tidak → ⏩ Lewati."); break; }
        if (res === "turnstile") { await pause(r, `verifikasi Cloudflare belum dicentang dalam 3 menit. ${SARAN_RELOAD} (atau selesaikan kotak verifikasi bila diminta).`); break; }
        if (res.startsWith("error")) { await pause(r, res.slice(6) + ` (pasien ${cur.antrean} ${cur.nama}). Setelah data pasien muncul, klik ⏭ Lanjut.`); break; }
        r.step = "verify";
        if (!(await setRun(r))) break;
        continue;
      }

      // PENGAMAN WAJIB: form hanya diisi bila No.Kartu BPJS yang tampil = pasien antrean yang dipilih
      if (r.step === "verify") {
        const kt = kartuTampil();
        if (!kt) { await pause(r, `pasien belum termuat di form Pelayanan (No.Kartu BPJS kosong). Muat ${cur.antrean} dulu.`); break; }
        if (kt !== cur.kartu) { await pause(r, `No.Kartu yang tampil (${kt}) BUKAN milik ${cur.antrean} ${cur.nama} (${cur.kartu}). Bot tidak mengisi.`); break; }
        log(`Pasien termuat & cocok: ${cur.antrean} · ${kt}.`);
        r.step = "fill";
        if (!(await setRun(r))) break;
        continue;
      }

      if (r.step === "fill") {
        // v3.1.1: halaman berpindah (mis. Muat antrean diklik saat pratinjau terbuka) → muat ulang pasien di Pelayanan, jangan isi di halaman lain
        if (!location.pathname.startsWith(URL_KUNJ)) {
          r.step = "load"; if (!(await setRun(r))) break;
          log(`Halaman bukan Pelayanan; ${cur.antrean} dimuat ulang di halaman Pelayanan.`, "info");
          location.href = URL_KUNJ; return;
        }
        document.getElementById("br-antrean").value = cur.antrean;
        document.getElementById("br-kartu").value = cur.kartu;
        const found = await findCcareData(cur, true);
        if (!found || !(await loadFromCcare(found.data))) { r.belumIsi = true; await pause(r, "data C-CARE pasien ini tidak ditemukan. Klik ⏭ Lanjut untuk mengambil ulang dari C-CARE, atau ⏩ Lewati."); break; }
        if (found.data.tglKunjungan && found.data.tglKunjungan !== cur.tgl) {
          r.belumIsi = true; await pause(r, `tanggal kunjungan C-CARE (${found.data.tglKunjungan}) BERBEDA dengan tanggal PCare (${cur.tgl}). Bot tidak mengisi.`); break;
        }
        if (!String(found.data.anamnesa || "").trim()) {
          r.belumIsi = true; await pause(r, "Anamnesa di C-CARE masih kosong → kemungkinan pasien belum diperiksa dokter. Bot tidak mengisi. Setelah dokter mengisi, klik ⏭ Lanjut (data diambil ulang)."); break;
        }
        r.belumIsi = false;
        JK_PASIEN = String(found.data.kelamin || cur.kelamin || "").toUpperCase().charAt(0);
        if (cur.tahanAuto) blockAuto = true;   // v3.4.3: pasien ini pernah dibatalkan/ditahan → wajib dicek manusia
        if (!found.strong) { blockAuto = true; log(`Dicocokkan lewat ${found.via}. Periksa identitas sebelum simpan.`, false); }
        else log(`Identitas cocok: ${found.data.nama} · ${found.data.kelamin} · ${found.data.umur} th (RM ${found.data.rm || "-"}).`);
        if (!(await masih(r))) break;
        const res = await fillForm({ allowAutoSave: true });
        if (res.saved === true) {
          await markProcessed(cur, "otomatis");
          r.beruntunUmum = 0;
          if (!(await lanjutKePasienBerikut(r, cur))) break;
          await BR.sleep(1000);
          continue;
        }
        if (!(await masih(r))) break;
        // v3.2.1: simpan sudah diklik tetapi hasilnya ditolak/tidak pasti → JANGAN langsung simpan ulang.
        // Cek dulu status pasien di daftar antrean PCare (sumber kebenaran): bukan "Baru" lagi = sudah tersimpan.
        if (res.saved === false && sudahAdaDiPcare(TOLAK_TERAKHIR)) {
          log(`PCare: ${cur.antrean} sudah pernah dilayani di poli ini → dianggap selesai, tidak diulang.`, "info");
          await markProcessed(cur, "manual");
          r.beruntunUmum = 0;
          if (!(await lanjutKePasienBerikut(r, cur))) break;
          continue;
        }
        if (res.saved === false || res.saved === "?") {
          r.step = "cekSimpan"; r.hasilSimpan = res.saved;
          if (!(await setRun(r))) break;
          location.href = URL_DAFTAR; return;
        }
        const daftarMasalah = [...new Set([...(res.missing || []).map((m) => "belum terisi: " + m), ...peringatanPasien])].join("; ");
        await pause(r, res.saved === false
          ? "simpan belum berhasil setelah diulang. Periksa form."
          : r.nonstop ? `ada peringatan → tidak disimpan: ${daftarMasalah || "lihat Aktivitas"}`
          : "perbaiki form bila perlu, klik Simpan PCare (atau Simpan ke PCare di pratinjau berikutnya).");
        if (!r.nonstop) intaiSimpanManual(cur);
        break;
      }
      break;
    }
  } finally { looping = false; clearInterval(detak); }
}

// ---------- Pemberitahuan PCare (window.alert, tombol OK saja) saat menyimpan ----------
// Bendera dipasang tepat saat tombol "Simpan" PCare diklik (oleh bot ATAU oleh Anda, ketika bot sedang aktif),
// dilepas lagi setelah 15 detik. Di luar itu, alert PCare tampil seperti biasa.
let lepasBendera = null;
document.addEventListener("click", (e) => {      // SINKRON: harus terpasang sebelum handler PCare berjalan
  const b = e.target.closest && e.target.closest("button, input[type=button], input[type=submit], a.btn");
  if (!b || b.closest(BR.UI_SENDIRI) || BR.norm(b.textContent || b.value) !== "simpan") return;
  POTRET_SIMPAN = potretSimpan();                 // v3.2.1: keadaan halaman tepat sebelum Simpan (pembanding hasil)
  if (PRATINJAU_SIMPAN_PCARE && !BOT_KLIK_SIMPAN) PRATINJAU_SIMPAN_PCARE();
  if (!runAktif) return;
  document.documentElement.dataset.brSimpan = "1";
  clearTimeout(lepasBendera);
  lepasBendera = setTimeout(() => delete document.documentElement.dataset.brSimpan, 15000);
}, true);   // fase capture: terpasang SEBELUM handler Simpan milik PCare memanggil alert
document.documentElement.addEventListener("br-alert", () => {
  const pesan = (document.documentElement.dataset.brAlert || "").replace(/\s+/g, " ").trim();
  delete document.documentElement.dataset.brAlert;
  if (pesan) ALERT_SIMPAN.push(pesan);
  if (pesan) log(`Pemberitahuan PCare (OK otomatis): "${pesan}"`, /gagal|error|tidak dapat|harus|wajib|salah/i.test(pesan) ? false : "info");
});

// ---------- v3.2.4 LOG RINCI (hanya ke file log, bukan ke kolom aplikasi) ----------
// Halaman yang dibuka, tombol PCare yang diklik (oleh Anda atau bot), dan pesan PCare yang muncul (modal/alert/toast).
// Nama pasien yang dikenali & nomor 9–16 digit tetap disamarkan oleh pencatat log.
const rinci = (t) => BR.keFile("PCARE", "RINCI", String(t).replace(/\s+/g, " ").trim().slice(0, 300));
rinci(`Halaman dibuka: ${location.pathname}${document.title ? " · " + document.title.slice(0, 40) : ""}`);
document.addEventListener("click", (e) => {
  const b = e.target.closest && e.target.closest("button, input[type=button], input[type=submit], a.btn, a[href], .btn, input[type=radio], input[type=checkbox]");
  if (!b || b.closest(BR.UI_SENDIRI) || !e.isTrusted && !BOT_KLIK_SIMPAN && b.tagName !== "BUTTON") return;
  const teks = (b.type === "radio" || b.type === "checkbox") ? `${b.name || b.id}=${b.value}` : (b.textContent || b.value || b.title || b.id || "").trim().slice(0, 40);
  if (teks) rinci(`Klik ${e.isTrusted ? "petugas" : "bot"}: ${teks}${document.getElementById("br-pratinjau") ? " (pratinjau terbuka)" : ""}`);
}, true);
(() => {
  const sudah = new Set();
  const periksa = () => { for (const el of document.querySelectorAll(PESAN_PCARE)) {
    if (el.closest(BR.UI_SENDIRI) || !BR.visible(el)) continue;
    const t = (el.innerText || "").replace(/\s+/g, " ").trim().slice(0, 200);
    if (t && !sudah.has(t)) { sudah.add(t); rinci("Pesan PCare tampil: " + t); }
  } };
  let tunda = null;
  new MutationObserver(() => { clearTimeout(tunda); tunda = setTimeout(periksa, 300); }).observe(document.documentElement, { subtree: true, childList: true, attributes: true, attributeFilter: ["class", "style"] });
})();

// ---------- v3.3.1: banner REMINDER! / WARNING! PCare ditutup otomatis ----------
// Hanya pengumuman berjudul persis "REMINDER!" atau "WARNING!" (mis. Pakta Integritas HFIS, masa berlaku SIP).
// Isinya dicatat sekali sehari di Aktivitas supaya informasinya tidak hilang. Dialog keputusan (Ya/Tidak) TIDAK disentuh.
function tutupPengingat() {
  for (const h of document.querySelectorAll("h1, h2, h3, h4, h5, b, strong")) {
    const judul = (h.textContent || "").trim().toUpperCase();
    if (judul !== "REMINDER!" && judul !== "WARNING!") continue;
    const wadah = h.closest(".alert, .modal, .modal-dialog, .callout, .panel, .box") || h.parentElement;
    if (!wadah || wadah.closest(BR.UI_SENDIRI) || !BR.visible(wadah) || wadah.dataset.brTutup) continue;
    wadah.dataset.brTutup = "1";
    const isi = (wadah.innerText || "").replace(/\s+/g, " ").replace(/^×\s*/, "").trim();
    const kunci = "br-pengingat-" + BR.today() + "-" + isi.slice(0, 80);
    try { if (!localStorage.getItem(kunci)) { localStorage.setItem(kunci, "1"); log(`Pengumuman PCare ditutup otomatis: ${isi.slice(0, 220)}`, "info"); } } catch (e) {}
    const x = [...wadah.querySelectorAll("button, a, span")].find((b) => /^(×|x|✕)$/i.test((b.textContent || "").trim()) || b.classList.contains("close") || b.dataset.dismiss);
    if (x) x.click();
    setTimeout(() => { if (BR.visible(wadah)) wadah.style.display = "none"; }, 300);
  }
}

// ---------- Mulai ----------
BR.pasangPencatatGalat("PCARE");
const halamanLogin = /\/eclaim\/login/i.test(location.pathname) || !!BR.formLogin();
// v3.4.5: alasan login ditolak (halaman PCare sendiri sering tidak menampilkan apa pun)
document.documentElement.addEventListener("br-login-jawab", () => {
  let j = {}; try { j = JSON.parse(document.documentElement.dataset.brLoginJawab || "{}"); } catch (e) {}
  if (j.kode === "200") { BR.keFile("PCARE", "INFO", "Login PCare diterima server."); return; }
  const alasan = j.waf ? "verifikasi Cloudflare ditolak server (token kedaluwarsa). Tunggu centang hijau baru, lalu klik Sign In sekali"
    : j.pesan ? `${j.pesan}${j.kode ? ` (kode ${j.kode})` : ""}`
    : j.http === 0 ? "tidak ada jawaban dari server PCare (jaringan terputus atau diblokir)"
    : `server menjawab HTTP ${j.http}${j.kode ? `, kode ${j.kode}` : ""} tanpa pesan`;
  BR.keFile("PCARE", "PERINGATAN", `Login PCare ditolak: ${alasan}.`);
  BR.kabarLogin(`Login ditolak: ${alasan}.`);
});
if (!halamanLogin) {
  setTimeout(tutupPengingat, 300);
  let tPengingat = null;
  new MutationObserver(() => { clearTimeout(tPengingat); tPengingat = setTimeout(tutupPengingat, 200); }).observe(document.documentElement, { subtree: true, childList: true });
}
// =====================================================================
// v3.1.0 MEJA KERJA — kolom Antrean & Data pasien di aplikasi (di luar halaman PCare)
// Halaman ini menulis antrean + status ke penyimpanan; aplikasi mengirim perintah lewat "perintahBot".
// =====================================================================
var meja = {
  baris: [], tgl: "", belum: [], _t: null, _s: null, _akt: [],
  status(msg) { clearTimeout(this._s); this._s = setTimeout(() => BR.store.set("statusBot", { teks: String(msg || ""), at: Date.now() }), 250); },
  aktivitas(msg, ok) {
    this._akt.unshift({ jam: new Date().toLocaleTimeString("id-ID").slice(0, 5), teks: String(msg || "").slice(0, 300), jenis: ok === false ? "cek" : ok === "info" ? "info" : "ok" });
    this._akt = this._akt.slice(0, 30);
    clearTimeout(this._a); this._a = setTimeout(() => BR.store.set("aktivitasBot", this._akt), 300);
  },
  async simpan() {
    if (!this.baris.length) return;
    const processed = (await BR.store.get("processed")) || {};
    const lewat = await bacaLewat();
    const kecuali = await BR.poliKecuali();
    const rows = this.baris.map((r) => {
      const p = processed[BR.kunciProses(r)], lw = lewat[r.kartu];
      let st = "belum", ket = "";
      if (p && p.tgl === BR.today() && /otomatis|manual/.test(p.hasil)) {
        // v3.4.3: PCare sumber kebenaran — dibaca ≥ 2 menit sesudah dicatat tersimpan tetapi masih "Baru" → Perlu dicek
        const [hh, mm] = String(p.jam || "").split(":").map(Number), dicatat = new Date(); dicatat.setHours(hh || 0, mm || 0, 0, 0);
        if (perluDilayani(r) && p.jam && (this.dibaca || 0) - dicatat.getTime() >= 120e3) {
          st = "cek"; ket = `Bot tercatat tersimpan pukul ${String(p.jam).replace(":", ".")}, tetapi di PCare masih Baru.`;
        } else { st = "tersimpan"; ket = p.jam ? "pukul " + String(p.jam).replace(":", ".") : ""; }
      }
      else if (lw) { st = "cek"; ket = lw.alasan || ""; }
      else if (p && p.tgl === BR.today() && p.hasil === "dilewati") { st = "dilewati"; }
      else if (!perluDilayani(r)) { st = "dilayani"; ket = r.status || ""; }
      else if (BR.cocokPoli(r.poli, kecuali)) { st = "dikecualikan"; ket = `${r.poli} tidak diproses bot (Pengaturan).`; }
      return { antrean: r.antrean, nama: r.nama, kelamin: r.kelamin || "", usia: isNaN(r.usia) ? null : r.usia, kartu: r.kartu, poli: r.poli || "", status: st, ket };
    });
    await BR.store.set("mejaAntrean", { tgl: this.tgl, jam: new Date().toLocaleTimeString("id-ID").slice(0, 5), rows });
  },
};
chrome.storage.onChanged.addListener((ch, area) => {
  if (area !== "local") return;
  if ((ch.processed || ch.lewatHariIni || ch.poliDikecualikan) && meja.baris.length) { clearTimeout(meja._t); meja._t = setTimeout(() => meja.simpan(), 300); }
  if (ch.panelBotTampil) aturPanelBot(ch.panelBotTampil.newValue);
  if (ch.aktivitasBot && Array.isArray(ch.aktivitasBot.newValue) && !ch.aktivitasBot.newValue.length) meja._akt = [];   // v3.2.7: dikosongkan dari aplikasi
  if (ch.autoSave) { const c = document.getElementById("br-auto"); if (c) c.checked = !!ch.autoSave.newValue; }        // v3.2.5: sakelar dari kolom Antrean
  if (ch.lanjutOtomatis) { const c = document.getElementById("br-lanjut"); if (c) c.checked = ch.lanjutOtomatis.newValue !== false; }
  if (ch.perintahBot && ch.perintahBot.newValue) jalankanPerintah(ch.perintahBot.newValue);
});
// panel mengambang disembunyikan di aplikasi (kendali pindah ke kolom Antrean); bisa ditampilkan lagi
function aturPanelBot(tampil) { const p = document.getElementById("br-panel"); if (p) p.classList.toggle("br-sembunyi", BR.diAplikasi || tampil === false); }   // v3.2.5: di aplikasi selalu tersembunyi
const lapor = (id, ok, pesan) => BR.store.set("hasilPerintah", { id, ok, pesan, at: Date.now() });
async function jalankanPerintah(c) {
  if (!c || !c.id || Date.now() - (c.at || 0) > 15000) return;
  if (sessionStorage.getItem("br-perintah-" + c.id)) return;              // satu perintah dikerjakan sekali
  sessionStorage.setItem("br-perintah-" + c.id, "1");
  if (c.cmd === "pv") return pvDariAplikasi(c);
  if (halamanLogin && c.cmd !== "panel") return lapor(c.id, false, "PCare belum login.");
  if (c.cmd === "refresh" || c.cmd === "proses" || c.cmd === "jalankan" || c.cmd === "nonstop") {
    const run = await getRun();
    if ((run.active && !run.paused) || document.getElementById("br-pratinjau")) {
      const sk = run.current ? `${run.current.antrean}` : "pasien";
      return lapor(c.id, false, `Bot sedang memproses ${sk}. Selesaikan pratinjau (Simpan/Batal) atau klik Berhenti dulu.`);
    }
  }
  if (c.cmd === "refresh") { lapor(c.id, true, "Membaca antrean PCare…"); return tampilkanPasien(); }
  if (c.cmd === "nonstop") { const b = document.getElementById("br-nonstop"); if (b) b.click(); return lapor(c.id, !!b, b ? "Bot nonstop berjalan." : "Tombol nonstop tidak ditemukan."); }
  if (c.cmd === "jalankan") { const b = document.getElementById("br-run"); if (b) b.click(); return lapor(c.id, !!b, b ? "Bot berjalan." : "Tombol Jalankan tidak ditemukan."); }
  if (c.cmd === "abaikanJK") {   // v3.2.9: beda jenis kelamin C-CARE vs PCare → tetap proses (pratinjau WAJIB dicek, tanpa simpan otomatis)
    const r = await getRun();
    if (!r.active || !r.paused || !r.current) return lapor(c.id, false, "Bot tidak sedang menunggu.");
    r.current.abaikanJK = true;
    await setRun(r);
    log(`${r.current.antrean}: petugas memilih tetap proses walau jenis kelamin C-CARE dan PCare berbeda. Simpan otomatis dimatikan untuk pasien ini.`, false);
    document.getElementById("br-next")?.click();
    return lapor(c.id, true, "Diproses ulang. Periksa pratinjau sebelum simpan.");
  }
  if (c.cmd === "lanjut" || c.cmd === "lewati") {   // v3.2.2: tombol ⏭ Lanjut / ⏩ Lewati dari kolom Antrean
    const b = document.getElementById(c.cmd === "lanjut" ? "br-next" : "br-skip");
    if (!b) return lapor(c.id, false, "Tombol tidak ditemukan.");
    b.click(); return lapor(c.id, true, c.cmd === "lanjut" ? "Bot dilanjutkan." : "Pasien dilewati.");
  }
  if (c.cmd === "berhenti") { await runStop(); return lapor(c.id, true, "Bot dihentikan."); }
  if (c.cmd === "proses") {
    const r = (meja.baris || []).find((x) => x.antrean === c.antrean && (!c.kartu || x.kartu === c.kartu));
    if (!r) return lapor(c.id, false, "Pasien tidak ada di antrean terakhir. Klik Muat antrean dulu.");
    lapor(c.id, true, `Memproses ${r.antrean}…`); return runStartFor(r, meja.tgl || tglPcare());
  }
  if (c.cmd === "tandai") {   // v3.2.1: Anda sudah menyimpan sendiri di PCare → tandai, bot tidak memprosesnya lagi hari ini
    if (!c.antrean || !/^\d{13}$/.test(String(c.kartu || ""))) return lapor(c.id, false, "Data pasien tidak lengkap.");
    const r = { antrean: c.antrean, kartu: c.kartu, nama: c.nama || "" };
    await markProcessed(r, "manual");
    log(`${r.antrean} ditandai tersimpan oleh petugas.`, "info");
    return lapor(c.id, true, `${r.antrean} ditandai tersimpan.`);
  }
  if (c.cmd === "isiRujukan") return lapor(c.id, ...(await isiSpesialisRujukan(c.spesialis || [])));
}
// Popup "Pencarian Fasilitas Kesehatan Rujukan": pilih Rujukan Vertikal → Spesialis → spesialis yang cocok. Tidak menyimpan.
async function isiSpesialisRujukan(daftar) {
  const m = document.getElementById("modal-rujukLanjut");
  if (!m || !BR.visible(m)) return [false, "Buka dulu popup rujukan di PCare (Status Pulang → Rujuk → Cari)."];
  const klikRadio = (nama, nilai) => { const r = m.querySelector(`input[name="${nama}"][value="${nilai}"]`); if (r && !r.checked) { r.click(); BR.fire(r); } return !!r; };
  klikRadio("jenisRujukan_rb", "4"); await BR.sleep(300);
  klikRadio("opsiRujuk_rb", "2"); await BR.sleep(400);
  const terisi = [];
  for (let i = 0; i < Math.min(3, daftar.length); i++) {
    const s = document.getElementById("spesialis" + (i + 1));
    if (!s) { if (i) { const plus = document.getElementById("addspesialis" + (i + 1)); if (plus) { plus.click(); await BR.sleep(400); } } }
    const sel = document.getElementById("spesialis" + (i + 1));
    if (!sel) break;
    for (let t = 0; t < 10 && sel.options.length < 2; t++) await BR.sleep(300);
    const cari = (daftar[i].cari || [daftar[i].nama]).map((x) => BR.norm(x));
    const opt = [...sel.options].find((o) => o.value && cari.some((c) => BR.norm(o.text).includes(c)));
    if (!opt) return [false, `Spesialis "${daftar[i].nama}" tidak ditemukan di daftar PCare. Pilih manual.`];
    sel.value = opt.value; BR.fire(sel); if (window.jQuery) try { window.jQuery(sel).trigger("change"); } catch (e) {}
    terisi.push(opt.text.trim());
    await BR.sleep(500);
  }
  log(`Rujukan: spesialis diisi dari C-CARE → ${terisi.join(", ")}. Pilih faskes & simpan oleh petugas.`, "info");
  return [true, `Spesialis terisi: ${terisi.join(", ")}. Lanjutkan Tgl. rencana → Cari Faskes Rujukan.`];
}

buildPanel();
if (BR.diAplikasi && !halamanLogin) BR.store.set("kabarLogin_pcare", null);   
if (BR.diAplikasi) BR.store.set("pratinjauAktif", null);   // halaman baru: tidak ada pratinjau yang terbuka   // v3.2.0: sudah masuk → pita login di aplikasi hilang
BR.store.get("panelBotTampil").then((v) => aturPanelBot(v));
if (halamanLogin) {   // v2.0.0: login otomatis PCare; bot TIDAK dijalankan di halaman login
  BR.loginOtomatis("pcare", (t) => status(t), { kotak: true }).then((h) => {
    if (h === "mati") BR.kabarLogin("Login otomatis PCare belum aktif. Aktifkan di Pengaturan, atau login manual.");
  });
}
// lanjutkan otomatis setelah PCare berpindah halaman
BR.store.get("bukaDaftarLaluTampilkan").then(async (v) => {
  if (v && location.pathname.startsWith(URL_DAFTAR)) { await BR.store.set("bukaDaftarLaluTampilkan", false); setTimeout(tampilkanPasien, 1500); }
});
if (!halamanLogin) getRun().then((r) => { if (r.active && !r.paused) setTimeout(runLoop, 1500); else if (r.active) status("⏸ Menunggu Anda — klik ⏭ Lanjut"); });
else getRun().then((r) => { if (r.active) status("⏸ PCare minta login. Bot lanjut sendiri sesudah login."); });
