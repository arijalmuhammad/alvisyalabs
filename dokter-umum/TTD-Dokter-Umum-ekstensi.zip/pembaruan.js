/* Cek versi baru (ekstensi "dimuat tanpa dikemas" tidak bisa memperbarui diri): hanya membaca versi.json di alvisya.my.id. */
const VERSI_URL = 'https://alvisya.my.id/dokter-umum/versi.json';
const lebihBaru = (a, b) => { const x = a.split('.').map(Number), y = b.split('.').map(Number);
  for (let i = 0; i < 3; i++) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0); } return false; };
async function cekPembaruan() {
  try {
    const j = await (await fetch(VERSI_URL, { cache: 'no-store' })).json();
    const kini = chrome.runtime.getManifest().version;
    const ada = typeof j.ekstensi === 'string' && lebihBaru(j.ekstensi, kini) && /^https:\/\/alvisya\.my\.id\//.test(j.ekstensiUrl || '');
    return ada ? { versi: j.ekstensi, url: j.ekstensiUrl } : null;
  } catch (e) { console.warn('[TTD] cek pembaruan gagal', e); return null; }
}
