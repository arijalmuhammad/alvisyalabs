/* Daftar pasien C-CARE (Poli/…/Index, KIA): sembunyikan kolom "Tanggal Kunjungan" & "Tanggal Pemeriksaan",
 * urutkan Menunggu Dokter → Menunggu Obat → Menunggu Perawat, dan persingkat status ("Menunggu Pemeriksaan Dokter" → "Menunggu Dokter", "… Perawat" → "Menunggu Perawat").
 * Hanya tampilan (CSS) — data, urutan, pencarian, dan Export C-CARE tidak berubah. Bisa dimatikan di Pengaturan → Auto Fill. */
(() => {
  const SASARAN = ['tanggal kunjungan', 'tanggal pemeriksaan'];
  const URUT = { 'menunggu pemeriksaan dokter': 0, 'menunggu dokter': 0, 'menunggu obat': 1, 'menunggu pemeriksaan perawat': 2, 'menunggu perawat': 2 };
  const PENDEK = { 'menunggu pemeriksaan dokter': 'Menunggu Dokter', 'menunggu pemeriksaan perawat': 'Menunggu Perawat' };
  const gaya = document.createElement('style'); gaya.id = 'sjc-daftar-ringkas';
  const norm = s => String(s || '').replace(/\s+/g, ' ').trim().toLowerCase();
  let aktif = false, nomor = 0, siapBaru = new Set();
  function terapkan() {
    if (!aktif) {
      gaya.textContent = '';
      document.querySelectorAll('.sjc-baru').forEach(x => x.remove());
      document.querySelectorAll('td[data-sjc-asli]').forEach(td => { td.textContent = td.dataset.sjcAsli; td.removeAttribute('data-sjc-asli'); td.removeAttribute('title'); });
      document.querySelectorAll('table[data-sjc-ringkas] > tbody').forEach(tb => {           // kembalikan urutan asli C-CARE
        [...tb.rows].filter(r => r.dataset.sjcI !== undefined).sort((a, b) => a.dataset.sjcI - b.dataset.sjcI).forEach(r => tb.appendChild(r));
      });
      return;
    }
    const aturan = [];
    document.querySelectorAll('table').forEach(tb => {
      const kepala = tb.tHead && tb.tHead.rows[tb.tHead.rows.length - 1]; if (!kepala) return;
      const kolom = [...kepala.cells].map((c, i) => SASARAN.includes(norm(c.textContent)) ? i + 1 : 0).filter(Boolean);
      if (!kolom.length) return;
      if (!tb.dataset.sjcRingkas) tb.dataset.sjcRingkas = String(++nomor);
      const sel = `table[data-sjc-ringkas="${tb.dataset.sjcRingkas}"]`;
      kolom.forEach(k => aturan.push(`${sel} > thead > tr > :nth-child(${k}), ${sel} > tbody > tr > :nth-child(${k}), ${sel} > tfoot > tr > :nth-child(${k})`));
    });
    document.querySelectorAll('table tbody td').forEach(td => {      // status pendek (hanya teks tampilan; data asli disimpan di data-sjc-asli)
      if (td.children.length) return;
      const p = PENDEK[norm(td.textContent)];
      if (p) { td.dataset.sjcAsli = td.textContent; td.title = td.textContent.replace(/\s+/g, ' ').trim(); td.textContent = p; }
    });
    // urutan: Menunggu Dokter → Menunggu Obat → Menunggu Perawat → lainnya (urutan asli dipertahankan di tiap kelompok).
    // Berhenti bila pengguna mengklik judul kolom untuk mengurutkan sendiri.
    document.querySelectorAll('table[data-sjc-ringkas]').forEach(tb => {
      if (tb.dataset.sjcManual) return;
      const kepala = tb.tHead.rows[tb.tHead.rows.length - 1], ks = [...kepala.cells].findIndex(c => norm(c.textContent) === 'status pemeriksaan');
      if (ks < 0 || !tb.tBodies[0]) return;
      if (!tb.dataset.sjcKlik) { tb.dataset.sjcKlik = '1'; kepala.addEventListener('click', () => { tb.dataset.sjcManual = '1'; }, true); }
      const rows = [...tb.tBodies[0].rows]; rows.forEach((r, i) => { if (r.dataset.sjcI === undefined) r.dataset.sjcI = String(i); });
      const rank = r => { const c = r.cells[ks]; if (!c) return 9; const v = URUT[norm(c.dataset.sjcAsli || c.textContent)]; return v === undefined ? 3 : v; };
      const urut = rows.map((r, i) => [rank(r), i, r]).sort((a, b) => a[0] - b[0] || a[1] - b[1]).map(x => x[2]);
      if (urut.some((r, i) => r !== rows[i])) urut.forEach(r => tb.tBodies[0].appendChild(r));
    });
    // label "Baru siap" di kolom Nama Pasien untuk pasien yang baru selesai di perawat (dari pemantau Siap dipanggil)
    document.querySelectorAll('table[data-sjc-ringkas]').forEach(tb => {
      const kepala = tb.tHead.rows[tb.tHead.rows.length - 1], kn = [...kepala.cells].findIndex(c => norm(c.textContent) === 'nama pasien');
      if (kn < 0 || !tb.tBodies[0]) return;
      [...tb.tBodies[0].rows].forEach(r => {
        const id = ([...r.querySelectorAll('a[href]')].map(a => (a.getAttribute('href').match(/\/(\d+)\/?$/) || [])[1]).find(x => x && siapBaru.has(x))) || '';
        const c = r.cells[kn], ada = c && c.querySelector('.sjc-baru');
        if (id && c && !ada) c.insertAdjacentHTML('afterbegin', '<span class="sjc-baru" role="img" title="Baru siap dipanggil" aria-label="Baru siap dipanggil"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 22a2 2 0 0 0 2-2h-4a2 2 0 0 0 2 2zm6-6V11c0-3.07-1.64-5.64-4.5-6.32V4a1.5 1.5 0 0 0-3 0v.68C7.63 5.36 6 7.92 6 11v5l-2 2v1h16v-1z"/></svg></span>');
        if (!id && ada) ada.remove();
      });
    });
    const teks = (aturan.length ? aturan.join(',\n') + ' { display: none !important; }\n' : '') +
      '.sjc-baru{display:inline-grid;place-items:center;width:22px;height:22px;margin:0 6px 2px 0;border-radius:50%;background:#B91C1C;color:#fff;vertical-align:middle;animation:sjc-denyut 1.6s ease-in-out 3}.sjc-baru svg{width:14px;height:14px;fill:currentColor}@keyframes sjc-denyut{50%{box-shadow:0 0 0 5px rgba(185,28,28,.18)}}';
    if (gaya.textContent !== teks) gaya.textContent = teks;
    if (!gaya.isConnected) document.head.appendChild(gaya);
  }

  /* ---------- balon kecil kanan bawah (selaras CCare Farmasi): jumlah siap dipanggil · titik pantau · cek sekarang ---------- */
  const NAMA_SINGKAT = { 1: 'Umum', 2: 'Gigi', kia: 'KIA', 4: 'Sehat', '4mcu': 'MCU', 5: 'Tindakan', 8: 'Prolanis', 7: 'Gizi' };
  const NAMA_POLI = { 1: 'Poli Umum', 2: 'Poli Gigi', kia: 'KIA', 4: 'Kunjungan Sehat', '4mcu': 'MCU', 5: 'Ruang Tindakan', 8: 'Prolanis', 7: 'Poli Gizi' };
  const IKB = {
    segar: '<svg viewBox="0 0 24 24"><path d="M17.65 6.35A7.96 7.96 0 0 0 12 4a8 8 0 1 0 7.73 10h-2.08A6 6 0 1 1 12 6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z"/></svg>',
    tutup: '<svg viewBox="0 0 24 24"><path d="M19 6.41 17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>',
    tabbaru: '<svg viewBox="0 0 24 24"><path d="M19 19H5V5h7V3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7h-2v7zM14 3v2h3.59l-9.83 9.83 1.41 1.41L19 6.41V10h2V3h-7z"/></svg>',
    jam: '<svg viewBox="0 0 24 24"><path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm0 18a8 8 0 1 1 0-16 8 8 0 0 1 0 16zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67V7z"/></svg>',
    tambah: '<svg viewBox="0 0 24 24"><path d="M15 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm-9-2V7H4v3H1v2h3v3h2v-3h3v-2H6zm9 4c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg>',
  };
  const GAYA_BALON = `:host{all:initial}[hidden]{display:none!important}*{box-sizing:border-box;font-family:"Source Sans 3","Source Sans Pro",system-ui,"Segoe UI",sans-serif}
  svg{width:16px;height:16px;fill:currentColor}button{font:inherit;cursor:pointer;white-space:nowrap}button:focus-visible{outline:2px solid #263C92;outline-offset:2px}
  .pil{position:fixed;right:28px;bottom:20px;z-index:2147483000;display:flex;align-items:center;gap:4px;height:34px;padding:0 4px 0 5px;background:#fff;border:1px solid #D5E0E0;border-radius:999px;box-shadow:0 4px 16px rgba(15,39,66,.16);color:#0F2742;font-size:13px;line-height:1}
  .logo{width:24px;height:24px;border:0;padding:0;background:none;display:grid;place-items:center}.logo img{width:24px;height:24px;border-radius:7px;display:block}
  .pil.mini .seg,.pil.mini .ib{display:none}
  .seg{display:flex;align-items:center;gap:5px;border:0;background:none;padding:0 4px;height:26px;border-radius:999px;color:#0F2742;font-size:13px}.seg:hover{background:#F2F6F6}
  .n{min-width:20px;height:20px;border-radius:999px;background:#B91C1C;color:#fff;font-weight:700;font-size:12px;display:grid;place-items:center;padding:0 6px;font-variant-numeric:tabular-nums}.n.nol{background:#E8ECF7;color:#263C92}
  .titik{width:8px;height:8px;border-radius:50%;background:#9DB0B8;flex:none}.titik.ok{background:#3B7A1E;animation:denyut 2s infinite}.titik.awas{background:#B45309}.titik.galat{background:#B91C1C}
  @keyframes denyut{0%{box-shadow:0 0 0 0 rgba(59,122,30,.5)}70%{box-shadow:0 0 0 5px rgba(59,122,30,0)}100%{box-shadow:0 0 0 0 rgba(59,122,30,0)}}
  .ib{position:relative;border:0;padding:0;width:26px;height:26px;color:#4F6478;background:none;border-radius:999px;display:grid;place-items:center}.ib:hover{background:#F2F6F6;color:#263C92}
  .ib.putar svg{animation:putar .8s linear}@keyframes putar{to{transform:rotate(360deg)}}
  .ib.daftar-baru{color:#263C92}.ib .lenc{position:absolute;top:-3px;right:-3px;min-width:15px;height:15px;border-radius:999px;background:#263C92;color:#fff;font-size:10px;font-weight:700;display:grid;place-items:center;padding:0 3px}
  .lembar{position:fixed;right:28px;bottom:62px;z-index:2147483000;width:340px;max-width:calc(100vw - 32px);max-height:min(60vh,420px);overflow-y:auto;overflow-x:hidden;background:#fff;border:1px solid #D5E0E0;border-radius:12px;box-shadow:0 6px 24px rgba(15,39,66,.18);color:#0F2742;font-size:13px;line-height:1.4}
  .kp{display:flex;align-items:center;gap:6px;padding:8px 10px;border-bottom:1px solid #E3EBEA;font-weight:700;position:sticky;top:0;background:#fff}.kp .ib{margin-left:auto}
  .bd{padding:6px;display:grid;grid-template-columns:minmax(0,1fr);gap:2px}.ket{color:#4F6478;font-size:12px;padding:6px}
  .brs{display:flex;align-items:center;gap:2px;min-width:0}.brs .hapus{flex:none;opacity:.55}.brs:hover .hapus,.brs .hapus:focus-visible{opacity:1}.brs .hapus:hover{color:#B91C1C}
  .pasien{display:flex;align-items:center;gap:8px;flex:1;min-width:0;border:0;background:none;padding:6px;border-radius:8px;text-align:left;color:#0F2742}.pasien:hover{background:#F2F6F6}
  .pasien .tg{flex:none;font-size:12px;color:#4F6478;font-variant-numeric:tabular-nums;display:flex;align-items:center;gap:3px}.pasien .tg svg{width:14px;height:14px;fill:currentColor}
  .pasien .tg.awas{color:#B45309;font-weight:600}.pasien .tg.kritis{color:#B91C1C;font-weight:700}
  .prw{color:#4F6478;font-size:12px;font-variant-numeric:tabular-nums}.kaki{border-top:1px solid #E3EBEA;padding:8px 10px;color:#4F6478;font-size:12px}
  .pasien .nm{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:600}.pasien small{color:#4F6478;font-weight:400}.pasien svg{fill:#263C92}
  @media (prefers-color-scheme: dark){.pil,.lembar,.kp{background:#15252B;border-color:#2A3D44;color:#E6EEF0}.seg,.pasien{color:#E6EEF0}.seg:hover,.ib:hover,.pasien:hover{background:#1E3036}.ket,.pasien small{color:#9DB0B8}}`;
  const balon = (() => {
    let akar = null, ui = null, siap = [], baruN = 0, perawat = { n: 0, poli: {} };
    function buat() {
      if (ui) return;
      const host = document.createElement('div'); host.id = 'ccare-dokter-balon'; document.documentElement.append(host);
      akar = host.attachShadow({ mode: 'open' });
      akar.innerHTML = `<style>${GAYA_BALON}</style>
        <div class="lembar" hidden role="dialog" aria-label="Siap dipanggil"><div class="kp">Siap dipanggil<button class="ib" data-a="tutup" title="Tutup" aria-label="Tutup">${IKB.tutup}</button></div><div class="bd"></div><div class="kaki" hidden></div></div>
        <div class="pil" role="region" aria-label="Alvisya Dokter">
          <button class="logo" data-a="mini" title="Alvisya Dokter — klik untuk ciutkan/buka" aria-label="Ciutkan atau buka balon Alvisya Dokter"><img alt="" src="${chrome.runtime.getURL('ikon/48.png')}"></button>
          <button class="seg" data-a="lembar" title="Pasien siap dipanggil"><span class="n nol">0</span><span>Siap</span><span class="titik"></span><span class="prw" hidden></span></button>
          <button class="ib daftar-baru" data-a="muat" hidden title="Pasien baru terdaftar — muat ulang daftar" aria-label="Pasien baru terdaftar, muat ulang daftar">${IKB.tambah}<span class="lenc"></span></button>
          <button class="ib" data-a="cek" title="Cek sekarang" aria-label="Cek sekarang">${IKB.segar}</button>
        </div>`;
      const q = s => akar.querySelector(s);
      ui = { prw: q('.prw'), kaki: q('.kaki'), pil: q('.pil'), n: q('.n'), titik: q('.titik'), seg: q('.seg'), lembar: q('.lembar'), bd: q('.bd'), muat: q('[data-a=muat]'), lenc: q('.lenc'), cek: q('[data-a=cek]') };
      akar.addEventListener('click', e => {
        const b = e.target.closest('button'); if (!b) return;
        const a = b.dataset.a;
        if (a === 'mini') { const m = !ui.pil.classList.contains('mini'); ui.pil.classList.toggle('mini', m); if (m) ui.lembar.hidden = true; chrome.storage.local.set({ balonMini: m }); }
        else if (a === 'lembar') { ui.lembar.hidden = !ui.lembar.hidden; gambar(); }
        else if (a === 'tutup') ui.lembar.hidden = true;
        else if (a === 'cek') { b.classList.remove('putar'); void b.offsetWidth; b.classList.add('putar'); chrome.runtime.sendMessage({ aksi: 'cekSekarang' }).catch(() => {}); }
        else if (a === 'muat') { const t = [...document.querySelectorAll('button, input[type=submit]')].find(x => /tampilkan/i.test(x.textContent || x.value)); if (t) t.click(); else location.reload(); }
        else if (a === 'buka') chrome.runtime.sendMessage({ aksi: 'bukaCppt', id: b.dataset.id }).catch(() => {});
        else if (a === 'sembunyi') { b.closest('.brs').remove(); chrome.runtime.sendMessage({ aksi: 'sembunyikanSiap', id: b.dataset.id }).catch(() => {}); }
      });
      document.addEventListener('keydown', e => { if (e.key === 'Escape' && ui) ui.lembar.hidden = true; });
      chrome.storage.local.get('balonMini', s => { if (s.balonMini && ui) ui.pil.classList.add('mini'); });
    }
    let tandaGambar = '';
    /* lama menunggu sejak pemantau melihat pasien di Menunggu Dokter; "≥" bila sudah menunggu sebelum pemantau berjalan */
    /* jam kunjungan dari C-CARE (fakta), bukan lama menunggu hasil tebakan pemantau */
    const tunggu = x => ({ t: x.jam || '', k: '' });
    function gambar() {
      if (!ui || ui.lembar.hidden) return;
      const esc = t => String(t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
      const tanda = JSON.stringify([siap.map(([id, x]) => [id, x.nama, x.poli, tunggu(x).t]), perawat]);
      if (tanda === tandaGambar) return; tandaGambar = tanda;                      // tidak digambar ulang tanpa perubahan (fokus & hover tetap)
      ui.bd.innerHTML = siap.length ? siap.map(([id, x]) => { const w = tunggu(x); return `<div class="brs"><button class="pasien" data-a="buka" data-id="${esc(id)}" title="${esc(x.nama || '')} — buka CPPT di tab baru"><span class="nm">${esc(x.nama || '-')} <small>· ${esc(NAMA_SINGKAT[x.poli] || 'Poli')}</small></span><span class="tg ${w.k}" title="Jam kunjungan di C-CARE">${w.t}</span>${IKB.tabbaru}</button><button class="ib hapus" data-a="sembunyi" data-id="${esc(id)}" title="Sudah ditangani — keluarkan dari daftar (status C-CARE tidak diubah)" aria-label="Keluarkan dari daftar">${IKB.tutup}</button></div>`; }).join('')
        : '<div class="ket">Belum ada pasien siap dipanggil.</div>';
      const per = Object.entries(perawat.poli);
      ui.kaki.hidden = !perawat.n; ui.kaki.textContent = perawat.n ? 'Berikutnya, di perawat: ' + per.map(([p, n]) => (NAMA_POLI[p] || 'Poli') + ' ' + n).join(' · ') : '';
    }
    return {
      perbarui(p, mati) {
        if (mati) { if (akar) { akar.host.remove(); akar = null; ui = null; } return; }
        buat();
        siap = Object.entries(siapTerkini(p)).sort((a, b) => (a[1].jam ? String(a[1].jam).padStart(5, '0') : '99.99').localeCompare(b[1].jam ? String(b[1].jam).padStart(5, '0') : '99.99') || (a[1].sejak || 0) - (b[1].sejak || 0));   // urut jam kunjungan
        perawat = { n: 0, poli: {} };                                              // pasien di tahap perawat = yang akan siap berikutnya (tanpa nama)
        ((p && p.baris) || []).forEach(b => { const t = norm(b.status); if (/menunggu/.test(t) && /perawat/.test(t)) { perawat.n++; perawat.poli[b.poli] = (perawat.poli[b.poli] || 0) + 1; } });
        ui.prw.hidden = !perawat.n; ui.prw.textContent = '· ' + perawat.n + ' di perawat';
        ui.n.textContent = siap.length; ui.n.classList.toggle('nol', !siap.length);
        const umur = p && p.waktu ? Date.now() - p.waktu : 1e9;
        ui.titik.className = 'titik ' + (umur < 15000 ? 'ok' : umur < 60000 ? 'awas' : '');
        ui.seg.title = umur < 15000 ? 'Memantau · ' + siap.length + ' siap dipanggil' + (perawat.n ? ' · ' + perawat.n + ' masih di perawat' : '') : 'Pemantau belum berjalan';
        gambar();
      },
      baru(n) { baruN = n; if (!ui) return; ui.muat.hidden = !n; ui.lenc.textContent = n > 9 ? '9+' : n; },
    };
  })();
  let tunda = 0;
  new MutationObserver(() => { clearTimeout(tunda); tunda = setTimeout(terapkan, 60); }).observe(document.body, { childList: true, subtree: true });
  /* daftar yang sedang terbuka ikut diperbarui dari pemeriksaan latar (tanpa memuat ulang halaman):
     status diganti di tempat; pasien yang belum ada di tabel → simbol di balon (klik = muat ulang daftar). */
  let tundaLangsung = 0;
  function perbaruiLangsung(p) {
    if (sedangDipakai(3000)) { clearTimeout(tundaLangsung); tundaLangsung = setTimeout(() => perbaruiLangsung(pantauAkhir), 2000); return; }   // baris tidak bergeser di bawah kursor
    if (!aktif || !p || !Array.isArray(p.baris) || !(p.waktu > performance.timeOrigin)) return;   // hanya data yang lebih baru dari halaman ini
    const m = location.pathname.match(/\/Poli\/Index\/(\d+)/i), poli = m ? m[1] : /^\/kia/i.test(location.pathname) ? 'kia' : null;
    if (poli === null) return;
    const tgl = (document.querySelector('input[name=Tanggal]') || {}).value;
    if (tgl && /^\d{4}-\d{2}-\d{2}$/.test(tgl) && tgl !== p.tanggal) return;          // sedang melihat tanggal lain
    const S = anggota(), data = p.baris.filter(b => S.has(String(b.poli)));
    const tb = document.querySelector('table[data-sjc-ringkas]'); if (!tb || !tb.tBodies[0]) return;
    const kepala = tb.tHead.rows[tb.tHead.rows.length - 1], ks = [...kepala.cells].findIndex(c => norm(c.textContent) === 'status pemeriksaan');
    if (ks < 0) return;
    const peta = {};
    [...tb.tBodies[0].rows].forEach(r => r.querySelectorAll('a[href]').forEach(a => { const x = (a.getAttribute('href').match(/\/(\d+)\/?$/) || [])[1]; if (x) peta[x] = r; }));
    let hilang = 0;
    data.forEach(b => {
      if (b.status === 'Batal berobat') return;                         // label buatan pemantau, bukan teks C-CARE
      const r = peta[b.k]; if (!r) { hilang++; return; }
      const c = r.cells[ks]; if (!c) return;
      const kini = c.dataset.sjcAsli || c.textContent;
      if (norm(kini) !== norm(b.status)) { delete c.dataset.sjcAsli; c.removeAttribute('title'); c.textContent = b.status; }
    });
    const info = document.querySelector('.dataTables_info'), total = info && +((info.textContent.match(/(?:of|dari)\s+([\d.,]+)/i) || [])[1] || '').replace(/[.,]/g, '');
    const baru = total ? Math.max(0, data.length - total) : hilang;
    balon.baru(baru > 0 ? baru : 0);
    terapkan();
    if (baru > 0) segarkanNanti(800);                                   // ada pasien baru → tabel diperbarui senyap
  }

  /* ---------- tabel daftar diperbarui senyap (tanpa muat ulang): pasien baru masuk, status & tombol aksi ikut terkini ----------
     Memakai filter yang sedang tampil (dicatat saat halaman dimuat), sama seperti menekan Tampilkan. Ditunda selama Anda
     sedang mengetik/mengklik/menggulir (≤ 3 dtk), saat ada jendela dialog, atau tab tidak terlihat. */
  const rute = location.pathname.match(/^\/Poli\/Index\/(\d+)/i);
  const formFilter = (document.querySelector('input[name=Tanggal]') || {}).form;
  const awalFilter = rute && formFilter ? new URLSearchParams(new FormData(formFilter)) : null;
  let waktuSegar = 0, sedangSegar = false, terakhirSegar = 0, gerakTabel = 0;
  document.addEventListener('pointermove', e => { if (e.target.closest && e.target.closest('#datatable-poli, #ccare-dokter-tahap')) gerakTabel = Date.now(); }, { passive: true, capture: true });
  const sedangDipakai = ms => Date.now() - (window.__sjcAktif || 0) < ms || Date.now() - gerakTabel < 1500;   // kursor sedang bergerak di tabel → baris tidak digeser
  function segarkanNanti(ms) { if (!awalFilter) return; clearTimeout(waktuSegar); waktuSegar = setTimeout(() => segarkanSenyap(), ms); }
  /* ---------- Gabungan poli per grup (Atur gabungan): poli dalam grup yang sama tampil jadi satu daftar ----------
     MCU bukan JenisPoliId sendiri: baris Kunjungan Sehat (poli 4) yang tombolnya ke /Poli/Mcu/. MCU tanpa grup ikut Kunjungan Sehat. */
  const URUT_POLI = ['1', '2', 'kia', '4', '4mcu', '5', '8', '7'];
  const NAMA_PENDEK = { 1: 'Umum', 2: 'Gigi', kia: 'KIA', 4: 'Sehat', '4mcu': 'MCU', 5: 'Tindakan', 8: 'Prolanis', 7: 'Gizi' };
  const NAMA_ATUR = { 1: 'Poli Umum', 2: 'Poli Gigi', kia: 'KIA', 4: 'Kunjungan Sehat', '4mcu': 'MCU', 5: 'Ruang Tindakan', 8: 'Poli Prolanis', 7: 'Poli Gizi' };
  const GRUP = ['A', 'B', 'C'];                                      // 'X' = Sembunyikan (tidak ditampilkan, tidak dipantau)
  const poliIni = rute ? rute[1] : null, bisaGabung = !!awalFilter;
  let grup = {};
  /** grup MCU yang berlaku: hanya bila segrup dengan poli lain; MCU sendirian = ikut Kunjungan Sehat */
  const grupMcu = () => { const g = grup['4mcu']; return g && g !== 'X' && URUT_POLI.some(p => p !== '4mcu' && grup[p] === g) ? g : null; };
  /** isi halaman ini: poli segrup + MCU bila ikut Kunjungan Sehat */
  function anggota() {
    const g = grup[poliIni] === 'X' ? null : grup[poliIni], gm = grupMcu(), S = new Set(g ? URUT_POLI.filter(p => p !== '4mcu' && grup[p] === g) : []); S.add(poliIni);
    if (grup['4mcu'] !== 'X' && (gm ? gm === g : S.has('4'))) S.add('4mcu');
    return S;
  }
  const tampilGabung = () => [...anggota()].filter(p => !(p === '4mcu' && !grupMcu())).length > 1;
  const sumber = () => [...new Set([...anggota()].map(p => p === '4mcu' ? '4' : p))];       // poli yang perlu diambil
  const perluSaring = () => tampilGabung() || (poliIni === '4' && (!!grupMcu() || grup['4mcu'] === 'X'));          // halaman Sehat tanpa baris MCU
  let gabung = false;                                                                        // = tampilGabung(), disegarkan saat setelan berubah
  async function ambilDaftar(poli, sinyal) {
    const kia = poli === 'kia', q = new URLSearchParams(awalFilter);
    if (kia) q.delete('JenisPoliId'); else q.set('JenisPoliId', poli);
    const r = await fetch(kia ? '/Kia' : '/Poli/Index/' + poli, { method: 'POST', body: q, credentials: 'include', signal: sinyal, priority: 'low', headers: { 'Content-Type': 'application/x-www-form-urlencoded' } });
    if (!r.ok || !/\/(Poli\/Index|Kia)/i.test(new URL(r.url).pathname)) return null;         // dialihkan (sesi habis) → abaikan
    const d = new DOMParser().parseFromString(await r.text(), 'text/html');
    const tgl = d.querySelector('input[name=Tanggal]'), st = d.querySelector('select[name=StatusKunjunganId]');
    if (!tgl || tgl.value !== awalFilter.get('Tanggal') || (st && st.value !== (awalFilter.get('StatusKunjunganId') || ''))) return null;   // filter lain → jangan dipakai
    const tb = d.getElementById(kia ? 'datatable-kia' : 'datatable-poli'); if (!tb || !tb.tBodies[0]) return null;
    return [...tb.tBodies[0].rows].filter(r => r.cells.length > 2).map(tr => {
      if (kia) {                                                     // KIA: No, Tgl periksa, RM, Nama, Status, Dokter, Kategori, Aksi → susunan kolom poli
        const c = [...tr.cells], baru = d.createElement('tr'), kosong = () => d.createElement('td');
        const tk = kosong(); tk.innerHTML = c[1].innerHTML;
        baru.append(c[0], tk, c[1], c[2], c[3], c[4], c[c.length - 1]); tr = baru;
      }
      tr.dataset.sjcPoli = poli === '4' && jenisMcu(tr) ? '4mcu' : poli;
      return tr;
    });
  }
  /* MCU & Kunjungan Sehat sama-sama /Poli/Ubah/{id} di daftar; C-CARE mengalihkan kunjungan MCU ke /Poli/Mcu/{id}.
     Dicek sekali per kunjungan (GET tanpa mengikuti pengalihan, isi tidak dibaca) lalu diingat di 'tandaMcu'. */
  let tandaMcu = {}, sedangCekMcu = false;
  const idUbah = tr => { const a = tr.querySelector('a[href*="/Poli/Ubah/"], a[href*="/Poli/Mcu/"]'); return a ? (a.getAttribute('href').match(/(\d+)\/?$/) || [])[1] : null; };
  const jenisMcu = tr => !!tr.querySelector('a[href*="/Mcu/"]') || tandaMcu[idUbah(tr)] === 1;
  async function cekMcuDaftar() {
    if (sedangCekMcu || !simpanan['4']) return;
    const ids = simpanan['4'].map(idUbah).filter(id => id && !(id in tandaMcu)).slice(0, 40); if (!ids.length) return;
    sedangCekMcu = true; let ubah = false;
    try {
      for (let i = 0; i < ids.length; i += 2) await Promise.all(ids.slice(i, i + 2).map(async id => {
        try {
          const r = await fetch('/Poli/Ubah/' + id, { credentials: 'include', redirect: 'manual', priority: 'low' });
          try { r.body && r.body.cancel(); } catch (e) {}
          if (r.type === 'opaqueredirect') { tandaMcu[id] = 1; ubah = true; } else if (r.ok) tandaMcu[id] = 0;
        } catch (e) {}
      }));
      const k = Object.keys(tandaMcu); if (k.length > 3000) k.slice(0, k.length - 3000).forEach(x => delete tandaMcu[x]);
      chrome.storage.local.set({ tandaMcu });
    } finally { sedangCekMcu = false; }
    if (ubah) { (simpanan['4'] || []).forEach(tr => { tr.dataset.sjcPoli = jenisMcu(tr) ? '4mcu' : '4'; }); gambarGabung(); }
  }
  async function segarkanSenyap(paksa) {
    if (!awalFilter || matiUtama || sedangSegar) return;
    const sibuk = !paksa && sedangDipakai(3000) || document.visibilityState !== 'visible' ||
      document.querySelector('.modal.in, .modal.show, .swal2-container, .sweet-alert.visible') || String(getSelection()).length > 0;
    if (sibuk) { segarkanNanti(2000); return; }
    if (!paksa && Date.now() - terakhirSegar < 4000) { segarkanNanti(4000); return; }
    sedangSegar = true; terakhirSegar = Date.now();
    const c = new AbortController(); (window.__sjcCtrl = window.__sjcCtrl || new Set()).add(c);   // Set: sama dengan pantau.js
    try {
      /* tiap poli digambar begitu datang (poli lambat, mis. Kunjungan Sehat, tidak menahan yang lain) */
      const polis = perluSaring() ? sumber() : [poliIni], gagal = [];
      /* v4.10.25: satu kali coba ulang (±1,2 dtk) sebelum menulis "Gagal dimuat" — C-CARE kadang lambat/menolak saat banyak poli diambil bersamaan */
      const ambilUlang = p => ambilDaftar(p, c.signal).catch(e => { if (e && e.name === 'AbortError') throw e; return null; })
        .then(rows => rows || new Promise(ok => setTimeout(ok, 1200)).then(() => ambilDaftar(p, c.signal)).then(r2 => { if (!r2) console.warn('[SJC] daftar poli gagal dimuat 2×:', NAMA_PENDEK[p]); return r2; }));
      await Promise.all(polis.map(p => ambilUlang(p).then(rows => { if (rows) simpanan[p] = rows; else gagal.push(NAMA_PENDEK[p]); gambarGabung(); if (p === '4' && rows) cekMcuDaftar(); }, e => { if (e && e.name === 'AbortError') throw e; gagal.push(NAMA_PENDEK[p]); })));
      if (gabung) tulisKetGabung(gagal);
    } catch (e) {} finally {
      sedangSegar = false; window.__sjcCtrl.delete(c);
    }
  }
  const simpanan = {};                                                // baris terakhir per poli (sesi halaman ini)
  let tundaGambar = 0;
  function gambarGabung() {
    clearTimeout(tundaGambar);
    tundaGambar = setTimeout(() => {
      if (!simpanan[poliIni]) return;                                   // daftar poli ini sendiri belum ada → jangan sentuh tabel
      if (sedangDipakai(1500)) { gambarGabung(); return; }              // Anda sedang bekerja → tunggu
      const S = anggota(), polis = perluSaring() ? sumber() : [poliIni];
      const rows = [].concat(...polis.map(p => (simpanan[p] || []).filter(tr => !perluSaring() || S.has(tr.dataset.sjcPoli)).map(tr => {
        const x = tr.cloneNode(true);
        if (gabung && x.cells[1]) x.cells[1].innerHTML = `<span class="sjc-poli">${NAMA_PENDEK[tr.dataset.sjcPoli]}</span>`;   // kolom Tanggal Kunjungan (tersembunyi) dipakai jadi kolom Poli
        return x;
      })));
      rows.forEach((tr, i) => { if (tr.cells[0]) tr.cells[0].textContent = i + 1; });
      judulPoli(gabung);
      document.dispatchEvent(new CustomEvent('sjc-daftar-ganti', { detail: rows.map(r => r.outerHTML).join('') }));
    }, 150);
  }
  /* judul kolom ke-2 (Tanggal Kunjungan) ↔ "Poli" saat digabung; kolom Tanggal Kunjungan memang disembunyikan ringkas daftar */
  function judulPoli(on) {
    const tb = document.getElementById('datatable-poli'), th = tb && tb.tHead && tb.tHead.rows[tb.tHead.rows.length - 1].cells[1]; if (!th) return;
    if (on && th.dataset.sjcJudul === undefined) { th.dataset.sjcJudul = th.textContent; th.textContent = 'Poli'; }
    else if (!on && th.dataset.sjcJudul !== undefined) { th.textContent = th.dataset.sjcJudul; delete th.dataset.sjcJudul; }
    const kepala = document.querySelector('.dataTables_scrollHead thead tr:last-child'); if (kepala && kepala.cells[1]) kepala.cells[1].textContent = th.textContent;   // DataTables scrollX
  }
  /* tombol "Atur gabungan" di samping Tampilkan; setelan diingat di komputer ini (grupPoli) */
  let ketGabung = null;
  function tulisKetGabung(gagal) {
    if (!ketGabung) return;
    const nama = [...anggota()].filter(p => !(p === '4mcu' && !grupMcu())).sort((a, b) => URUT_POLI.indexOf(a) - URUT_POLI.indexOf(b)).map(p => NAMA_PENDEK[p]);
    ketGabung.textContent = gabung ? (gagal && gagal.length ? 'Gagal dimuat: ' + gagal.join(', ') : 'Digabung: ' + nama.join(' · ')) : '';
    ketGabung.classList.toggle('awas', !!(gabung && gagal && gagal.length));
  }
  function terapkanSetelan() {
    gabung = tampilGabung(); tulisKetGabung(null);
    if (perluSaring()) { if (gabung && ketGabung) ketGabung.textContent = 'Memuat gabungan…'; terakhirSegar = 0; clearTimeout(waktuSegar); segarkanSenyap(true); }
    else { judulPoli(false); if (simpanan[poliIni]) gambarGabung(); else { terakhirSegar = 0; segarkanNanti(0); } }
  }
  function pasangAtur() {
    if (!bisaGabung || document.getElementById('sjcAtur')) return;
    const kirim = formFilter.querySelector('[type=submit], button:not([type=button])'); if (!kirim) return;
    const g = document.createElement('style'); g.id = 'sjc-gabung-gaya';
    g.textContent = `.sjc-gabung{display:inline-flex;align-items:center;flex-wrap:wrap;gap:8px;margin-left:12px;vertical-align:middle;font:14px/1.3 "Source Sans 3","Source Sans Pro",system-ui,sans-serif;color:#0F2742}
      .sjc-gabung>button{min-height:32px;padding:0 12px;border:1px solid #D5E0E0;border-radius:8px;background:#fff;color:#263C92;font:600 14px/1 "Source Sans 3","Source Sans Pro",system-ui,sans-serif;white-space:nowrap;cursor:pointer;display:inline-flex;align-items:center;gap:6px}
      .sjc-gabung>button svg{width:16px;height:16px;fill:currentColor}
      .sjc-gabung>button:hover{background:#F2F6F6}.sjc-gabung>button:focus-visible{outline:2px solid #263C92;outline-offset:2px}
      .sjc-gabung small{color:#4F6478;font-size:12px}.sjc-gabung small.awas{color:#B45309;font-weight:600}
      .sjc-atur-isi{position:fixed;z-index:2147483000;width:460px;max-width:calc(100vw - 16px);box-sizing:border-box;padding:16px;border:1px solid #D5E0E0;border-radius:12px;background:#fff;box-shadow:0 8px 24px rgba(15,39,66,.16);font:14px/1.35 "Source Sans 3","Source Sans Pro",system-ui,sans-serif;color:#0F2742}
      .sjc-atur-isi[hidden]{display:none}
      .sjc-atur-isi h3{margin:0 0 4px;font-size:16px;font-weight:700}
      .sjc-atur-isi p{margin:0 0 12px;font-size:13px;color:#4F6478}
      .sjc-atur-isi table{width:100%;border-collapse:collapse}
      .sjc-atur-isi th{font-size:12px;font-weight:600;color:#4F6478;text-align:center;padding:0 0 6px}
      .sjc-atur-isi th:first-child,.sjc-atur-isi td:first-child{text-align:left;font-weight:600;white-space:nowrap}
      .sjc-atur-isi td{border-top:1px solid #E3EBEA;padding:0;text-align:center;height:36px}
      .sjc-atur-isi td label{display:flex;align-items:center;justify-content:center;width:100%;height:36px;cursor:pointer;margin:0}
      .sjc-atur-isi input{width:16px;height:16px;margin:0;accent-color:#263C92;cursor:pointer}
      .sjc-atur-isi th.sb,.sjc-atur-isi td.sb{border-left:1px solid #E3EBEA}
      .sjc-atur-isi td.sb input{accent-color:#B91C1C}
      .sjc-atur-isi tr[data-sembunyi] td:first-child{color:#4F6478;text-decoration:line-through}
      .sjc-atur-isi input:disabled{cursor:not-allowed;opacity:.35}
      .sjc-atur-isi tr.ini td:first-child::after{content:" · halaman ini";font-weight:400;color:#4F6478;font-size:12px}
      .sjc-atur-isi .kaki{display:flex;justify-content:space-between;align-items:center;gap:8px;margin-top:12px}
      .sjc-atur-isi .kaki small{color:#4F6478;font-size:12px}
      .sjc-atur-isi .kaki button{min-height:32px;padding:0 12px;border:0;border-radius:8px;background:#263C92;color:#fff;font:600 14px/1 "Source Sans 3","Source Sans Pro",system-ui,sans-serif;cursor:pointer}
      .sjc-atur-isi .kaki button:focus-visible,.sjc-atur-isi input:focus-visible{outline:2px solid #263C92;outline-offset:2px}
      .sjc-poli{display:inline-block;padding:0 6px;border:1px solid #D5E0E0;border-radius:6px;background:#F2F6F6;color:#4F6478;font-size:11px;font-weight:600;line-height:18px;vertical-align:middle;white-space:nowrap}`;
    document.head.appendChild(g);
    const w = document.createElement('span'); w.className = 'sjc-gabung';
    w.innerHTML = '<button type="button" id="sjcAtur" aria-expanded="false" aria-controls="sjcAturIsi"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 5h8v6H3zm10 0h8v6h-8zM3 13h8v6H3zm10 3h8v2h-8z"/></svg>Atur gabungan</button><small id="sjcGabungKet"></small>';
    kirim.after(w); ketGabung = w.querySelector('#sjcGabungKet');
    const isi = document.createElement('div'); isi.className = 'sjc-atur-isi'; isi.id = 'sjcAturIsi'; isi.hidden = true;
    isi.setAttribute('role', 'dialog'); isi.setAttribute('aria-label', 'Atur gabungan poli');
    document.body.appendChild(isi);
    const tb = w.querySelector('#sjcAtur');
    const gambar = () => {
      isi.innerHTML = '<h3>Gabungan poli</h3><p>Poli dalam grup yang sama tampil jadi satu daftar. Sembunyikan: tidak ditampilkan dan tidak dipantau.</p><table><thead><tr><th scope="col">Poli</th><th scope="col">Sendiri</th>' + GRUP.map((x, i) => `<th scope="col">Grup ${i + 1}</th>`).join('') + '<th scope="col" class="sb">Sembunyikan</th></tr></thead><tbody>' +
        URUT_POLI.map(p => `<tr${p === poliIni ? ' class="ini"' : ''}${grup[p] === 'X' ? ' data-sembunyi' : ''}><td>${NAMA_ATUR[p]}</td>` + ['', ...GRUP, 'X'].map((x, i) => `<td${x === 'X' ? ' class="sb"' : ''}><label><input type="radio" name="sjcg-${p}" value="${x}"${(grup[p] || '') === x ? ' checked' : ''}${x === 'X' && p === poliIni ? ' disabled' : ''} aria-label="${NAMA_ATUR[p]}: ${x === 'X' ? 'Sembunyikan' : i ? 'Grup ' + i : 'Sendiri'}"></label></td>`).join('') + '</tr>').join('') +
        '</tbody></table><div class="kaki"><small>MCU tanpa grup ikut Kunjungan Sehat.</small><button type="button" data-tutup>Selesai</button></div>';
    };
    const letakkan = () => { const r = tb.getBoundingClientRect(), lebar = Math.min(460, innerWidth - 16); isi.style.left = Math.max(8, Math.min(r.left, innerWidth - lebar - 8)) + 'px'; isi.style.top = Math.min(r.bottom + 6, Math.max(8, innerHeight - isi.offsetHeight - 8)) + 'px'; };
    const buka = on => { if (on) { gambar(); isi.hidden = false; letakkan(); (isi.querySelector('input:checked') || isi.querySelector('input')).focus(); } else isi.hidden = true; tb.setAttribute('aria-expanded', String(on)); };
    tb.addEventListener('click', () => buka(isi.hidden));
    isi.addEventListener('keydown', e => { if (e.key === 'Escape') { buka(false); tb.focus(); } });
    isi.addEventListener('click', e => { if (e.target.closest('[data-tutup]')) { buka(false); tb.focus(); } });
    document.addEventListener('mousedown', e => { if (!isi.hidden && !isi.contains(e.target) && !tb.contains(e.target)) buka(false); });
    addEventListener('resize', () => { if (!isi.hidden) letakkan(); }); addEventListener('scroll', () => { if (!isi.hidden) letakkan(); }, true);
    isi.addEventListener('change', e => {
      const x = e.target; if (!x.name || !x.name.startsWith('sjcg-')) return;
      const p = x.name.slice(5); if (x.value) grup[p] = x.value; else delete grup[p];
      x.closest('tr').toggleAttribute('data-sembunyi', x.value === 'X');
      chrome.storage.local.set({ grupPoli: grup });
    });
  }
  if (bisaGabung) chrome.storage.local.get(['grupPoli', 'gabungPoli', 'poliGabungPilih', 'tandaMcu'], s => {
    tandaMcu = s.tandaMcu || {};
    if (s.grupPoli && typeof s.grupPoli === 'object') grup = s.grupPoli;
    else if (s.gabungPoli) {                                            // migrasi dari sakelar lama "Semua poli"
      (Array.isArray(s.poliGabungPilih) ? s.poliGabungPilih : ['1', '4', '5', '8', '7', 'kia']).forEach(p => { if (URUT_POLI.includes(p)) grup[p] = 'A'; });
      chrome.storage.local.set({ grupPoli: grup });
    }
    pasangAtur(); gabung = tampilGabung(); tulisKetGabung(null);
    if (perluSaring()) { gabung && ketGabung && (ketGabung.textContent = 'Memuat gabungan…'); terakhirSegar = 0; segarkanNanti(0); }
  });
  chrome.storage.onChanged.addListener((c, a) => { if (a === 'local' && c.grupPoli && bisaGabung) { grup = c.grupPoli.newValue || {}; terapkanSetelan(); } });
  document.addEventListener('sjc-daftar-hasil', e => { if (e.detail === 'ganti') { balon.baru(0); terapkan(); } });
  if (awalFilter) {
    setInterval(() => { if (!gabung || Date.now() - terakhirSegar > 30000) segarkanNanti(0); }, 20000);   // jaring pengaman (gabungan: tiap 30 dtk)
    document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') segarkanNanti(300); });
  }
  const siapTerkini = p => { const o = {}, bc = (p && p.baca) || {}, sl = (p && p.selesai) || {}, kini = Date.now(); Object.entries((p && p.siap) || {}).forEach(([k, x]) => { if (!sl[k] && kini - (bc[String(x.poli)] || 0) < 120000) o[k] = x; }); return o; };   // sama dengan pantau.js
  const aktifDari = ic => !(ic || {}).tampilTanggal && !(ic || {}).mati;     // Auto Fill Mati → daftar asli C-CARE
  const baca = s => { aktif = aktifDari(s && s.isiCepat); terapkan(); };
  let matiUtama = false, pantauAkhir = null, pantauInti = null, pantauBaca = null;
  /* 'pantau' (daftar, berubah jarang) + 'pantauBaca' (jejak baca, tiap putaran) */
  const gabungPantau = () => { if (!pantauInti) return pantauInti; const p = Object.assign({}, pantauInti); if (pantauBaca && pantauBaca.tanggal === p.tanggal) { p.baca = Object.assign({}, p.baca, pantauBaca.baca); p.waktu = Math.max(p.waktu || 0, pantauBaca.waktu || 0); } return p; };
  const bacaSiap = p => { pantauAkhir = p; siapBaru = new Set(Object.entries(siapTerkini(p)).filter(([, x]) => x.baru && !x.dibuka && Date.now() - (x.sejak || 0) < 300000).map(([k]) => k)); /* simbol baru hanya 5 menit pertama */ terapkan(); perbaruiLangsung(p); balon.perbarui(p, matiUtama); };
  setInterval(() => balon.perbarui(pantauAkhir, matiUtama), 5000);
  chrome.storage.local.get(['isiCepat', 'pantau', 'pantauBaca'], s => { aktif = aktifDari(s.isiCepat); matiUtama = !!(s.isiCepat || {}).mati; pantauInti = s.pantau; pantauBaca = s.pantauBaca; bacaSiap(gabungPantau()); });
  chrome.storage.onChanged.addListener((u, area) => {
    if (area !== 'local') return;
    if (u.isiCepat) { matiUtama = !!(u.isiCepat.newValue || {}).mati; baca({ isiCepat: u.isiCepat.newValue }); balon.perbarui(pantauAkhir, matiUtama); }
    if (u.pantau) { pantauInti = u.pantau.newValue; if (u.pantauBaca) pantauBaca = u.pantauBaca.newValue; bacaSiap(gabungPantau()); }        // isi berubah → tabel & balon
    else if (u.pantauBaca) { pantauBaca = u.pantauBaca.newValue; pantauAkhir = gabungPantau(); balon.perbarui(pantauAkhir, matiUtama); }   // hanya jejak baca → balon saja (ringan)
  });
})();
