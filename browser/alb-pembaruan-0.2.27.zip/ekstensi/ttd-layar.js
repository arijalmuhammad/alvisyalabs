/* Alvisya Dokter v4.7.6 — kotak tanda tangan C-CARE (.ccare-canvas-stage, mis. Form Informasi Rencana Asuhan):
 * di layar penuh ada bilah bawah "Bersihkan" + "Selesai" (48 px, ramah jari) sehingga selalu bisa kembali ke tampilan asli,
 * tombol perbesar dibuat 44 px. Bila browser tidak mendukung layar penuh untuk elemen (mis. sebagian tablet), dipakai
 * layar penuh tiruan (position:fixed). Tidak mengubah isi tanda tangan dan tidak menekan Simpan. */
(() => {
  if (window.__sjcTtd) return; window.__sjcTtd = true;
  const fsEl = () => document.fullscreenElement || document.webkitFullscreenElement || null;
  const keluarFs = () => { const f = document.exitFullscreen || document.webkitExitFullscreen; if (f) try { f.call(document); } catch (e) {} };
  const st = document.createElement('style');
  st.textContent = `.ccare-canvas-fs-btn{width:44px!important;height:44px!important;touch-action:manipulation}
    .sjc-ttd-bar{display:none;position:absolute;left:50%;bottom:16px;transform:translateX(-50%);gap:12px;z-index:11;line-height:normal}
    .ccare-canvas-stage:fullscreen .sjc-ttd-bar,.ccare-canvas-stage:-webkit-full-screen .sjc-ttd-bar,.ccare-canvas-stage.sjc-penuh .sjc-ttd-bar{display:flex}
    .sjc-ttd-bar button{min-height:48px;min-width:120px;padding:0 20px;border-radius:8px;font:600 16px/1 "Source Sans 3","Source Sans Pro",system-ui,sans-serif;cursor:pointer;touch-action:manipulation;box-shadow:0 4px 12px rgba(15,39,66,.16)}
    .sjc-ttd-bar .bersih{border:1px solid #D5E0E0;background:#fff;color:#0F2742}
    .sjc-ttd-bar .selesai{border:0;background:#263C92;color:#fff}
    .sjc-ttd-bar button:focus-visible{outline:2px solid #263C92;outline-offset:2px}
    .ccare-canvas-stage.sjc-penuh{position:fixed!important;inset:0;z-index:2147483000;width:100vw;height:100vh;display:flex!important;align-items:center;justify-content:center;background:#F4F4F4}`;
  document.head.appendChild(st);
  /** tombol yang tetap jalan dengan jari: aksi saat jari diangkat, klik susulan diabaikan */
  function ketuk(b, aksi) {
    let jari = 0;
    b.addEventListener('touchend', e => { e.preventDefault(); e.stopPropagation(); jari = Date.now(); aksi(); }, { passive: false });
    b.addEventListener('click', e => { e.preventDefault(); e.stopPropagation(); if (Date.now() - jari > 600) aksi(); });
    ['touchstart', 'pointerdown', 'mousedown'].forEach(ev => b.addEventListener(ev, e => e.stopPropagation()));
  }
  function pasang(stage) {
    if (stage.dataset.sjcTtd) return; stage.dataset.sjcTtd = '1';
    const fsBtn = stage.querySelector('.ccare-canvas-fs-btn');
    const dukung = !!(stage.requestFullscreen || stage.webkitRequestFullscreen);
    const tutup = () => { if (fsEl()) keluarFs(); stage.classList.remove('sjc-penuh'); if (fsBtn) fsBtn.focus(); };
    const bar = document.createElement('div'); bar.className = 'sjc-ttd-bar';
    bar.innerHTML = '<button type="button" class="bersih">Bersihkan</button><button type="button" class="selesai">Selesai</button>';
    stage.appendChild(bar);
    ketuk(bar.querySelector('.selesai'), tutup);
    ketuk(bar.querySelector('.bersih'), () => {
      const asli = [...(stage.closest('form') || document).querySelectorAll('button, input[type=button]')].find(x => !bar.contains(x) && /bersihkan|hapus/i.test(x.textContent || x.value));
      if (asli) asli.click();
    });
    if (fsBtn) {
      /* di layar penuh, ketukan jari pada tombol perbesar = kembali; tanpa dukungan layar penuh → layar penuh tiruan */
      fsBtn.addEventListener('touchend', e => { if (fsEl() || stage.classList.contains('sjc-penuh')) { e.preventDefault(); e.stopImmediatePropagation(); tutup(); } }, { capture: true, passive: false });
      fsBtn.addEventListener('click', e => {
        if (stage.classList.contains('sjc-penuh')) { e.preventDefault(); e.stopImmediatePropagation(); tutup(); return; }
        if (!dukung) { e.preventDefault(); e.stopImmediatePropagation(); stage.classList.add('sjc-penuh'); return; }
        if (!fsEl()) setTimeout(() => { if (!fsEl()) stage.classList.add('sjc-penuh'); }, 500);   // layar penuh ditolak browser → tiruan
      }, true);
      fsBtn.setAttribute('aria-label', 'Perbesar kotak tanda tangan');
    }
    stage.addEventListener('keydown', e => { if (e.key === 'Escape' && stage.classList.contains('sjc-penuh')) tutup(); });
  }
  const cari = () => document.querySelectorAll('.ccare-canvas-stage').forEach(pasang);
  cari();
  /* kelas stage dipasang skrip C-CARE setelah halaman dimuat → amati sebentar */
  const mo = new MutationObserver(cari); mo.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['class'] });
  setTimeout(() => mo.disconnect(), 15000);
})();
