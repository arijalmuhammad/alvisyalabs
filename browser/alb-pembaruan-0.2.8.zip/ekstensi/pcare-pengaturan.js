/* Pengaturan → tab PCare. Dimuat setelah pengaturan.js (memakai $, pesan, tandaTersimpan, teksSakelar, IK, esc bila ada).
 * pcareSetelan tersimpan otomatis (& ikut sinkron akun Chrome); pcareAkun (ID/sandi) lewat tombol Simpan, hanya komputer ini. */
(() => {
  const BAWAAN = {
    aktif: true, otoMasuk: true, jamDari: '07:00', jamSampai: '21:00', tutupPeringatan: true,
    kecuali: ['gagal', 'error', 'galat', 'salah', 'tidak valid', 'tidak aktif', 'non aktif', 'nonaktif', 'tidak ditemukan',
      'tidak terdaftar', 'sudah terdaftar', 'sudah ada', 'ganda', 'duplikat', 'ditolak', 'wajib', 'harus', 'kuota', 'batas',
      'melebihi', 'kedaluwarsa', 'expired', 'tunggak', 'yakin', 'hapus', 'batal', 'rujuk', 'password', 'sandi'],
    jagaSesi: false, jagaMenit: 10, idleMenit: 15,
  };
  const ikon = k => (typeof IK !== 'undefined' && IK[k]) || '';
  const lolos = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const ambil = async () => Object.assign({}, BAWAAN, (await chrome.storage.local.get('pcareSetelan')).pcareSetelan || {});

  async function muat() {
    const s = await ambil(), { pcareAkun: a = {} } = await chrome.storage.local.get('pcareAkun');
    $('pcAktif').checked = s.aktif; $('pcOtoMasuk').checked = s.otoMasuk; $('pcJagaSesi').checked = s.jagaSesi; $('pcTutup').checked = s.tutupPeringatan;
    $('pcJamDari').value = s.jamDari; $('pcJamSampai').value = s.jamSampai; $('pcIdle').value = s.idleMenit;
    $('pcKecuali').value = (s.kecuali || []).join('\n');
    $('pcUser').value = a.user || ''; $('pcSandi').value = a.sandi || '';
    teksSakelar($('tab-pcare')); statusAkun();
  }
  async function statusAkun() {
    const { pcareAkun: a = {}, pcareStatus: st = {} } = await chrome.storage.local.get(['pcareAkun', 'pcareStatus']), e = $('pcStatusAkun');
    if (!a.user || !a.sandi) { e.className = 'pc-status awas'; e.innerHTML = ikon('awas') + '<span>Belum ada ID tersimpan — masuk otomatis belum bisa berjalan.</span>'; return; }
    if (st.masukGagal) {
      e.className = 'pc-status galat'; e.innerHTML = ikon('galat') + '<span>Masuk otomatis berhenti: percobaan terakhir ditolak PCare. Periksa ID &amp; sandi.</span><button type="button" class="kedua" id="pcCobaLagi">Coba lagi</button>';
      $('pcCobaLagi').onclick = async () => { const { pcareStatus: s2 = {} } = await chrome.storage.local.get('pcareStatus'); delete s2.masukGagal; delete s2.percobaanMasuk; await chrome.storage.local.set({ pcareStatus: s2 }); statusAkun(); pesan('Masuk otomatis dijalankan lagi pada percobaan berikutnya.', 'ok'); };
      return;
    }
    e.className = 'pc-status ok'; e.innerHTML = ikon('ok') + `<span>ID <b>${lolos(a.user)}</b> tersimpan${st.keluarSengaja ? ' · dijeda karena Anda keluar sendiri' : ''}.</span>`;
  }
  async function simpan() {
    const idle = Math.min(120, Math.max(1, parseInt($('pcIdle').value, 10) || BAWAAN.idleMenit));
    const lama = await ambil();
    await chrome.storage.local.set({ pcareSetelan: Object.assign(lama, {
      aktif: $('pcAktif').checked, otoMasuk: $('pcOtoMasuk').checked, jagaSesi: $('pcJagaSesi').checked, tutupPeringatan: $('pcTutup').checked,
      jamDari: $('pcJamDari').value || BAWAAN.jamDari, jamSampai: $('pcJamSampai').value || BAWAAN.jamSampai, idleMenit: idle,
      kecuali: $('pcKecuali').value.split('\n').map(x => x.trim()).filter(Boolean),
    }) });
    chrome.runtime.sendMessage({ aksi: 'simpanSetelanAkun' }, r => tandaTersimpan(r && r.ok));
  }
  ['pcAktif', 'pcOtoMasuk', 'pcJagaSesi', 'pcTutup'].forEach(id => $(id).addEventListener('change', () => { teksSakelar($('tab-pcare')); simpan(); }));
  ['pcJamDari', 'pcJamSampai', 'pcIdle'].forEach(id => $(id).addEventListener('change', simpan));
  let t = null; $('pcKecuali').addEventListener('input', () => { clearTimeout(t); t = setTimeout(simpan, 700); });
  $('pcKecualiBawaan').onclick = () => { $('pcKecuali').value = BAWAAN.kecuali.join('\n'); simpan(); pesan('Daftar pengecualian dikembalikan ke bawaan.', 'ok'); };
  $('pcLihat').onclick = () => { const on = $('pcSandi').type === 'password'; $('pcSandi').type = on ? 'text' : 'password'; $('pcLihat').textContent = on ? 'Sembunyi' : 'Lihat'; $('pcLihat').setAttribute('aria-pressed', on); };
  $('pcSimpanAkun').onclick = async () => {
    const user = $('pcUser').value.trim(), sandi = $('pcSandi').value;
    if (!user || !sandi) return pesan('Isi ID dan sandi dulu.', 'galat');
    const { pcareStatus: st = {} } = await chrome.storage.local.get('pcareStatus'); delete st.masukGagal; delete st.percobaanMasuk;
    await chrome.storage.local.set({ pcareAkun: { user, sandi }, pcareStatus: st });
    statusAkun(); pesan('ID & sandi PCare tersimpan di komputer ini.', 'ok');
  };
  $('pcHapusAkun').onclick = async () => {
    if (!confirm('Hapus ID & sandi PCare dari komputer ini? Masuk otomatis berhenti sampai disimpan lagi.')) return;
    await chrome.storage.local.remove(['pcareAkun', 'pcareStatus']); $('pcUser').value = ''; $('pcSandi').value = '';
    statusAkun(); pesan('ID & sandi PCare dihapus.', 'ok');
  };
  chrome.storage.onChanged.addListener((c, a) => { if (a === 'local' && (c.pcareStatus || c.pcareAkun)) statusAkun(); });
  muat();
})();
