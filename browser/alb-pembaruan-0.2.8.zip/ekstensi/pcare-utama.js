/* CCare Dokter · PCare — dunia halaman (MAIN), document_start.
 * Meredam alert() bawaan browser yang hanya pemberitahuan, KECUALI yang memuat kata pengecualian (gagal, tidak aktif, …).
 * confirm() dan prompt() TIDAK pernah disentuh. Setelan dibaca dari localStorage (ditulis pcare-halaman.js, tanpa ID/sandi). */
(() => {
  const asli = window.alert;
  window.alert = function (pesan) {
    let s = null; try { s = JSON.parse(localStorage.getItem('pcbSetelan') || 'null'); } catch (e) {}
    const teks = String(pesan == null ? '' : pesan), t = teks.toLowerCase();
    if (!s || !s.tutup || /\/eclaim\/Login/i.test(location.pathname) || (s.kecuali || []).some(k => k && t.includes(String(k).toLowerCase()))) return asli.apply(this, arguments);
    window.postMessage({ pcbLog: 'Ditutup (alert): ' + teks.replace(/\s+/g, ' ').slice(0, 120) }, location.origin);
  };
})();
