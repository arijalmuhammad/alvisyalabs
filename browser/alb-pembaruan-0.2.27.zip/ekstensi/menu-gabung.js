/* Alvisya Dokter v4.7.2 — menu samping mengikuti "Atur gabungan": poli segrup dikumpulkan berdekatan dan diberi latar aksen
 * tipis + garis kiri; antar kelompok dipisah garis. MCU (bukan menu sendiri) ditandai "+ MCU" pada grupnya.
 * Tanpa grup → urutan asli C-CARE. Hanya tampilan; tautan tidak diubah. */
(() => {
  if (window.__sjcMenuGabung) return; window.__sjcMenuGabung = true;
  const idDari = h => { const m = h.match(/^\/Poli\/Index\/(\d+)\/?$/i); return m ? m[1] : /^\/Kia\/?$/i.test(h) ? 'kia' : null; };
  const st = document.createElement('style');
  st.textContent = `.sjc-mg>a,a.sjc-mg{background:#E8ECF7!important;color:#1D2F73!important;box-shadow:inset 3px 0 0 #263C92}
    .sjc-mg>a i,a.sjc-mg i{color:#263C92!important}
    .sjc-mg-t{margin-left:8px;padding:0 6px;border-radius:8px;border:1px solid #263C92;font:600 11px/16px "Source Sans 3","Source Sans Pro",system-ui,sans-serif;color:#263C92;background:#fff;white-space:nowrap}
    .sjc-sb>a,a.sjc-sb{opacity:.45}
    .sjc-pisah{list-style:none;height:0;margin:4px 12px;border-top:1px solid #D5E0E0;padding:0!important;pointer-events:none}`;
  document.head.appendChild(st);
  function butir() {   // [{el, id}] urutan asli; el = <li> pembungkus bila ada
    const L = [];
    document.querySelectorAll('a[href]').forEach(a => {
      if (a.closest('table') || a.closest('.sjc-atur-isi')) return;
      let h; try { h = new URL(a.getAttribute('href'), location.origin).pathname; } catch (e) { return; }
      const id = idDari(h); if (!id) return;
      const el = a.parentElement && a.parentElement.tagName === 'LI' ? a.parentElement : a;
      if (el.dataset.sjcUrut === undefined) el.dataset.sjcUrut = [...el.parentElement.children].indexOf(el);
      L.push({ el, a, id });
    });
    return L.filter(x => x.el.parentElement === (L[0] && L[0].el.parentElement)).sort((p, q) => p.el.dataset.sjcUrut - q.el.dataset.sjcUrut);
  }
  function tandai(grup) {
    const L = butir(); if (!L.length) return;
    const induk = L[0].el.parentElement;
    induk.querySelectorAll(':scope>.sjc-pisah').forEach(x => x.remove());
    L.forEach(x => { x.el.classList.remove('sjc-mg', 'sjc-sb'); x.a.classList.remove('sjc-mg', 'sjc-sb'); if (grup[x.id] === 'X') { (x.el.tagName === 'LI' ? x.el : x.a).classList.add('sjc-sb'); x.a.title = 'Disembunyikan dari gabungan dan pemantau'; } else if (x.a.title.startsWith('Disembunyikan')) x.a.removeAttribute('title'); const t = x.a.querySelector('.sjc-mg-t'); if (t) t.remove(); });
    const ukuran = g => g === 'X' ? 0 : L.filter(x => grup[x.id] === g).length + (grup['4mcu'] === g && grup['4'] !== g ? 1 : 0);   // MCU bukan menu, ditandai "+ MCU"
    const blok = [], peta = {};                                         // kelompok menurut urutan kemunculan pertama
    L.forEach(x => { const g = grup[x.id] && ukuran(grup[x.id]) > 1 ? grup[x.id] : null; if (g && peta[g]) peta[g].push(x); else { const b = [x]; blok.push(b); if (g) peta[g] = b; } });
    const ada = blok.some(b => b.length > 1 || (grup[b[0].id] && ukuran(grup[b[0].id]) > 1));
    const pertama = L.reduce((m, x) => [...induk.children].indexOf(x.el) < [...induk.children].indexOf(m.el) ? x : m, L[0]).el;
    let akhir = document.createComment('sjc'); induk.insertBefore(akhir, pertama);
    blok.forEach((b, i) => {
      if (i && ada) { const s = document.createElement(pertama.tagName === 'LI' ? 'li' : 'div'); s.className = 'sjc-pisah'; s.setAttribute('aria-hidden', 'true'); akhir.after(s); akhir = s; }
      const g = grup[b[0].id], segrup = ada && g && ukuran(g) > 1;
      b.forEach(x => { akhir.after(x.el); akhir = x.el; if (segrup) (x.el.tagName === 'LI' ? x.el : x.a).classList.add('sjc-mg'); });
      if (segrup && grup['4mcu'] === g && grup['4'] !== g) { const t = document.createElement('span'); t.className = 'sjc-mg-t'; t.textContent = '+ MCU'; b[0].a.appendChild(t); }
    });
    [...induk.childNodes].forEach(n => { if (n.nodeType === 8 && n.data === 'sjc') n.remove(); });
  }
  const baca = () => chrome.storage.local.get(['grupPoli', 'isiCepat'], s => tandai((s.isiCepat || {}).mati ? {} : (s.grupPoli || {})));
  baca();
  chrome.storage.onChanged.addListener((c, a) => { if (a === 'local' && (c.grupPoli || c.isiCepat)) baca(); });
})();
