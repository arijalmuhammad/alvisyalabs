/* Pengaturan → Akun & Sheet → QR untuk HP (v4.10.7): menyambungkan CCare Plus di HP tanpa mengetik alamat & kunci.
 * Isi QR sama dengan "Sambungkan HP atau tablet" di CCare Plus: alvisya.my.id/ccareplus/#SJC1:<{u,k,n} base64url>.
 * Kunci hanya di bagian # (tidak terkirim ke server alvisya.my.id). QR baru tampil setelah tombol ditekan. */
(() => {
  const $ = id => document.getElementById(id); if (!$('qrHp')) return;
  const POLA_URL = /^https:\/\/script\.google\.com\/macros\/s\/[\w-]+\/exec$/;
  const tutup = () => { $('qrHpKotak').hidden = true; $('qrHpGambar').innerHTML = ''; $('qrHp').setAttribute('aria-expanded', 'false'); $('qrHp').textContent = 'Tampilkan QR untuk HP (CCare Plus)'; };
  $('qrHp').addEventListener('click', () => {
    if (!$('qrHpKotak').hidden) { tutup(); return; }
    const u = $('url').value.trim(), k = $('kunci').value.trim(), n = $('nama').value.trim();
    if (!POLA_URL.test(u) || !k) { tulisPesan($('pesanUji'), 'Isi Alamat Web App dan Kunci dulu, lalu tekan Uji koneksi.', 'galat'); $(POLA_URL.test(u) ? 'kunci' : 'url').focus(); return; }
    const b64 = btoa(unescape(encodeURIComponent(JSON.stringify({ u, k, n })))).replace(/\+/g, '-').replace(/\//g, '_');
    const q = qrcode(0, 'M'); q.addData('https://alvisya.my.id/ccareplus/#SJC1:' + b64); q.make();
    $('qrHpGambar').innerHTML = q.createImgTag(4, 8, '');
    const img = $('qrHpGambar').querySelector('img'); img.alt = ''; img.style.cssText = 'width:100%;height:100%;image-rendering:pixelated';
    $('qrHpKotak').hidden = false; $('qrHp').setAttribute('aria-expanded', 'true'); $('qrHp').textContent = 'Sembunyikan QR';
  });
  ['url', 'kunci', 'nama'].forEach(id => $(id).addEventListener('input', () => { if (!$('qrHpKotak').hidden) tutup(); }));   // isian berubah → QR lama tidak dipakai
})();
