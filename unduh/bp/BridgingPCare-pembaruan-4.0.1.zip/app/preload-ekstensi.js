// Preload halaman milik bot (latar = background.js, pengaturan.html). contextIsolation mati: halaman lokal tepercaya.
"use strict";
const { ipcRenderer } = require("electron");
const arg = (n) => { const a = process.argv.find((x) => x.startsWith(`--${n}=`)); return a ? a.slice(n.length + 3) : ""; };
window.chrome = require("./shim.js")(ipcRenderer, { dirEks: arg("br-eks"), peran: arg("br-peran") });
