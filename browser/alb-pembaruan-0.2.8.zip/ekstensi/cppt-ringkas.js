/* CPPT C-CARE lebih ringkas (hanya tampilan, bisa dimatikan: Pengaturan → Tampilan → CPPT ringkas):
 * - kolom label ISIAN DOKTER / ISIAN PERAWAT dari 30% menjadi 200 px → kotak isian lebih lebar
 * - kotak teks menyesuaikan tinggi isinya (tidak perlu menggulir di dalam kotak)
 * - Upload Resep, Foto EKG, Dokumen Penunjang disembunyikan (tidak dihapus; nilai kosong tetap terkirim seperti biasa) */
(() => {
  if (!document.getElementById('Pemeriksaan_tab') && !document.querySelector('.tab-pane')) return;
  const gaya = document.createElement('style');
  gaya.textContent = `
  @media (min-width:768px){.tab-pane table.table-bordered td.text-bold[width="30%"]{width:200px!important}}
  .sjc-cr-sembunyi{display:none!important}
  textarea.sjc-cr-tumbuh{overflow-y:hidden!important;resize:vertical}`;
  const sembunyi = () => {
    const el = [];
    document.querySelectorAll('[id=FileEkg], [id=FileDokumenPenunjang]').forEach(i => { const tr = i.closest('tr'); if (tr) el.push(tr); });
    const up = document.getElementById('GrupUploadResep'); const w = up && (up.closest('.table-responsive') || up.closest('table')); if (w) el.push(w);
    return el;
  };
  const kotak = () => [...document.querySelectorAll('.tab-pane table.table-bordered textarea')].filter(t => !t.readOnly || t.closest('#Pemeriksaan_tab'));
  const tumbuh = t => { if (!t.classList.contains('sjc-cr-tumbuh') || !t.offsetParent) return; t.style.height = 'auto'; t.style.height = Math.max(44, t.scrollHeight + 2) + 'px'; };
  let aktif = false;
  function terapkan(on) {
    aktif = on;
    if (on) {
      if (!gaya.isConnected) document.head.appendChild(gaya);
      sembunyi().forEach(e => e.classList.add('sjc-cr-sembunyi'));
      kotak().forEach(t => { if (!t.classList.contains('sjc-cr-tumbuh')) { t.dataset.sjcRows = t.getAttribute('rows') || ''; t.rows = 1; } t.classList.add('sjc-cr-tumbuh'); tumbuh(t); });
    } else {
      gaya.remove();
      document.querySelectorAll('.sjc-cr-sembunyi').forEach(e => e.classList.remove('sjc-cr-sembunyi'));
      document.querySelectorAll('textarea.sjc-cr-tumbuh').forEach(t => { t.classList.remove('sjc-cr-tumbuh'); t.style.height = ''; if (t.dataset.sjcRows) t.setAttribute('rows', t.dataset.sjcRows); else t.removeAttribute('rows'); });
    }
  }
  window.addEventListener('resize', () => { if (aktif) document.querySelectorAll('textarea.sjc-cr-tumbuh').forEach(tumbuh); });
  document.addEventListener('input', e => { if (aktif && e.target.tagName === 'TEXTAREA') tumbuh(e.target); }, true);
  // isi dari Auto Fill / ganti tab: ukur ulang (kotak di tab tersembunyi tingginya 0 sampai tabnya dibuka)
  setInterval(() => { if (aktif) document.querySelectorAll('textarea.sjc-cr-tumbuh').forEach(t => { const h = t.style.height; tumbuh(t); if (t.style.height !== h) {} }); }, 800);
  const aktifDari = ic => !(ic || {}).mati && !(ic || {}).cpptBiasa;
  chrome.storage.local.get('isiCepat', s => terapkan(aktifDari(s.isiCepat)));
  chrome.storage.onChanged.addListener((u, a) => { if (a === 'local' && u.isiCepat) terapkan(aktifDari(u.isiCepat.newValue)); });
})();
