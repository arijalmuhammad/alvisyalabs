/* Auto Fill formulir dari CPPT: Persetujuan Tindakan Kedokteran, Pemberian Informasi/Edukasi, Surgical Safety Checklist.
 * Hanya mengisi yang masih kosong (kotak centang hanya dicentang, tidak pernah dilepas), tidak menekan Simpan,
 * tidak mengirim data ke mana pun. Data pasien dibaca dari halaman ini dan ringkasan kunjungan C-CARE (hanya baca).
 * Bisa dimatikan per formulir: Pengaturan → Auto Fill → Formulir. */
(() => {
  const m = location.pathname.match(/\/Formulir\/(TindakanKedokteran|PemberianInformasiEdukasi|SurgicalSafetyChecklist)\/(\d+)/i);
  if (!m || !document.querySelector('form')) return;
  const JENIS = { tindakankedokteran: 'fTK', pemberianinformasiedukasi: 'fEdu', surgicalsafetychecklist: 'fSSC' }[m[1].toLowerCase()], ID = m[2];
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const bersih = s => String(s == null ? '' : s).replace(/ /g, ' ').replace(/\s+/g, ' ').trim();
  const kosong = v => !bersih(v) || /^[-–—.\s]*$/.test(String(v));
  const norm = s => String(s || '').toLowerCase().replace(/[^a-z]/g, '');
  const wib = (n = 0) => new Date(Date.now() + 7 * 36e5 + n * 864e5);
  function setNilai(el, v) {
    const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : el.tagName === 'SELECT' ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto, 'value').set.call(el, v);
    el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true }));
  }
  const nama = n => document.getElementsByName(n)[0];
  const diisi = [];
  const isi = (n, v, label) => { const el = typeof n === 'string' ? nama(n) : n; if (!el || v == null || v === '' || el.disabled || el.readOnly) return; if (!kosong(el.value)) return; setNilai(el, String(v)); diisi.push(label || n); };
  const pilih = (n, cocok, label) => {               // select: hanya bila belum dipilih
    const el = nama(n); if (!el || (el.value && el.selectedIndex > 0)) return;
    const o = [...el.options].find(cocok); if (!o) return; setNilai(el, o.value); diisi.push(label || n);
  };
  const centang = (el, label) => { if (!el || el.checked || el.disabled) return false; el.checked = true; el.dispatchEvent(new Event('click', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true })); if (label) diisi.push(label); return true; };
  const radio = (n, nilai, label) => { const rs = $$(`input[type=radio][name="${CSS.escape(n)}"]`); if (!rs.length || rs.some(r => r.checked)) return; centang(rs.find(r => r.value === nilai), label); };

  /* identitas pasien di kepala halaman: label | : | nilai */
  function identitas(label) {
    const el = $$('p,td,th,div,span,b,strong,label').find(x => !x.children.length && bersih(x.textContent).toLowerCase() === label.toLowerCase());
    if (!el) return '';
    const tr = el.closest('tr'); if (tr) { const c = [...tr.cells].reverse().find(c => !c.contains(el) && bersih(c.textContent) && bersih(c.textContent) !== ':'); return c ? bersih(c.textContent) : ''; }
    let k = el.closest('[class*="col-"]') || el.parentElement;
    for (let s = k.nextElementSibling; s; s = s.nextElementSibling) { const t = bersih(s.textContent); if (t && t !== ':') return t.replace(/^:\s*/, ''); }
    return '';
  }
  /* akun yang sedang dipakai: nama dari Pengaturan (Nama dokter) atau panel samping C-CARE; jabatan dari panel samping */
  function akun(namaSetelan) {
    const panel = bersih((document.querySelector('.user-panel .info, .user-panel') || {}).textContent || '');
    const n = namaSetelan || panel.split(' - ')[0];
    const jab = (panel.match(/\b(Dokter Gigi|Dokter|Perawat|Bidan|Apoteker|Ahli Gizi|Nutrisionis|Analis|Fisioterapis)\b/i) || [])[1] || '';
    return { nama: bersih(n), jabatan: jab };
  }
  const cocokAkun = a => o => { const t = norm(o.text), n = norm(a.nama); return n.length > 3 && (t === n || t.startsWith(n) || t.includes(n)); };
  /* dari kunjungan (hanya baca): ICD-10 "KODE / nama" dari CPPT, TTV perawat dari ringkasan kunjungan */
  async function diagnosa() {
    try {
      const d = new DOMParser().parseFromString(await (await fetch('/Poli/Ubah/' + ID, { credentials: 'include' })).text(), 'text/html');
      const t = $$('#KodePenyakit option', d).filter(o => o.selected || o.hasAttribute('selected')).map(o => bersih(o.textContent)).filter(Boolean);
      if (t.length) return t.join('; ');
    } catch (e) {}
    try {
      const d = new DOMParser().parseFromString(await (await fetch('/RekapRekamMedis/Detail/' + ID, { credentials: 'include' })).text(), 'text/html');
      const tr = $$('tr', d).find(r => r.cells.length >= 2 && /^diagnosa$/i.test(bersih(r.cells[0].textContent)));
      return tr ? bersih([...tr.cells].slice(1).map(c => c.textContent).join(' ')).replace(/^:\s*/, '') : '';
    } catch (e) { return ''; }
  }
  async function ttv() {
    try {
      const d = new DOMParser().parseFromString(await (await fetch('/RekapRekamMedis/Detail/' + ID, { credentials: 'include' })).text(), 'text/html'), o = {};
      $$('tr', d).forEach(r => {
        if (r.cells.length < 2) return; const l = bersih(r.cells[0].textContent).toLowerCase(), v = (bersih([...r.cells].slice(1).map(c => c.textContent).join(' ')).match(/\d+(?:[.,]\d+)?/) || [])[0];
        if (!v) return;
        if (/^sistol/.test(l)) o.sis = v; else if (/^diastol/.test(l)) o.dia = v; else if (/^nadi/.test(l)) o.nadi = v; else if (/^respirasi|^pernap|^pernaf|^rr\b/.test(l)) o.rr = v; else if (/^skala nyeri/.test(l)) o.nyeri = v;
      });
      return o;
    } catch (e) { return {}; }
  }

  async function jalankan(ATUR, namaSetelan) {
    const N = nilaiAutofill(ATUR).formulir, a = akun(namaSetelan);
    if (JENIS === 'fTK') {
      pilih('PetugasPemberiInformasiId', cocokAkun(a), 'Pemberi informasi');
      pilih('PetugasDokterPerawatId', cocokAkun(a), 'Dokter yang memberi informasi');
      const dg = await diagnosa();
      isi('ListJenisInformasi[0].IsiInformasi', dg, 'Diagnosa');
      isi('ListJenisInformasi[1].IsiInformasi', N.tkTindakan, 'Tindakan');
      isi('ListJenisInformasi[2].IsiInformasi', N.tkAlternatif, 'Alternatif');
      isi('ListJenisInformasi[3].IsiInformasi', N.tkRisiko, 'Risiko');
      isi('ListJenisInformasi[4].IsiInformasi', N.tkPrognosis, 'Prognosis');
      isi('ListJenisInformasi[5].IsiInformasi', N.tkBiaya, 'Biaya');
      isi('ListJenisInformasi[6].IsiInformasi', N.tkLain, 'Lain-lain');
      isi('NamaPasienAtauKeluarga', identitas('Nama Pasien'), 'Nama');
      isi('Umur', (identitas('Umur').match(/\d+/) || [])[0], 'Umur');
      const jk = identitas('Jenis Kelamin'); radio('JenisKelaminId', /perempuan|wanita/i.test(jk) ? '2' : /laki/i.test(jk) ? '1' : '', 'Jenis kelamin');
      isi('Alamat', identitas('Alamat'), 'Alamat');
      pilih('IsSetujuTindakan', o => o.value === 'True', 'Setuju');
      isi('Tindakan', N.tkTindakan, 'Tindakan disetujui');
      pilih('TindakanTerhadapId', o => o.value === '1', 'Terhadap: Saya');
    } else if (JENIS === 'fEdu') {
      isi('Profesi', N.eduProfesi || a.jabatan || 'Dokter', 'Profesi');
      let n = 0; $$('input[type=checkbox]').filter(c => /^ListIsi\[\d+\]\.Isian$/.test(c.name)).forEach(c => { if (centang(c)) n++; });
      if (n) diisi.push(n + ' butir edukasi');
      const k = +N.eduKontrol || 0; if (k) isi($$('input[type=date]').find(i => /^ListIsi\[\d+\]\.CatatanTambahan$/.test(i.name)), wib(k).toISOString().slice(0, 10), 'Tanggal kontrol');
    } else if (JENIS === 'fSSC') {
      isi('TanggalTindakan', wib().toISOString().slice(0, 10), 'Tanggal tindakan');
      isi('Diagnosa', await diagnosa(), 'Diagnosa');
      isi('RencanaAsuhan', N.sscRencana, 'Rencana asuhan');
      const g = String(N.sscGcs || '').match(/\d+/g);
      if (g && g.length === 3) { isi('ListIsi[0].Isi', g.reduce((x, y) => x + +y, 0), 'GCS'); isi('ListIsi[1].Isi', g[0]); isi('ListIsi[2].Isi', g[1]); isi('ListIsi[3].Isi', g[2]); }
      const t = await ttv();                                            // TTV perawat → kolom SEBELUM tindakan saja
      if (t.sis && t.dia) isi('ListIsi[4].Isi', t.sis + '/' + t.dia, 'TD'); isi('ListIsi[5].Isi', t.nadi, 'Nadi'); isi('ListIsi[6].Isi', t.rr, 'RR'); isi('ListIsi[7].Isi', t.nyeri, 'Skala nyeri');
      isi('ListIsi[9].Isi', wib().toISOString().slice(11, 16), 'Time in');
      let n = 0; $$('form input[type=checkbox]').forEach(c => { if (centang(c)) n++; }); if (n) diisi.push(n + ' butir dicentang');
      [...new Set($$('form input[type=radio]').filter(r => r.value === 'Stabil').map(r => r.name))].forEach(nm => radio(nm, 'Stabil'));
    }
    pesan(diisi.length ? `Auto Fill: ${diisi.length} isian terisi. Periksa sebelum Simpan.` : 'Auto Fill: tidak ada yang perlu diisi.');
  }
  function pesan(t) {
    const h = document.createElement('div'); h.id = 'sjc-formulir';
    h.setAttribute('role', 'status');
    h.style.cssText = 'position:fixed;right:16px;bottom:16px;z-index:9999;max-width:360px;background:#0F2742;color:#fff;border-radius:12px;padding:10px 12px 10px 14px;font:14px/1.4 system-ui,sans-serif;box-shadow:0 8px 24px rgba(15,39,66,.25);display:flex;gap:10px;align-items:flex-start';
    h.innerHTML = '<span style="flex:1"></span><button type="button" aria-label="Tutup" style="background:none;border:0;color:#fff;font-size:18px;line-height:1;cursor:pointer;padding:0 2px">×</button>';
    h.querySelector('span').textContent = t; h.querySelector('button').onclick = () => h.remove();
    document.body.appendChild(h); setTimeout(() => h.remove(), 12000);
  }
  chrome.storage.local.get(['isiCepat', 'nama'], s => {
    const ic = s.isiCepat || {};
    if (ic.mati || ic.autoSalin === false || (ic.poliMati || {})[JENIS]) return;
    jalankan(ic, s.nama).catch(() => {});
  });
})();
