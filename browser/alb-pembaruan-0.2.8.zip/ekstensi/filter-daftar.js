/* Filter daftar poli C-CARE tetap pilihan dokter.
 * C-CARE menyimpan filter terakhir (Tanggal + Status Pemeriksaan) di sesi server, dipakai bersama semua tab — termasuk
 * pembacaan latar Siap dipanggil. Pembacaan latar selalu mengembalikan filter itu, tetapi bila halaman daftar kebetulan
 * dimuat (mis. setelah Simpan CPPT) tepat saat pembacaan berjalan, filternya bisa ikut berubah.
 * Di sini: pilihan dokter dicatat saat menekan Tampilkan; daftar yang terbuka dengan filter lain dimuat ulang sekali
 * dengan pilihan dokter (bawaan: hari ini + "Pilih Status Kunjungan"). Hanya filter daftar — tidak menyimpan apa pun ke C-CARE. */
(() => {
  const sel = document.querySelector('select[name=StatusKunjunganId]'), tgl = document.querySelector('input[name=Tanggal]');
  const form = sel && sel.form; if (!form || !tgl) return;
  const hariIni = () => new Date(Date.now() + 7 * 36e5).toISOString().slice(0, 10);
  const KIRIM = 'sjcFilterKirim';
  form.addEventListener('submit', () => {                               // pilihan dokter (Tampilkan / Muat ulang daftar)
    const h = hariIni();
    chrome.storage.local.set({ filterDaftar: { st: sel.value, tgl: tgl.value === h ? null : tgl.value, hari: h } });
    try { sessionStorage.setItem(KIRIM, String(Date.now())); } catch (e) {}
  }, true);
  let dariKirim = false;
  try { const w = +sessionStorage.getItem(KIRIM) || 0; sessionStorage.removeItem(KIRIM); dariKirim = Date.now() - w < 60000; } catch (e) {}
  if (dariKirim) return;                                                // halaman ini hasil Tampilkan → memang pilihan dokter
  chrome.storage.local.get(['filterDaftar', 'isiCepat'], ({ filterDaftar: f, isiCepat: ic }) => {
    if (ic && ic.mati) return;                                          // Auto Fill Mati → pemantau tidak membaca, filter tidak perlu dijaga
    const h = hariIni(), p = f && f.hari === h ? f : { st: '', tgl: null };
    const mauSt = p.st || '', mauTgl = p.tgl || h;
    if (sel.value === mauSt && tgl.value === mauTgl) return;
    if (![...sel.options].some(o => o.value === mauSt)) return;
    try {                                                               // pengaman: maks. 3 koreksi beruntun dalam 20 detik
      const k = JSON.parse(sessionStorage.getItem('sjcFilterKoreksi') || '[]').filter(t => Date.now() - t < 20000);
      if (k.length >= 3) return; k.push(Date.now()); sessionStorage.setItem('sjcFilterKoreksi', JSON.stringify(k));
    } catch (e) {}
    sel.value = mauSt; tgl.value = mauTgl;
    try { sessionStorage.setItem(KIRIM, String(Date.now())); } catch (e) {}
    if (form.requestSubmit) form.requestSubmit(); else form.submit();
  });
})();
