/* Scan Jasa C-CARE — latar: pekerjaan scan (dipakai balon popup & scan otomatis), Tunda / Lanjut / Stop.
 * Status pekerjaan disimpan di chrome.storage.local 'job' agar balon bisa ditutup-buka dan pekerjaan
 * yang ditunda tetap bisa dilanjutkan walau service worker sempat dimatikan Chrome.
 */
importScripts('scan-core.js', 'isi-cepat-bawaan.js', 'pantau.js');

/* PCare: tawaran "Simpan ID & sandi?" dititipkan di storage.session (memori saja, hilang saat browser ditutup) —
 * content script di halaman PCare perlu izin membacanya. */
const pcareBukaSesi = () => { try { chrome.storage.session.setAccessLevel({ accessLevel: 'TRUSTED_AND_UNTRUSTED_CONTEXTS' }).catch(() => {}); } catch (e) {} };
pcareBukaSesi();
chrome.runtime.onStartup.addListener(pcareBukaSesi);
chrome.runtime.onInstalled.addListener(pcareBukaSesi);
self.addEventListener('error', e => tulisLog('galat', 'sistem', e.message, e.error && e.error.stack));
self.addEventListener('unhandledrejection', e => tulisLog('galat', 'sistem', (e.reason && e.reason.message) || String(e.reason), e.reason && e.reason.stack));

const SUSUL_MAKS = 7;
const hariIni = () => new Date(Date.now() + 7 * 36e5).toISOString().slice(0, 10);          // WIB
const geser = (t, n) => { const d = new Date(t + 'T00:00:00Z'); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };
const jamWib = () => new Date(Date.now() + 7 * 36e5).getUTCHours();
const waktuWib = () => new Date(Date.now() + 7 * 36e5).toISOString().slice(0, 16).replace('T', ' ');

/* ---------------- status pekerjaan ---------------- */
let job = null;                 // salinan di memori
const ctl = { tunda: false, stop: false, jalan: false };
let simpanTerakhir = 0, simpanTertunda = null;
async function muatJob() { if (!job) job = (await chrome.storage.local.get('job')).job || null; return job; }
function simpanJob(segera) {
  const tulis = () => { simpanTerakhir = Date.now(); clearTimeout(simpanTertunda); simpanTertunda = null; return chrome.storage.local.set({ job }); };
  if (segera || Date.now() - simpanTerakhir > 400) return tulis();
  if (!simpanTertunda) simpanTertunda = setTimeout(tulis, 400);
}
function ringkas(milik) { const s = susunPasien(milik || []); return { jumlah: jumlahPerTanggal(s.pasien), pasien: s.pasien, catatan: s.catatan, ganda: s.ganda }; }

async function mulaiJob(daftar, opsi = {}) {
  if (await scanMati()) return { ok: false, pesan: PESAN_SCAN_MATI };
  await muatJob();
  if (ctl.jalan || (job && job.status === 'jalan')) return { ok: false, pesan: 'Scan lain sedang berjalan.' };
  if (!daftar.length) return { ok: false, pesan: 'Pilih tanggal dulu.' };
  const { nama } = await chrome.storage.local.get('nama');
  if (!nama) return { ok: false, pesan: 'Isi Nama dokter di Pengaturan dulu.' };
  job = { id: Date.now(), status: 'jalan', otomatis: !!opsi.otomatis, dariHp: opsi.dariHp || null, nama, daftar, idx: 0, milik: [], tanpaDokter: 0, dibaca: 0,
    pesan: 'Menyiapkan…', hasil: null, kirim: null, sementara: [], mulai: waktuWib() };
  ctl.tunda = false; ctl.stop = false;
  await simpanJob(true);
  tulisLog('info', job.otomatis ? 'otomatis' : 'scan', `Mulai scan ${daftar.length} tanggal: ${daftar[0]} s.d. ${daftar[daftar.length - 1]}`);
  jalankanJob();
  return { ok: true };
}

async function jalankanJob() {
  if (ctl.jalan) return; ctl.jalan = true;
  try {
    await muatJob();
    if (!job || job.status !== 'jalan') return;
    const tab = await tabCcare(true, job.tabId);
    if (!tab) return await selesaiGalat('Tab C-CARE tidak bisa dibuka.');
    job.tabDibuat = job.tabDibuat || tab.dibuat; job.tabId = tab.id;
    const kc = kunciCache(job.nama);
    const cache = (await chrome.storage.local.get(kc))[kc] || {};
    while (job.idx < job.daftar.length) {
      if (ctl.stop) break;
      if (ctl.tunda) { job.status = 'tunda'; job.pesan = 'Ditunda. Tekan Lanjut untuk meneruskan.'; await simpanJob(true); return; }
      const tgl = job.daftar[job.idx];
      const label = `${tgl.split('-').reverse().join('/')} (${job.idx + 1}/${job.daftar.length})`;
      const r = await prosesTanggal(tab, tgl, job.nama, cache, (t, f) => { job.pesan = `${label}: ${t}`; if (f != null) job.sub = f; simpanJob(); }, () => ctl.tunda || ctl.stop);
      if (r.login) {                                           // sesi habis: jangan buang kemajuan — tunda, login ulang, Lanjut
        job.status = 'tunda'; job.pesan = 'Sesi C-CARE habis. Login ulang di tab C-CARE, lalu tekan Lanjut.'; await simpanJob(true);
        tulisLog('awas', job.otomatis ? 'otomatis' : 'scan', `Sesi C-CARE habis di tanggal ${tgl} (${job.idx + 1}/${job.daftar.length}) — scan ditunda, ${job.idx} tanggal selesai tetap tersimpan`);
        bunyi('perhatian');
        if (job.dariHp) laporHp(job.dariHp, 'gagal', 'C-CARE perlu login ulang di komputer, lalu tekan Lanjut di ekstensi.');
        chrome.notifications.create({ type: 'basic', iconUrl: 'ikon.png', title: 'Scan Jasa C-CARE ditunda', message: 'Sesi C-CARE habis. Login ulang, lalu buka balon dan tekan Lanjut.' });
        return;
      }
      if (r.batal) continue;                                   // tanggal ini diulang saat Lanjut
      job.milik.push(...r.milik); job.tanpaDokter += r.tanpaDokter; job.dibaca += r.dibaca; job.idx++; job.sub = 0;
      job.sementara = ringkas(job.milik).jumlah;
      await tandaiTanggal([tgl], 'scan', job.sementara);
      await chrome.storage.local.set({ [kc]: pangkas(cache) });
      await simpanJob(true);
    }
    const h = ringkas(job.milik);
    const berhenti = job.idx < job.daftar.length;
    job.hasil = { pasien: h.pasien, jumlah: h.jumlah, catatan: h.catatan, ganda: h.ganda, tanggal: job.daftar.slice(0, job.idx) };
    job.milik = [];                                             // nama pasien hanya disimpan di hasil sampai terkirim
    await simpanBelumKirim(job.hasil);                           // tetap bisa dikirim walau balon sudah "Scan baru"
    job.status = berhenti ? 'henti' : 'selesai';
    tulisLog(berhenti ? 'awas' : 'info', job.otomatis ? 'otomatis' : 'scan', `${berhenti ? 'Dihentikan' : 'Selesai'}: ${job.idx}/${job.daftar.length} tanggal, ${h.pasien.length} pasien, ${h.ganda} ganda, ${job.tanpaDokter} tanpa dokter, ${job.dibaca} kunjungan dibaca`);
    job.pesan = (berhenti ? `Dihentikan: ${job.idx} dari ${job.daftar.length} tanggal diperiksa. ` : `Selesai: ${job.idx} tanggal diperiksa. `) +
      `${h.pasien.length} pasien atas nama Anda` + (h.ganda ? `, ${h.ganda} ganda dihitung satu` : '') + '.' +
      (job.tanpaDokter ? ` ${job.tanpaDokter} kunjungan tanpa nama dokter dilewati.` : '') +
      (job.dibaca && !h.pasien.length ? ' Tidak ada yang cocok — periksa ejaan Nama dokter.' : '');
    // untuk balon: kalimat utama + catatan terpisah (catatan bukan kabar buruk)
    job.pesanUtama = (berhenti ? `Dihentikan: ${job.idx} dari ${job.daftar.length} tanggal diperiksa, ` : `Selesai: ${job.idx} tanggal diperiksa, `) +
      `${h.pasien.length} pasien atas nama Anda.` + (job.dibaca && !h.pasien.length ? ' Tidak ada yang cocok — periksa ejaan Nama dokter.' : '');
    job.catatanHasil = [
      ...(h.ganda ? [['info', `${h.ganda} pasien ganda dihitung satu`]] : []),
      ...(job.tanpaDokter ? [['info', `${job.tanpaDokter} kunjungan tanpa nama dokter tidak dihitung`]] : []),
      ...Object.entries(h.catatan || {}).map(([t, c]) => ['info', `${t.slice(8)}/${t.slice(5, 7)}: ${c}`]),
    ];
    await simpanJob(true);
    bunyi(berhenti ? null : (h.pasien.length ? 'selesai' : 'perhatian'));
    if (!job.otomatis && !berhenti) chrome.notifications.create({ type: 'basic', iconUrl: 'ikon.png', title: 'Scan Jasa C-CARE selesai', message: job.pesanUtama, silent: true });
    if (job.tabDibuat) chrome.tabs.remove(job.tabId || tab.id).catch(() => {});   // tutup tab scan latar
    const { kirimOtomatis = true, url, kunci } = await chrome.storage.local.get(['kirimOtomatis', 'url', 'kunci']);
    if (job.status === 'selesai' && url && kunci && (job.otomatis || kirimOtomatis || job.dariHp)) await kirimJob();   // langsung aman di Sheet
    if (job.dariHp) laporHp(job.dariHp, job.status === 'selesai' && job.kirim && job.kirim.ok ? 'selesai' : 'gagal',
      job.pesanUtama + (job.kirim ? ' ' + (job.kirim.utama || job.kirim.pesan || '') : ''));
  } catch (e) {
    await selesaiGalat('Gagal: ' + (e.message || e), false, e && e.stack);
  } finally { ctl.jalan = false; ctl.stop = false; }
}

/** bunyi pemberitahuan lewat dokumen offscreen; bisa dimatikan di Pengaturan.
 *  Dokumen baru memutar bunyi dari parameter URL saat dimuat (tanpa pesan → tidak ada balapan). */
let tutupBunyi = null;
/** bunyi Siap dipanggil: pilihan, volume, diulang (Pengaturan → Bunyi) */
async function bunyiSiap(uji) {
  try {
    const { siapBunyi = {}, bunyiSendiri } = await chrome.storage.local.get(['siapBunyi', 'bunyiSendiri']);
    const b = Object.assign({ aktif: true, pilih: 'kapsul', volume: 80, ulang: 1 }, siapBunyi, uji || {});
    if (!b.aktif && !uji) return;
    if (!chrome.offscreen) return;
    clearTimeout(tutupBunyi);
    if (!(await chrome.offscreen.hasDocument())) { await chrome.offscreen.createDocument({ url: 'offscreen.html', reasons: ['AUDIO_PLAYBACK'], justification: 'Bunyi pasien siap dipanggil' }); await new Promise(r => setTimeout(r, 150)); }
    await chrome.runtime.sendMessage({ target: 'bunyi', nama: b.pilih, volume: b.volume / 100, ulang: b.ulang, data: b.pilih === 'sendiri' && bunyiSendiri ? bunyiSendiri.data : undefined }).catch(() => {});
    tutupBunyi = setTimeout(() => chrome.offscreen.closeDocument().catch(() => {}), 4000 * (b.ulang || 1) + 3000);
  } catch (e) { if (!/single offscreen|only a single/i.test(e.message || '')) tulisLog('awas', 'bunyi', 'Bunyi gagal diputar: ' + (e.message || e)); }
}
async function bunyi(jenis, paksa) {
  if (!jenis) return;
  try {
    const { bunyiAktif = true } = await chrome.storage.local.get('bunyiAktif');
    if ((!bunyiAktif && !paksa) || !chrome.offscreen) return;
    clearTimeout(tutupBunyi);
    if (await chrome.offscreen.hasDocument()) await chrome.runtime.sendMessage({ target: 'bunyi', jenis }).catch(() => {});
    else await chrome.offscreen.createDocument({ url: 'offscreen.html?jenis=' + jenis, reasons: ['AUDIO_PLAYBACK'], justification: 'Bunyi saat scan selesai' });
    tutupBunyi = setTimeout(() => chrome.offscreen.closeDocument().catch(() => {}), 5000);
  } catch (e) { if (!/single offscreen|only a single/i.test(e.message || '')) tulisLog('awas', 'bunyi', 'Bunyi gagal diputar: ' + (e.message || e)); }
}

async function selesaiGalat(teks, login, detail) {
  tulisLog('galat', job && job.otomatis ? 'otomatis' : 'scan', teks + (job ? ` (tanggal ${job.daftar[job.idx] || '-'}, ${job.idx}/${job.daftar.length})` : ''), detail);
  job.status = 'galat'; job.pesan = teks; await simpanJob(true);
  if (job.dariHp) laporHp(job.dariHp, 'gagal', teks);
  if (job.tabDibuat && job.tabId) chrome.tabs.remove(job.tabId).catch(() => {});
  bunyi('perhatian');
  if (job.otomatis) { await ulangiNanti(); catat(login ? 'C-CARE belum login — scan otomatis ditunda.' : teks, true); }
}

async function kirimJob() {
  if (await scanMati()) return { ok: false, pesan: PESAN_SCAN_MATI };
  await muatJob();
  if (!job || !job.hasil) return { ok: false, pesan: 'Belum ada hasil.' };
  const s = await chrome.storage.local.get(['url', 'kunci', 'nama']);
  if (!s.url || !s.kunci) { job.kirim = { ok: false, pesan: 'Isi Alamat Web App dan Kunci di Pengaturan.' }; await simpanJob(true); return job.kirim; }
  job.kirim = { proses: true }; await simpanJob(true);
  try {
    const j = await kirimKeSheet(s.url, s.kunci, s.nama, job.hasil.tanggal, job.hasil.pasien);
    job.kirim = { ok: true, waktu: waktuWib(), beda: j.beda, pesan: `Terkirim: ${j.pasienBaru} pasien baru, ${j.pasienUbah || 0} diperbarui, ${j.pasienAda} sudah ada (tidak ditimpa)` +
      (j.lewatPeriode ? `, ${j.lewatPeriode} di luar periode berjalan hanya dihitung jumlahnya` : '') +
      (j.beda ? `. ${j.beda} hari beda dengan Rekapan klinik — lihat Log Scan.` : '.'),
      utama: `Terkirim: ${j.pasienBaru} pasien baru` + (j.pasienUbah ? `, ${j.pasienUbah} diperbarui jenisnya (mis. jadi MCU)` : '') + (j.pasienAda ? `, ${j.pasienAda} sudah ada (tidak ditimpa)` : '') + '.',
      catatan: [
        ...(j.lewatPeriode ? [['info', `${j.lewatPeriode} pasien di luar periode berjalan hanya dihitung jumlahnya`]] : []),
        ...(j.jadwal && j.jadwal.length ? [['info', 'Jadwal Shift dikoreksi: ' + j.jadwal.map(x => `${x.tanggal.slice(8)}/${x.tanggal.slice(5, 7)} ${x.ke}`).join(', ')]] : []),
        ...(j.beda ? [['awas', `${j.beda} hari beda dengan Rekapan klinik (angka Rekapan yang dipakai) — cek Log Scan`]] : []),
      ] };
    job.hasil.pasien = [];                                      // nama pasien tidak disimpan lagi di komputer
    await hapusBelumKirim(job.hasil.tanggal);
    await tandaiTanggal(job.hasil.tanggal, 'kirim', job.hasil.jumlah);
    tulisLog(j.beda ? 'awas' : 'info', 'kirim', job.kirim.pesan);
    await chrome.storage.local.set({ terakhirKirim: { tanggal: job.hasil.tanggal[job.hasil.tanggal.length - 1], pasien: job.hasil.jumlah.reduce((a, x) => a + x.pagi + x.siang + x.ugd + x.mcu + x.tele, 0), waktu: waktuWib() } });
    if (job.otomatis) {
      await chrome.storage.local.set({ terakhir: job.hasil.tanggal[job.hasil.tanggal.length - 1], ulang: 0 });
      const per = job.hasil.jumlah.map(x => `${x.tanggal.slice(8)}/${x.tanggal.slice(5, 7)}: ${x.pagi + x.siang} poli, ${x.ugd} UGD`).join(' · ');
      catat(`Otomatis ${job.hasil.tanggal.length} hari — ${per || 'tidak ada pasien atas nama Anda'}. ${j.pasienBaru} pasien baru.` + (j.beda ? ` ${j.beda} hari beda.` : ''), !!j.beda);
    }
  } catch (e) {
    job.kirim = { ok: false, pesan: 'Gagal mengirim: ' + (e.message || e) };
    tulisLog('galat', 'kirim', job.kirim.pesan, e && e.stack);
    if (job.otomatis) { await ulangiNanti(); catat(job.kirim.pesan, true); }
  }
  await simpanJob(true);
  return job.kirim;
}

/* ---------------- hasil scan yang belum terkirim, per tanggal ----------------
 * Disimpan sampai terkirim (lalu dihapus), agar tanggal "Belum kirim" bisa dikirim dari kalender tanpa scan ulang. */
async function simpanBelumKirim(hasil) {
  if (!hasil || !hasil.tanggal || !hasil.tanggal.length) return;
  const { belumKirim = {} } = await chrome.storage.local.get('belumKirim');
  hasil.tanggal.forEach(t => { belumKirim[t] = { pasien: (hasil.pasien || []).filter(p => p.tanggal === t), catatan: (hasil.catatan || {})[t] || '', waktu: waktuWib() }; });
  const kunci = Object.keys(belumKirim).sort().slice(-62), o = {}; kunci.forEach(k => o[k] = belumKirim[k]);
  await chrome.storage.local.set({ belumKirim: o });
}
async function hapusBelumKirim(tanggal) {
  const { belumKirim = {} } = await chrome.storage.local.get('belumKirim');
  (tanggal || []).forEach(t => delete belumKirim[t]);
  await chrome.storage.local.set({ belumKirim });
}
async function kirimTersimpan(daftar) {
  if (await scanMati()) return { ok: false, pesan: PESAN_SCAN_MATI };
  const s = await chrome.storage.local.get(['url', 'kunci', 'nama', 'belumKirim']);
  if (!s.url || !s.kunci) return { ok: false, pesan: 'Isi Alamat Web App dan Kunci di Pengaturan.' };
  const bk = s.belumKirim || {}, tanggal = [...new Set(daftar || [])].filter(t => bk[t]).sort();
  if (!tanggal.length) return { ok: false, pesan: 'Tanggal ini belum punya hasil scan tersimpan — scan dulu.' };
  const pasien = tanggal.flatMap(t => bk[t].pasien), jumlah = jumlahPerTanggal(pasien);
  try {
    const j = await kirimKeSheet(s.url, s.kunci, s.nama, tanggal, pasien);
    await hapusBelumKirim(tanggal);
    await tandaiTanggal(tanggal, 'kirim', jumlah);
    await chrome.storage.local.set({ terakhirKirim: { tanggal: tanggal[tanggal.length - 1], pasien: pasien.length, waktu: waktuWib() } });
    const pesan = `Terkirim ${tanggal.length} tanggal: ${j.pasienBaru} pasien baru` + (j.pasienUbah ? `, ${j.pasienUbah} diperbarui jenisnya (mis. jadi MCU)` : '') + (j.pasienAda ? `, ${j.pasienAda} sudah ada (tidak ditimpa)` : '') + '.' +
      (j.beda ? ` ${j.beda} hari beda dengan Rekapan klinik — cek Log Scan.` : '');
    tulisLog(j.beda ? 'awas' : 'info', 'kirim', pesan + ' (dari kalender)');
    sinkronStatus(true);
    return { ok: true, pesan, beda: !!j.beda };
  } catch (e) {
    const pesan = 'Gagal mengirim: ' + (e.message || e); tulisLog('galat', 'kirim', pesan, e && e.stack); return { ok: false, pesan };
  }
}

/** status per tanggal untuk kalender balon: 'scan' (discan, belum kirim) / 'kirim' (terkirim). Hanya angka, tanpa nama. */
async function tandaiTanggal(daftar, st, jumlah) {
  const { statusTgl = {} } = await chrome.storage.local.get('statusTgl');
  const waktu = waktuWib();
  daftar.forEach(t => {
    const x = (jumlah || []).find(j => j.tanggal === t);
    const pasien = x ? x.pagi + x.siang + x.ugd + x.mcu + x.tele : 0;
    if (st === 'scan' && statusTgl[t] && statusTgl[t].st === 'kirim' && statusTgl[t].pasien === pasien) return;   // sudah terkirim & sama
    statusTgl[t] = { st, pasien, waktu };
  });
  const kunci = Object.keys(statusTgl).sort().slice(-400); const o = {}; kunci.forEach(k => o[k] = statusTgl[k]);
  await chrome.storage.local.set({ statusTgl: o });
}

/** Ambil tanggal yang sudah ada di Sheet (Data Klinik, semua sumber) → tandai hijau. Hasil scan lokal yang belum dikirim tetap kuning. */
let sinkronTerakhir = 0;
let galatSinkron = { pesan: '', waktu: 0 };
async function sinkronStatus(paksa) {
  if (await scanMati()) return { ok: false, mati: true, pesan: PESAN_SCAN_MATI };
  if (!paksa && Date.now() - sinkronTerakhir < 3 * 60e3) return { ok: true, lewati: true };
  const s = await chrome.storage.local.get(['url', 'kunci', 'statusTgl']);
  if (!s.url || !s.kunci) return { ok: false, pesan: 'Alamat/Kunci belum diisi' };
  try {
    const j = await ambilStatusSheet(s.url, s.kunci);
    const st = s.statusTgl || {};
    Object.keys(st).forEach(t => { if (st[t].dariSheet && !j.data[t]) delete st[t]; });          // dihapus dari Sheet
    Object.entries(j.data).forEach(([t, x]) => {
      if (st[t] && st[t].st === 'scan') return;                                                    // hasil scan baru belum dikirim
      st[t] = { st: 'kirim', pasien: x.pasien, sumber: x.sumber, dariSheet: true, waktu: st[t] && st[t].waktu || '' };
    });
    await chrome.storage.local.set({ statusTgl: st, statusSheetWaktu: waktuWib() });
    sinkronTerakhir = Date.now();
    return { ok: true, jumlah: Object.keys(j.data).length };
  } catch (e) {
    const pesan = /Aksi tidak dikenal/i.test(e.message) ? 'Apps Script belum diperbarui (perlu doGet status) — Terapkan versi baru.' : e.message;
    sinkronTerakhir = Date.now();                                                                    // jangan coba ulang tiap buka balon
    if (pesan !== galatSinkron.pesan || Date.now() - galatSinkron.waktu > 30 * 60e3) {               // log sekali per 30 menit
      galatSinkron = { pesan, waktu: Date.now() };
      tulisLog('awas', 'status', 'Gagal membaca status tanggal dari Sheet: ' + pesan);
    }
    return { ok: false, pesan };
  }
}
/** pindahkan hasil scan versi lama (sebelum ada kalender) ke status tanggal */
async function migrasiStatus() {
  const { job: j, statusTgl } = await chrome.storage.local.get(['job', 'statusTgl']);
  if (j && j.hasil && j.hasil.tanggal && j.hasil.tanggal.length) {
    const belum = j.hasil.tanggal.filter(t => !(statusTgl || {})[t]);
    if (belum.length) { await tandaiTanggal(belum, j.kirim && j.kirim.ok ? 'kirim' : 'scan', j.hasil.jumlah); tulisLog('info', 'status', `Status ${belum.length} tanggal dari scan sebelumnya dipulihkan`); }
    if (!(j.kirim && j.kirim.ok) && (j.hasil.pasien || []).length) await simpanBelumKirim(j.hasil);   // hasil lama yang belum terkirim
  }
}

/* ---------------- pesan dari balon / halaman pengaturan ---------------- */
chrome.runtime.onMessage.addListener((m, _s, balas) => {
  (async () => {
    await muatJob();
    switch (m && m.aksi) {
      case 'mulai': return balas(await mulaiJob(Array.isArray(m.tanggal) ? [...new Set(m.tanggal)].sort().slice(0, 62) : rentangTanggal(m.dari, m.sampai)));
      case 'tunda': ctl.tunda = true; if (job && job.status === 'jalan') { job.pesan = 'Menunda setelah langkah ini…'; simpanJob(true); } return balas({ ok: true });
      case 'lanjut':
        ctl.tunda = false;
        if (job && job.status === 'tunda') { job.status = 'jalan'; job.pesan = 'Melanjutkan…'; await simpanJob(true); jalankanJob(); }
        return balas({ ok: true });
      case 'stop':
        ctl.stop = true; ctl.tunda = false;
        if (job && job.status === 'tunda') { job.status = 'jalan'; await simpanJob(true); jalankanJob(); }   // susun hasil dari tanggal yang sudah selesai
        else if (job && job.status === 'jalan') { job.pesan = 'Menghentikan…'; simpanJob(true); }
        return balas({ ok: true });
      case 'kirim': { const k = await kirimJob(); sinkronStatus(true); return balas(k); }
      case 'kirimTanggal': return balas(await kirimTersimpan(m.tanggal));
      case 'sinkronStatus': return balas(await sinkronStatus(!!m.paksa));
      case 'pulihkanSetelan': { const p = await pulihkanSetelan(); if (p) { aturAlarm(); sinkronStatus(true); } return balas({ ok: true, dipulihkan: p }); }
      case 'simpanSetelanAkun': return balas({ ok: await simpanSetelanAkun() });
      case 'tutupHasil': job = null; await chrome.storage.local.remove('job'); return balas({ ok: true });
      case 'ujiBunyi': bunyiSiap(m.bunyi || {}); return balas({ ok: true });
      case 'cekSekarang': pantauTerakhir = 0; lambatTerakhir = 0; paksaCek = Date.now(); mulaiLingkar(); return balas({ ok: true });
      case 'aturAlarm': await aturAlarm(); return balas({ ok: true });
      case 'relayTtd': {   // tablet tanda tangan: hanya ke URL Apps Script /exec, hanya ?t=…&set=angka atau &get
        if (!/^https:\/\/script\.google\.com\/macros\/s\/[\w-]+\/exec\?t=[\w-]{20,64}&(set=\d{1,10}|get)$/.test(String(m.url))) return balas({ ok: false, galat: 'url' });
        try { const r = await fetch(m.url, { cache: 'no-store' }); return balas(await r.json()); } catch (e) { return balas({ ok: false, galat: 'jaringan' }); }
      }
      case 'relayLepas': {   // CPPT ditutup → "0" di relay = tidak ada pasien (tablet kembali ke "Sebentar, ya.")
        const id = String(m.id || ''); if (!/^\d{1,10}$/.test(id)) return balas({ ok: false });
        balas({ ok: true });
        const c = (await chrome.storage.local.get('ttdTablet')).ttdTablet || {};
        if (c.peran !== 'pc' || !/^https:\/\/script\.google\.com\/macros\/s\/[\w-]+\/exec$/.test(c.url || '') || !/^[\w-]{20,64}$/.test(c.t || '')) return;
        await new Promise(r => setTimeout(r, 2000));   // halaman yang dimuat ulang (mis. sesudah TTD) sempat mengirim ulang kunjungan ini
        try {
          const r = await (await fetch(`${c.url}?t=${c.t}&get`, { cache: 'no-store' })).json();
          if (r && r.ok && String(r.id) === id && r.kini - r.w > 3000) await fetch(`${c.url}?t=${c.t}&set=0`, { cache: 'no-store' });
        } catch (e) { /* jaringan: tablet tetap menampilkan form sampai CPPT lain dibuka */ }
        return;
      }
      case 'antrean': pantauSiap(_s.tab && _s.tab.id); return balas({ ok: true });   // dari tab C-CARE yang terlihat (±30 detik, daftar lengkap)
      case 'antreanCepat': terimaCepat(m.poli, Array.isArray(m.baris) ? m.baris : [], _s.tab && _s.tab.id); return balas({ ok: true });   // ±2 detik, hanya Menunggu Dokter
      case 'periksaDaftar': case 'bukaCppt': case 'cpptDisimpan': case 'sembunyikanSiap': return;   // dijawab pendengar di pantau.js
      /* ---- PCare (pcare-halaman.js) ---- */
      case 'pcareBukaPengaturan': chrome.tabs.create({ url: chrome.runtime.getURL('pengaturan.html#pcare') }); return balas({ ok: true });
      case 'pcareIdle': return chrome.idle.queryState(Math.max(60, (m.detik | 0) || 900), st => balas({ ok: true, aktif: st === 'active' }));
      default: return balas({ ok: false });
    }
  })();
  return true;
});

/* ---------------- scan otomatis harian + susulan ---------------- */
async function aturAlarm() {
  const { otomatis, jamOtomatis = '21:00' } = await chrome.storage.local.get(['otomatis', 'jamOtomatis']);
  await chrome.alarms.clear('scan-harian');
  if (!otomatis) return;
  const [h, m] = jamOtomatis.split(':').map(Number);
  const now = Date.now(), wib = new Date(now + 7 * 36e5);
  let target = Date.UTC(wib.getUTCFullYear(), wib.getUTCMonth(), wib.getUTCDate(), h, m) - 7 * 36e5;
  if (target <= now) target += 864e5;
  chrome.alarms.create('scan-harian', { when: target, periodInMinutes: 1440 });
}
/** v3.0.0: Ruang Tindakan & Prolanis dapat isian sendiri (salinan Poli Umum); scan otomatis harian dihapus dari Pengaturan */
async function migrasiV3() {
  const { isiCepat, otomatis, migrasiV3: sudah } = await chrome.storage.local.get(['isiCepat', 'otomatis', 'migrasiV3']);
  const ic = isiCepat || {}, o = {};
  if (pisahkanIsian(ic)) o.isiCepat = ic;
  /* v3.6.2: Kunjungan Sehat = register MCU (status C-CARE tetap "Menunggu Dokter") → tidak ikut Siap dipanggil; bisa dinyalakan lagi di Pengaturan → Pantau */
  const lamaPer = await chrome.storage.local.get(['migrasiMcu', 'pantauPer', 'pantauSiap', 'pantauPoli', 'pantauBunyi']);
  if (!lamaPer.migrasiMcu) { const pp = JSON.parse(JSON.stringify(aturanPer(lamaPer))); pp['4'] = Object.assign({}, pp['4'], { notif: false, bunyi: false, cepat: false }); o.pantauPer = pp; o.migrasiMcu = true; tulisLog('info', 'pembaruan', 'Kunjungan Sehat (MCU) dikeluarkan dari Siap dipanggil'); }
  if (!sudah) { o.migrasiV3 = true; if (otomatis) { o.otomatis = false; await chrome.alarms.clear('scan-harian'); tulisLog('info', 'pembaruan', 'Scan otomatis harian dimatikan (dihapus dari Pengaturan v3)'); } }
  if (Object.keys(o).length) await chrome.storage.local.set(o);
}
/* v4.6.4: rapikan log anamnesa lama — catatan kembar (keluhan + anamnesa + ICD-10 sama, selang < 30 menit) disatukan */
async function rapikanLogAnamnesa() {
  const { logAnamnesa = [], logRapi } = await chrome.storage.local.get(['logAnamnesa', 'logRapi']);
  if (logRapi || !logAnamnesa.length) return;
  const kunci = x => [x.keluhan, x.anamnesa, (x.icd || []).map(i => i.kode).sort().join(',')].join('|');
  const out = [];
  logAnamnesa.forEach(x => {
    const j = out.findIndex(y => kunci(y) === kunci(x) && x.t - y.t < 30 * 60e3 && x.t >= y.t);
    if (j >= 0) out[j] = x; else out.push(x);
  });
  await chrome.storage.local.set({ logAnamnesa: out, logRapi: true });
  if (out.length < logAnamnesa.length) tulisLog('info', 'pembaruan', `Log anamnesa dirapikan: ${logAnamnesa.length - out.length} catatan kembar disatukan`);
}
/* Relay tablet tanda tangan bawaan (Apps Script "Relay TTD Pasien (CCare Dokter)" di akun Gmail pemilik, v4.10.0).
   APK Tanda Tangan Pasien 2.6 membawa URL + token yang sama → PC dan tablet langsung saling mengenal tanpa diatur.
   Dipasang sekali per versi relay; perangkat yang diatur sebagai tablet tidak diubah. Bisa diganti di Pengaturan. */
const RELAY_BAWAAN = { url: 'https://script.google.com/macros/s/AKfycbzfszQuJjcDD71vzMB9xGWTu40OIRn88PUDNywQpz5IOUcdR21M5lqhHz4W1FugC8Xx/exec', t: 'eTTve7SibZ6LF5_ZOZudk9b8odCgo8lb', versi: 1 };
async function pasangRelayBawaan() {
  const s = await chrome.storage.local.get(['ttdTablet', 'relayBawaan']);
  if ((s.relayBawaan || 0) >= RELAY_BAWAAN.versi) return;
  const c = s.ttdTablet || {};
  if (c.peran !== 'tablet') await chrome.storage.local.set({ ttdTablet: { peran: 'pc', url: RELAY_BAWAAN.url, t: RELAY_BAWAAN.t } });
  await chrome.storage.local.set({ relayBawaan: RELAY_BAWAAN.versi });
}
chrome.runtime.onInstalled.addListener(async d => {
  rapikanLogAnamnesa();
  await pulihkanSetelan();                                      // pasang ulang / PC baru: ambil pengaturan dari akun Chrome
  await pasangRelayBawaan();
  await migrasiV3();
  migrasiStatus().then(() => sinkronStatus(true));
  tulisLog('info', 'pembaruan', d.reason === 'install' ? `Dipasang v${chrome.runtime.getManifest().version}` : d.reason === 'update' ? (d.previousVersion === chrome.runtime.getManifest().version ? `Dimuat ulang v${d.previousVersion}` : `Diperbarui v${d.previousVersion} → v${chrome.runtime.getManifest().version}`) : d.reason);
  await aturAlarm(); aturAlarmHp(); aturAlarmPantau();
  if (d.reason === 'update' && d.previousVersion !== chrome.runtime.getManifest().version) {
    await chrome.storage.local.set({ baruDiperbarui: chrome.runtime.getManifest().version });
    chrome.tabs.create({ url: chrome.runtime.getURL('pengaturan.html') });
  }
});
chrome.runtime.onStartup.addListener(async () => {
  await pasangRelayBawaan();
  aturAlarmHp(); aturAlarmPantau(); setTimeout(cekMintaHp, 20000);
  if (await pulihkanSetelan()) sinkronStatus(true);
  else simpanSetelanAkun();                                     // pastikan salinan akun selalu yang terbaru
  await aturAlarm();
  await muatJob();
  if (job && job.status === 'jalan') { job.status = 'tunda'; job.pesan = 'Chrome sempat ditutup. Tekan Lanjut untuk meneruskan.'; await simpanJob(true); }
  jalankanOtomatis();
});
// pengaturan diubah di komputer lain (akun Chrome sama) → ikut di sini
chrome.storage.onChanged.addListener(async (c, area) => {
  if (area !== 'sync' || !c.setelan || !c.setelan.newValue) return;
  const n = c.setelan.newValue, l = await chrome.storage.local.get(KUNCI_SETELAN), o = {};
  KUNCI_SETELAN.forEach(k => { if (n[k] !== undefined && JSON.stringify(n[k]) !== JSON.stringify(l[k])) o[k] = n[k]; });
  if (Object.keys(o).length) { await chrome.storage.local.set(o); if (o.otomatis !== undefined || o.jamOtomatis) aturAlarm(); }
});
chrome.alarms.onAlarm.addListener(a => { if (a.name === 'scan-harian' || a.name === 'scan-ulang') jalankanOtomatis(); if (a.name === 'cek-hp') cekMintaHp(); if (a.name === 'pantau-siap') { pantauSiap(); mulaiLingkar(); muatPantau().then(pantau => { if (pantau && pantau.siap) bacaAturan().then(A => { if (A.aktif && !A.mati) lencana(pantau); }); }); } });

/* ---------------- scan diminta dari aplikasi HP (Jasa IPB): cek tiap 5 menit ---------------- */
async function laporHp(id, status, pesan) {
  try {
    const s = await chrome.storage.local.get(['url', 'kunci']);
    await ambil(s.url, { method: 'POST', headers: { 'Content-Type': 'text/plain;charset=utf-8' }, body: JSON.stringify({ aksi: 'scan.status', kunci: s.kunci, id, status, pesan: String(pesan || '').slice(0, 200) }) });
  } catch (e) { tulisLog('awas', 'hp', 'Status scan ke aplikasi HP belum terkirim: ' + (e.message || e)); }
}
async function cekMintaHp() {
  if (await scanMati()) return;
  const s = await chrome.storage.local.get(['url', 'kunci', 'nama', 'mintaHpTerakhir']);
  if (!s.url || !s.kunci || !s.nama) return;
  await muatJob();
  if (ctl.jalan || (job && (job.status === 'jalan' || job.status === 'tunda'))) return;
  let m;
  try { m = (await ambilStatusSheet(s.url, s.kunci)).mintaScan; } catch (e) { return; }
  if (!m || m.status !== 'menunggu' || m.id === s.mintaHpTerakhir) return;
  await chrome.storage.local.set({ mintaHpTerakhir: m.id });
  tulisLog('info', 'hp', `Scan diminta dari HP (${m.waktu}): ${m.tanggal.join(', ')}`);
  await laporHp(m.id, 'jalan', 'Mulai scan ' + m.tanggal.length + ' tanggal di komputer');
  const r = await mulaiJob(m.tanggal.slice().sort(), { dariHp: m.id });
  if (!r.ok) laporHp(m.id, 'gagal', r.pesan);
}
async function aturAlarmHp() { if (!(await chrome.alarms.get('cek-hp'))) chrome.alarms.create('cek-hp', { delayInMinutes: 1, periodInMinutes: 5 }); }

async function jalankanOtomatis() {
  if (await scanMati()) return;
  const s = await chrome.storage.local.get(['otomatis', 'url', 'kunci', 'nama', 'terakhir', 'jamOtomatis']);
  if (!s.otomatis || !s.url || !s.kunci || !s.nama) return;
  await muatJob();
  if (job && (job.status === 'jalan' || job.status === 'tunda')) return;   // jangan ganggu scan manual
  const [h] = (s.jamOtomatis || '21:00').split(':').map(Number);
  const akhir = jamWib() >= h ? hariIni() : geser(hariIni(), -1);
  const awal = s.terakhir ? geser(s.terakhir, 1) : akhir;
  if (awal > akhir) return;
  const { liburTambahan } = await chrome.storage.local.get('liburTambahan');
  const peta = petaLibur(liburTambahan);
  let daftar = rentangTanggal(awal, akhir).filter(t => !liburTutup(t, peta));   // Minggu & tanggal dikecualikan dilewati; libur nasional tetap discan
  if (!daftar.length) { await chrome.storage.local.set({ terakhir: akhir }); return; }
  if (daftar.length > SUSUL_MAKS) daftar = daftar.slice(-SUSUL_MAKS);
  await mulaiJob(daftar, { otomatis: true });
}
async function ulangiNanti() {
  const { ulang = 0 } = await chrome.storage.local.get('ulang');
  if (ulang + 1 > 2) { await chrome.storage.local.set({ ulang: 0 }); return; }
  await chrome.storage.local.set({ ulang: ulang + 1 });
  chrome.alarms.create('scan-ulang', { delayInMinutes: 5 });
}
async function catat(teks, perhatian) {
  const { riwayat = [] } = await chrome.storage.local.get('riwayat');
  riwayat.push({ waktu: waktuWib(), teks }); await chrome.storage.local.set({ riwayat: riwayat.slice(-30) });
  chrome.notifications.create({ type: 'basic', iconUrl: 'ikon.png', title: perhatian ? 'Scan Jasa C-CARE — perlu dicek' : 'Scan Jasa C-CARE', message: teks });
}
