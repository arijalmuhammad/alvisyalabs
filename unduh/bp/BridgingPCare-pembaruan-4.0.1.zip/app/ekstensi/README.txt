BARU DI v2.1.0 (22-10-2026) — PORTABEL, terpasang semua
- Ekstrak ZIP ke folder mana saja (mis. D:\BridgingPCare), klik dua kali BridgingPCare.exe. Tidak dipasang ke AppData.
- Pertama kali: aplikasi mengunduh BROWSER KHUSUS BOT (Chrome for Testing, ±170 MB) ke folder browser\. Bot sudah
  termuat di dalamnya — tidak perlu lagi "Load unpacked". Ikon "Bridging PCare" dibuat di Desktop.
- Login otomatis PCare diperbaiki: form PCare memakai id acak (username_xxxx / password_xxxx) dan tombol #btnLogin.
  Bot menunggu kotak Cloudflare lolos (biasanya otomatis), lalu klik Sign In. Captcha gambar tetap Anda yang mengetik.
- Password, pengaturan, log, cadangan, profil browser: semua di folder yang sama (data\, log\, cadangan\, profil\).
- Password dari v2.0.0 dibawa otomatis (laptop & akun Windows yang sama).
- Browser bot dicek pembaruannya seminggu sekali; versi baru dipakai saat dibuka berikutnya.

BRIDGING PCARE – KLINIK IPB v2.0.0 (aplikasi Windows)  (ekstensi terpisah dari Rekap Morbiditas)
==================================================================

BARU DI v2.0.0 (22-10-2026) — aplikasi Windows BridgingPCare-Setup.exe
- PASANG: jalankan BridgingPCare-Setup.exe (sekali). File masuk ke %LOCALAPPDATA%\BridgingPCare.
  Lalu di chrome://extensions → Developer mode → Load unpacked → pilih %LOCALAPPDATA%\BridgingPCare\ekstensi
  (hapus "Bridging PCare" versi lama dulu).
- ⚙️ Pengaturan (tombol di panel bot):
  • Login otomatis PCare & C-CARE. Password disimpan TERENKRIPSI oleh Windows (DPAPI), hanya bisa dibuka akun Windows
    yang sama di laptop yang sama; tidak di Chrome, tidak di log. Captcha / kotak Cloudflare tetap diisi manusia.
    Maks. 2 percobaan per 10 menit. Bila PCare logout di tengah jalan, bot login lagi lalu lanjut sendiri.
    Tab latar C-CARE: hanya satu tab yang login, lainnya menunggu.
  • Log: semua aktivitas & galat ke file harian %LOCALAPPDATA%\BridgingPCare\log\bot-TANGGAL.log (60 hari).
    Nama pasien yang dikenali bot → inisial, No. Kartu/NIK → ****1234. Tombol "Salin 300 baris terakhir" untuk dikirim ke Claude.
  • Pembaruan: "Pilih file pembaruan (.zip)" atau online (alamat terbaru.json). File diganti di folder yang SAMA,
    versi lama dicadangkan (5 terakhir), ekstensi & tab PCare/C-CARE dimuat ulang otomatis. Ada "Kembalikan versi sebelumnya".
- ID ekstensi kini tetap (jhadhnjbadjkfdjikeclmmmelkcfllkm) agar aplikasi Windows mengenalinya.

BARU DI v1.9.9 (20-10-2026)
- 🔄 Refresh kini MENGHENTIKAN dulu proses yang berjalan (putaran bot, pencarian C-CARE, hitung mundur simpan), lalu
  membaca ulang daftar. Refresh berulang: hanya yang terakhir yang dipakai.
- Menu baru "🧹 Tanda selesai & bersihkan data": daftar pasien yang ditandai bot hari ini (disimpan bot / ditandai
  selesai manual / dilewati) beserta status PCare-nya. Yang di PCare masih "Baru" ditandai ⚠️. Tombol ↩ per pasien
  membatalkan tanda (pasien diproses lagi, kunjungan C-CARE-nya dilepas). Ada juga: Bersihkan log, Bersihkan cache
  C-CARE, Reset semua hari ini (tombol berbahaya harus diklik dua kali). Tombol reset lama di menu Manual dihapus.
- Pratinjau: ✏️ Koreksi tidak lagi menutup pratinjau. Isian (Keluhan, Anamnesa, Diagnosa, Terapi Obat/Non Obat, BMHP,
  tanda vital, TB/BB/LP) bisa diedit, lalu "💾 Simpan ke PCare" menulis ke form dan menyimpan. Dicek dulu: batas hasil
  ukur, diastole < sistole, panjang teks PCare, kode diagnosa dikenali. "▾ Kecilkan" memindahkan pratinjau ke pojok
  agar form PCare terlihat; "↺ Muat ulang dari form" mengambil isian yang Anda ubah langsung di form.

BARU DI v1.9.8 (20-10-2026) — "data C-CARE pasien ini tidak ditemukan" padahal sudah Selesai di C-CARE
- Langkah isi form kini memakai kunjungan C-CARE yang SUDAH dipilih di langkah pencarian. Dulu data dicocokkan ulang
  dengan aturan yang lebih ketat (nama persis, umur wajib terbaca), sehingga data yang baru diambil bisa "hilang".
  Bila tetap tidak ketemu, Aktivitas menulis RINCIAN alasannya (jumlah data, terpakai antrean lain, JK/umur beda).
- ⏭ Lanjut pada jeda "data C-CARE tidak ditemukan" / "Anamnesa kosong" / "tanggal beda" kini MENGAMBIL ULANG data
  dari C-CARE. Dulu Lanjut menandai pasien "selesai manual" sehingga pasien terlewat walau belum disimpan di PCare.
- Hanya SATU tab PCare yang menjalankan bot (tab tempat Anda klik ▶). Tab PCare lain menampilkan "bot sedang berjalan
  di tab PCare lain" dan tidak ikut memproses pasien.
- Tab latar yang dibuka bot (C-CARE) dikumpulkan di satu grup tab "Bot C-CARE" (abu-abu, diciutkan). Izin baru: tabGroups.

BARU DI v1.9.7 (20-10-2026) — dicek dengan antrean PCare dan C-CARE asli hari ini
- Penyebab notifikasi "C-CARE tidak ditemukan" hari ini: 10 pendaftaran PCare berpoli "Konseling" (antrean 1–10).
  Di C-CARE pasien ini tercatat di Kunjungan Sehat (10 pasien), sebagian juga di Poli Gizi (7). Bot tidak mencari di
  Kunjungan Sehat, sehingga 3 pasien yang hanya ada di Kunjungan Sehat dilaporkan "tidak ditemukan".
  Kini: pendaftaran PCare "Konseling" dicari juga di Kunjungan Sehat; bila pasien ada di Poli Gizi DAN Kunjungan Sehat,
  kunjungan Poli Gizi yang dipakai. Pendaftaran PCare Poli Umum tetap TIDAK mengambil data Kunjungan Sehat.
- Gelar di nama PCare dibuang sebelum dicocokkan ("…. S.E.", "DR.… , S.SI,MSI", A.Md, Ir., Drs.).
- Catatan: antrean Konseling tidak berkode dokter (bukan "A2-9"), jadi Tenaga Medis tidak terisi otomatis → bot
  berhenti di pratinjau (Nonstop: dilewati) sampai kode petugas Konseling ditambahkan.

BARU DI v1.9.6 (20-10-2026) — "C-CARE tidak ditemukan" padahal datanya ada
- Pencarian C-CARE kini membaca SEMUA baris daftar poli pada tanggal itu (lewat form Tampilkan halaman, tanpa
  mengetik di kotak Search), lalu mencocokkan nama di sana. Dulu hanya kata pertama / terakhir nama yang dicari.
- Pencocokan nama diperbaiki: nama satu kata (9 dari 104 nama C-CARE hari ini), singkatan M./Moch/Muh = Muhammad,
  Abd = Abdul, inisial ("R" = "Rizky"), dan awalan ("Fitri" ≈ "Fitriani"). Jenis kelamin dan umur tetap dicek di
  halaman kunjungan, jadi nama yang longgar tidak membuat pasien tertukar; pasien dengan >1 kandidat tetap dipilih manual.
- Poli Gigi dan Kunjungan Sehat ikut dicari HANYA untuk memberi tahu "pasien tercatat di Poli Gigi/Kunjungan Sehat"
  (tetap tidak dikirim otomatis).
- Bila ada poli yang gagal/waktu habis dicari, pesannya kini "pencarian BELUM LENGKAP", bukan "tidak ditemukan".
  Waktu tunggu pencarian 60 detik.
- Bot tidak lagi meninggalkan kata pencarian di kotak Search C-CARE (dulu tersimpan stateSave, daftar poli Anda ikut tersaring).

BARU DI v1.9.5 (20-10-2026)
- PERBAIKAN: tombol ⏹ Berhenti kini benar-benar menghentikan bot. Dulu langkah yang sedang berjalan (mencari di C-CARE,
  memuat pasien, menunggu Cloudflare, hitung mundur simpan) menulis balik status lama "aktif" setelah selesai,
  sehingga bot hidup lagi dan lanjut ke pasien berikutnya.
  Kini: tiap putaran punya penanda; Berhenti menandainya "dihentikan" dan status itu tidak bisa ditimpa.
  Hitung mundur "Simpan otomatis dalam 5 detik" langsung batal, tidak ada simpan sesudah Berhenti,
  tunggu Cloudflare berhenti seketika, tab C-CARE latar ditutup, dan tab PCare lain ikut berhenti.
  Mulai lagi dengan ▶ (putaran baru).

BARU DI v1.9.4 (17-10-2026)
- PERBAIKAN: tabel Riwayat Pendaftaran PCare berhalaman (mis. 15 pasien per halaman). Dulu bot hanya membaca
  halaman yang sedang tampil, sehingga pasien Baru di halaman 2, 3, dst. tidak terdeteksi.
  Dicek langsung di PCare (17-10-2026): tabel = DataTables server-side, 15 baris/halaman, dan URUTAN BARIS DARI SERVER
  TIDAK TETAP (membuka hal. 1-2-3 bergantian sempat membaca 39 dari 40 karena satu pasien bergeser halaman).
  Kini bot meminta tabel menampilkan SEMUA baris dalam satu halaman (minimal 100, hanya tampilan, tidak mengubah data),
  lalu mencocokkan jumlahnya dengan "Showing … of N entries". Bila cara itu gagal, cadangan: buka halaman satu per satu
  dan diulang s.d. 3 putaran sampai jumlahnya sama. Masih kurang → peringatan merah di Aktivitas.
  Sesudah Refresh, tabel PCare tetap menampilkan semua pasien dalam satu halaman (lebih mudah dicek).
  Berlaku untuk 🔄 Refresh, ▶ Jalankan semua, 🌙 Nonstop, dan cek antrian C-CARE.

BARU DI v1.9.3 (16-10-2026)
- Panjang isian teks diperiksa sebelum simpan, sesuai aturan form PCare: Keluhan min 4, Anamnesa min 10,
  Terapi Obat dan Terapi Non Obat 4–255, BMHP maks 255 karakter. Resep panjang (>255) kini berhenti untuk
  diringkas manual, bukan terpotong diam-diam.

BARU DI v1.9.2 (16-10-2026)
- Batas hasil ukur disamakan dengan aturan form Pelayanan PCare: Suhu 25–45, TB 30–250, BB 2–300, LP 25–300,
  Sistole 40–250, Diastole 30–180, RR 5–70, HR 30–160; isian lebih dari 3 karakter (suhu 5) dianggap tidak sesuai.
  Dulu HR 161–180 lolos di bot tetapi ditolak PCare.

BARU DI v1.9.1 (16-10-2026)
- Poli Gizi (/Poli/Index/7) ikut dicari; di PCare diisi sebagai Poli Umum seperti Umum, Tindakan, Prolanis, KIA.
  Kunjungan Sehat tetap tidak dicari (tidak didaftarkan ke PCare). Bot kini membuka 5 tab latar sekaligus.

BARU DI v1.9.0 (16-10-2026) — satu pasien, beberapa kunjungan sehari
- Aturan klinik: setiap kunjungan C-CARE = 1 pendaftaran PCare (mis. Poli Umum lalu Ruang Tindakan = 2 antrean PCare).
- PERBAIKAN: v1.8.1 mencatat "sudah diproses" per No. Kartu, sehingga antrean KEDUA dengan kartu yang sama
  terlewat diam-diam. Kini dicatat per No. Kartu + antrean.
- PERBAIKAN: data C-CARE di antrian bot kini disimpan per kunjungan (alamat halaman), bukan per pasien,
  sehingga kunjungan kedua tidak menimpa / dipakai ulang untuk antrean lain.
- Kunjungan C-CARE yang sudah tersimpan ke PCare ditandai TERPAKAI hari itu dan tidak dipilih lagi.
  Antrean pertama dengan 2 kandidat tetap dipilih manual; antrean kedua otomatis memakai kunjungan yang tersisa.
- Bila halaman kunjungan C-CARE menampilkan No. Kartu BPJS (usulan UP-41), kartu yang cocok mengalahkan
  pencocokan nama; kartu berbeda = berhenti.
- Catatan: daftar "sudah diproses" dari v1.8.1 hari yang sama tidak dibawa (status PCare "Sudah Dilayani" tetap mencegah ganda).

PASANG
1. chrome://extensions → HAPUS "Bot Klinik IPB" (gabungan) bila terpasang.
2. "Developer mode" → "Load unpacked" → pilih folder bridging-pcare.
3. Login PCare dan C-CARE di Chrome yang sama.

BRIDGING PCARE (tombol ▶ di panel PCare)
- Bot mencari pasien pada TANGGAL kunjungan di Poli Umum (/Poli/Index/1), Ruang Tindakan (/Poli/Index/5),
  Prolanis (/Poli/Index/8), KIA (/Kia) dan Poli Gizi (/Poli/Index/7) BERSAMAAN (5 tab latar belakang). Poli Gigi & Kunjungan Sehat tidak dicari.
  Ditemukan di tepat 1 poli → data diambil (log menyebut polinya). Ditemukan di >1 poli → bot berhenti, Anda pilih manual.
- "Lanjut otomatis" (bawaan AKTIF): setelah tersimpan, baik lewat 💾 bot maupun Simpan PCare yang Anda klik sendiri
  (setelah Koreksi), bot langsung lanjut ke pasien berikutnya. Matikan sakelarnya bila ingin berhenti tiap pasien.
- Pemberitahuan PCare bertombol OK saja (mis. "Peserta Berpotensi Menderita Penyakit Diabetes Melitus dan/atau
  Hipertensi ...") yang muncul saat Simpan diklik ketika bot aktif: di-OK-kan otomatis dan isinya dicatat di Aktivitas
  (kotak kuning). Dialog keputusan (Ya/Tidak, mis. "tetap melayani?") TETAP tidak pernah dijawab bot.
- Bot HANYA melayani pasien berstatus "Baru" di Riwayat Pendaftaran. "Sudah Dilayani" (dan status lain) dilewati.
- 🌙 JALANKAN NONSTOP (tanpa pemantauan): pasien tanpa peringatan disimpan otomatis (hitung mundur 5 dtk);
  pasien bermasalah (tidak ada di C-CARE, ada field kosong/peringatan, dialog keputusan, simpan gagal, dll.)
  TIDAK disimpan, dicatat di "⚠️ Perlu dikerjakan manual" beserta alasannya, lalu bot lanjut ke pasien berikutnya.
  Kotak Cloudflare perlu dicentang → bot MEMANGGIL Anda (bunyi, notifikasi, judul tab berkedip) dan menunggu s.d. 3 menit;
  setelah Anda centang, bot lanjut sendiri. Tidak dicentang → halaman dimuat ulang 1× lalu dicoba lagi. 3 pasien berturut-turut gagal karena
  Cloudflare / C-CARE belum login → Nonstop berhenti (agar tidak semua pasien terlewati).
  Kerjakan daftar manual dengan ▶ di tiap baris (dengan pemantauan seperti biasa).
- Bot TIDAK pernah mencentang kotak Cloudflare "Verifikasi bahwa Anda adalah manusia"; bot memanggil Anda lalu menunggu.
- Diagnosa: sampai 3 kode dari C-CARE diisi ke Diagnosa (utama), Diagnosa #2 dan #3 (sekunder), urutan sesuai C-CARE
  (⊕ diklik otomatis bila baris belum tampil). Lebih dari 3 diagnosa → peringatan, pilih sendiri.
- Anamnesa di C-CARE kosong → dianggap BELUM diperiksa dokter → tidak diisi (Nonstop: dilewati & dicatat).
- Hasil ukur "tidak sesuai" (pesan merah PCare, atau di luar batas wajar: Suhu 25–45, TB 30–250, BB 2–300, LP 25–300,
  Sistole 40–250, Diastole 30–180, RR 5–70, HR 30–160) → TIDAK disimpan, diisi manual (Nonstop: dilewati & dicatat).
- Login PCare sendiri (bot tidak menyimpan / mengetik password, tidak mengerjakan captcha).
- Riwayat Pendaftaran → 🔄 Refresh → ▶ per pasien / ▶ Jalankan semua.
- Data C-CARE diambil otomatis di tab latar (C-CARE harus sudah login di Chrome yang sama).
- Dialog keputusan (mis. "tetap melayani?") TIDAK dijawab bot.

KEAMANAN: tidak menyimpan / mengetik password, tidak mengerjakan captcha. Data pasien tidak dikirim ke pihak ketiga
(kecuali nama obat untuk cek golongan alergi di RxNav, tanpa identitas pasien). Tidak menulis ke C-CARE.
