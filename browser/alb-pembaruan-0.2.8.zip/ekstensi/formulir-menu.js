/* CPPT C-CARE: tombol "Formulir …" (Persetujuan Tindakan, Rencana Asuhan, Edukasi, Rujukan, Surgical Safety) dipindah
 * ke satu menu "Formulir" di ujung kanan bilah tab, sehingga ISIAN DOKTER / ISIAN PERAWAT memakai lebar penuh.
 * Hanya tata letak: tautan formulir sama persis dengan tombol asli C-CARE. Bisa dimatikan di Pengaturan → Auto Fill. */
(() => {
  const ul = [...document.querySelectorAll('ul.nav-tabs, ul.nav')].find(u => u.querySelector('a[href="#Pemeriksaan_tab"], a[href="#PengkajianUlang_tab"]'));
  if (!ul) return;
  const tombol = [...document.querySelectorAll('.tab-pane a')].filter(a => /^\s*formulir\b/i.test(a.textContent) && a.getAttribute('href'));
  if (!tombol.length) return;
  const daftar = []; tombol.forEach(a => { const n = a.textContent.replace(/\s+/g, ' ').trim(); if (!daftar.some(x => x.n === n)) daftar.push({ n, a }); });
  /* kolom tombol per tab: induk col-* terdekat yang memuat SEMUA tombol formulir di tab itu */
  const kolom = [];
  document.querySelectorAll('.tab-pane').forEach(p => {
    const t = [...p.querySelectorAll('a')].filter(a => tombol.includes(a)); if (!t.length) return;
    let k = t[0].parentElement;
    while (k && k !== p && !(/\bcol-/.test(k.className) && t.every(x => k.contains(x)) && k.parentElement && [...k.parentElement.children].some(s => s !== k && /\bcol-/.test(s.className)))) k = k.parentElement;
    if (k && k !== p) kolom.push({ k, lebar: [...k.parentElement.children].filter(s => s !== k && /\bcol-/.test(s.className) && s.tagName !== 'STYLE') });
  });
  const gaya = document.createElement('style');
  gaya.textContent = `
  .sjc-fm-sembunyi{display:none!important}
  .sjc-fm-lebar{flex:0 0 100%!important;max-width:100%!important;width:100%!important}
  li.sjc-fm{margin-left:auto;position:relative;display:flex;align-items:center;padding:4px 8px 4px 0;list-style:none}
  .sjc-fm>button{display:inline-flex;align-items:center;gap:6px;min-height:32px;padding:0 12px;border:1px solid #D5E0E0;border-radius:8px;background:#fff;color:#0F2742;font:600 13px/1 "Source Sans 3","Source Sans Pro",system-ui,sans-serif;cursor:pointer}
  .sjc-fm>button:hover{background:#F2F6F6}.sjc-fm>button:focus-visible{outline:2px solid #263C92;outline-offset:2px}.sjc-fm-menu a:focus,.sjc-fm-menu a:focus-visible{outline:2px solid #263C92;outline-offset:-2px}
  .sjc-fm svg{width:18px;height:18px;fill:#263C92;flex:none}.sjc-fm>button .pnh{width:16px;height:16px;fill:#4F6478;transition:transform .15s}
  .sjc-fm>button[aria-expanded=true] .pnh{transform:rotate(180deg)}
  .sjc-fm-menu{position:absolute;right:8px;top:calc(100% + 4px);z-index:1060;min-width:280px;max-width:calc(100vw - 32px);margin:0;padding:4px 0;list-style:none;background:#fff;border:1px solid #D5E0E0;border-radius:8px;box-shadow:0 8px 24px rgba(15,39,66,.16)}
  .sjc-fm-menu[hidden]{display:none}
  .sjc-fm-menu a{display:block;padding:9px 16px;color:#0F2742;font-size:14px;line-height:1.3;text-decoration:none;white-space:normal}
  .sjc-fm-menu a:hover,.sjc-fm-menu a:focus{background:#F2F6F6;color:#0F2742;text-decoration:none}`;
  const li = document.createElement('li'); li.className = 'nav-item sjc-fm';
  const IK = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8zm2 16H8v-2h8zm0-4H8v-2h8zm-3-5V3.5L18.5 9z"/></svg>';
  li.innerHTML = `<button type="button" aria-haspopup="true" aria-expanded="false" title="Formulir persetujuan, edukasi, rujukan">${IK}Formulir<svg class="pnh" viewBox="0 0 24 24" aria-hidden="true"><path d="M7 10l5 5 5-5z"/></svg></button><ul class="sjc-fm-menu" role="menu" hidden></ul>`;
  const btn = li.querySelector('button'), menu = li.querySelector('ul');
  daftar.forEach(({ n, a }) => {
    const x = document.createElement('a'); x.href = a.href; x.setAttribute('role', 'menuitem'); x.textContent = n.replace(/^formulir\s+/i, '');
    if (a.target) x.target = a.target;
    x.addEventListener('click', e => { if (e.ctrlKey || e.metaKey || e.shiftKey || e.button) return; e.preventDefault(); tutup(); a.click(); });   // pakai tombol asli (perilaku C-CARE)
    const w = document.createElement('li'); w.setAttribute('role', 'none'); w.appendChild(x); menu.appendChild(w);
  });
  const item = () => [...menu.querySelectorAll('a')];
  function buka() { menu.hidden = false; btn.setAttribute('aria-expanded', 'true'); item()[0].focus(); }
  function tutup(fokus) { if (menu.hidden) return; menu.hidden = true; btn.setAttribute('aria-expanded', 'false'); if (fokus) btn.focus(); }
  btn.addEventListener('click', () => menu.hidden ? buka() : tutup());
  btn.addEventListener('keydown', e => { if (e.key === 'ArrowDown') { e.preventDefault(); buka(); } });
  menu.addEventListener('keydown', e => {
    const a = item(), i = a.indexOf(document.activeElement);
    if (e.key === 'Escape') { e.preventDefault(); tutup(true); }
    else if (e.key === 'ArrowDown') { e.preventDefault(); a[(i + 1) % a.length].focus(); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); a[(i - 1 + a.length) % a.length].focus(); }
    else if (e.key === 'Tab') tutup();
  });
  document.addEventListener('click', e => { if (!li.contains(e.target)) tutup(); });
  function terapkan(aktif) {
    if (aktif) {
      if (!gaya.isConnected) document.head.appendChild(gaya);
      if (!li.isConnected) { if (getComputedStyle(ul).display !== 'flex') ul.style.display = 'flex'; ul.style.flexWrap = 'wrap'; ul.appendChild(li); }
      kolom.forEach(({ k, lebar }) => { k.classList.add('sjc-fm-sembunyi'); lebar.forEach(s => s.classList.add('sjc-fm-lebar')); });
    } else {
      tutup(); li.remove();
      kolom.forEach(({ k, lebar }) => { k.classList.remove('sjc-fm-sembunyi'); lebar.forEach(s => s.classList.remove('sjc-fm-lebar')); });
    }
  }
  const aktifDari = s => { const ic = (s && s.isiCepat) || {}; return !ic.mati && !ic.formulirBiasa; };
  chrome.storage.local.get('isiCepat', s => terapkan(aktifDari(s)));
  chrome.storage.onChanged.addListener((u, area) => { if (area === 'local' && u.isiCepat) terapkan(aktifDari({ isiCepat: u.isiCepat.newValue })); });
})();
