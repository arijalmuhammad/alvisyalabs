importScripts('pembaruan.js');
/* TTD Dokter Umum — background: hanya meneruskan permintaan relay tanda tangan (Apps Script relay bawaan, token unik per PC). */
const RELAY_URL = 'https://script.google.com/macros/s/AKfycbzfszQuJjcDD71vzMB9xGWTu40OIRn88PUDNywQpz5IOUcdR21M5lqhHz4W1FugC8Xx/exec';
const POLA_URL = /^https:\/\/script\.google\.com\/macros\/s\/[\w-]+\/exec$/, POLA_T = /^[\w-]{20,64}$/;
const tokenBaru = () => { const a = new Uint8Array(18); crypto.getRandomValues(a); return btoa(String.fromCharCode(...a)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); };

/* Token unik per PC: HP dokter ini tidak ikut menerima pasien dari PC/tablet klinik lain. */
async function pastikanSetelan() {
  const c = (await chrome.storage.local.get('ttdTablet')).ttdTablet || {};
  if (c.peran === 'pc' && POLA_URL.test(c.url || '') && POLA_T.test(c.t || '')) return false;
  await chrome.storage.local.set({ ttdTablet: { peran: 'pc', url: RELAY_URL, t: tokenBaru() } });
  return true;
}
chrome.runtime.onInstalled.addListener(async d => {
  await pastikanSetelan();
  if (d.reason === 'install') chrome.runtime.openOptionsPage();
});
chrome.runtime.onStartup.addListener(pastikanSetelan);
chrome.action.onClicked.addListener(() => chrome.runtime.openOptionsPage());

chrome.runtime.onMessage.addListener((m, _s, balas) => {
  (async () => {
    if (m.aksi === 'relayTtd') {   // hanya ke URL Apps Script /exec, hanya ?t=…&set=angka atau &get
      if (!/^https:\/\/script\.google\.com\/macros\/s\/[\w-]+\/exec\?t=[\w-]{20,64}&(set=\d{1,10}|get)$/.test(String(m.url))) return balas({ ok: false, galat: 'url' });
      try { const r = await fetch(m.url, { cache: 'no-store' }); return balas(await r.json()); } catch (e) { return balas({ ok: false, galat: 'jaringan' }); }
    }
    if (m.aksi === 'relayLepas') {   // CPPT ditutup → "0" di relay = HP kembali ke layar menunggu
      const id = String(m.id || ''); if (!/^\d{1,10}$/.test(id)) return balas({ ok: false });
      balas({ ok: true });
      const c = (await chrome.storage.local.get('ttdTablet')).ttdTablet || {};
      if (c.peran !== 'pc' || !POLA_URL.test(c.url || '') || !POLA_T.test(c.t || '')) return;
      await new Promise(r => setTimeout(r, 2000));   // halaman yang dimuat ulang (mis. sesudah TTD) sempat mengirim ulang kunjungan ini
      try {
        const r = await (await fetch(`${c.url}?t=${c.t}&get`, { cache: 'no-store' })).json();
        if (r && r.ok && String(r.id) === id && r.kini - r.w > 3000) await fetch(`${c.url}?t=${c.t}&set=0`, { cache: 'no-store' });
      } catch (e) { console.warn('[TTD] relay lepas gagal', e && e.message); }
      return;
    }
    balas({ ok: false });
  })();
  return true;
});

async function tandaiPembaruan() {
  const p = await cekPembaruan();
  chrome.action.setBadgeText({ text: p ? 'BARU' : '' });
  if (p) { chrome.action.setBadgeBackgroundColor({ color: '#0F766E' }); chrome.action.setTitle({ title: 'Versi ' + p.versi + ' tersedia: buka pengaturan ekstensi' }); }
}
chrome.runtime.onStartup.addListener(tandaiPembaruan);
chrome.runtime.onInstalled.addListener(tandaiPembaruan);
