/* Surat PDF dari C-CARE digambar ke kanvas lalu dicetak (dialog Cetak Windows), tanpa disimpan ke folder Unduhan.
 * Dipanggil proses utama: window.__cetak(base64) → selesai bila semua halaman tergambar. */
pdfjsLib.GlobalWorkerOptions.workerSrc = 'pdf.worker.min.js';   // worker dimuat di halaman (file:// tidak bisa membuat Worker)
const PT_KE_PX = 96 / 72, MUTU = 2;   // kanvas 2× agar tulisan tajam di kertas
window.__cetak = async (b64) => {
  const data = Uint8Array.from(atob(b64), (c) => c.charCodeAt(0));
  const pdf = await pdfjsLib.getDocument({ data, isEvalSupported: false }).promise;
  let ukuran = null;
  for (let i = 1; i <= pdf.numPages; i++) {
    const hal = await pdf.getPage(i), vp1 = hal.getViewport({ scale: 1 });
    if (!ukuran) ukuran = vp1;
    const vp = hal.getViewport({ scale: PT_KE_PX * MUTU }), kv = document.createElement('canvas');
    kv.width = Math.ceil(vp.width); kv.height = Math.ceil(vp.height);
    kv.style.width = (vp1.width * PT_KE_PX) + 'px'; kv.style.height = (vp1.height * PT_KE_PX) + 'px';
    await hal.render({ canvasContext: kv.getContext('2d'), viewport: vp }).promise;
    document.body.appendChild(kv);
  }
  // ukuran kertas mengikuti halaman pertama surat (mis. A5/A4), tanpa margin tambahan
  document.getElementById('halaman').textContent = `@page{size:${ukuran.width}pt ${ukuran.height}pt;margin:0}`;
  document.getElementById('ket').textContent = `${pdf.numPages} halaman siap dicetak.`;
  return pdf.numPages;
};
