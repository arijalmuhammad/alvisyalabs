/* Scan Jasa C-CARE — pasang pembaruan dari file ZIP langsung dari halaman Pengaturan.
 * Cara kerja: folder ekstensi dihubungkan sekali (File System Access API, izin baca-tulis),
 * ZIP dibaca di browser (tanpa unggah ke mana pun), isinya ditulis menimpa folder itu, lalu ekstensi dimuat ulang.
 * Pengaman: ZIP wajib berisi manifest.json dengan kunci (key) & nama yang sama, dan versi lebih baru.
 */

/* ---------- pembaca ZIP (store & deflate) ---------- */
async function bacaZip(buf) {
  const dv = new DataView(buf), u8 = new Uint8Array(buf), dec = new TextDecoder();
  let eocd = -1;
  for (let i = buf.byteLength - 22; i >= Math.max(0, buf.byteLength - 66000); i--) if (dv.getUint32(i, true) === 0x06054b50) { eocd = i; break; }
  if (eocd < 0) throw new Error('Bukan file ZIP yang valid.');
  const jumlah = dv.getUint16(eocd + 10, true);
  let p = dv.getUint32(eocd + 16, true);
  const out = [];
  for (let n = 0; n < jumlah; n++) {
    if (dv.getUint32(p, true) !== 0x02014b50) throw new Error('Struktur ZIP rusak.');
    const metode = dv.getUint16(p + 10, true), ukuranZ = dv.getUint32(p + 20, true);
    const nl = dv.getUint16(p + 28, true), el = dv.getUint16(p + 30, true), kl = dv.getUint16(p + 32, true);
    const lokal = dv.getUint32(p + 42, true);
    const nama = dec.decode(u8.subarray(p + 46, p + 46 + nl));
    p += 46 + nl + el + kl;
    if (nama.endsWith('/')) continue;
    const mulai = lokal + 30 + dv.getUint16(lokal + 26, true) + dv.getUint16(lokal + 28, true);
    const mentah = u8.slice(mulai, mulai + ukuranZ);
    let data;
    if (metode === 0) data = mentah;
    else if (metode === 8) data = new Uint8Array(await new Response(new Blob([mentah]).stream().pipeThrough(new DecompressionStream('deflate-raw'))).arrayBuffer());
    else throw new Error('Metode kompresi ZIP tidak didukung: ' + metode);
    out.push({ nama, data });
  }
  return out;
}
/** buang folder induk bersama (mis. "scan-jasa-ccare/"), tolak jalur aneh */
function rapikan(berkas) {
  const akar = berkas.length && berkas.every(b => b.nama.includes('/')) ? berkas[0].nama.split('/')[0] + '/' : '';
  const hasil = berkas.map(b => ({ nama: akar && b.nama.startsWith(akar) ? b.nama.slice(akar.length) : b.nama, data: b.data }))
    .filter(b => b.nama && !/(^|\/)(__MACOSX|\.DS_Store)/.test(b.nama));
  hasil.forEach(b => { if (b.nama.includes('..') || b.nama.startsWith('/') || !/^[\w .\-\/]+$/.test(b.nama)) throw new Error('Nama file tidak aman di ZIP: ' + b.nama); });
  return hasil;
}
function bandingVersi(a, b) { const x = a.split('.').map(Number), y = b.split('.').map(Number); for (let i = 0; i < 4; i++) { const d = (x[i] || 0) - (y[i] || 0); if (d) return d; } return 0; }
/** periksa isi ZIP terhadap ekstensi yang terpasang */
function periksaPaket(berkas, sekarang) {
  const m = berkas.find(b => b.nama === 'manifest.json');
  if (!m) throw new Error('ZIP tidak berisi manifest.json — bukan paket Scan Jasa C-CARE.');
  const baru = JSON.parse(new TextDecoder().decode(m.data));
  const NAMA = ['Scan Jasa C-CARE', 'Alvisya Dokter'];                // nama lama & baru (v3.2.0) dianggap ekstensi yang sama
  if (!(baru.name === sekarang.name || (NAMA.includes(baru.name) && NAMA.includes(sekarang.name))) || baru.key !== sekarang.key) throw new Error('ZIP ini bukan untuk ekstensi Alvisya Dokter yang terpasang.');
  const rilis = berkas.find(b => b.nama === 'CATATAN-RILIS.txt');
  const catatan = rilis ? new TextDecoder().decode(rilis.data).split(/\n(?=v\d)/)[0].trim() : '';
  return { versi: baru.version, beda: bandingVersi(baru.version, sekarang.version), catatan };
}

/* ---------- simpan pegangan folder (IndexedDB) ---------- */
function db() { return new Promise((ok, gagal) => { const r = indexedDB.open('scan-jasa', 1); r.onupgradeneeded = () => r.result.createObjectStore('kv'); r.onsuccess = () => ok(r.result); r.onerror = () => gagal(r.error); }); }
async function simpanFolder(h) { const d = await db(); await new Promise(ok => { const t = d.transaction('kv', 'readwrite'); t.objectStore('kv').put(h, 'folder'); t.oncomplete = ok; }); }
async function ambilFolder() { const d = await db(); return new Promise(ok => { const r = d.transaction('kv').objectStore('kv').get('folder'); r.onsuccess = () => ok(r.result || null); r.onerror = () => ok(null); }); }
async function izinTulis(h, minta) {
  if (!h) return false;
  if (await h.queryPermission({ mode: 'readwrite' }) === 'granted') return true;
  return minta ? (await h.requestPermission({ mode: 'readwrite' })) === 'granted' : false;
}
/** pastikan folder yang dipilih memang folder ekstensi ini */
async function cocokFolder(h, sekarang) {
  try {
    const f = await (await h.getFileHandle('manifest.json')).getFile();
    const m = JSON.parse(await f.text());
    return m.key === sekarang.key && m.name === sekarang.name;
  } catch (e) { return false; }
}
async function tulisBerkas(akar, berkas, lapor) {
  for (const [i, b] of berkas.entries()) {
    const bagian = b.nama.split('/'); let dir = akar;
    for (const s of bagian.slice(0, -1)) dir = await dir.getDirectoryHandle(s, { create: true });
    const w = await (await dir.getFileHandle(bagian[bagian.length - 1], { create: true })).createWritable();
    await w.write(b.data); await w.close();
    lapor(i + 1, berkas.length);
  }
}

/* ---------- antarmuka di halaman Pengaturan ---------- */
if (typeof document !== 'undefined' && document.getElementById('pbFolder')) {
  const $ = id => document.getElementById(id);
  const sekarang = chrome.runtime.getManifest();
  let folder = null, paket = null;
  const lapor = (t, k = '') => { $('pbPesan').textContent = t; $('pbPesan').className = 'pesan ' + k; };

  async function tampilFolder() {
    folder = await ambilFolder();
    const ok = folder && await izinTulis(folder, false);
    $('pbFolderNama').textContent = folder ? folder.name + (ok ? '' : ' (perlu izin ulang saat memasang)') : 'Belum dihubungkan';
    $('pbFolderNama').className = folder ? '' : 'awas';
    $('pbFolder').textContent = folder ? 'Ganti folder' : 'Hubungkan folder';
  }
  $('pbFolder').onclick = async () => {
    try {
      let h = await showDirectoryPicker({ id: 'scan-jasa-ccare', mode: 'readwrite' });
      // boleh memilih folder induk (mis. "Scan Jasa C-Care") — cari subfolder scan-jasa-ccare di dalamnya
      if (!await cocokFolder(h, sekarang)) { try { const sub = await h.getDirectoryHandle('scan-jasa-ccare'); if (await cocokFolder(sub, sekarang)) h = sub; } catch (e) {} }
      if (!await cocokFolder(h, sekarang)) return lapor('Folder itu bukan folder ekstensi Scan Jasa C-CARE yang terpasang. Pilih folder scan-jasa-ccare yang dulu dimuat di chrome://extensions.', 'galat');
      await simpanFolder(h); await tampilFolder(); lapor('Folder terhubung. Sekarang pilih file ZIP update.', 'ok');
    } catch (e) { if (e.name !== 'AbortError') lapor('Gagal: ' + e.message, 'galat'); }
  };

  async function muatZip(file) {
    paket = null; $('pbPasang').disabled = true; $('pbInfo').hidden = true;
    try {
      if (!/\.zip$/i.test(file.name)) throw new Error('Pilih file .zip.');
      const berkas = rapikan(await bacaZip(await file.arrayBuffer()));
      const cek = periksaPaket(berkas, sekarang);
      paket = { berkas, ...cek, file: file.name };
      $('pbInfo').hidden = false;
      $('pbVersi').textContent = `v${sekarang.version} → v${cek.versi} · ${berkas.length} file`;
      $('pbCatatan').textContent = cek.catatan;
      if (cek.beda < 0) lapor(`ZIP ini versi lebih lama (v${cek.versi}). Tetap bisa dipasang bila memang ingin kembali ke versi itu.`, 'awas');
      else if (cek.beda === 0) lapor('Versi ZIP sama dengan yang terpasang. Pasang ulang hanya bila ada file yang rusak.', 'awas');
      else lapor('Paket valid. Tekan Pasang pembaruan.', 'ok');
      $('pbPasang').disabled = false;
    } catch (e) { tulisLog('awas', 'pembaruan', `ZIP ${file.name} ditolak: ${e.message}`); lapor(e.message, 'galat'); }
  }
  $('pbPilih').onclick = () => $('pbFile').click();
  $('pbFile').onchange = () => { if ($('pbFile').files[0]) muatZip($('pbFile').files[0]); $('pbFile').value = ''; };
  const zona = $('pbZona');
  zona.ondragover = e => { e.preventDefault(); zona.classList.add('aktif'); };
  zona.ondragleave = () => zona.classList.remove('aktif');
  zona.ondrop = e => { e.preventDefault(); zona.classList.remove('aktif'); const f = e.dataTransfer.files[0]; if (f) muatZip(f); };

  $('pbPasang').onclick = async () => {
    if (!paket) return;
    try {
      if (!folder) { lapor('Hubungkan folder ekstensi dulu (langkah 1).', 'galat'); return; }
      if (!await izinTulis(folder, true)) { lapor('Izin menulis ke folder ditolak. Klik Pasang lagi lalu pilih Izinkan.', 'galat'); return; }
      if (!await cocokFolder(folder, sekarang)) { lapor('Folder terhubung bukan lagi folder ekstensi ini. Hubungkan ulang.', 'galat'); return; }
      $('pbPasang').disabled = true;
      await tulisBerkas(folder, paket.berkas, (i, n) => lapor(`Memasang ${i}/${n} file…`));
      await tulisLog('info', 'pembaruan', `ZIP ${paket.file}: ${paket.berkas.length} file ditulis (v${sekarang.version} → v${paket.versi})`);
      lapor(`v${paket.versi} terpasang. Memuat ulang ekstensi…`, 'ok');
      setTimeout(() => chrome.runtime.reload(), 600);
    } catch (e) { tulisLog('galat', 'pembaruan', 'Gagal memasang ZIP: ' + e.message, e.stack); lapor('Gagal memasang: ' + e.message + '. File lama mungkin sebagian tertimpa — ulangi Pasang.', 'galat'); $('pbPasang').disabled = false; }
  };
  tampilFolder();
}

if (typeof module !== 'undefined') module.exports = { bacaZip, rapikan, periksaPaket, bandingVersi };
