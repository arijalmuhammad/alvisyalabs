/* Cari pengaturan (v4.9): menyaring kartu dan baris di SEMUA tab; kosongkan / Esc = kembali ke tab terakhir. Tidak mengubah isian. */
(() => {
  const inp = document.getElementById('cari'); if (!inp) return;
  const hasil = document.getElementById('hasilCari'), kosong = document.getElementById('kosongCari');
  const normal = t => (t || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
  function saring() {
    const q = normal(inp.value.trim()), kata = q.split(/\s+/).filter(Boolean);
    document.body.classList.toggle('mencari', kata.length > 0);
    document.querySelectorAll('.tak-cocok').forEach(e => e.classList.remove('tak-cocok'));
    if (!kata.length) { hasil.textContent = ''; kosong.hidden = true; return; }
    const cocok = el => { const t = normal(el.textContent); return kata.every(k => t.includes(k)); };
    let n = 0;
    document.querySelectorAll('main > section').forEach(sec => {
      let adaDiSeksi = false;
      sec.querySelectorAll('.kartu').forEach(k => {
        const kepala = k.querySelector('.kk');
        if (kepala && cocok(kepala)) { adaDiSeksi = true; n++; return; }      // judul kartu cocok → seluruh kartu tampil
        const baris = [...k.querySelectorAll('.baris')];
        let ada = false;
        baris.forEach(b => { if (cocok(b)) { ada = true; n++; } else b.classList.add('tak-cocok'); });
        const ki = k.querySelector('.ki');
        if (ki) { if (cocok(ki)) { ada = true; n++; } else ki.classList.add('tak-cocok'); }
        if (!ada && !baris.length && !ki && cocok(k)) { ada = true; n++; }
        if (!ada) k.classList.add('tak-cocok'); else adaDiSeksi = true;
      });
      if (!adaDiSeksi) sec.classList.add('tak-cocok');
    });
    hasil.textContent = n ? n + ' cocok' : '';
    kosong.hidden = n > 0;
  }
  inp.addEventListener('input', saring);
  inp.addEventListener('keydown', e => { if (e.key === 'Escape' && inp.value) { inp.value = ''; saring(); } });
  document.addEventListener('keydown', e => { if (e.key === '/' && document.activeElement !== inp && !/input|textarea|select/i.test(document.activeElement.tagName)) { e.preventDefault(); inp.focus(); } });
})();
