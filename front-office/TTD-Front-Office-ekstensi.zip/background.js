/* TTD Front Office — background: hanya meneruskan permintaan relay tanda tangan (Apps Script relay bawaan, token unik per PC). */
const RELAY_URL = 'https://script.google.com/macros/s/AKfycbzfszQuJjcDD71vzMB9xGWTu40OIRn88PUDNywQpz5IOUcdR21M5lqhHz4W1FugC8Xx/exec';
const POLA_URL = /^https:\/\/script\.google\.com\/macros\/s\/[\w-]+\/exec$/, POLA_T = /^[\w-]{20,64}$/;
const tokenBaru = () => { const a = new Uint8Array(18); crypto.getRandomValues(a); return btoa(String.fromCharCode(...a)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); };

/* Token unik per PC: tablet FO ini tidak ikut menerima pasien dari PC/tablet lain. */
async function pastikanSetelan() {
  const c = (await chrome.storage.local.get('ttdTablet')).ttdTablet || {};
  if (c.peran === 'pc' && POLA_URL.test(c.url || '') && POLA_T.test(c.t || '')) return false;
  await chrome.storage.local.set({ ttdTablet: { peran: 'pc', url: RELAY_URL, t: tokenBaru() } });
  return true;
}
chrome.runtime.onInstalled.addListener(async d => {
  await pastikanSetelan();
  if (d.reason === 'install') chrome.runtime.openOptionsPage();
});
chrome.runtime.onStartup.addListener(pastikanSetelan);
chrome.action.onClicked.addListener(() => chrome.runtime.openOptionsPage());

chrome.runtime.onMessage.addListener((m, _s, balas) => {
  (async () => {
    if (m.aksi === 'relayTtd') {   // hanya ke URL Apps Script /exec, hanya ?t=…&set=angka atau &get
      if (!/^https:\/\/script\.google\.com\/macros\/s\/[\w-]+\/exec\?t=[\w-]{20,64}&(set=\d{1,10}|get)$/.test(String(m.url))) return balas({ ok: false, galat: 'url' });
      try { const r = await fetch(m.url, { cache: 'no-store' }); return balas(await r.json()); } catch (e) { return balas({ ok: false, galat: 'jaringan' }); }
    }
    if (m.aksi === 'bukaPengaturan') { chrome.runtime.openOptionsPage(); return balas({ ok: true }); }
    balas({ ok: false });
  })();
  return true;
});
